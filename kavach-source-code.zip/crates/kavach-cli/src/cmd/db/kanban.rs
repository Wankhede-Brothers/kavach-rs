use std::io::{self, Write as _};

/// Returns true when `title` starts with `DONE` followed by any non-alphanumeric char.
/// Matches: "DONE: foo", "DONE foo", "DONE-foo", "DONE_foo", etc.
/// Does NOT match "DONEfoo" (no separator) or "done: foo" (case-sensitive).
pub(crate) fn is_done_title(title: &str) -> bool {
    match title.strip_prefix("DONE") {
        Some(rest) => rest.starts_with(|c: char| !c.is_alphanumeric()),
        None => false,
    }
}

/// Close a roadmap entry by key: prepend "DONE:" to title, sync kanban_cards.
pub fn close(project_slug: &str, key: &str) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    close_with_conn(&conn, project.id, key)
}

fn close_with_conn(conn: &rusqlite::Connection, project_id: i64, key: &str) -> i32 {
    let entry = match kavach_db::memory::get_by_key(conn, project_id, "roadmap", key) {
        Ok(e) => e,
        Err(kavach_db::DbError::EntryNotFound { .. }) => {
            let _ = writeln!(io::stderr().lock(), "error: no roadmap entry with key: {key}");
            return 1;
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };

    let done_title = if is_done_title(&entry.title) {
        entry.title.clone()
    } else {
        format!("DONE: {}", entry.title)
    };

    let params = kavach_db::memory::UpsertParams {
        project_id,
        category: "roadmap",
        entry_key: key,
        title: &done_title,
        content: &entry.content,
        tags: None,
        ttl_days: None,
        source: None,
    };
    if let Err(e) = kavach_db::memory::upsert(conn, &params) {
        let _ = writeln!(io::stderr().lock(), "error: {e}");
        return 1;
    }

    super::write::sync_roadmap_to_kanban_pub(conn, project_id, key, &done_title);
    let _ = writeln!(io::stdout().lock(), "closed [roadmap] {key} — {done_title}");
    0
}

pub fn run(project_slug: &str) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };

    // Authoritative source: roadmap entries not yet marked DONE.
    // kavach db write uses "DONE:" title prefix to signal completion.
    // kanban_cards holds auto-projected intent noise — not used here.
    let roadmap = match kavach_db::memory::list_by_project(&conn, project.id, Some("roadmap")) {
        Ok(entries) => entries,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };

    let open: Vec<_> = roadmap
        .iter()
        .filter(|e| !is_done_title(&e.title))
        .collect();

    let out = io::stdout();
    let mut lock = out.lock();

    if open.is_empty() {
        let _ = writeln!(lock, "kanban: no open roadmap items for {project_slug}");
        return 0;
    }

    let _ = writeln!(lock, "[OPEN]");
    for entry in &open {
        let _ = writeln!(lock, "  {} — {}", entry.entry_key, entry.title);
    }
    0
}

#[cfg(test)]
mod tests {
    use super::*;
    use kavach_db::{connection::open_memory, migrate::run_migrations, memory, projects};

    type R = Result<(), Box<dyn std::error::Error>>;

    #[test]
    fn should_return_error_when_project_not_found() {
        let result = run("nonexistent-project-slug-xyz");
        assert_eq!(result, 1);
    }

    #[test]
    fn should_return_zero_for_existing_project() {
        let result = run("kavach-rs");
        assert_eq!(result, 0);
    }

    #[test]
    fn done_prefix_filter_logic() {
        assert!(is_done_title("DONE: task"));
        assert!(is_done_title("DONE task"));
        assert!(is_done_title("DONE-task"));
        assert!(is_done_title("DONE_task"));
        assert!(!is_done_title("DONEtask"));
        assert!(!is_done_title("done: task"));
        assert!(!is_done_title("open task"));
        assert!(!is_done_title(""));
    }

    fn seed(conn: &rusqlite::Connection, pid: i64, key: &str, title: &str) -> R {
        memory::upsert(conn, &memory::UpsertParams {
            project_id: pid,
            category: "roadmap",
            entry_key: key,
            title,
            content: "file: src/foo.rs",
            tags: None,
            ttl_days: None,
            source: None,
        })?;
        Ok(())
    }

    #[test]
    fn close_marks_open_entry_as_done() -> R {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "ct1", "CT1")?;
        let proj = projects::get_by_slug(&conn, "ct1")?;
        seed(&conn, proj.id, "task-a", "Build the thing")?;
        assert_eq!(close_with_conn(&conn, proj.id, "task-a"), 0);
        let entry = memory::get_by_key(&conn, proj.id, "roadmap", "task-a")?;
        assert!(entry.title.starts_with("DONE:"), "got: {}", entry.title);
        Ok(())
    }

    #[test]
    fn close_is_idempotent_when_already_done() -> R {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "ct2", "CT2")?;
        let proj = projects::get_by_slug(&conn, "ct2")?;
        seed(&conn, proj.id, "task-b", "DONE: Already closed")?;
        assert_eq!(close_with_conn(&conn, proj.id, "task-b"), 0);
        let entry = memory::get_by_key(&conn, proj.id, "roadmap", "task-b")?;
        assert_eq!(entry.title, "DONE: Already closed");
        Ok(())
    }

    #[test]
    fn close_returns_error_for_unknown_key() -> R {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "ct3", "CT3")?;
        let proj = projects::get_by_slug(&conn, "ct3")?;
        assert_eq!(close_with_conn(&conn, proj.id, "no-such-key"), 1);
        Ok(())
    }
}
