use std::io::{self, Write as _};

pub fn run_project(abs_path: &str) -> i32 {
    if !abs_path.starts_with('/') {
        let _ = writeln!(io::stderr().lock(), "error: path must be absolute: {abs_path}");
        return 1;
    }
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    match kavach_db::projects::find_by_path(&conn, abs_path) {
        Ok(Some(p)) => {
            let _ = writeln!(
                io::stdout().lock(),
                "{} (id={}, path={})",
                p.slug, p.id, p.workdir.as_deref().unwrap_or("?"),
            );
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stderr().lock(), "no project matches: {abs_path}");
            1
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}

pub fn run_part(abs_path: &str) -> i32 {
    if !abs_path.starts_with('/') {
        let _ = writeln!(io::stderr().lock(), "error: path must be absolute: {abs_path}");
        return 1;
    }
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    match kavach_db::parts::find_by_path(&conn, abs_path) {
        Ok(Some(p)) => {
            let _ = writeln!(
                io::stdout().lock(),
                "{} ({}, id={}, path={})",
                p.part_name, p.part_type, p.id, p.part_path,
            );
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stderr().lock(), "no part matches: {abs_path}");
            1
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
