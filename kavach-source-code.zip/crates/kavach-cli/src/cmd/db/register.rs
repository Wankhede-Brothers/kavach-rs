use std::io::{self, Write as _};

pub fn run(slug: &str, abs_path: &str, stack: Option<&str>) -> i32 {
    if !abs_path.starts_with('/') {
        let _ = writeln!(io::stderr().lock(), "error: path must be absolute: {abs_path}");
        return 1;
    }
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    match kavach_db::projects::register(&conn, slug, slug, abs_path, stack, None) {
        Ok(id) => {
            let _ = writeln!(
                io::stdout().lock(),
                "registered project: {slug} (id={id}) at {abs_path}"
            );
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
