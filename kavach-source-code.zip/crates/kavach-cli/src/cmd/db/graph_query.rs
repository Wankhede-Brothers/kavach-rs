use std::io::{self, Write as _};

pub fn run(entity_type: Option<&str>, name: Option<&str>, limit: usize) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db open failed: {e}");
            return 1;
        }
    };
    if let Some(n) = name {
        let etype = match entity_type {
            Some(t) => t,
            None => "skill",
        };
        let entity = match kavach_db::graph_entity::find_entity(&conn, etype, n) {
            Ok(e) => e,
            Err(_) => {
                let _ = writeln!(io::stderr().lock(), "entity not found: {etype}/{n}");
                return 1;
            }
        };
        let _ = writeln!(io::stdout().lock(), "[{etype}] {n} (id={})", entity.id);
        match kavach_db::graph::get_related(&conn, entity.id, 200) {
            Ok(edges) => {
                if edges.is_empty() {
                    let _ = writeln!(io::stdout().lock(), "  (no edges)");
                } else {
                    for (rel, target) in &edges {
                        let _ = writeln!(
                            io::stdout().lock(),
                            "  ──{}──► [{}] {}",
                            rel.rel_type, target.entity_type, target.name
                        );
                    }
                }
            }
            Err(e) => {
                let _ = writeln!(io::stderr().lock(), "graph query failed: {e}");
                return 1;
            }
        }
        return 0;
    }
    match kavach_db::graph_entity::list_entities(&conn, entity_type) {
        Ok(entities) => {
            for e in entities.iter().take(limit) {
                match &e.properties {
                    Some(p) if !p.is_empty() => {
                        let _ = writeln!(io::stdout().lock(), "[{}] {} (id={}) {}", e.entity_type, e.name, e.id, p);
                    }
                    Some(_) | None => {
                        let _ = writeln!(io::stdout().lock(), "[{}] {} (id={})", e.entity_type, e.name, e.id);
                    }
                }
            }
            let shown = entities.len().min(limit);
            let _ = writeln!(io::stdout().lock(), "--- {shown}/{} entities shown ---", entities.len());
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "graph list failed: {e}");
            1
        }
    }
}
