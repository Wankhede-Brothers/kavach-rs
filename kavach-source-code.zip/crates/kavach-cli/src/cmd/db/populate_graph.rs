use std::io::{self, Write as _};

pub fn run() -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db open failed: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "db migrate failed: {e}");
        return 1;
    }
    match kavach_db::graph_populate::populate_all(&conn) {
        Ok(stats) => {
            let _ = writeln!(
                io::stdout().lock(),
                "graph populated: {} projects, {} parts, {} sessions, {} memory, {} files, {} event_types, {} enforcement_nodes, {} memory_dag",
                stats.projects, stats.parts, stats.sessions,
                stats.memory, stats.files, stats.event_types, stats.enforcement_nodes, stats.memory_dag,
            );
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "populate-graph failed: {e}");
            1
        }
    }
}
