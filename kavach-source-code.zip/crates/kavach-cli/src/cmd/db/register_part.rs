use std::io::{self, Write as _};

pub fn run(project_slug: &str, name: &str, abs_path: &str, part_type: &str) -> i32 {
    if !abs_path.starts_with('/') {
        let _ = writeln!(io::stderr().lock(), "error: path must be absolute: {abs_path}");
        return 1;
    }
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    match kavach_db::parts::upsert(&conn, project.id, name, abs_path, part_type, None, None) {
        Ok(id) => {
            let _ = writeln!(
                io::stdout().lock(),
                "registered part: {name} ({part_type}) id={id} at {abs_path}"
            );
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
