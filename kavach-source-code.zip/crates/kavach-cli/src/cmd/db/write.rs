use std::io::{self, Write as _};

const ROADMAP_CATEGORY: &str = "roadmap";
const KANBAN_PRIORITY_P1: &str = "P1";
const KANBAN_STATUS_DONE: &str = "done";

pub fn run(
    project_slug: &str,
    category: &str,
    key: &str,
    title: &str,
    content: Option<&str>,
) -> i32 {
    // Use --content flag value. Warn if empty — title-only entries lose detail.
    // NEVER block on stdin — background processes hang forever.
    let body = match content {
        Some(c) => c.to_string(),
        None => {
            let _ = writeln!(
                io::stderr().lock(),
                "warning: no --content provided. Only the title will be stored. \
                 Use --content \"...\" to persist plan details, decisions, or context."
            );
            String::new()
        }
    };
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(kavach_db::DbError::ProjectNotFound { .. }) => {
            let _ = writeln!(io::stderr().lock(), "error: project not found: {project_slug}");
            suggest_projects(&conn, project_slug);
            return 1;
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    let params = kavach_db::memory::UpsertParams {
        project_id: project.id,
        category,
        entry_key: key,
        title,
        content: &body,
        tags: None,
        ttl_days: None,
        source: None,
    };
    match kavach_db::memory::upsert(&conn, &params) {
        Ok(id) => {
            if category == ROADMAP_CATEGORY {
                sync_roadmap_to_kanban_pub(&conn, project.id, key, title);
            }
            let _ = writeln!(
                io::stdout().lock(),
                "wrote [{category}] {key} — {title} (id={id})"
            );
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}

/// Bridge a roadmap write to kanban_cards so `kavach db kanban` shows project work.
/// Fire-and-forget — never fails the write if kanban sync errors.
pub(crate) fn sync_roadmap_to_kanban_pub(conn: &rusqlite::Connection, project_id: i64, key: &str, title: &str) {
    let is_done = super::kanban::is_done_title(title);
    // Look up existing card by description (stores the roadmap key as a stable identifier).
    let existing_id: Option<i64> = match conn.query_row(
        "SELECT id FROM kanban_cards WHERE project_id = ?1 AND description = ?2 LIMIT 1",
        rusqlite::params![project_id, key],
        |r| r.get(0),
    ) {
        Ok(id) => Some(id),
        Err(rusqlite::Error::QueryReturnedNoRows) => None,
        // Unexpected DB error: degrade silently — never block the write.
        Err(_) => return,
    };
    match existing_id {
        Some(card_id) => {
            if is_done {
                let _ = kavach_db::kanban::update_status(conn, card_id, KANBAN_STATUS_DONE);
            }
        }
        None => {
            if !is_done {
                // Create card, then stamp description with key for future lookups.
                if let Ok(card_id) = kavach_db::kanban::create(conn, project_id, title, KANBAN_PRIORITY_P1) {
                    let _ = conn.execute(
                        "UPDATE kanban_cards SET description = ?2 WHERE id = ?1",
                        rusqlite::params![card_id, key],
                    );
                }
            }
        }
    }
}

/// List registered projects and suggest close matches when slug not found.
fn suggest_projects(conn: &rusqlite::Connection, attempted: &str) {
    let mut err = io::stderr().lock();
    match kavach_db::projects::list_all(conn) {
        Ok(projects) if projects.is_empty() => {
            let _ = writeln!(err, "hint: no projects registered yet");
            let _ = writeln!(err, "  register with: kavach db register --slug <slug> --path <abs_path>");
        }
        Ok(projects) => {
            let attempted_lower = attempted.to_lowercase();
            let close: Vec<&str> = projects
                .iter()
                .filter(|p| {
                    let slug = p.slug.to_lowercase();
                    slug.contains(&attempted_lower)
                        || attempted_lower.contains(&slug)
                        || common_prefix_len(&slug, &attempted_lower) >= 3
                })
                .map(|p| p.slug.as_str())
                .collect();
            if close.is_empty() {
                let all: Vec<&str> = projects.iter().map(|p| p.slug.as_str()).collect();
                let _ = writeln!(err, "registered projects: {}", all.join(", "));
            } else {
                let _ = writeln!(err, "did you mean: {}?", close.join(", "));
            }
            let _ = writeln!(err, "  list all: kavach db list-projects");
            let _ = writeln!(err, "  register: kavach db register --slug <slug> --path <abs_path>");
        }
        Err(_) => {
            let _ = writeln!(err, "hint: run 'kavach db list-projects' to see registered projects");
        }
    }
}

fn common_prefix_len(a: &str, b: &str) -> usize {
    a.chars().zip(b.chars()).take_while(|(x, y)| x == y).count()
}

#[cfg(test)]
mod tests {
    use kavach_db::{connection::open_memory, migrate::run_migrations, projects, kanban};

    type TestResult = Result<(), Box<dyn std::error::Error>>;

    fn setup() -> Result<rusqlite::Connection, Box<dyn std::error::Error>> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "test-proj", "Test Project")?;
        Ok(conn)
    }

    #[test]
    fn should_create_kanban_card_when_roadmap_written() -> TestResult {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test-proj")?;
        super::sync_roadmap_to_kanban_pub(&conn, p.id, "phase-1", "Implement auth");
        let cards = kanban::list_by_project(&conn, p.id, None)?;
        assert_eq!(cards.len(), 1);
        match cards.first() {
            Some(card) => {
                assert_eq!(card.title, "Implement auth");
                assert_eq!(card.description.as_deref(), Some("phase-1"));
            }
            None => return Err("expected one card".into()),
        }
        Ok(())
    }

    #[test]
    fn should_mark_card_done_when_title_prefixed_with_done() -> TestResult {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test-proj")?;
        super::sync_roadmap_to_kanban_pub(&conn, p.id, "phase-1", "Implement auth");
        super::sync_roadmap_to_kanban_pub(&conn, p.id, "phase-1", "DONE Implement auth");
        let done = kanban::list_by_project(&conn, p.id, Some("done"))?;
        assert_eq!(done.len(), 1);
        Ok(())
    }

    #[test]
    fn should_not_create_card_when_title_prefixed_with_done() -> TestResult {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test-proj")?;
        super::sync_roadmap_to_kanban_pub(&conn, p.id, "phase-2", "DONE Already done task");
        let cards = kanban::list_by_project(&conn, p.id, None)?;
        assert!(cards.is_empty());
        Ok(())
    }

    #[test]
    fn should_not_duplicate_card_when_roadmap_key_written_twice() -> TestResult {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test-proj")?;
        super::sync_roadmap_to_kanban_pub(&conn, p.id, "phase-3", "Add payments");
        super::sync_roadmap_to_kanban_pub(&conn, p.id, "phase-3", "Add payments updated");
        let cards = kanban::list_by_project(&conn, p.id, None)?;
        assert_eq!(cards.len(), 1);
        Ok(())
    }
}
