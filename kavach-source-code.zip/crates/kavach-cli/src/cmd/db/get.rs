use std::io::{self, Write as _};

pub fn run(project_slug: &str, category: &str, key: &str, full: bool) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    match kavach_db::memory::get(&conn, project.id, category, key) {
        Ok(entry) => {
            let out = io::stdout();
            let mut lock = out.lock();
            let _ = writeln!(lock, "[{}] {} — {}", entry.category, entry.entry_key, entry.title);
            let _ = writeln!(lock, "status: {} | access: {} | updated: {}",
                entry.status, entry.access_count, entry.updated_at);
            if full {
                print_full_metadata(&mut lock, &entry);
            }
            if !entry.content.is_empty() {
                let _ = writeln!(lock, "---");
                let _ = writeln!(lock, "{}", entry.content);
            }
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}

fn print_full_metadata(w: &mut impl io::Write, e: &kavach_db::memory::MemoryEntry) {
    let _ = writeln!(w, "created: {} | id: {}", e.created_at, e.id);
    if let Some(ref tags) = e.tags {
        let _ = writeln!(w, "tags: {tags}");
    }
    if let Some(ttl) = e.ttl_days {
        let _ = writeln!(w, "ttl: {ttl} days");
    }
    if let Some(ref src) = e.source {
        let _ = writeln!(w, "source: {src}");
    }
    if let Some(ref exp) = e.expires_at {
        let _ = writeln!(w, "expires: {exp}");
    }
    if let Some(ref ver) = e.verified_at {
        let _ = writeln!(w, "verified: {ver}");
    }
    if let Some(ref acc) = e.accessed_at {
        let _ = writeln!(w, "last_access: {acc}");
    }
    if let Some(decay) = e.decay_score {
        let _ = writeln!(w, "decay: {decay:.2}");
    }
}
