use std::collections::HashSet;
use std::io::{self, Write as _};

use super::schema::{connect, list_foreign_keys, list_tables};

pub fn run(dsn: &str) -> i32 {
    let mut client = match connect(dsn) {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "connect error: {e}");
            return 1;
        }
    };
    let tables = match list_tables(&mut client) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "list tables failed: {e}");
            return 1;
        }
    };
    let fks = match list_foreign_keys(&mut client) {
        Ok(f) => f,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "list fks failed: {e}");
            return 1;
        }
    };
    let mut referenced: HashSet<String> = HashSet::new();
    let mut referencing: HashSet<String> = HashSet::new();
    for fk in &fks {
        referenced.insert(format!("{}.{}", fk.parent_schema, fk.parent_table));
        referencing.insert(format!("{}.{}", fk.child_schema, fk.child_table));
    }
    let out = io::stdout();
    let mut w = out.lock();
    let _ = writeln!(w, "# Isolated tables — no FK in OR out\n");
    let mut isolated_count = 0usize;
    let mut root_count = 0usize;
    for t in &tables {
        let key = format!("{}.{}", t.schema, t.name);
        let is_ref = referenced.contains(&key);
        let is_ing = referencing.contains(&key);
        if !is_ref && !is_ing {
            let _ = writeln!(w, "[ISOLATED] {key}");
            isolated_count += 1;
        } else if is_ref && !is_ing {
            let _ = writeln!(w, "[ROOT]     {key} (referenced by children, no parents)");
            root_count += 1;
        }
    }
    let _ = writeln!(w, "\nsummary: {isolated_count} isolated, {root_count} root, {} total tables", tables.len());
    0
}
