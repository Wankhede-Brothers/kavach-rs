use std::io::{self, Write as _};
use std::path::Path;

use sha2::{Digest, Sha384};

use super::schema::connect;

/// Update `_sqlx_migrations.checksum` for one version to match the sha384 of the
/// current file on disk. Correct fix for sqlx `migration X was previously applied
/// but has been modified` when the file content change is intentional and the
/// migration is already idempotent (CREATE TABLE IF NOT EXISTS, ALTER TABLE IF
/// NOT EXISTS). Does NOT re-execute the migration — only updates the stored
/// checksum so future `sqlx migrate run` invocations pass the integrity check.
pub fn run(dsn: &str, version: i64, file: &str) -> i32 {
    let path = Path::new(file);
    let bytes = match std::fs::read(path) {
        Ok(b) => b,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "read {file} failed: {e}");
            return 1;
        }
    };
    let hex = sha384_hex(&bytes);
    let mut client = match connect(dsn) {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "connect error: {e}");
            return 1;
        }
    };
    let row = match client.query_one(
        "SELECT COUNT(*) FROM _sqlx_migrations WHERE version = $1",
        &[&version],
    ) {
        Ok(r) => r,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "query _sqlx_migrations failed: {e}");
            return 1;
        }
    };
    let count: i64 = row.get(0);
    if count == 0 {
        let _ = writeln!(
            io::stderr().lock(),
            "no row in _sqlx_migrations for version {version} — use sqlx migrate run to apply it fresh",
        );
        return 1;
    }
    let affected = client.execute(
        "UPDATE _sqlx_migrations SET checksum = decode($1, 'hex') WHERE version = $2",
        &[&hex, &version],
    );
    match affected {
        Ok(n) => {
            let _ = writeln!(
                io::stdout().lock(),
                "updated version {version} checksum → {hex} ({n} row affected)",
            );
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "UPDATE failed: {e}");
            1
        }
    }
}

/// Compute sha384 of bytes and return as lowercase hex string (96 chars).
fn sha384_hex(bytes: &[u8]) -> String {
    let mut hasher = Sha384::new();
    hasher.update(bytes);
    let digest = hasher.finalize();
    let mut out = String::with_capacity(96);
    for b in digest.iter() {
        use std::fmt::Write as _;
        let _ = write!(out, "{b:02x}");
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_return_96_char_hex_for_empty_input() {
        let hex = sha384_hex(b"");
        assert_eq!(hex.len(), 96);
    }

    #[test]
    fn should_match_known_sha384_empty_vector() {
        // Published NIST test vector for SHA-384 of empty input.
        let hex = sha384_hex(b"");
        assert_eq!(
            hex,
            "38b060a751ac96384cd9327eb1b1e36a21fdb71114be07434c0cc7bf63f6e1da274edebfe76f65fbd51ad2f14898b95b"
        );
    }

    #[test]
    fn should_produce_different_hex_for_different_input() {
        let a = sha384_hex(b"migration v1");
        let b = sha384_hex(b"migration v2");
        assert_ne!(a, b);
    }
}
