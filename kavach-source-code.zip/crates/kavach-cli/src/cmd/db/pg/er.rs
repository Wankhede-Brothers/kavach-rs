use std::io::{self, Write as _};

use super::schema::{connect, list_foreign_keys, list_tables};

pub fn run(dsn: &str) -> i32 {
    let mut client = match connect(dsn) {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "connect error: {e}");
            return 1;
        }
    };
    let tables = match list_tables(&mut client) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "list tables failed: {e}");
            return 1;
        }
    };
    let fks = match list_foreign_keys(&mut client) {
        Ok(f) => f,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "list fks failed: {e}");
            return 1;
        }
    };
    let out = io::stdout();
    let mut w = out.lock();
    let _ = writeln!(w, "```mermaid");
    let _ = writeln!(w, "erDiagram");
    for t in &tables {
        let _ = writeln!(w, "  {} {{", sanitize(&t.name));
        let _ = writeln!(w, "    int id PK");
        let _ = writeln!(w, "  }}");
    }
    for fk in &fks {
        let _ = writeln!(
            w,
            "  {} ||--o{{ {} : \"{}\"",
            sanitize(&fk.parent_table),
            sanitize(&fk.child_table),
            fk.child_column,
        );
    }
    let _ = writeln!(w, "```");
    0
}

/// Mermaid identifiers reject hyphens and quotes — replace them.
fn sanitize(name: &str) -> String {
    name.chars()
        .map(|c| if c.is_alphanumeric() || c == '_' { c } else { '_' })
        .collect()
}
