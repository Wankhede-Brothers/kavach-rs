use std::io::{self, Write as _};

use super::schema::{connect, list_foreign_keys, list_tables};

pub fn run(dsn: &str) -> i32 {
    let mut client = match connect(dsn) {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "connect error: {e}");
            return 1;
        }
    };
    let tables = match list_tables(&mut client) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "list tables failed: {e}");
            return 1;
        }
    };
    let fks = match list_foreign_keys(&mut client) {
        Ok(f) => f,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "list fks failed: {e}");
            return 1;
        }
    };
    let out = io::stdout();
    let mut w = out.lock();
    let _ = writeln!(w, "# PostgreSQL schema introspection\n");
    let _ = writeln!(w, "## Tables ({} total)", tables.len());
    for t in &tables {
        let _ = writeln!(w, "- {}.{}", t.schema, t.name);
    }
    let _ = writeln!(w, "\n## Foreign Keys ({} total)", fks.len());
    for fk in &fks {
        let _ = writeln!(
            w,
            "- {}.{}.{} → {}.{}.{} [{}]",
            fk.child_schema, fk.child_table, fk.child_column,
            fk.parent_schema, fk.parent_table, fk.parent_column,
            fk.constraint_name,
        );
    }
    0
}
