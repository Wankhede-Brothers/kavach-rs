use std::io::{self, Write as _};

pub fn run(project_slug: &str, category: Option<&str>) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    match kavach_db::memory::list_titles_by_project(&conn, project.id, category, 20) {
        Ok(entries) => {
            let out = io::stdout();
            let mut lock = out.lock();
            if entries.is_empty() {
                let label = match category {
                    Some(c) => c,
                    None => "all",
                };
                let _ = writeln!(lock, "no entries for {project_slug} ({label})");
                return 0;
            }
            for entry in &entries {
                let _ = writeln!(
                    lock,
                    "[{}] {} — {} (access: {}, updated: {})",
                    entry.category, entry.entry_key, entry.title,
                    entry.access_count, entry.updated_at,
                );
            }
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
