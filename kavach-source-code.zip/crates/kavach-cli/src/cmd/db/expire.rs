use std::io::{self, Write as _};

pub fn run() -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    match kavach_db::memory::expire_stale(&conn) {
        Ok(count) => {
            let _ = writeln!(io::stdout().lock(), "archived {count} expired entries");
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
