use std::io::{self, Write as _};

pub fn run(event_type: &str, payload: Option<&str>) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let session = kavach_session::get_or_create_session();
    let project_id = if !session.work_dir.is_empty() {
        kavach_db::projects::find_by_path(&conn, &session.work_dir)
            .ok()
            .flatten()
            .map(|p| p.id)
    } else {
        None
    };
    let session_ref = if session.session_id.is_empty() {
        None
    } else {
        // Only reference if session exists in DB; pass None to skip FK
        kavach_db::sessions::get(&conn, &session.session_id)
            .ok()
            .map(|_| session.session_id.clone())
    };
    match kavach_db::events::append(
        &conn,
        session_ref.as_deref(),
        event_type,
        "kavach-cli",
        project_id,
        payload,
    ) {
        Ok(id) => {
            let _ = writeln!(io::stdout().lock(), "event {event_type} logged (id={id})");
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
