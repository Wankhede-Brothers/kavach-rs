use crate::cli::DbAction;
use super::{
    event, expire, find, get, graph_query, kanban, list, pg, populate_graph,
    query, register, register_part, rotate, sync, write,
};

pub fn run(action: DbAction) -> i32 {
    match action {
        DbAction::Register { slug, path, stack } => register::run(&slug, &path, stack.as_deref()),
        DbAction::RegisterPart { project, name, path, part_type } => {
            register_part::run(&project, &name, &path, &part_type)
        }
        DbAction::Query { project, category } => query::run(&project, category.as_deref()),
        DbAction::Write { project, category, key, title, content } => {
            write::run(&project, &category, &key, &title, content.as_deref())
        }
        DbAction::Sync => sync::run(),
        DbAction::FindProject { path } => find::run_project(&path),
        DbAction::FindPart { path } => find::run_part(&path),
        DbAction::ListProjects => list::run_projects(),
        DbAction::ListParts { project } => list::run_parts(&project),
        DbAction::Expire => expire::run(),
        DbAction::Get { project, category, key, full } => get::run(&project, &category, &key, full),
        DbAction::Event { event_type, payload } => event::run(&event_type, payload.as_deref()),
        DbAction::Rotate { days } => rotate::run(days),
        DbAction::Kanban { project } => kanban::run(&project),
        DbAction::KanbanClose { project, key } => kanban::close(&project, &key),
        DbAction::PopulateGraph => populate_graph::run(),
        DbAction::GraphQuery { entity_type, name, limit } => {
            graph_query::run(entity_type.as_deref(), name.as_deref(), limit)
        }
        DbAction::PgIntrospect { dsn } => pg::run_introspect(&dsn),
        DbAction::PgIsolation { dsn } => pg::run_isolation(&dsn),
        DbAction::PgEr { dsn } => pg::run_er(&dsn),
        DbAction::PgDrift { dsn } => pg::run_drift(&dsn),
        DbAction::PgFixChecksum { dsn, version, file } => {
            pg::run_fix_checksum(&dsn, version, &file)
        }
    }
}
