use std::io::{self, Write as _};

pub fn run(days: i64) -> i32 {
    if days <= 0 {
        let _ = writeln!(io::stderr().lock(), "error: days must be positive");
        return 1;
    }
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    match kavach_db::events::rotate(&conn, days) {
        Ok(count) => {
            let _ = writeln!(
                io::stdout().lock(),
                "deleted {count} events older than {days} days"
            );
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
