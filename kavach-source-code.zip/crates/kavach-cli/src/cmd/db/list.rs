use std::io::{self, Write as _};

pub fn run_projects() -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    match kavach_db::projects::list_all(&conn) {
        Ok(projects) => {
            let out = io::stdout();
            let mut lock = out.lock();
            if projects.is_empty() {
                let _ = writeln!(lock, "no projects registered");
                return 0;
            }
            for p in &projects {
                let path = p.workdir.as_deref().unwrap_or("(no path)");
                let stack = p.stack.as_deref().unwrap_or("");
                let _ = writeln!(lock, "{} — {} [{stack}]", p.slug, path);
            }
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}

pub fn run_parts(project_slug: &str) -> i32 {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let project = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    match kavach_db::parts::list_by_project(&conn, project.id) {
        Ok(parts) => {
            let out = io::stdout();
            let mut lock = out.lock();
            if parts.is_empty() {
                let _ = writeln!(lock, "no parts for {project_slug}");
                return 0;
            }
            for p in &parts {
                let stack = p.stack.as_deref().unwrap_or("");
                let _ = writeln!(lock, "{} ({}) — {} [{stack}]", p.part_name, p.part_type, p.part_path);
            }
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}
