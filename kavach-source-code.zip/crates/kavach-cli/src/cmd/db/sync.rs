use std::io::{self, Write as _};

/// Sync current session state to kavach-db as an event.
pub fn run() -> i32 {
    let session = kavach_session::get_or_create_session();
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            return 1;
        }
    };
    if let Err(e) = kavach_db::run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "error: migration: {e}");
        return 1;
    }
    let payload = serde_json::json!({
        "turn_count": session.turn_count,
        "research_done": session.research_done,
        "files_modified": session.files_modified,
        "tasks_created": session.tasks_created,
        "tasks_completed": session.tasks_completed,
        "context_phase": session.context_phase,
    });
    let project_id = resolve_project_id(&conn, &session.project, &session.work_dir);
    let session_ref = if session.session_id.is_empty() {
        None
    } else {
        kavach_db::sessions::get(&conn, &session.session_id)
            .ok()
            .map(|_| session.session_id.clone())
    };
    match kavach_db::events::append(
        &conn,
        session_ref.as_deref(),
        "session_sync",
        "kavach-cli",
        project_id,
        Some(&payload.to_string()),
    ) {
        Ok(_id) => {
            let _ = writeln!(io::stdout().lock(), "synced session state to kavach-db");
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "error: {e}");
            1
        }
    }
}

fn resolve_project_id(
    conn: &rusqlite::Connection,
    slug: &str,
    workdir: &str,
) -> Option<i64> {
    if !slug.is_empty()
        && let Ok(p) = kavach_db::projects::get_by_slug(conn, slug)
    {
        return Some(p.id);
    }
    if !workdir.is_empty()
        && let Ok(Some(p)) = kavach_db::projects::find_by_path(conn, workdir)
    {
        return Some(p.id);
    }
    None
}
