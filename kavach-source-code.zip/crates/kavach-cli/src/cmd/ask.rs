use std::io::{self, Write as _};

pub fn run(prompt: &str, max_uses: u8) -> i32 {
    match kavach_advisor::ask(prompt, max_uses) {
        Ok(text) => {
            let _ = writeln!(io::stdout().lock(), "{text}");
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "advisor error: {e}");
            1
        }
    }
}
