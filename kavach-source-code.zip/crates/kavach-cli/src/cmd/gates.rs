use std::io::{self, Write};

use kavach_hook::HookAction;
use kavach_types::HookInput;

/// `kavach gates <name> --hook` — run a gate, reading JSON from stdin.
/// `kavach gates <name> --verify "prompt"` — dry-run a gate with inline prompt.
/// Without flags, prints gate info.
pub fn run(gate_name: &str, hook: bool, verify: Option<String>) -> i32 {
    if let Some(prompt) = verify {
        return run_verify(gate_name, &prompt);
    }

    if gate_name == "reset-test-enforcement" {
        return reset_test_enforcement();
    }

    if !hook {
        print_gate_info(gate_name);
        return 0;
    }

    // Read hook input from stdin
    let input = match kavach_hook::must_read_hook_input() {
        Ok(input) => input,
        Err(HookAction::Error) => return 1,
        Err(HookAction::Done) => return 0,
    };

    // Dispatch to engine
    match kavach_engine::run_gate(gate_name, &input) {
        Ok(()) => 0,
        Err(e) => {
            kavach_hook::output_error(&e.to_string());
            1
        }
    }
}

/// Clear stuck test enforcement state from the current session.
///
/// Used when the gate deadlocks: test_nudge_count hit the block threshold but the
/// files already have test coverage. Calling this clears test_files_pending and
/// resets test_nudge_count to 0 so writes can proceed.
fn reset_test_enforcement() -> i32 {
    let mut session = kavach_session::get_or_create_session();
    let count = session.test_files_pending.len();
    session.clear_test_pending();
    let out = io::stdout();
    let mut w = out.lock();
    let _ = writeln!(w, "reset: cleared {count} pending test file(s), nudge count reset to 0");
    0
}

/// Dry-run a gate with an inline prompt string (no stdin JSON needed).
fn run_verify(gate_name: &str, prompt: &str) -> i32 {
    let input = HookInput {
        hook_event_name: "UserPromptSubmit".to_string(),
        prompt: prompt.to_string(),
        ..HookInput::default()
    };

    match kavach_engine::run_gate(gate_name, &input) {
        Ok(()) => 0,
        Err(e) => {
            kavach_hook::output_error(&e.to_string());
            1
        }
    }
}

fn print_gate_info(gate_name: &str) {
    let out = io::stdout();
    let mut w = out.lock();
    let description = match gate_name {
        "pre-write" => "Security chain + content check + research gate (Write/Edit/NotebookEdit)",
        "post-write" => "Antiprod scan + quality + lint + memory sync (Write/Edit/NotebookEdit)",
        "pre-tool" => "Bash blocklist + read validation + subagent budget (all tools)",
        "post-tool" => "Context injection + research tracking + task sync (all tools)",
        "intent" => "Intent classification + skill routing + CEO delegation (UserPromptSubmit)",
        "subagent-start" => "Subagent lifecycle start + budget injection",
        "subagent-stop" => "Subagent lifecycle stop + output tracking",
        "session-start" => "Session initialization lifecycle hook",
        "session-end" => "Session end lifecycle hook",
        "pre-compact" => "Pre-compact lifecycle hook",
        "stop" => "Stop lifecycle hook",
        "post-tool-failure" => "Post-tool failure recovery and error tracking",
        "permission" => "Permission elevation gate for sensitive operations",
        "permission-request" => "PermissionRequest event handler (hookSpecificOutput format)",
        "notification" => "Notification dispatch to external channels",
        "teammate-idle" => "Teammate idle detection and task reassignment",
        "task-completed" => "Task completion verification and memory sync",
        other => {
            let err = io::stderr();
            let mut ew = err.lock();
            let _ = writeln!(ew, "unknown gate: {other}");
            let _ = writeln!(ew, "available: pre-write, post-write, pre-tool, post-tool, intent, subagent-start, subagent-stop, session-start, session-end, pre-compact, stop, post-tool-failure, permission, permission-request, notification, teammate-idle, task-completed");
            return;
        }
    };
    let _ = writeln!(w, "{gate_name}: {description}");
    let _ = writeln!(w, "usage: echo '{{}}' | kavach gates {gate_name} --hook");
}
