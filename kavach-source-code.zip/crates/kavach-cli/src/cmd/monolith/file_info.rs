// ALGO: Tarjan SCC + Leiden two-pass
// PROBLEM_CLASS: graph_traversal
// REJECTED: [{"name":"DFS/BFS","reason":"no boundary guarantee"},{"name":"Louvain","reason":"25% badly-connected communities"},{"name":"VAE-GNN","reason":"requires labeled training corpus, 73.53% accuracy"}]
// TIME: O(V+E) | SPACE: O(V+E)
// YEAR: 1972 | SEARCHED: 2026-04
// TRADEOFF: does not detect soft coupling (high fan-in without import cycles)
// BENCHMARK: https://crates.io/crates/petgraph

const MIXED_CONCERNS_LINE_LIMIT: usize = 200;

/// Metadata about a single Rust source file.
#[derive(Debug)]
pub struct FileInfo {
    pub path: String,
    pub line_count: usize,
    pub has_struct: bool,
    pub has_impl: bool,
    pub has_async_fn: bool,
    pub deps: Vec<String>,
}

fn has_keyword(content: &str, keyword: &str) -> bool {
    content.contains(keyword)
}

impl FileInfo {
    pub fn from_content(path: String, content: &str) -> Self {
        let line_count = content.lines().count();
        let has_struct = has_keyword(content, "\nstruct ") || has_keyword(content, "\npub struct ");
        let has_impl = has_keyword(content, "\nimpl ");
        let has_async_fn = has_keyword(content, "async fn ");
        let deps = extract_deps(content);
        Self { path, line_count, has_struct, has_impl, has_async_fn, deps }
    }

    pub fn is_mixed_concerns_monolith(&self) -> bool {
        if self.path.contains("// split:") {
            return false;
        }
        self.line_count > MIXED_CONCERNS_LINE_LIMIT
            && self.has_struct
            && self.has_impl
            && self.has_async_fn
    }
}

/// Returns true when `name` has an opening brace — i.e. it is an inline mod body, not a file mod.
fn mod_is_inline(name: &str) -> bool {
    name.find('{').is_some()
}

pub fn extract_deps(content: &str) -> Vec<String> {
    let mut deps = Vec::new();
    for line in content.lines() {
        let trimmed = line.trim();
        if let Some(rest) = trimmed.strip_prefix("use ") {
            if let Some(module) = rest.split("::").next() {
                let name = module.trim_end_matches(';').trim().to_string();
                if !name.is_empty() {
                    deps.push(name);
                }
            }
        } else if let Some(rest) = trimmed.strip_prefix("mod ") {
            let name = rest.trim_end_matches(';').trim();
            if !mod_is_inline(name) && !name.is_empty() {
                deps.push(name.to_string());
            }
        }
    }
    deps
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_detect_mixed_concerns_when_over_200_lines() {
        let big: String = (0..201).map(|_| "x\n").collect();
        let content = format!("{big}struct Foo {{}}\nimpl Foo {{}}\nasync fn bar() {{}}");
        let fi = FileInfo::from_content("src/foo.rs".into(), &content);
        assert!(fi.is_mixed_concerns_monolith());
    }

    #[test]
    fn should_not_flag_split_escape_hatch() {
        let big: String = (0..201).map(|_| "x\n").collect();
        let content = format!("{big}struct Foo {{}}\nimpl Foo {{}}\nasync fn bar() {{}}");
        let fi = FileInfo::from_content("// split: intentional src/foo.rs".into(), &content);
        assert!(!fi.is_mixed_concerns_monolith());
    }

    #[test]
    fn should_extract_use_deps() {
        let content = "use std::collections::HashMap;\nuse tokio::sync::Mutex;";
        let deps = extract_deps(content);
        assert!(deps.iter().any(|d| d == "std"));
        assert!(deps.iter().any(|d| d == "tokio"));
    }

    #[test]
    fn should_skip_inline_mod() {
        let content = "mod foo;\nmod bar { fn x() {} }";
        let deps = extract_deps(content);
        assert!(deps.iter().any(|d| d == "foo"));
        assert!(!deps.iter().any(|d| d == "bar"));
    }
}
