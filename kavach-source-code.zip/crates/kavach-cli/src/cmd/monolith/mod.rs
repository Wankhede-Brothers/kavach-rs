// hub: monolith subcommand dispatch
mod file_info;
mod scan;
mod tarjan;

use crate::cli::MonolithAction;

pub fn run(action: MonolithAction) -> i32 {
    match action {
        MonolithAction::Scan { dir, mixed_only } => scan::run(&dir, mixed_only),
    }
}
