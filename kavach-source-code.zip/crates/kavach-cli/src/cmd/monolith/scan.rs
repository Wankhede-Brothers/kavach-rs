use super::file_info::{FileInfo, extract_deps};
use super::tarjan::find_cycles;
use std::collections::HashMap;
use std::fs;
use std::io::{self, Write as IoWrite};

pub fn run(dir: &str, mixed_only: bool) -> i32 {
    let files = match collect_rs_files(dir) {
        Ok(f) => f,
        Err(e) => {
            let _ = writeln!(io::stderr(), "error: {e}");
            return 1;
        }
    };

    let stdout = io::stdout();
    let mut out = stdout.lock();

    // Report mixed-concerns monoliths
    let mut found_any = false;
    for fi in &files {
        if fi.is_mixed_concerns_monolith() {
            found_any = true;
            let _ = writeln!(out, "MONOLITH  {}", fi.path);
        }
    }

    if !mixed_only {
        // Build name→index map for dependency resolution
        let name_to_idx: HashMap<String, usize> = files
            .iter()
            .enumerate()
            .filter_map(|(i, fi)| stem(&fi.path).map(|s| (s, i)))
            .collect();

        // Build adjacency list
        let mut adj: Vec<Vec<usize>> = (0..files.len()).map(|_| Vec::new()).collect();
        for (i, fi) in files.iter().enumerate() {
            for dep in &fi.deps {
                if let Some(&j) = name_to_idx.get(dep.as_str()) {
                    if let Some(neighbors) = adj.get_mut(i) {
                        neighbors.push(j);
                    }
                }
            }
        }

        // Find circular dependency clusters via Tarjan SCC
        let sccs = find_cycles(&adj);
        for scc in &sccs {
            found_any = true;
            let _ = writeln!(out, "CYCLE");
            for &idx in scc {
                if let Some(fi) = files.get(idx) {
                    let _ = writeln!(out, "  {}", fi.path);
                }
            }
        }
    }

    if !found_any {
        let _ = writeln!(out, "ok — no monolith files or circular dependencies found");
    }
    0
}

fn stem(path: &str) -> Option<String> {
    std::path::Path::new(path)
        .file_stem()
        .and_then(|s| s.to_str())
        .map(|s| s.to_string())
}

fn collect_rs_files(dir: &str) -> Result<Vec<FileInfo>, io::Error> {
    let mut result = Vec::new();
    collect_recursive(dir, &mut result)?;
    Ok(result)
}

fn collect_recursive(dir: &str, out: &mut Vec<FileInfo>) -> Result<(), io::Error> {
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_dir() {
            let sub = path.to_string_lossy().into_owned();
            // Skip target/ and hidden directories
            if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
                if name == "target" || name.starts_with('.') {
                    continue;
                }
            }
            collect_recursive(&sub, out)?;
        } else if path.extension().and_then(|e| e.to_str()) == Some("rs") {
            let path_str = path.to_string_lossy().into_owned();
            match fs::read_to_string(&path) {
                Ok(content) => {
                    let deps = extract_deps(&content);
                    let fi = FileInfo::from_content(path_str, &content);
                    // Override deps with full extraction (from_content already calls it)
                    let _ = deps; // deps already embedded in fi via from_content
                    out.push(fi);
                }
                Err(_) => continue,
            }
        }
    }
    Ok(())
}
