use std::io::{self, Write};

use crate::cli::SessionAction;

/// `kavach session <action>` — manage session lifecycle.
pub fn run(action: SessionAction) -> i32 {
    match action {
        SessionAction::Init => handle_init(),
        SessionAction::Validate => handle_validate(),
        SessionAction::End => handle_end(),
        SessionAction::Compact => handle_compact(),
        SessionAction::Resume => handle_resume(),
        SessionAction::Land => handle_land(),
        SessionAction::EndHook => handle_end_hook(),
        SessionAction::ClearTestLocks => handle_clear_test_locks(),
    }
}

fn handle_init() -> i32 {
    let session = kavach_session::get_or_create_session();
    let toon = session.to_compact();
    let _ = io::stdout().lock().write_all(toon.as_bytes());
    0
}

fn handle_validate() -> i32 {
    match kavach_session::load_session_state() {
        Ok(Some(session)) => {
            let toon = session.to_compact();
            let _ = io::stdout().lock().write_all(toon.as_bytes());
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stderr().lock(), "no active session");
            1
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "session error: {e}");
            1
        }
    }
}

fn handle_end() -> i32 {
    match kavach_session::load_session_state() {
        Ok(Some(session)) => {
            let research = if session.research_done { "DONE" } else { "PENDING" };
            let memory = if session.memory_queried { "DONE" } else { "PENDING" };
            let out = format!(
                "[SESSION_END]\n\
                 id: {}\n\
                 project: {}\n\
                 turns: {}\n\
                 research: {research}\n\
                 memory: {memory}\n\
                 files_modified: {}\n\
                 tasks_created: {}\n\
                 tasks_completed: {}\n",
                session.id,
                session.project,
                session.turn_count,
                session.files_modified.len(),
                session.tasks_created,
                session.tasks_completed,
            );
            let _ = io::stdout().lock().write_all(out.as_bytes());
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stderr().lock(), "no active session to end");
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "session error: {e}");
            1
        }
    }
}

fn handle_compact() -> i32 {
    match kavach_session::load_session_state() {
        Ok(Some(mut session)) => {
            session.mark_post_compact();
            let toon = session.to_compact();
            let _ = io::stdout().lock().write_all(toon.as_bytes());
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stderr().lock(), "no active session to compact");
            1
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "session error: {e}");
            1
        }
    }
}

fn handle_resume() -> i32 {
    let session = kavach_session::get_or_create_session();
    let toon = session.to_compact();
    let _ = io::stdout().lock().write_all(toon.as_bytes());
    0
}

fn handle_land() -> i32 {
    match kavach_session::load_session_state() {
        Ok(Some(mut session)) => {
            session.set_task("", "landed");
            let toon = session.to_compact();
            let _ = io::stdout().lock().write_all(toon.as_bytes());
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stderr().lock(), "no active session");
            1
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "session error: {e}");
            1
        }
    }
}

fn handle_clear_test_locks() -> i32 {
    match kavach_session::load_session_state() {
        Ok(Some(mut session)) => {
            let count = session.active_test_crates.len();
            session.active_test_crates.clear();
            session.save_or_log();
            let _ = writeln!(io::stdout().lock(), "cleared {count} stale test lock(s)");
            0
        }
        Ok(None) => {
            let _ = writeln!(io::stdout().lock(), "no active session");
            0
        }
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "session error: {e}");
            1
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn run_accepts_all_session_action_variants() {
        // Compile-time exhaustion check: if a new SessionAction variant is added
        // without a handler arm in run(), this function signature check fails to compile.
        let _: fn(SessionAction) -> i32 = run;
    }

    #[test]
    fn handle_clear_test_locks_returns_zero_when_no_session() {
        // No active session on disk during unit tests — function must return 0 (not panic).
        let result = handle_clear_test_locks();
        assert_eq!(result, 0);
    }
}

fn handle_end_hook() -> i32 {
    match kavach_session::load_session_state() {
        Ok(Some(session)) => {
            let context = format!(
                "[SESSION_END]\n\
                 id: {}\n\
                 turns: {}\n\
                 files: {}\n",
                session.id,
                session.turn_count,
                session.files_modified.len(),
            );
            kavach_hook::exit_session_end(&context);
            0
        }
        Ok(None) => {
            kavach_hook::exit_session_end("");
            0
        }
        Err(_) => {
            kavach_hook::exit_session_end("");
            0
        }
    }
}
