// kavach tailwind-plus index — walk ~/.claude/tailwind-plus/, extract keywords, write index.json
use std::collections::HashSet;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

use kavach_config::{tailwind_plus_dir, tailwind_plus_index};
use serde_json::json;

use crate::cli::TailwindPlusAction;

/// Dispatch `kavach tailwind-plus <action>`.
pub fn run(action: TailwindPlusAction) -> i32 {
    match action {
        TailwindPlusAction::Index => handle_index(),
    }
}

fn handle_index() -> i32 {
    let base = tailwind_plus_dir();
    if !base.exists() {
        let _ = writeln!(
            io::stderr().lock(),
            "tailwind-plus dir not found: {}",
            base.display()
        );
        return 1;
    }
    let mut entries: Vec<serde_json::Value> = Vec::new();
    let mut stack: Vec<PathBuf> = vec![base.clone()];
    while let Some(dir) = stack.pop() {
        let read_dir = match fs::read_dir(&dir) {
            Ok(rd) => rd,
            Err(e) => {
                let _ = writeln!(io::stderr().lock(), "read_dir {} failed: {e}", dir.display());
                return 1;
            }
        };
        for entry_result in read_dir {
            let entry = match entry_result {
                Ok(e) => e,
                Err(_) => continue,
            };
            let path = entry.path();
            let ft = match entry.file_type() {
                Ok(t) => t,
                Err(_) => continue,
            };
            if ft.is_dir() {
                stack.push(path);
            } else if ft.is_file() && is_component_file(&path) {
                if let Some(record) = build_record(&base, &path) {
                    entries.push(record);
                }
            }
        }
    }
    let index = json!({ "components": entries });
    let json_str = match serde_json::to_string_pretty(&index) {
        Ok(s) => s,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "serialize failed: {e}");
            return 1;
        }
    };
    let index_path = tailwind_plus_index();
    if let Some(parent) = index_path.parent() {
        if let Err(e) = fs::create_dir_all(parent) {
            let _ = writeln!(io::stderr().lock(), "create dir failed: {e}");
            return 1;
        }
    }
    if let Err(e) = fs::write(&index_path, &json_str) {
        let _ = writeln!(io::stderr().lock(), "write index failed: {e}");
        return 1;
    }
    let _ = writeln!(
        io::stdout().lock(),
        "indexed {} components → {}",
        entries.len(),
        index_path.display()
    );
    0
}

fn is_component_file(path: &Path) -> bool {
    match path.extension().and_then(|e| e.to_str()) {
        Some("jsx") | Some("tsx") | Some("js") | Some("ts") => true,
        Some(_) | None => false,
    }
}

/// Build a single index record for one component file.
fn build_record(base: &Path, path: &Path) -> Option<serde_json::Value> {
    let rel = match path.strip_prefix(base) {
        Ok(r) => r,
        Err(_) => return None,
    };
    let rel_str = match rel.to_str() {
        Some(s) => s.replace('\\', "/"),
        None => return None,
    };
    let category = match rel.parent().and_then(|p| p.to_str()) {
        Some(s) => s.replace('\\', "/"),
        None => String::new(),
    };
    let name = match path.file_stem().and_then(|s| s.to_str()) {
        Some(n) => n.to_string(),
        None => return None,
    };
    let keywords = extract_keywords(&category, &name, path);
    let lines = count_lines(path);
    Some(json!({
        "category": category,
        "name": name,
        "file": rel_str,
        "keywords": keywords,
        "lines": lines,
    }))
}

/// Keywords from: category path segments + file stem + first-5-line tokens.
fn extract_keywords(category: &str, name: &str, path: &Path) -> Vec<String> {
    let mut kw: Vec<String> = Vec::new();
    for seg in category.split('/') {
        let seg = seg.trim();
        if !seg.is_empty() {
            for part in seg.split('-') {
                let part = part.trim();
                if part.len() > 1 {
                    kw.push(part.to_lowercase());
                }
            }
        }
    }
    for part in name.split('-') {
        let part = part.trim();
        if part.len() > 1 {
            kw.push(part.to_lowercase());
        }
    }
    if let Ok(body) = fs::read_to_string(path) {
        for line in body.lines().take(5) {
            for token in line.split(|c: char| !c.is_alphanumeric() && c != '-') {
                let t = token.trim().to_lowercase();
                if t.len() > 2 && !is_noise_token(&t) {
                    kw.push(t);
                }
            }
        }
    }
    let mut seen = HashSet::new();
    kw.retain(|k| seen.insert(k.clone()));
    kw
}

fn is_noise_token(t: &str) -> bool {
    matches!(
        t,
        "import" | "from" | "use" | "const" | "let" | "var" | "export"
            | "default" | "function" | "return" | "react" | "jsx" | "tsx"
    )
}

fn count_lines(path: &Path) -> usize {
    match fs::read_to_string(path) {
        Ok(s) => s.lines().count(),
        Err(_) => 0,
    }
}
