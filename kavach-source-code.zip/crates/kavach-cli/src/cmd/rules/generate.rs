use std::io::{self, Write};
use std::path::Path;

use kavach_rule_generator::{detect_patterns, emit_skill, generate_skill};

pub fn run(dir: &str) -> i32 {
    let out = io::stdout();
    let mut w = out.lock();
    let dir_path = Path::new(dir);
    if !dir_path.is_dir() {
        let _ = writeln!(io::stderr(), "rules generate: not a directory: {dir}");
        return 1;
    }
    let (files, content) = scan_directory(dir_path);
    let file_refs: Vec<&str> = files.iter().map(|s| s.as_str()).collect();
    let patterns = detect_patterns(&file_refs, &content);
    if patterns.is_empty() {
        let _ = writeln!(w, "No patterns detected in: {dir}");
        return 0;
    }
    let _ = writeln!(w, "Detected {} pattern(s):", patterns.len());
    for pat in &patterns {
        let _ = writeln!(
            w,
            "  {:?} — {} (confidence: {:.0}%)",
            pat.pattern_type,
            pat.name,
            pat.confidence * 100.0
        );
        let skill = generate_skill(pat);
        let toon = emit_skill(&skill);
        let _ = writeln!(w, "--- Generated TOON ---");
        let _ = writeln!(w, "{toon}");
    }
    0
}

fn scan_directory(dir: &Path) -> (Vec<String>, String) {
    let mut files = Vec::new();
    let mut content = String::new();
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return (files, content),
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_file() {
            files.push(path.display().to_string());
            if let Ok(text) = std::fs::read_to_string(&path)
                && content.len() < 8192
            {
                content.push_str(&text[..text.len().min(2048)]);
            }
        }
    }
    (files, content)
}
