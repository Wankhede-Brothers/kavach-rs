use std::io::{self, Write};
use std::path::PathBuf;

use kavach_rule_engine::{EvalContext, RuleAction, RuleEngine};

fn skills_dir() -> Option<PathBuf> {
    let home = std::env::var("HOME").ok()?;
    Some(PathBuf::from(home).join(".local/share/kavach/skills"))
}

pub fn run(path: &str) -> i32 {
    let out = io::stdout();
    let mut w = out.lock();
    let content = match std::fs::read_to_string(path) {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr(), "rules check: cannot read {path}: {e}");
            return 1;
        }
    };
    let Some(dir) = skills_dir() else {
        let _ = writeln!(io::stderr(), "rules check: HOME not set");
        return 1;
    };
    let mut engine = RuleEngine::new(dir);
    engine.load_skills();
    let ctx = EvalContext::new("Write", &content).with_file(path).with_content(&content);
    let results = engine.evaluate(&ctx);
    if results.is_empty() {
        let _ = writeln!(w, "No rule violations for: {path}");
        return 0;
    }
    let _ = writeln!(w, "{} result(s) for: {path}", results.len());
    for r in &results {
        let action_str = match &r.action {
            RuleAction::Allow => "ALLOW",
            RuleAction::Block => "BLOCK",
            RuleAction::Warn => "WARN",
            RuleAction::Modify => "MODIFY",
        };
        let _ = writeln!(
            w,
            "  [{action_str}] {} — {} (severity: {})",
            r.rule_name, r.reason, r.severity
        );
    }
    let worst = RuleEngine::worst_action(&results);
    if worst == RuleAction::Block { 1 } else { 0 }
}
