use std::io::{self, Write};
use std::path::PathBuf;

use kavach_rule_storage::RuleStore;

fn skills_dir() -> Option<PathBuf> {
    Some(kavach_config::skills_dir())
}

pub fn run(name: &str) -> i32 {
    let out = io::stdout();
    let mut w = out.lock();
    let Some(dir) = skills_dir() else {
        let _ = writeln!(io::stderr(), "rules show: HOME not set");
        return 1;
    };
    let mut store = RuleStore::new(dir);
    if let Err(e) = store.load_all() {
        let _ = writeln!(io::stderr(), "rules show: {e}");
        return 1;
    }
    let rule = match store.get(name) {
        Some(r) => r,
        None => {
            let _ = writeln!(io::stderr(), "rules show: rule not found: {name}");
            let available = store.list();
            if !available.is_empty() {
                let _ = writeln!(io::stderr(), "available: {}", available.join(", "));
            }
            return 1;
        }
    };
    let _ = writeln!(w, "Rule: {}", rule.definition.metadata.name);
    let _ = writeln!(w, "  Description: {}", rule.definition.metadata.description);
    let _ = writeln!(w, "  Protocol: {}", rule.definition.metadata.protocol);
    let _ = writeln!(w, "  Version: {}", rule.version);
    let _ = writeln!(w, "  Source: {}", rule.source_path.display());
    let _ = writeln!(w, "  Hash: {}", rule.content_hash);
    let rg = &rule.definition.research_gate;
    let _ = writeln!(w, "  Research Gate:");
    let _ = writeln!(w, "    Mandatory: {}", rg.mandatory);
    let _ = writeln!(w, "    Rule: {}", rg.rule);
    if !rule.definition.metadata.triggers.is_empty() {
        let _ = writeln!(w, "  Triggers:");
        for t in &rule.definition.metadata.triggers {
            let _ = writeln!(w, "    - {t}");
        }
    }
    0
}
