use std::io::{self, Write};

/// Show skill registry entries with enforcement tiers and file patterns.
pub fn run() -> i32 {
    let out = io::stdout();
    let mut w = out.lock();

    let cache_path = kavach_config::registry_cache_path();
    let registry = match kavach_rule_storage::load_registry(&cache_path) {
        Ok(r) => r,
        Err(_) => match build_registry(&cache_path) {
            Some(r) => r,
            None => {
                let _ = writeln!(w, "No skill registry found and rebuild failed.");
                return 1;
            }
        },
    };

    if registry.skills.is_empty() {
        let _ = writeln!(w, "Skill registry is empty (no skills with file_patterns).");
        return 0;
    }

    let _ = writeln!(
        w,
        "Skill Registry ({} enforced skill(s)):",
        registry.skills.len()
    );
    let _ = writeln!(w, "Built: {}", registry.built_at);
    let _ = writeln!(w);

    for entry in &registry.skills {
        let tier = if entry.priority.is_critical() {
            "CRITICAL"
        } else {
            "advisory"
        };
        let _ = writeln!(w, "  [{tier}] {}", entry.name);
        for pat in &entry.file_patterns {
            let _ = writeln!(w, "    pattern: {pat}");
        }
    }
    0
}

fn build_registry(cache_path: &std::path::Path) -> Option<kavach_rule_storage::SkillRegistry> {
    let skills_dir = kavach_config::skills_dir();
    let mut store = kavach_rule_storage::RuleStore::new(skills_dir);
    if let Err(e) = store.load_all() {
        let _ = writeln!(io::stderr().lock(), "rules list: failed to load skills: {e}");
        return None;
    }
    let rules: Vec<_> = store
        .list()
        .iter()
        .filter_map(|name| store.get(name).cloned())
        .collect();
    let registry = kavach_rule_storage::build_from_rules(&rules);
    if let Err(e) = kavach_rule_storage::save_registry(cache_path, &registry) {
        let _ = writeln!(io::stderr().lock(), "rules list: failed to save registry: {e}");
    }
    Some(registry)
}
