// hub: CLI dispatch hub — dispatch() fn is intentionally here as the top-level router
mod ask;
mod db;
mod gates;
mod monolith;
mod rag;
mod rules;
mod session;
mod status;
mod tailwind_plus;

use crate::cli::Commands;

/// Dispatch CLI command and return exit code (0 = success, 1 = error).
pub fn dispatch(command: Commands) -> i32 {
    match command {
        Commands::Status => status::run(),
        Commands::Gates { gate_name, hook, verify } => gates::run(&gate_name, hook, verify),
        Commands::Session { action } => session::run(action),
        Commands::Rules { action } => rules::run(action),
        Commands::Db { action } => db::run(action),
        Commands::Rag { action } => rag::run(action),
        Commands::Ask { prompt, max_uses } => ask::run(&prompt, max_uses),
        Commands::Monolith { action } => monolith::run(action),
        Commands::TailwindPlus { action } => tailwind_plus::run(action),
    }
}
