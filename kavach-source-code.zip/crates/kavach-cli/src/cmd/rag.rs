use std::collections::HashSet;
use std::fs;
use std::io::{self, Write};
use std::path::PathBuf;

use kavach_db::{graph, graph_entity, open_default, rag_trees, run_migrations};
use kavach_db::rag::{
    apply_summaries, build_trees_from_dir, pending_requests, Matcher, Query, RagTree,
    SummaryResponse,
};

use crate::cli::RagAction;

/// `kavach rag <action>` — dispatch to the matching handler.
pub fn run(action: RagAction) -> i32 {
    match action {
        RagAction::Build { source, label, persist } => handle_build(&source, &label, persist),
        RagAction::Query { tree, file, text, intent, top_k } => {
            handle_query(&tree, &file, &text, &intent, top_k)
        }
        RagAction::Pending { tree } => handle_pending(&tree),
        RagAction::Apply { tree, responses } => handle_apply(&tree, &responses),
        RagAction::List => handle_list(),
        RagAction::EnrichSkills { source, label } => handle_enrich_skills(&source, &label),
        RagAction::Enrich { source, label } => handle_enrich(&source, &label),
        RagAction::RefreshIfStale { source, label } => handle_refresh_if_stale(&source, &label),
    }
}

fn handle_refresh_if_stale(source: &str, label: &str) -> i32 {
    let path = PathBuf::from(source);
    let all_trees = match build_trees_from_dir(&path, label) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "scan failed: {e}");
            return 1;
        }
    };
    // For skills label: only index SKILL.md roots, skip sub-files.
    let mut trees: Vec<RagTree> = if label == "skills" {
        all_trees.into_iter().filter(|t| t.root.id.ends_with("SKILL.md")).collect()
    } else {
        all_trees
    };
    for tree in &mut trees {
        let source_path = path.join(&tree.root.id);
        let body = match fs::read_to_string(&source_path) {
            Ok(b) => b,
            Err(_) => continue,
        };
        if let Some(meta) = parse_frontmatter(&body) {
            apply_metadata(&mut tree.root, &meta);
        }
    }
    let prospective = match serialize_payload(&trees) {
        Ok(p) => p,
        Err(code) => return code,
    };
    let prospective_hash = hash_bytes(prospective.as_bytes());
    let conn = match open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db open failed: {e}");
            return 1;
        }
    };
    if let Err(e) = run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "db migrate failed: {e}");
        return 1;
    }
    let current = match rag_trees::get(&conn, label) {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db get failed: {e}");
            return 1;
        }
    };
    if let Some(stored) = current
        && stored.source_hash == prospective_hash
    {
        let _ = writeln!(
            io::stdout().lock(),
            "rag '{label}' fresh (hash {})",
            short_hash(&prospective_hash)
        );
        return 0;
    }
    let built_at = kavach_hook::today();
    if let Err(e) = rag_trees::upsert_with_dir(
        &conn,
        label,
        &built_at,
        prospective.as_bytes(),
        &prospective_hash,
        source,
    ) {
        let _ = writeln!(io::stderr().lock(), "db upsert failed: {e}");
        return 1;
    }
    let _ = writeln!(
        io::stdout().lock(),
        "rag '{label}' refreshed ({} trees, hash {})",
        trees.len(),
        short_hash(&prospective_hash)
    );
    0
}

fn serialize_payload(trees: &[RagTree]) -> Result<String, i32> {
    let mut payload = String::new();
    for tree in trees {
        let json = match tree.to_json() {
            Ok(j) => j,
            Err(e) => {
                let _ = writeln!(io::stderr().lock(), "serialize failed: {e}");
                return Err(1);
            }
        };
        payload.push_str(&json);
        payload.push('\n');
    }
    Ok(payload)
}

fn handle_build(source: &str, label: &str, persist: bool) -> i32 {
    let path = PathBuf::from(source);
    let trees = match build_trees_from_dir(&path, label) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "rag build failed: {e}");
            return 1;
        }
    };
    if persist {
        return persist_trees(label, &trees, source);
    }
    let mut out = io::stdout().lock();
    for tree in &trees {
        let json = match tree.to_json() {
            Ok(j) => j,
            Err(e) => {
                let _ = writeln!(io::stderr().lock(), "serialize failed: {e}");
                return 1;
            }
        };
        if writeln!(out, "{json}").is_err() {
            return 1;
        }
    }
    0
}

fn persist_trees(label: &str, trees: &[RagTree], source_dir: &str) -> i32 {
    let conn = match open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db open failed: {e}");
            return 1;
        }
    };
    if let Err(e) = run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "db migrate failed: {e}");
        return 1;
    }
    let mut payload = String::new();
    for tree in trees {
        let json = match tree.to_json() {
            Ok(j) => j,
            Err(e) => {
                let _ = writeln!(io::stderr().lock(), "serialize failed: {e}");
                return 1;
            }
        };
        payload.push_str(&json);
        payload.push('\n');
    }
    let built_at = kavach_hook::today();
    let source_hash = hash_bytes(payload.as_bytes());
    let short = short_hash(&source_hash);
    if let Err(e) = rag_trees::upsert_with_dir(
        &conn, label, &built_at, payload.as_bytes(), &source_hash, source_dir,
    ) {
        let _ = writeln!(io::stderr().lock(), "db upsert failed: {e}");
        return 1;
    }
    let _ = writeln!(
        io::stdout().lock(),
        "persisted {} tree(s) under label '{label}' (hash {short})",
        trees.len()
    );
    0
}

fn handle_list() -> i32 {
    let conn = match open_default() {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db open failed: {e}");
            return 1;
        }
    };
    if let Err(e) = run_migrations(&conn) {
        let _ = writeln!(io::stderr().lock(), "db migrate failed: {e}");
        return 1;
    }
    let rows = match rag_trees::list(&conn) {
        Ok(r) => r,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "db list failed: {e}");
            return 1;
        }
    };
    let mut out = io::stdout().lock();
    for (source, built_at, source_hash) in &rows {
        let short = short_hash(source_hash);
        if writeln!(out, "{source}\t{built_at}\t{short}").is_err() {
            return 1;
        }
    }
    0
}

/// Generic enricher: scans any markdown directory, extracts frontmatter
/// (description, keywords/triggers, file_patterns), persists to kavach-db.
/// Works with rules, agents, commands, docs — any markdown source.
fn handle_enrich(source: &str, label: &str) -> i32 {
    let path = PathBuf::from(source);
    let mut trees = match build_trees_from_dir(&path, label) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "scan failed: {e}");
            return 1;
        }
    };
    let mut enriched = 0usize;
    let mut cross_invoke_pairs: Vec<(String, Vec<String>)> = Vec::new();
    for tree in &mut trees {
        let source_path = path.join(&tree.root.id);
        let body = match fs::read_to_string(&source_path) {
            Ok(b) => b,
            Err(_) => continue,
        };
        if let Some(meta) = parse_frontmatter(&body) {
            apply_metadata(&mut tree.root, &meta);
            enriched += 1;
        }
        let targets = parse_cross_invoke(&body);
        if !targets.is_empty() {
            cross_invoke_pairs.push((tree.root.id.clone(), targets));
        }
    }
    let code = persist_trees(label, &trees, source);
    if code == 0 && !cross_invoke_pairs.is_empty() {
        index_skill_graph(&cross_invoke_pairs);
    }
    let _ = writeln!(
        io::stdout().lock(),
        "enriched {enriched}/{} tree(s) under '{label}'",
        trees.len()
    );
    code
}

fn handle_enrich_skills(source: &str, label: &str) -> i32 {
    let path = PathBuf::from(source);
    let all_trees = match build_trees_from_dir(&path, label) {
        Ok(t) => t,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "scan failed: {e}");
            return 1;
        }
    };
    // Only index SKILL.md files — sub-files (patterns, rules, examples) are noise.
    let mut trees: Vec<RagTree> = all_trees
        .into_iter()
        .filter(|t| t.root.id.ends_with("SKILL.md"))
        .collect();
    let mut enriched = 0usize;
    let mut cross_invoke_pairs: Vec<(String, Vec<String>)> = Vec::new();
    for tree in &mut trees {
        let source_path = path.join(&tree.root.id);
        let body = match fs::read_to_string(&source_path) {
            Ok(b) => b,
            Err(_) => continue,
        };
        if let Some(meta) = parse_frontmatter(&body) {
            apply_metadata(&mut tree.root, &meta);
            enriched += 1;
        }
        let targets = parse_cross_invoke(&body);
        if !targets.is_empty() {
            cross_invoke_pairs.push((tree.root.id.clone(), targets));
        }
    }
    let code = persist_trees(label, &trees, source);
    if code == 0 && !cross_invoke_pairs.is_empty() {
        index_skill_graph(&cross_invoke_pairs);
    }
    let _ = writeln!(
        io::stdout().lock(),
        "enriched {enriched}/{} skill tree(s)",
        trees.len()
    );
    code
}

#[derive(Debug, Default)]
struct SkillMetadata {
    description: String,
    triggers: Vec<String>,
    file_patterns: Vec<String>,
}

fn parse_frontmatter(body: &str) -> Option<SkillMetadata> {
    let rest = body.strip_prefix("---\n")?;
    let end = rest.find("\n---")?;
    let yaml = rest.get(..end)?;
    let mut meta = SkillMetadata::default();
    let mut in_file_patterns = false;
    let mut in_metadata = false;
    for line in yaml.lines() {
        let trimmed = line.trim_end();
        if let Some(desc) = trimmed.strip_prefix("description:") {
            meta.description = strip_quotes(desc.trim());
            in_file_patterns = false;
            in_metadata = false;
            continue;
        }
        if trimmed == "file_patterns:" {
            in_file_patterns = true;
            in_metadata = false;
            continue;
        }
        if trimmed == "metadata:" {
            in_metadata = true;
            in_file_patterns = false;
            continue;
        }
        if in_file_patterns {
            if let Some(item) = trimmed.strip_prefix("  - ") {
                meta.file_patterns.push(strip_quotes(item.trim()));
                continue;
            }
            if !trimmed.starts_with(' ') {
                in_file_patterns = false;
            }
        }
        if in_metadata {
            if let Some(rest) = trimmed.strip_prefix("  triggers:") {
                meta.triggers = parse_inline_list(rest.trim());
                continue;
            }
            if !trimmed.starts_with(' ') {
                in_metadata = false;
            }
        }
    }
    if meta.triggers.is_empty() {
        meta.triggers = extract_trigger_phrase(&meta.description);
    }
    Some(meta)
}

fn apply_metadata(node: &mut kavach_db::rag::TreeNode, meta: &SkillMetadata) {
    node.summary = meta.description.clone();
    let existing_kw: HashSet<&str> = node.keywords.iter().map(String::as_str).collect();
    let new_kw: Vec<String> = meta.triggers.iter()
        .filter(|t| !existing_kw.contains(t.as_str()))
        .cloned()
        .collect();
    node.keywords.extend(new_kw);

    let candidates = if !meta.file_patterns.is_empty() {
        meta.file_patterns.clone()
    } else {
        infer_file_patterns(&meta.description, &meta.triggers)
    };
    let existing_fp: HashSet<&str> = node.file_patterns.iter().map(String::as_str).collect();
    let new_fp: Vec<String> = candidates.iter()
        .filter(|p| !existing_fp.contains(p.as_str()))
        .cloned()
        .collect();
    node.file_patterns.extend(new_fp);
}

/// Infer file_patterns from skill description and triggers when not explicitly set.
fn infer_file_patterns(description: &str, triggers: &[String]) -> Vec<String> {
    let combined = format!("{description} {}", triggers.join(" ")).to_lowercase();
    let mut patterns: Vec<String> = Vec::new();
    // Rust signals
    if combined.contains("rust") || combined.contains("cargo")
        || combined.contains(".rs") || combined.contains("struct")
        || combined.contains("trait") || combined.contains("impl")
        || combined.contains("thiserror") || combined.contains("tokio")
    {
        patterns.push("**/*.rs".to_string());
    }
    // TypeScript/JavaScript signals
    if combined.contains("typescript") || combined.contains("react")
        || combined.contains("tsx") || combined.contains("jsx")
        || combined.contains("astro") || combined.contains("svelte")
        || combined.contains("vue") || combined.contains("frontend")
    {
        patterns.push("**/*.tsx".to_string());
        patterns.push("**/*.ts".to_string());
    }
    // SQL signals
    if combined.contains("sql") || combined.contains("postgresql")
        || combined.contains("migration") || combined.contains("database")
        || combined.contains("query") || combined.contains("sqlx")
    {
        patterns.push("**/*.sql".to_string());
        patterns.push("**/*.rs".to_string());
    }
    // Docker/infra signals
    if combined.contains("docker") || combined.contains("kubernetes")
        || combined.contains("grpc") || combined.contains("yaml")
    {
        patterns.push("**/Dockerfile".to_string());
        patterns.push("**/*.yaml".to_string());
    }
    // CSS/styling signals
    if combined.contains("css") || combined.contains("tailwind")
        || combined.contains("styling")
    {
        patterns.push("**/*.css".to_string());
    }
    patterns
}

fn strip_quotes(s: &str) -> String {
    let trimmed = s.trim();
    let without_leading = match trimmed.strip_prefix('"') {
        Some(t) => t,
        None => trimmed,
    };
    let without_trailing = match without_leading.strip_suffix('"') {
        Some(t) => t,
        None => without_leading,
    };
    without_trailing.to_string()
}

fn parse_inline_list(s: &str) -> Vec<String> {
    let trimmed = s
        .trim()
        .trim_start_matches('[')
        .trim_end_matches(']');
    trimmed
        .split(',')
        .map(|t| t.trim().trim_matches('"').to_string())
        .filter(|t| !t.is_empty())
        .collect()
}

fn extract_trigger_phrase(description: &str) -> Vec<String> {
    let marker = "Trigger on:";
    let idx = match description.find(marker) {
        Some(i) => i.saturating_add(marker.len()),
        None => return Vec::new(),
    };
    let tail = match description.get(idx..) {
        Some(t) => t,
        None => return Vec::new(),
    };
    let end = match tail.find('.') {
        Some(i) => i,
        None => tail.len(),
    };
    let phrase = match tail.get(..end) {
        Some(p) => p,
        None => return Vec::new(),
    };
    phrase
        .split(',')
        .map(|t| t.trim().to_lowercase())
        .filter(|t| !t.is_empty())
        .collect()
}

const CROSS_INVOKE_HEADER: &str = "CROSS_INVOKE";
const INVOKE_PREFIX: &str = "INVOKE ";

/// Parse `CROSS_INVOKE` directives from a SKILL.md body.
/// Matches lines inside a `CROSS_INVOKE` block like: `  For X → INVOKE skill-name`.
fn parse_cross_invoke(body: &str) -> Vec<String> {
    let mut targets: Vec<String> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let mut in_section = false;
    for line in body.lines() {
        let trimmed = line.trim();
        if trimmed == CROSS_INVOKE_HEADER {
            in_section = true;
            continue;
        }
        if !in_section {
            continue;
        }
        if trimmed.is_empty() {
            in_section = false;
            continue;
        }
        match trimmed.find(INVOKE_PREFIX) {
            None => { in_section = false; }
            Some(pos) => {
                let offset = pos.saturating_add(INVOKE_PREFIX.len());
                if let Some(after) = trimmed.get(offset..)
                    && let Some(skill_raw) = after.split_whitespace().next()
                {
                    let skill = skill_raw.trim_end_matches('.');
                    if !skill.is_empty() && seen.insert(skill.to_string()) {
                        targets.push(skill.to_string());
                    }
                }
            }
        }
    }
    targets
}

/// Upsert skill entities and `cross_invoke` edges into kavach-db.
/// Silently skips on db failure — graph indexing is advisory, not blocking.
fn index_skill_graph(pairs: &[(String, Vec<String>)]) {
    let conn = match open_default() {
        Ok(c) => c,
        Err(_) => return,
    };
    for (source_id, targets) in pairs {
        let base = source_id.trim_end_matches("/SKILL.md");
        let source_name = match base.split('/').next_back() {
            Some(n) => n,
            None => base,
        };
        let from_id = match graph_entity::upsert_entity(&conn, "skill", source_name, None) {
            Ok(id) => id,
            Err(_) => continue,
        };
        for target in targets {
            let to_id = match graph_entity::upsert_entity(&conn, "skill", target, None) {
                Ok(id) => id,
                Err(_) => continue,
            };
            let _ = graph::add_relationship(&conn, from_id, to_id, "cross_invoke", 1.0);
        }
    }
}

fn short_hash(hash: &str) -> &str {
    match hash.get(..16) {
        Some(s) => s,
        None => hash,
    }
}

fn hash_bytes(bytes: &[u8]) -> String {
    // BLAKE3: 4x faster than SHA-256 for RAG tree source hashing.
    blake3::hash(bytes).to_hex().to_string()
}

fn handle_query(tree_path: &str, file: &str, text: &str, intent: &str, top_k: usize) -> i32 {
    let tree = match load_tree(tree_path) {
        Ok(t) => t,
        Err(code) => return code,
    };
    let matcher = Matcher::new(&tree).with_top_k(top_k);
    let query = Query::new(file, text, intent);
    let hits = matcher.run(&query);
    let mut out = io::stdout().lock();
    for hit in &hits {
        let line = format!("{}\t{}\t{}", hit.score.0, hit.node_id, hit.title);
        if writeln!(out, "{line}").is_err() {
            return 1;
        }
    }
    0
}

fn handle_apply(tree_path: &str, responses_path: &str) -> i32 {
    let mut tree = match load_tree(tree_path) {
        Ok(t) => t,
        Err(code) => return code,
    };
    let body = match fs::read_to_string(responses_path) {
        Ok(b) => b,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "read '{responses_path}' failed: {e}");
            return 1;
        }
    };
    let mut responses: Vec<SummaryResponse> = Vec::new();
    for (idx, line) in body.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }
        match serde_json::from_str::<SummaryResponse>(line) {
            Ok(r) => responses.push(r),
            Err(e) => {
                let _ = writeln!(
                    io::stderr().lock(),
                    "parse response line {} failed: {e}",
                    idx.saturating_add(1)
                );
                return 1;
            }
        }
    }
    apply_summaries(&mut tree.root, &responses);
    let json = match tree.to_json_pretty() {
        Ok(j) => j,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "serialize failed: {e}");
            return 1;
        }
    };
    if writeln!(io::stdout().lock(), "{json}").is_err() {
        return 1;
    }
    0
}

fn handle_pending(tree_path: &str) -> i32 {
    let tree = match load_tree(tree_path) {
        Ok(t) => t,
        Err(code) => return code,
    };
    let reqs = pending_requests(&tree.root);
    let mut out = io::stdout().lock();
    for req in &reqs {
        let line = match req.to_line() {
            Ok(s) => s,
            Err(e) => {
                let _ = writeln!(io::stderr().lock(), "serialize failed: {e}");
                return 1;
            }
        };
        if writeln!(out, "{line}").is_err() {
            return 1;
        }
    }
    0
}

fn load_tree(path: &str) -> Result<RagTree, i32> {
    let body = match fs::read_to_string(path) {
        Ok(b) => b,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "read '{path}' failed: {e}");
            return Err(1);
        }
    };
    match RagTree::from_json(&body) {
        Ok(t) => Ok(t),
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "parse '{path}' failed: {e}");
            Err(1)
        }
    }
}
