mod cli;
mod cmd;

use clap::Parser;

fn main() {
    let args = cli::Cli::parse();
    let code = cmd::dispatch(args.command);
    std::process::exit(code);
}
