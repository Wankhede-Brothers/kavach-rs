use clap::Subcommand;

#[derive(Subcommand)]
pub enum MonolithAction {
    /// Scan a directory for monolith files using Tarjan SCC + mixed-concerns detection.
    /// Reports circular dependency clusters and files that should be split.
    Scan {
        /// Root directory to scan (defaults to current working directory)
        #[arg(long, default_value = ".")]
        dir: String,
        /// Only report files with mixed concerns over the line threshold (skip SCC-only output)
        #[arg(long)]
        mixed_only: bool,
    },
}
