// hub: clap CLI entry point — Cli struct and Commands enum are intentionally here
use clap::{Parser, Subcommand};

mod db;
mod monolith;
mod rag;
mod rules;
mod session;
mod tailwind_plus;

pub use db::DbAction;
pub use monolith::MonolithAction;
pub use rag::RagAction;
pub use rules::RulesAction;
pub use session::SessionAction;
pub use tailwind_plus::TailwindPlusAction;

#[derive(Parser)]
#[command(name = "kavach", about = "Kavach — Claude Code enforcement hooks")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,
}

#[derive(Subcommand)]
pub enum Commands {
    /// Show session status and enforcement state
    Status,
    /// Run a gate hook (called by Claude Code hooks)
    Gates {
        /// Gate name (e.g. pre-write, post-write, pre-tool, post-tool, intent)
        gate_name: String,
        /// Read JSON input from stdin (hook mode)
        #[arg(long)]
        hook: bool,
        /// Verify a prompt against a gate without hook mode (dry-run)
        #[arg(long)]
        verify: Option<String>,
    },
    /// Manage session lifecycle
    Session {
        #[command(subcommand)]
        action: SessionAction,
    },
    /// Manage rules and skills
    Rules {
        #[command(subcommand)]
        action: RulesAction,
    },
    /// Manage kavach-db (SQLite memory bank)
    Db {
        #[command(subcommand)]
        action: DbAction,
    },
    /// Build and query vectorless RAG trees
    Rag {
        #[command(subcommand)]
        action: RagAction,
    },
    /// Ask the advisor (Haiku executor + Opus advisor)
    Ask {
        /// Prompt to send to the advisor
        prompt: String,
        /// Maximum advisor consultations (default 3)
        #[arg(long, default_value_t = 3)]
        max_uses: u8,
    },
    /// Scan for monolith files and circular dependency clusters
    Monolith {
        #[command(subcommand)]
        action: MonolithAction,
    },
    /// Build and query the Tailwind Plus component index
    TailwindPlus {
        #[command(subcommand)]
        action: TailwindPlusAction,
    },
}
