use clap::Subcommand;

#[derive(Subcommand)]
pub enum DbAction {
    /// Register a project with absolute path
    Register {
        /// Project slug (unique identifier)
        #[arg(long)]
        slug: String,
        /// Absolute path to project root
        #[arg(long)]
        path: String,
        /// Tech stack (e.g. "rust|axum")
        #[arg(long)]
        stack: Option<String>,
    },
    /// Register a sub-part within a project
    RegisterPart {
        /// Parent project slug
        #[arg(long)]
        project: String,
        /// Part name (e.g. "backend", "frontend")
        #[arg(long)]
        name: String,
        /// Absolute path to part root
        #[arg(long)]
        path: String,
        /// Part type (backend, frontend, database, mobile, infra, docs, shared, other)
        #[arg(long = "type")]
        part_type: String,
    },
    /// Query memory entries for a project
    Query {
        /// Project slug
        #[arg(long)]
        project: String,
        /// Filter by category (decision, research, pattern, proposal, roadmap)
        #[arg(long)]
        category: Option<String>,
    },
    /// Write a memory entry
    Write {
        /// Project slug
        #[arg(long)]
        project: String,
        /// Category (decision, research, pattern, proposal, roadmap)
        #[arg(long)]
        category: String,
        /// Entry key (unique within project+category)
        #[arg(long)]
        key: String,
        /// Entry title
        #[arg(long)]
        title: String,
        /// Content (reads from stdin if omitted)
        #[arg(long)]
        content: Option<String>,
    },
    /// Sync session state to database
    Sync,
    /// Find project matching an absolute path
    FindProject {
        /// Absolute file or directory path
        #[arg(long)]
        path: String,
    },
    /// Find part matching an absolute path
    FindPart {
        /// Absolute file or directory path
        #[arg(long)]
        path: String,
    },
    /// List all registered projects
    ListProjects,
    /// List parts for a project
    ListParts {
        /// Project slug
        #[arg(long)]
        project: String,
    },
    /// Archive expired memory entries
    Expire,
    /// Append an event to the log
    Event {
        /// Event type (e.g. "file_write", "session_start")
        #[arg(long = "type")]
        event_type: String,
        /// JSON payload
        #[arg(long)]
        payload: Option<String>,
    },
    /// Fetch a single memory entry by key
    Get {
        /// Project slug
        #[arg(long)]
        project: String,
        /// Category (decision, research, pattern, proposal, roadmap)
        #[arg(long)]
        category: String,
        /// Entry key
        #[arg(long)]
        key: String,
        /// Show all metadata (tags, ttl, source, timestamps)
        #[arg(long)]
        full: bool,
    },
    /// Delete events older than N days
    Rotate {
        /// Number of days to retain
        #[arg(long)]
        days: i64,
    },
    /// Show kanban board for a project (todo / in_progress / done)
    Kanban {
        /// Project slug
        #[arg(long)]
        project: String,
    },
    /// Close a kanban roadmap item by key (marks DONE, syncs kanban_cards)
    KanbanClose {
        /// Project slug
        #[arg(long)]
        project: String,
        /// Roadmap entry key to close (e.g. phase-1-auth)
        #[arg(long)]
        key: String,
    },
    /// Populate the knowledge graph from existing relational data
    PopulateGraph,
    /// Query the knowledge graph — list entities and their edges
    GraphQuery {
        /// Filter by entity type (skill, rule, gate, project, file, memory, session, event_type)
        #[arg(long)]
        entity_type: Option<String>,
        /// Show edges for a specific entity name
        #[arg(long)]
        name: Option<String>,
        /// Max entities to show (default: 20)
        #[arg(long, default_value = "20")]
        limit: usize,
    },
    /// Introspect a local PostgreSQL database — list tables, columns, FKs
    PgIntrospect {
        /// Postgres DSN (e.g. postgres://localhost/mydb)
        #[arg(long)]
        dsn: String,
    },
    /// Find isolated tables (zero incoming + outgoing FK edges)
    PgIsolation {
        /// Postgres DSN
        #[arg(long)]
        dsn: String,
    },
    /// Emit ER diagram in Mermaid format from the live schema
    PgEr {
        /// Postgres DSN
        #[arg(long)]
        dsn: String,
    },
    /// Detect likely missing FKs — columns named `<table>_id` with no declared FK
    PgDrift {
        /// Postgres DSN
        #[arg(long)]
        dsn: String,
    },
    /// Fix sqlx `_sqlx_migrations` checksum drift for one version.
    /// Computes sha384 of the current .sql file and UPDATEs the stored checksum.
    PgFixChecksum {
        /// Postgres DSN
        #[arg(long)]
        dsn: String,
        /// Migration version number (e.g. 36)
        #[arg(long)]
        version: i64,
        /// Path to the migration .sql file whose sha384 replaces the stored checksum
        #[arg(long)]
        file: String,
    },
}
