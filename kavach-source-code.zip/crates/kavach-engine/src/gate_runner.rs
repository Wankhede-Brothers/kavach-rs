use kavach_types::HookInput;

use crate::error::EngineError;
use crate::gates;

/// Dispatch a gate by name. Called by the CLI with parsed HookInput.
/// Each gate handler reads session state, runs checks, and writes
/// JSON response to stdout via kavach_hook helpers.
pub fn run_gate(gate_name: &str, input: &HookInput) -> Result<(), EngineError> {
    match gate_name {
        "pre-write" => gates::pre_write::run(input),
        "post-write" => gates::post_write::run(input),
        "pre-tool" => gates::pre_tool::run(input),
        "post-tool" => gates::post_tool::run(input),
        "intent" => gates::intent::run(input),
        "subagent-start" => gates::subagent::run_start(input),
        "subagent-stop" => gates::subagent::run_stop(input),
        "teammate-idle" => gates::teammate::run_idle(input),
        "task-completed" => gates::teammate::run_task_completed(input),
        "post-tool-failure" => gates::post_tool_failure::run(input),
        "permission" => gates::permission::run(input),
        "notification" => gates::notification::run(input),
        "stop" => gates::stop::run(input),
        "stop-failure" => gates::stop_failure::run(input),
        "permission-request" => gates::permission_request::run(input),
        "session-start" => gates::session_start::run(input),
        "instructions-loaded" => gates::instructions_loaded::run(input),
        "config-change" => gates::config_change::run(input),
        "worktree-create" => gates::worktree_create::run(input),
        "worktree-remove" => gates::worktree_remove::run(input),
        "cwd-changed" => gates::cwd_changed::run(input),
        "file-changed" => gates::file_changed::run(input),
        "task-created" => gates::task_created::run(input),
        "session-end" => gates::session_end::run(input),
        "pre-tool-search" => gates::pre_tool_search::run(input),
        "pre-compact" => gates::pre_compact::run(input),
        "post-compact" => gates::post_compact::run(input),
        "elicitation" => gates::elicitation::run(input),
        "elicitation-result" => gates::elicitation::run_result(input),
        other => Err(EngineError::UnknownGate(other.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_unknown_gate() {
        let input = HookInput::default();
        let err = run_gate("nonexistent", &input).unwrap_err();
        assert!(matches!(err, EngineError::UnknownGate(_)));
    }

    #[test]
    fn test_lifecycle_gates_approve() {
        let input = HookInput::default();
        assert!(run_gate("session-start", &input).is_ok());
        assert!(run_gate("pre-compact", &input).is_ok());
    }

    #[test]
    fn test_new_gates() {
        let input = HookInput::default();
        assert!(run_gate("stop", &input).is_ok());
        assert!(run_gate("notification", &input).is_ok());
        assert!(run_gate("permission", &input).is_ok());
        assert!(run_gate("post-tool-failure", &input).is_ok());
    }

    #[test]
    fn test_new_hook_event_gates() {
        let input = HookInput::default();
        assert!(run_gate("instructions-loaded", &input).is_ok());
        assert!(run_gate("config-change", &input).is_ok());
        assert!(run_gate("worktree-create", &input).is_ok());
        assert!(run_gate("worktree-remove", &input).is_ok());
        assert!(run_gate("session-end", &input).is_ok());
    }

    #[test]
    fn test_compact_and_elicitation_gates() {
        let input = HookInput::default();
        assert!(run_gate("post-compact", &input).is_ok());
        assert!(run_gate("elicitation", &input).is_ok());
        assert!(run_gate("elicitation-result", &input).is_ok());
    }
}
