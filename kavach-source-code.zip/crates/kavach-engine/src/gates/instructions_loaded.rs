use kavach_types::HookInput;

use crate::error::EngineError;
use crate::gates::rules_manifest::active_rules;

/// InstructionsLoaded gate: track which CLAUDE.md files are loaded.
/// Observability only — no blocking capability.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let file_path = &input.file_path;
    let load_reason = &input.load_reason;

    if file_path.is_empty() {
        kavach_hook::exit_silent();
        return Ok(());
    }

    let rules = active_rules();
    let rules_count = rules.len().to_string();
    let context = kavach_hook::context_block(
        "INSTRUCTIONS_LOADED",
        &[
            ("file", file_path),
            ("reason", load_reason),
            ("active_rules", &rules_count),
        ],
    );
    kavach_hook::exit_notification_context(&context);
    Ok(())
}
