use kavach_types::HookInput;

use crate::error::EngineError;

/// Pre-tool search gate: validate WebSearch queries use current year, not stale training year.
/// HARD BLOCK when query contains a year older than current_year.
/// Prevents Claude from searching "Astro 5 2025" when Astro 6 is current and year=2026.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let query = input.get_string("query");
    if query.is_empty() {
        kavach_hook::exit_silent();
        return Ok(());
    }
    let current_year = kavach_hook::current_year();
    if let Some(reason) = check_stale_year_in_query(query, current_year) {
        kavach_hook::exit_pre_tool_deny(&reason);
        return Ok(());
    }
    // Check for stale framework versions from training weights vs actual package.json/Cargo.toml
    let session = kavach_session::get_or_create_session();
    if let Some(reason) = check_stale_version_in_query(query, &session.work_dir) {
        kavach_hook::exit_pre_tool_deny(&reason);
        return Ok(());
    }
    kavach_hook::exit_silent();
    Ok(())
}

/// Returns block reason if query contains a year from 2020..current_year (exclusive).
pub fn check_stale_year_in_query(query: &str, current_year: u32) -> Option<String> {
    for word in query.split_whitespace() {
        let digits: String = word.chars().filter(|c| c.is_ascii_digit()).collect();
        if digits.len() == 4 {
            if let Ok(year) = digits.parse::<u32>() {
                if year >= 2020 && year < current_year {
                    return Some(format!(
                        "STALE_YEAR_BLOCKED: Query contains year {year} but current year is {current_year}.\n\
                         Training weights are stale — do NOT search for old versions.\n\
                         FIX: Replace {year} with {current_year} in your search query."
                    ));
                }
            }
        }
    }
    None
}

/// Block searches referencing older major versions than what's actually installed.
/// Reads ALL deps from package.json and Cargo.toml dynamically — no hardcoded list.
/// E.g., if package.json has `"astro": "^6.1.0"`, blocks `"Astro 5"` in query.
pub fn check_stale_version_in_query(query: &str, work_dir: &str) -> Option<String> {
    if work_dir.is_empty() {
        return None;
    }
    let versions = read_all_dep_versions(work_dir);
    if versions.is_empty() {
        return None;
    }
    let query_lower = query.to_lowercase();
    let words: Vec<&str> = query_lower.split_whitespace().collect();
    for pair in words.windows(2) {
        if let [name_part, version_part] = pair {
            let query_major = match version_part.parse::<u32>() {
                Ok(v) => v,
                Err(_) => continue,
            };
            if query_major == 0 { continue; }
            let clean = name_part.trim_start_matches('@');
            for (dep_name, installed_major) in &versions {
                let dep_lower = dep_name.to_lowercase();
                // Match last path segment for scoped packages (@astrojs/node → node)
                let dep_last = match dep_lower.rsplit('/').next() {
                    Some(s) => s,
                    None => &dep_lower,
                };
                if clean == dep_lower || clean == dep_last || *name_part == dep_lower {
                    if query_major < *installed_major {
                        return Some(format!(
                            "STALE_VERSION_BLOCKED: Query references \"{name_part} {query_major}\" \
                             but {dep_name} {installed_major} is installed.\n\
                             Read package.json/Cargo.toml for actual versions.\n\
                             FIX: Replace \"{name_part} {query_major}\" with \"{name_part} {installed_major}\"."
                        ));
                    }
                }
            }
        }
    }
    None
}

/// Read ALL dependency names + major versions from package.json and Cargo.toml.
/// No hardcoded list — reads every dependency dynamically.
fn read_all_dep_versions(work_dir: &str) -> Vec<(String, u32)> {
    let mut result: Vec<(String, u32)> = Vec::new();
    let base = std::path::Path::new(work_dir);
    // package.json: dependencies + devDependencies
    if let Ok(body) = std::fs::read_to_string(base.join("package.json")) {
        if let Ok(json) = serde_json::from_str::<serde_json::Value>(&body) {
            for section in &["dependencies", "devDependencies"] {
                if let Some(deps) = json.get(*section).and_then(|v| v.as_object()) {
                    for (name, ver) in deps {
                        if let Some(v_str) = ver.as_str() {
                            if let Some(major) = extract_major_version(v_str) {
                                if !result.iter().any(|(n, _)| n == name) {
                                    result.push((name.clone(), major));
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    // Cargo.toml: [dependencies] and [dev-dependencies]
    if let Ok(body) = std::fs::read_to_string(base.join("Cargo.toml")) {
        let mut in_deps = false;
        for line in body.lines() {
            let trimmed = line.trim();
            if trimmed == "[dependencies]" || trimmed == "[dev-dependencies]" {
                in_deps = true;
                continue;
            }
            if trimmed.starts_with('[') { in_deps = false; continue; }
            if !in_deps { continue; }
            if let Some((name, rest)) = trimmed.split_once('=') {
                let name = name.trim();
                let rest = rest.trim().trim_matches('"');
                // Simple: name = "1.2.3"
                if let Some(major) = extract_major_version(rest) {
                    if !result.iter().any(|(n, _)| n == name) {
                        result.push((name.to_string(), major));
                    }
                }
                // Inline table: { version = "1.2" }
                if let Some(ver_pos) = rest.find("version") {
                    let after = match rest.get(ver_pos..) {
                        Some(a) => a,
                        None => continue,
                    };
                    if let Some(q1) = after.find('"') {
                        let inner = match after.get(q1 + 1..) {
                            Some(i) => i,
                            None => continue,
                        };
                        if let Some(q2) = inner.find('"') {
                            if let Some(ver_str) = inner.get(..q2) {
                                if let Some(major) = extract_major_version(ver_str) {
                                    if let Some(entry) = result.iter_mut().find(|(n, _)| n == name) {
                                        entry.1 = major;
                                    } else {
                                        result.push((name.to_string(), major));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    result
}

/// Extract major version from a semver-like string.
/// Handles: "6.1.0", "^6.1.0", "~6.0", ">=6", "6"
fn extract_major_version(version: &str) -> Option<u32> {
    let trimmed = version.trim_start_matches('^')
        .trim_start_matches('~')
        .trim_start_matches(">=")
        .trim_start_matches('>')
        .trim_start_matches('=')
        .trim();
    let first_part = trimmed.split('.').next()?;
    first_part.parse::<u32>().ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_block_stale_year_2025_when_current_2026() {
        let result = check_stale_year_in_query("Astro 5 dashboard 2025", 2026);
        assert!(result.is_some());
    }

    #[test]
    fn should_allow_current_year_query() {
        assert!(check_stale_year_in_query("Astro 6 dashboard 2026", 2026).is_none());
    }

    #[test]
    fn should_allow_future_year() {
        assert!(check_stale_year_in_query("roadmap 2027", 2026).is_none());
    }

    #[test]
    fn should_allow_query_without_year() {
        assert!(check_stale_year_in_query("Astro middleware patterns", 2026).is_none());
    }

    #[test]
    fn should_not_flag_years_before_2020() {
        assert!(check_stale_year_in_query("RFC 1918 private addresses", 2026).is_none());
    }

    #[test]
    fn should_block_stale_2024_when_current_2026() {
        assert!(check_stale_year_in_query("React 18 patterns 2024", 2026).is_some());
    }

    #[test]
    fn test_run_empty_query() {
        let _ = run(&HookInput::default());
    }

    // --- Version detection tests ---

    #[test]
    fn should_extract_major_from_caret_semver() {
        assert_eq!(extract_major_version("^6.1.0"), Some(6));
        assert_eq!(extract_major_version("^19.0.0"), Some(19));
    }

    #[test]
    fn should_extract_major_from_tilde() {
        assert_eq!(extract_major_version("~3.2.1"), Some(3));
    }

    #[test]
    fn should_extract_major_from_bare_version() {
        assert_eq!(extract_major_version("2.0.0"), Some(2));
        assert_eq!(extract_major_version("18"), Some(18));
    }

    #[test]
    fn should_return_none_for_non_version() {
        assert_eq!(extract_major_version("workspace"), None);
        assert_eq!(extract_major_version("{ path ="), None);
    }

    #[test]
    fn should_block_stale_version_when_newer_installed() {
        // Simulate: query says "astro 5" but installed is major 6
        let versions = vec![("astro".to_string(), 6u32)];
        // Direct test of matching logic
        let query = "Astro 5 dashboard redesign";
        let lower = query.to_lowercase();
        let words: Vec<&str> = lower.split_whitespace().collect();
        let mut blocked = false;
        for pair in words.windows(2) {
            if let [name, ver] = pair {
                if let Ok(qm) = ver.parse::<u32>() {
                    for (dep, im) in &versions {
                        if *name == dep.to_lowercase() && qm < *im {
                            blocked = true;
                        }
                    }
                }
            }
        }
        assert!(blocked);
    }

    #[test]
    fn should_not_block_current_version() {
        let result = check_stale_version_in_query("Astro 6 routing", "/nonexistent");
        assert!(result.is_none());
    }

    #[test]
    fn should_not_block_when_no_workdir() {
        assert!(check_stale_version_in_query("React 17 hooks", "").is_none());
    }
}
