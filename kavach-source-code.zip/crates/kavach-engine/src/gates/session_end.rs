use kavach_types::HookInput;

use crate::error::EngineError;

/// SessionEnd gate: final cleanup and memory sync.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let reason = if input.reason.is_empty() { "normal" } else { &input.reason };

    let mut session = kavach_session::get_or_create_session();
    session.set_task("session", "ended");
    let _ = session.save();
    let context = kavach_hook::context_block(
        "SESSION_END",
        &[
            ("why", reason),
            ("t", &session.turn_count.to_string()),
        ],
    );

    super::event_log::log_session(&session.session_id, "session_end", &session.model_id, &session.project);

    kavach_hook::exit_session_end(&context);
    Ok(())
}
