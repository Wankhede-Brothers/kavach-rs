use kavach_types::HookInput;

use crate::error::EngineError;
use crate::gates::{pre_tool_bash, pre_tool_read, pre_tool_search, pre_tool_skill, pre_tool_task};

/// Pre-tool umbrella gate: bash blocklist + read validation + subagent budget.
/// Runs before any tool use (except Write/Edit which go through pre-write).
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    match input.tool_name.as_str() {
        "Bash" => pre_tool_bash::handle_bash(input),
        "Read" => pre_tool_read::handle_read(input),
        "Task" => pre_tool_task::handle_task(input),
        "Skill" => pre_tool_skill::handle_skill(input),
        "WebSearch" | "WebFetch" => pre_tool_search::run(input),
        _ => {
            let mut session = kavach_session::get_or_create_session();
            let cfg = kavach_config::load_gates_config();
            // Hard block Agent tool when research required but not done.
            // Agent spawns can generate code from training weights in subagent context
            // where pre-write research gate is exempted for subagents.
            if input.tool_name == "Agent"
                && cfg.research.enabled && cfg.research.require_before_code
                && !session.research_done
                && session.intent_risk != "low"
            {
                let topic = if session.research_topic.is_empty() {
                    "relevant topic"
                } else {
                    &session.research_topic
                };
                let reason = format!(
                    "RESEARCH GATE: WebSearch required before spawning agents. \
                     Topic: {topic}. Tabula rasa: do not trust training weights — \
                     WebSearch first, then delegate."
                );
                kavach_hook::exit_pre_tool_deny(&reason);
                return Ok(());
            }
            // Advisory: remind model about pending research — fire once per intent window.
            if cfg.research.enabled && !session.research_done
                && !session.research_topic.is_empty()
                && !session.research_advisory_sent
            {
                let topic = session.research_topic.clone();
                session.research_advisory_sent = true;
                let _ = session.save();
                let ctx = format!(
                    "[RESEARCH_PENDING] WebSearch \"{topic}\" before writing code. \
                     Do not generate code from training weights."
                );
                kavach_hook::exit_pre_tool_allow(Some(&ctx));
                return Ok(());
            }
            kavach_hook::exit_pre_tool_allow(None);
            Ok(())
        }
    }
}
