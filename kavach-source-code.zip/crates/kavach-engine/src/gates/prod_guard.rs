/// Production operations guard — warns on high-risk commands.
/// Non-blocking: injects context warning, does not deny.
/// Check if command is a production operation that warrants a warning.
/// Returns Some(warning) for: psql on prod, doctl/aws/gcloud create,
/// git push to main/master, database migrations on non-local DBs.
pub fn check_prod_ops(command: &str) -> Option<String> {
    let lower = command.to_lowercase();

    // Production database operations
    if lower.contains("psql") && !lower.contains("localhost") && !lower.contains("127.0.0.1")
        && (lower.contains("-f ") || lower.contains("migrate") || lower.contains("alter ")
            || lower.contains("drop ") || lower.contains("create table"))
    {
        return Some(
            "[PROD_OPS_WARNING] Production database modification detected. \
             Confirm with user before applying migrations or schema changes \
             to non-local databases."
                .to_string(),
        );
    }

    // Cloud infrastructure creation
    if lower.contains("doctl apps create")
        || lower.contains("doctl apps update")
        || lower.contains("aws ecs create")
        || lower.contains("gcloud run deploy")
        || lower.contains("terraform apply")
        || lower.contains("pulumi up")
    {
        return Some(
            "[PROD_OPS_WARNING] Cloud infrastructure creation/modification detected. \
             Confirm with user before creating or modifying cloud resources."
                .to_string(),
        );
    }

    // Git push to main/master
    if lower.contains("git push") && (lower.contains(" main") || lower.contains(" master")) {
        return Some(
            "[PROD_OPS_WARNING] Pushing to main/master branch detected. \
             Confirm with user before pushing to production branch."
                .to_string(),
        );
    }

    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_psql_prod_migration_warned() {
        assert!(check_prod_ops("psql \"$DATABASE_URL\" -f migrations/001.sql").is_some());
        assert!(check_prod_ops("source .env && psql $DB -f migrate.sql").is_some());
    }

    #[test]
    fn test_psql_local_ok() {
        assert!(check_prod_ops("psql localhost -f test.sql").is_none());
        assert!(check_prod_ops("psql 127.0.0.1:5432 -f test.sql").is_none());
    }

    #[test]
    fn test_psql_read_ok() {
        assert!(check_prod_ops("psql \"$DATABASE_URL\" -c \"SELECT 1\"").is_none());
    }

    #[test]
    fn test_doctl_create_warned() {
        assert!(check_prod_ops("doctl apps create --spec app.yaml").is_some());
        assert!(check_prod_ops("doctl apps update $ID --spec app.yaml").is_some());
    }

    #[test]
    fn test_git_push_main_warned() {
        assert!(check_prod_ops("git push origin main").is_some());
        assert!(check_prod_ops("git push origin master").is_some());
    }

    #[test]
    fn test_git_push_branch_ok() {
        assert!(check_prod_ops("git push origin feature/foo").is_none());
    }

    #[test]
    fn test_terraform_warned() {
        assert!(check_prod_ops("terraform apply -auto-approve").is_some());
    }

    #[test]
    fn test_normal_commands_ok() {
        assert!(check_prod_ops("cargo test").is_none());
        assert!(check_prod_ops("git status").is_none());
        assert!(check_prod_ops("ls -la").is_none());
    }
}
