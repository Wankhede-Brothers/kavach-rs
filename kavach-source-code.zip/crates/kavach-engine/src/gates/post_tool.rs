use kavach_types::HookInput;

use crate::error::EngineError;
use crate::gates::{post_tool_bash, post_tool_read, post_tool_research, post_tool_task, result_trim};

/// Post-tool umbrella gate: context injection + research tracking + skill tracking.
/// Single session instance passed to all sub-handlers to prevent double-load race.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let mut session = kavach_session::get_or_create_session();
    session.increment_turn();
    session.clear_failure();

    // Check trimming FIRST — if needed, skip handlers (they write to stdout)
    // and do state tracking inline. Only ONE JSON output per hook invocation.
    if let Some(trimmed_output) = check_trim(input) {
        // Inline state tracking without calling handlers (which write stdout).
        track_state_only(input, &mut session);
        let context = kavach_hook::context_block("POST_TOOL:TRIMMED", &[]);
        kavach_hook::exit_post_tool_trimmed(&trimmed_output, &context);
        return Ok(());
    }

    match input.tool_name.as_str() {
        "WebSearch" | "WebFetch" => post_tool_research::handle(input, &mut session),
        "Skill" => handle_skill_done(input, &mut session),
        "Task" => post_tool_task::handle(input, &session),
        "Bash" => post_tool_bash::handle(input, &mut session),
        "Read" | "Glob" | "Grep" => post_tool_read::handle(input, &mut session),
        _ => {
            kavach_hook::exit_silent();
            Ok(())
        }
    }
}

/// Check if tool output should be trimmed to save context budget.
fn check_trim(input: &HookInput) -> Option<String> {
    let response_text = input.tool_response.as_ref()
        .and_then(|r| r.get("output"))
        .and_then(|v| v.as_str())
        .unwrap_or("");
    if response_text.is_empty() {
        return None;
    }
    match input.tool_name.as_str() {
        "Bash" => result_trim::trim_bash_output(response_text),
        "Glob" => result_trim::trim_glob_output(response_text),
        _ => None,
    }
}

/// Minimal state tracking when trimming short-circuits normal handler flow.
/// Does NOT write to stdout — only updates session state.
fn track_state_only(input: &HookInput, session: &mut kavach_session::SessionState) {
    match input.tool_name.as_str() {
        "WebSearch" | "WebFetch" => {
            session.mark_research_done();
        }
        "Skill" => {
            let skill_name = input.get_string("skill");
            if !skill_name.is_empty() {
                session.record_skill_invoked(skill_name);
            }
        }
        "Bash" => {
            let command = input.get_string("command");
            if post_tool_bash::is_test_command_pub(command) {
                session.clear_test_pending();
            }
        }
        _ => {}
    }
}

/// Track skill invocation for enforcement gate.
fn handle_skill_done(
    input: &HookInput,
    session: &mut kavach_session::SessionState,
) -> Result<(), EngineError> {
    let skill_name = input.get_string("skill");
    if !skill_name.is_empty() {
        session.record_skill_invoked(skill_name);

        let context = kavach_hook::context_block(
            "POST_TOOL:SKILL",
            &[("skill", skill_name)],
        );
        kavach_hook::exit_post_tool_context(&context);
    } else {
        kavach_hook::exit_silent();
    }
    Ok(())
}
