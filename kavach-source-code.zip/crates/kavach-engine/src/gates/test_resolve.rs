use kavach_session::SessionState;

/// Check if a write to `file_path` is writing a test file.
pub fn is_test_file_write(file_path: &str) -> bool {
    file_path.contains("_test")
        || file_path.contains("test_")
        || file_path.contains("/tests/")
        || file_path.ends_with("_tests.rs")
        || file_path.contains(".test.ts")
        || file_path.contains(".spec.ts")
}

/// Check if the written content adds inline test coverage to the source file.
///
/// When a developer adds `#[cfg(test)]` directly into `foo.rs`, the file is
/// both source and test. `is_test_file_write` returns false for it (no test
/// marker in the path), so without this check the post-write gate re-adds the
/// file to `test_files_pending` — the root of the circular deadlock.
pub fn content_adds_inline_tests(content: &str) -> bool {
    content.contains("#[cfg(test)]")
}

/// Remove files from pending that match this test file's coverage scope.
pub fn resolve_pending_for_test_file(session: &mut SessionState, test_path: &str) {
    let source_hint = test_path
        .replace("_tests.rs", ".rs")
        .replace("_test.rs", ".rs")
        .replace(".test.ts", ".ts")
        .replace(".spec.ts", ".ts");
    session.test_files_pending.retain(|f| !source_hint.contains(f.as_str()) && !f.contains(&source_hint));
    if session.test_files_pending.is_empty() {
        session.test_nudge_count = 0;
    }
    let _ = session.save();
}

#[cfg(test)]
mod tests {
    use super::*;
    use kavach_session::SessionState;

    #[test]
    fn test_is_test_file() {
        assert!(is_test_file_write("src/foo_tests.rs"));
        assert!(is_test_file_write("src/foo.test.ts"));
        assert!(!is_test_file_write("src/foo.rs"));
    }

    #[test]
    fn test_resolve_clears_pending() {
        let mut s = SessionState::default();
        s.test_files_pending.push("src/foo.rs".into());
        resolve_pending_for_test_file(&mut s, "src/foo_tests.rs");
        assert!(s.test_files_pending.is_empty());
    }

    #[test]
    fn should_detect_inline_tests_when_cfg_test_present() {
        assert!(content_adds_inline_tests("#[cfg(test)]\nmod tests {}"));
    }

    #[test]
    fn should_not_detect_inline_tests_when_cfg_test_absent() {
        assert!(!content_adds_inline_tests("pub fn foo() {}"));
    }

    #[test]
    fn should_resolve_pending_when_inline_tests_written_to_pending_file() {
        let mut s = SessionState::default();
        s.test_files_pending.push("src/bar.rs".into());
        s.test_nudge_count = 12;
        // Simulates: file_path == "src/bar.rs", content has #[cfg(test)]
        resolve_pending_for_test_file(&mut s, "src/bar.rs");
        assert!(s.test_files_pending.is_empty());
        assert_eq!(s.test_nudge_count, 0);
    }

    #[test]
    fn should_not_increment_nudge_when_file_already_pending() {
        let mut s = SessionState::default();
        s.add_test_pending("src/baz.rs");
        let count_before = s.test_nudge_count;
        // Adding same file again must not bump nudge count
        s.add_test_pending("src/baz.rs");
        assert_eq!(s.test_nudge_count, count_before);
    }
}
