use kavach_types::HookInput;

use crate::error::EngineError;

/// Classify failure type from error details for smart stop-gate decisions.
fn classify_failure(error: &str) -> &'static str {
    let lower = error.to_lowercase();
    if lower.contains("rate limit")
        || lower.contains("timeout")
        || lower.contains("timed out")
        || lower.contains("connection refused")
        || lower.contains("temporarily unavailable")
        || lower.contains("503")
        || lower.contains("429")
    {
        return "transient";
    }
    if lower.contains("not found")
        || lower.contains("no such file")
        || lower.contains("does not exist")
        || lower.contains("404")
    {
        return "not_found";
    }
    if lower.contains("permission denied")
        || lower.contains("access denied")
        || lower.contains("forbidden")
        || lower.contains("401")
        || lower.contains("403")
    {
        return "permission";
    }
    "validation"
}

/// Generic action guidance per failure type — used when no pattern matches.
fn action_for_type(failure_type: &str) -> &'static str {
    match failure_type {
        "transient" => "RETRY: Transient failure — wait briefly, then retry the same command.",
        "not_found" => "ADAPT: Resource not found — this is a valid result, not an error. Adjust approach.",
        "permission" => "ESCALATE: Access denied — try alternative tool or ask user for access.",
        _ => "DIAGNOSE: Read the error. FIX: Correct the cause. RETRY: Run again.",
    }
}

/// Build a `[SELF_EVOLVE]` advisory block for novel errors.
/// Instructs Claude to research the error, resolve it, then write the fix
/// back to kavach-db so it becomes an autonomous Tier 1 pattern.
fn self_evolve_block(error: &str, tool_name: &str, failure_type: &str) -> String {
    format!(
        "[SELF_EVOLVE]\n\
         status: novel_error\n\
         tool: {tool_name}\n\
         failure_type: {failure_type}\n\
         error_fingerprint: {tokens}\n\
         action: Research this error class. Find the root cause, best-fit algorithm/DSA for \
         detection, and optimal fix strategy. Then write back:\n\
         \x20 kavach db write --project <slug> --category gate_pattern \\\n\
         \x20   --key \"fix-{tool_name}-<short-slug>\" \\\n\
         \x20   --title \"<imperative rewrite of block message>\" \\\n\
         \x20   --content \"fix_strategy: <strategy>\\ndsa_rationale: <why this algorithm>\"\n\
         reason: Unrecognised error — storing fix enables autonomous resolution next occurrence.\n",
        tokens = kavach_db::gate_patterns::tokenize(error),
    )
}

/// PostToolUseFailure gate: two-tier self-evolving error handler.
///
/// Tier 1 (autonomous): known pattern found in gate_patterns — inject cached
///   fix_strategy + imperative_rewrite directly. Zero research needed.
/// Tier 2 (research): novel error — classify, inject [SELF_EVOLVE] advisory,
///   seed the pattern store so occurrence count accumulates toward promotion.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let tool_name = &input.tool_name;
    let error_text = if input.error.is_empty() {
        &input.reason
    } else {
        &input.error
    };

    let failure_type = classify_failure(error_text);
    let mut session = kavach_session::get_or_create_session();
    session.increment_turn();
    session.record_failure_typed(tool_name, failure_type);
    let turn_str = session.turn_count.to_string();
    let retryable = if failure_type == "transient" { "true" } else { "false" };

    // --- Tier 1: look up autonomous pattern ---
    let autonomous = kavach_db::open_default()
        .ok()
        .and_then(|conn| {
            let pid = kavach_db::projects::get_by_slug(&conn, &session.project)
                .ok()
                .map(|p| p.id)?;
            kavach_db::gate_patterns::find_autonomous(&conn, pid, error_text, tool_name)
                .ok()
                .flatten()
                .map(|pat| (conn, pid, pat))
        });

    let context = if let Some((conn, pid, pat)) = autonomous {
        // Tier 1: inject cached fix + imperative rewrite. Update occurrence count.
        kavach_db::projections::project_error_to_pattern(
            &conn, pid, error_text,
            &pat.fix_strategy, &pat.imperative_rewrite, &pat.dsa_rationale,
            tool_name, "post_tool_failure",
        );
        let mut ctx = kavach_hook::context_block(
            "TOOL_FAILURE",
            &[
                ("tool", tool_name),
                ("t", &turn_str),
                ("err", failure_type),
                ("retry", retryable),
                ("tier", "autonomous"),
                ("fix", &pat.fix_strategy),
                ("action", &pat.imperative_rewrite),
                ("n", &pat.occurrence_count.to_string()),
            ],
        );
        ctx.push('\n');
        ctx.push_str(&format!(
            "[DSA_RATIONALE]\n{}\n",
            pat.dsa_rationale
        ));
        ctx
    } else {
        // Tier 2: novel error — seed pattern store, inject SELF_EVOLVE block.
        let action = action_for_type(failure_type);
        super::event_log::log_tool_failure(
            &session.session_id,
            tool_name,
            error_text,
            action,  // preliminary fix_strategy until Claude researches
            "",      // imperative_rewrite unknown until research completes
            "",      // dsa_rationale unknown until research completes
            "post_tool_failure",
            &session.project,
        );
        let mut ctx = kavach_hook::context_block(
            "TOOL_FAILURE",
            &[
                ("tool", tool_name),
                ("t", &turn_str),
                ("err", failure_type),
                ("retry", retryable),
                ("tier", "research"),
                ("action", action),
            ],
        );
        ctx.push('\n');
        ctx.push_str(&self_evolve_block(error_text, tool_name, failure_type));
        ctx
    };

    kavach_hook::exit_post_tool_failure_context(&context);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classify_transient() {
        assert_eq!(classify_failure("rate limit exceeded"), "transient");
        assert_eq!(classify_failure("connection timed out"), "transient");
    }

    #[test]
    fn classify_not_found() {
        assert_eq!(classify_failure("No such file or directory"), "not_found");
        assert_eq!(classify_failure("resource does not exist"), "not_found");
    }

    #[test]
    fn classify_permission() {
        assert_eq!(classify_failure("permission denied"), "permission");
        assert_eq!(classify_failure("403 Forbidden"), "permission");
    }

    #[test]
    fn classify_validation() {
        assert_eq!(classify_failure("invalid argument"), "validation");
        assert_eq!(classify_failure("syntax error"), "validation");
    }

    #[test]
    fn self_evolve_block_contains_fingerprint() {
        let block = self_evolve_block("source .env loads secret values", "Bash", "validation");
        assert!(block.contains("[SELF_EVOLVE]"));
        assert!(block.contains("novel_error"));
        assert!(block.contains("env")); // tokenized fingerprint present
    }

    #[test]
    fn run_exits_without_panic_on_default_input() {
        let input = HookInput {
            tool_name: "Bash".into(),
            error: "No such file or directory".into(),
            ..Default::default()
        };
        assert!(run(&input).is_ok());
    }
}
