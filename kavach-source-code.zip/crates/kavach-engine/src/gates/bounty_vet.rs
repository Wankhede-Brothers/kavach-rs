//! Cargo-vet gate: check for unvetted crates if cargo-vet is installed.

use std::process::Command;

/// Check for unvetted crates. Returns Some(block) if issues found.
pub fn check(work_dir: &str) -> Option<String> {
    let output = Command::new("cargo")
        .args(["vet", "--output-format", "json"])
        .current_dir(work_dir)
        .output();

    let output = match output {
        Ok(o) => o,
        Err(_) => return None, // cargo-vet not installed
    };

    if output.status.success() {
        return None; // all crates vetted
    }

    let stderr = String::from_utf8_lossy(&output.stderr);
    if stderr.contains("not found")
        || stderr.contains("no such subcommand")
        || stderr.contains("no such command")
    {
        return None; // cargo-vet not installed
    }

    Some(format!(
        "BOUNTY_VET_WARNING: Unvetted crates detected.\n  Run `cargo vet` for details.\n  {stderr}"
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn returns_none_for_bad_dir() {
        assert!(check("/tmp/no_such_workspace_ever").is_none());
    }

    #[test]
    fn runs_without_panic() {
        let workspace = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent().and_then(|p| p.parent());
        if let Some(root) = workspace {
            let _ = check(&root.to_string_lossy());
        }
    }
}
