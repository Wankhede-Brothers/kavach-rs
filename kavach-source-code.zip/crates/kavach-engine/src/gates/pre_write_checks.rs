use kavach_types::HookInput;

/// Extract context from write operation for chain verification.
pub fn extract_write_context(input: &HookInput) -> String {
    let file_path = input.get_string("file_path");
    let content = input.get_string("content");
    let old_str = input.get_string("old_string");
    let new_str = input.get_string("new_string");
    let mut ctx = format!("Writing to {file_path}");
    if !content.is_empty() {
        let preview: String = content.chars().take(200).collect();
        ctx.push_str(&format!(" content: {preview}"));
    }
    if !old_str.is_empty() || !new_str.is_empty() {
        ctx.push_str(" (edit operation)");
    }
    ctx
}

/// Check if file is a code file (delegates to patterns).
pub fn is_code_write(path: &str) -> bool {
    kavach_patterns::is_code_file(path)
}

/// Detect bulk checkbox changes in plan/markdown files.
/// Returns Some(warning) if content has 10+ checked items (`- [x]`)
/// being added in a single write to a plan-like file.
pub fn detect_bulk_checkbox(path: &str, content: &str, new_str: &str) -> Option<String> {
    if !path.ends_with(".md") {
        return None;
    }
    let text = if !content.is_empty() { content } else { new_str };
    let checked_count = text.matches("- [x]").count() + text.matches("- [X]").count();
    if checked_count >= 10 {
        return Some(format!(
            "[BULK_CHECKBOX_WARNING] {checked_count} checked items (`- [x]`) detected \
             in a single write to {path}. Plan checkboxes must be verified \
             individually against code before checking. Bulk-checking is forbidden."
        ));
    }
    None
}

/// Check if a file path is a test file or exempt from test enforcement.
/// Test files, configs, docs, and non-code files bypass the test gate.
pub fn is_test_or_exempt(path: &str) -> bool {
    if !is_code_write(path) {
        return true;
    }
    let test_patterns = ["_tests.rs", "_test.rs", "tests/", "test_"];
    test_patterns.iter().any(|pat| path.contains(pat))
}

/// Build the approval context TOON block for pre-write gate.
pub fn build_approval_context(
    _tool_name: &str,
    toon: &str,
    session: &mut kavach_session::SessionState,
) -> String {
    let mut context = kavach_hook::context_block("PRE_WRITE", &[("status", "allow")]);
    if !toon.is_empty() {
        context.push_str(toon);
    }
    let module_ctx = session.inject_modules_once(&["zero-stubs", "dace"]);
    context.push_str(&module_ctx);
    context
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_write_context() {
        let input = HookInput {
            tool_input: Some(std::collections::HashMap::from([
                ("file_path".into(), serde_json::json!("src/main.rs")),
                ("content".into(), serde_json::json!("fn main() {}")),
            ])),
            ..Default::default()
        };
        let ctx = extract_write_context(&input);
        assert!(ctx.contains("src/main.rs"));
        assert!(ctx.contains("fn main"));
    }

    #[test]
    fn test_is_code_write() {
        assert!(is_code_write("src/main.rs"));
        assert!(!is_code_write("README.md"));
    }

    #[test]
    fn test_bulk_checkbox_warned() {
        let many_checked = "- [x] a\n".repeat(15);
        assert!(detect_bulk_checkbox("plan.md", &many_checked, "").is_some());
    }

    #[test]
    fn test_bulk_checkbox_few_ok() {
        let few = "- [x] a\n- [x] b\n- [x] c\n";
        assert!(detect_bulk_checkbox("plan.md", few, "").is_none());
    }

    #[test]
    fn test_bulk_checkbox_non_md_ok() {
        let many = "- [x] a\n".repeat(20);
        assert!(detect_bulk_checkbox("src/main.rs", &many, "").is_none());
    }

    #[test]
    fn test_bulk_checkbox_edit_new_str() {
        let many = "- [X] done\n".repeat(12);
        assert!(detect_bulk_checkbox("docs/plan.md", "", &many).is_some());
    }

    #[test]
    fn test_is_test_or_exempt() {
        assert!(is_test_or_exempt("src/gates/intent_tests.rs"));
        assert!(is_test_or_exempt("tests/integration.rs"));
        assert!(is_test_or_exempt("Cargo.toml"));
        assert!(is_test_or_exempt("README.md"));
        assert!(is_test_or_exempt("CLAUDE.md"));
        assert!(!is_test_or_exempt("src/gates/intent.rs"));
    }
}
