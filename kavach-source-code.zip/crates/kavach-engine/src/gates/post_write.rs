use kavach_types::HookInput;

use crate::error::EngineError;
use crate::gates::post_write_checks::{read_written_content, run_content_quality_checks};

/// Post-write umbrella gate: antiprod scan + quality + memory sync.
/// Runs after Write/Edit/NotebookEdit tools complete.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let file_path = input.get_string("file_path");
    let mut context_parts: Vec<String> = Vec::new();

    // 1a. Anti-production pattern scan (P0-P3)
    let content = read_written_content(input);
    if !content.is_empty() && !file_path.is_empty() {
        let violations = kavach_patterns::detect_antiprod(file_path, &content);
        if !violations.is_empty() {
            let fix_ctx = super::fix_instructions::generate_fix_instructions(
                &violations, file_path,
            );
            let has_p0 = violations.iter().any(|v| {
                matches!(v.level, kavach_patterns::AntiProdLevel::P0MockData)
            });
            if has_p0 {
                kavach_hook::exit_post_tool_block(
                    "P0 violation detected — fix required before continuing",
                    &fix_ctx,
                );
                return Ok(());
            }
            context_parts.push(fix_ctx);
        }
    }

    // 1b. Content quality: assumptions + hallucinations + completion claims
    run_content_quality_checks(&content, &mut context_parts);

    // 2. Track file + advance turn + clear failure on successful write
    let mut session = kavach_session::get_or_create_session();
    session.increment_turn();
    session.clear_failure();
    // Clear subagent action pending — parent is writing code (acting on findings)
    if session.subagent_action_pending {
        session.clear_subagent_action();
    }
    if !file_path.is_empty() {
        session.add_file_modified(file_path);
        // File edits count as active progress — reset the db-write overdue clock.
        // The stop gate threshold is 10 turns; coding activity should not trigger
        // the overdue block mid-implementation. Explicit kavach db write calls also
        // reset this (post_tool_bash.rs), so both paths stay in sync.
        session.last_db_write_turn = session.turn_count;
    }

    // 3. Test coverage detection — soft nudge loop
    if super::test_resolve::is_test_file_write(file_path) {
        super::test_resolve::resolve_pending_for_test_file(&mut session, file_path);
    } else if super::test_resolve::content_adds_inline_tests(&content)
        && session.test_files_pending.iter().any(|f| f == file_path)
    {
        // Inline #[cfg(test)] written into a pending file resolves its debt.
        // Without this branch the else-if below re-adds it, incrementing
        // test_nudge_count and recreating the circular deadlock.
        super::test_resolve::resolve_pending_for_test_file(&mut session, file_path);
    } else if !session.test_files_pending.iter().any(|f| f == file_path) {
        // Only call detect_missing_tests when the file is NOT already tracked —
        // re-detecting an already-pending file bumps test_nudge_count again,
        // which accelerates the gate into hard-block territory.
        if let Some(untested) = super::test_detect::detect_missing_tests(file_path) {
            session.add_test_pending(&untested);
            context_parts.push(format!(
                "[TEST_DETECTED]\nfile: {untested}\n\
                 status: No test file found for this source file\n\
                 action: Write tests to resolve this nudge"
            ));
        }
    }

    // 4. Orphan detection — new files/exports without wiring
    if let Some(orphan_ctx) = super::orphan_guard::check_orphan_risk(file_path, &content) {
        context_parts.push(orphan_ctx);
    }

    // 5. Detect memory file writes — remind to use kavach-db
    if file_path.contains("/memory/") || file_path.ends_with("MEMORY.md") {
        context_parts.push(
            "[MEMORY_DB_REMINDER]\n\
             You wrote to a memory file. Also persist to kavach-db:\n\
             kavach db write --project <slug> --category <cat> --key <key> --title <title>\n\
             Rule: kavach-db (SQLite) is the permanent store — MEMORY.md is session cache only"
            .into(),
        );
    }

    // 5. Log file write event to kavach-db
    super::event_log::log_file_write(&session.session_id, file_path, &input.tool_name, &session.project, &content);

    // 5a. Algorithm decision recorder — extracts // ALGO: comment, upserts to DB, fires events+graph+RAG
    super::post_tool_algo_recorder::record(file_path, &content, &session.project, session.turn_count.into());

    // 5b. Architecture decision recorder — extracts // ARCH: comment, upserts to DB, fires events+graph
    super::post_tool_arch_recorder::record(file_path, &content, &session.project, session.turn_count.into());

    // 5c. Memory sync event tracking
    context_parts.push(format!(
        "[MEMORY_SYNC]\nevents: file_Edit: {file_path}"
    ));

    // 6. Build and output response
    if context_parts.is_empty() {
        kavach_hook::exit_silent();
    } else {
        let mut full = format!(
            "[POST_WRITE]\nfile: {file_path}\n\n"
        );
        full.push_str(&context_parts.join("\n\n"));
        kavach_hook::exit_post_tool_context(&full);
    }
    Ok(())
}
