//! CVE gate: scan Cargo.lock against RustSec advisory database.
//! Blocks stop if vulnerabilities found.

use std::path::Path;

/// Find Cargo.lock by walking up from work_dir.
pub(crate) fn find_cargo_lock(work_dir: &str) -> Option<std::path::PathBuf> {
    let mut dir = Path::new(work_dir);
    loop {
        let candidate = dir.join("Cargo.lock");
        if candidate.exists() {
            return Some(candidate);
        }
        dir = dir.parent()?;
    }
}

/// Load suppressed advisory IDs from .cargo/audit.toml ignore list.
fn load_suppressed(work_dir: &str) -> Vec<String> {
    let mut dir = std::path::Path::new(work_dir);
    loop {
        let audit_path = dir.join(".cargo/audit.toml");
        if audit_path.exists() {
            let content = match std::fs::read_to_string(&audit_path) {
                Ok(c) => c,
                Err(_) => return vec![],
            };
            return content.lines()
                .filter_map(|line| {
                    let t = line.trim().trim_matches('"').trim_matches(',').trim();
                    if t.starts_with("RUSTSEC-") { Some(t.to_string()) } else { None }
                })
                .collect();
        }
        match dir.parent() {
            Some(p) => dir = p,
            None => return vec![],
        }
    }
}

/// Run `cargo tree -i <pkg>@<ver>` to get the reverse dependency path.
/// Returns the tree output trimmed, or empty string if cargo tree is unavailable.
fn dep_path(work_dir: &str, pkg: &str, ver: &str) -> String {
    let out = std::process::Command::new("cargo")
        .args(["tree", "-i", &format!("{pkg}@{ver}"), "--prefix", "depth"])
        .current_dir(work_dir)
        .output();
    match out {
        Ok(o) if o.status.success() => {
            String::from_utf8_lossy(&o.stdout).trim().to_string()
        }
        _ => String::new(),
    }
}

/// Returns true if every path in `tree_output` passes only through a disabled
/// (non-default) feature. Heuristic: if the output contains "[dev-dependencies]"
/// or "(feature = ...)" markers but the pkg itself is not in the default tree,
/// we treat it as disabled-feature-only.
///
/// Concretely: run `cargo tree <pkg>@<ver>` WITHOUT `-i` (forward tree).
/// If that returns no output (crate not in default dep graph), the advisory
/// is reachable only via an optional/disabled feature — skip it.
fn reachable_in_default_features(work_dir: &str, pkg: &str, ver: &str) -> bool {
    let out = std::process::Command::new("cargo")
        .args(["tree", "--prefix", "none", "-p", &format!("{pkg}@{ver}")])
        .current_dir(work_dir)
        .output();
    match out {
        Ok(o) => {
            let text = String::from_utf8_lossy(&o.stdout);
            // If cargo tree found the package, it prints at least one line with the pkg name.
            text.lines().any(|l| l.contains(pkg))
        }
        Err(_) => true, // Can't determine — assume reachable (conservative).
    }
}

/// Scan project for known CVEs. Respects .cargo/audit.toml ignore list.
/// Skips advisories where the vulnerable crate is only reachable via a
/// disabled (non-default) feature. Includes dep path in block message.
pub fn scan(work_dir: &str) -> Option<String> {
    let lock_path = find_cargo_lock(work_dir)?;
    let lockfile = match rustsec::Lockfile::load(&lock_path) {
        Ok(lf) => lf,
        Err(_) => return None,
    };
    let db = match rustsec::Database::fetch() {
        Ok(db) => db,
        Err(_) => return None,
    };

    let suppressed = load_suppressed(work_dir);
    let vulns: Vec<_> = db.vulnerabilities(&lockfile)
        .into_iter()
        .filter(|v| {
            let id = v.advisory.id.as_str();
            !suppressed.iter().any(|s| id.contains(s.as_str()))
        })
        .filter(|v| {
            // Skip if only reachable via a disabled/optional feature.
            let pkg = v.package.name.as_str();
            let ver = v.package.version.to_string();
            reachable_in_default_features(work_dir, pkg, &ver)
        })
        .collect();

    if vulns.is_empty() { return None; }

    let mut msg = format!(
        "BOUNTY_CVE_BLOCK: {} vulnerabilit{} (after audit.toml + feature filter):\n",
        vulns.len(), if vulns.len() == 1 { "y" } else { "ies" }
    );
    for v in &vulns {
        let id = &v.advisory.id;
        let pkg = v.package.name.as_str();
        let ver = v.package.version.to_string();
        let title = &v.advisory.title;
        msg.push_str(&format!("  {id}: {pkg}@{ver} — {title}\n"));
        let path = dep_path(work_dir, pkg, &ver);
        if !path.is_empty() {
            for line in path.lines().take(6) {
                msg.push_str(&format!("    {line}\n"));
            }
        }
    }
    msg.push_str("  ACTION: Run `cargo update` or pin fixed versions.\n");
    msg.push_str("  TIP: If this dep is optional, remove the feature from Cargo.toml.");
    Some(msg)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn finds_cargo_lock_from_crate_dir() {
        let result = find_cargo_lock(env!("CARGO_MANIFEST_DIR"));
        assert!(result.is_some());
    }

    #[test]
    fn returns_none_for_bad_dir() {
        assert!(find_cargo_lock("/tmp/no_such_path_ever").is_none());
    }

    #[test]
    fn finds_lock_from_nested_subdir() {
        let nested = format!("{}/src/gates", env!("CARGO_MANIFEST_DIR"));
        let result = find_cargo_lock(&nested);
        assert!(result.is_some());
        assert!(result.map_or(false, |p| p.ends_with("Cargo.lock")));
    }

    #[test]
    fn dep_path_returns_empty_for_unknown_pkg() {
        let path = dep_path(env!("CARGO_MANIFEST_DIR"), "no-such-crate-xyz", "0.0.0");
        // cargo tree fails for unknown pkg — must return empty string, never panic.
        assert!(path.is_empty() || !path.contains("error: could not"));
    }

    #[test]
    fn reachable_defaults_to_true_for_bad_dir() {
        // Can't run cargo tree outside a workspace — must return true (conservative).
        let result = reachable_in_default_features("/tmp/no_such_workspace_xyz", "tokio", "1.0.0");
        assert!(result);
    }

    #[test]
    fn reachable_returns_false_for_unknown_pkg_in_workspace() {
        // A crate that doesn't exist in this workspace is not reachable.
        let result = reachable_in_default_features(
            env!("CARGO_MANIFEST_DIR"),
            "sqlx-mysql",
            "0.7.0",
        );
        assert!(!result);
    }
}
