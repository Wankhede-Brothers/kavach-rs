use kavach_session::SessionState;

/// Filter files to only those under the session's `work_dir`.
/// Prevents cross-project contamination when multiple terminals share kavach.
fn scoped_files(session: &SessionState) -> impl Iterator<Item = &String> {
    let work_dir = &session.work_dir;
    session
        .files_modified
        .iter()
        .filter(move |f| f.starts_with(work_dir.as_str()))
}

/// Check if Rust files under this session's project were modified.
pub fn has_rust_modifications(session: &SessionState) -> bool {
    scoped_files(session).any(|f| f.ends_with(".rs"))
}

/// Walk ancestors of `start` to find the nearest directory containing `Cargo.toml`.
/// Returns `start` unchanged if no `Cargo.toml` ancestor exists.
fn find_cargo_root(start: &str) -> String {
    for ancestor in std::path::Path::new(start).ancestors() {
        if ancestor.join("Cargo.toml").exists() {
            return ancestor.to_string_lossy().into_owned();
        }
    }
    start.to_string()
}

/// Resolve the Rust workspace root for `cargo check`.
/// Only considers files under `session.work_dir` to prevent cross-project checks.
/// Walks up from the first scoped `.rs` file; falls back to `work_dir`.
pub fn resolve_cargo_dir(session: &SessionState) -> String {
    if let Some(rs_file) = scoped_files(session).find(|f| f.ends_with(".rs")) {
        let parent = match std::path::Path::new(rs_file.as_str()).parent() {
            Some(p) => p.to_string_lossy().into_owned(),
            None => session.work_dir.clone(),
        };
        return find_cargo_root(&parent);
    }
    find_cargo_root(&session.work_dir)
}

/// Run `cargo check` in the given directory; return block reason if it fails.
/// Karpathy Principle 4 (Goal-Driven Execution): wraps failure with [GOAL_CHECK] framing
/// showing how many .rs files were modified without a passing check.
pub fn run_cargo_check(work_dir: &str) -> Option<String> {
    let output = match std::process::Command::new("cargo")
        .args(["check", "--message-format=short"])
        .current_dir(work_dir)
        .output()
    {
        Ok(o) => o,
        Err(_) => return None,
    };
    if output.status.success() {
        return None;
    }
    let stderr = String::from_utf8_lossy(&output.stderr);
    let first_error: &str = if let Some(line) = stderr.lines().find(|l| l.contains("error")) {
        line
    } else {
        "cargo check failed"
    };
    Some(format!(
        "[GOAL_CHECK]\n\
         cargo check: FAIL\n\
         action: Define success criteria. Run `cargo nextest run -p <crate>` before stopping.\n\
         error: {first_error}\n\
         STOP BLOCKED: cargo check failed. Fix before stopping."
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    use kavach_session::SessionState;

    fn session_with_dir(dir: &str) -> SessionState {
        let mut s = SessionState::default();
        s.work_dir = dir.into();
        s
    }

    #[test]
    fn test_has_rust_modifications_empty() {
        let s = session_with_dir("/project");
        assert!(!has_rust_modifications(&s));
    }

    #[test]
    fn test_has_rust_modifications_with_rs() {
        let mut s = session_with_dir("/project");
        s.files_modified.push("/project/src/main.rs".into());
        assert!(has_rust_modifications(&s));
    }

    #[test]
    fn test_has_rust_modifications_no_rs() {
        let mut s = session_with_dir("/project");
        s.files_modified.push("/project/src/main.ts".into());
        assert!(!has_rust_modifications(&s));
    }

    #[test]
    fn test_cross_project_files_ignored() {
        let mut s = session_with_dir("/project-a");
        s.files_modified.push("/project-b/src/lib.rs".into());
        assert!(!has_rust_modifications(&s));
    }

    #[test]
    fn test_resolve_cargo_dir_ignores_other_project() {
        let mut s = session_with_dir("/project-a");
        s.files_modified.push("/project-b/crates/foo/src/lib.rs".into());
        let dir = resolve_cargo_dir(&s);
        assert!(
            dir.starts_with("/project-a"),
            "expected /project-a prefix, got: {dir}"
        );
    }

    #[test]
    fn test_scoped_files_filters_correctly() {
        let mut s = session_with_dir("/home/user/kavach");
        s.files_modified.push("/home/user/kavach/src/main.rs".into());
        s.files_modified.push("/home/user/other/src/lib.rs".into());
        s.files_modified.push("/home/user/kavach/crates/foo.rs".into());
        let scoped: Vec<_> = scoped_files(&s).collect();
        assert_eq!(scoped.len(), 2);
        assert!(scoped.iter().all(|f| f.starts_with("/home/user/kavach")));
    }
}
