//! Infrastructure Protocol Guard — enforces correct protocol usage.
//! GraphQL: depth limit, disable introspection in production.
//! Queues: at-least-once delivery requires idempotency.

use super::platform_guard_paths::is_test;
use super::platform_guard_msg::{build_block, build_advisory};

// Split needles to avoid self-triggering when this file is scanned.
const GQL: &str = concat!("graph", "ql");
const INTRO: &str = concat!("intros", "pection");
const ENABLED: &str = concat!("enabl", "ed");

fn is_infra_file(path: &str) -> bool {
    path.ends_with(".ts") || path.ends_with(".tsx") || path.ends_with(".rs")
}

pub fn check(file_path: &str, content: &str) -> Option<String> {
    if !is_infra_file(file_path) || is_test(file_path) { return None; }
    let lc = content.to_lowercase();
    let mut p0: Vec<(&str, &str)> = Vec::new();

    if lc.contains(GQL) && lc.contains(INTRO)
        && (lc.contains("true") || lc.contains(ENABLED))
        && !lc.contains("development") && !lc.contains("dev_only")
    {
        p0.push(("GRAPHQL_INTROSPECTION_ENABLED",
            "Disable GraphQL introspection in production — it leaks the full schema to attackers."));
    }
    if lc.contains(GQL) && lc.contains("schema")
        && !lc.contains("depthlimit") && !lc.contains("depth_limit")
        && !lc.contains("maxdepth") && !lc.contains("max_depth")
        && !lc.contains("dev_only") && !lc.contains("development")
    {
        p0.push(("GRAPHQL_NO_DEPTH_LIMIT",
            "Add depth limiting to GraphQL schema (max 10-15) — prevents nested query DoS."));
    }
    if p0.is_empty() { return None; }
    Some(build_block("INFRA_PROTOCOL_GUARD", &p0))
}

pub fn format_advisory(file_path: &str, content: &str) -> Option<String> {
    if !is_infra_file(file_path) || is_test(file_path) { return None; }
    let lc = content.to_lowercase();
    let mut p1: Vec<(&str, &str)> = Vec::new();

    if lc.contains("longpoll") || lc.contains("long_poll") {
        p1.push(("AVOID_LONG_POLLING",
            "Replace long polling with SSE (EventSource) — lower latency, fewer connections."));
    }
    if (lc.contains("queue") || file_path.contains("consumer"))
        && (lc.contains("queue") || lc.contains("batch"))
        && !lc.contains("idempoten") && !lc.contains("dedup")
    {
        p1.push(("QUEUE_NO_IDEMPOTENCY",
            "Add idempotency key to queue consumer — message queues deliver at-least-once."));
    }
    if p1.is_empty() { return None; }
    Some(build_advisory("INFRA_PROTOCOL_GUARD", &p1))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_block_graphql_introspection_enabled() {
        assert!(check("src/gateway.ts",
            "const schema = createSchema({ graphql: true, introspection: true })").is_some());
    }

    #[test]
    fn should_allow_graphql_introspection_in_dev() {
        assert!(check("src/gateway.ts",
            "const schema = createSchema({ graphql: true, introspection: true, dev_only: true })").is_none());
    }

    #[test]
    fn should_block_graphql_schema_without_depth_limit() {
        assert!(check("src/gateway.ts",
            "const graphql = buildSchema({ schema: typeDefs })").is_some());
    }

    #[test]
    fn should_allow_graphql_schema_with_depth_limit() {
        assert!(check("src/gateway.ts",
            "const graphql = buildSchema({ schema: typeDefs, maxDepth: 15 })").is_none());
    }

    #[test]
    fn should_skip_non_infra_files() {
        assert!(check("src/styles.css", "graphql introspection true").is_none());
    }

    #[test]
    fn should_skip_test_files() {
        assert!(check("src/gateway.test.ts",
            "graphql introspection true schema").is_none());
    }

    #[test]
    fn should_advise_long_polling() {
        assert!(format_advisory("src/api.ts", "const longPoll = startPolling()").is_some());
    }

    #[test]
    fn should_advise_queue_without_idempotency() {
        assert!(format_advisory("src/consumer.ts",
            "export default { async queue(batch) { for (const msg of batch) {} } }").is_some());
    }
}
