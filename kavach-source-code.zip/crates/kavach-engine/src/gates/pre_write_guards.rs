// Stage 3: Language guards — chain verification + tiered severity system.
// ARCH: TieredGuardSeverity — per Meta-Harness research, complex verification degrades performance
// PATTERN: tiered_severity | SCOPE: pre_write | CAP: AP | SEARCHED: 2026-04
// P0 (block): Security-critical. P1 (advisory): Quality. P2 (silent): Style.
use kavach_types::HookInput;
use crate::gates::pre_write_context::WriteContext;
use crate::gates::pre_write_checks::extract_write_context;

// Guard severity tiers defined by comment convention:
// P0 = security-critical (hard block) - OWASP, crypto, DB security, frontend security
// P1 = quality (advisory in context) - rust patterns, ts patterns, complexity, UX
// P2 = style (silent log) - algo complexity, secrecy, alloc hints

pub(crate) struct GuardResult {
    pub block: Option<String>,
    pub algo_advisory: Option<String>,
    pub runner_compact: String,
    /// P1 advisories (quality issues) — shown in context but don't block.
    pub p1_advisories: Vec<String>,
}

/// Run chain verification and tiered guards.
/// P0 (security) = hard block. P1 (quality) = advisory. P2 (style) = silent.
pub(crate) fn check(
    ctx: &WriteContext<'_>,
    input: &HookInput,
    session: &kavach_session::SessionState,
) -> GuardResult {
    let mut algo_advisory: Option<String> = None;
    let mut p1_advisories: Vec<String> = Vec::new();

    // Chain verification (code files only)
    let tool_input = input.tool_input.clone().unwrap_or_default();
    let prompt = extract_write_context(input);
    let mut runner = kavach_chain::Runner::new(&session.session_id);
    if ctx.is_code {
        let chain_state = runner.run_full(
            &prompt, ctx.tool_name, &tool_input, session.research_done,
        );
        if chain_state.is_blocked() {
            return GuardResult {
                block: Some(chain_state.get_block_reason()),
                algo_advisory: None,
                runner_compact: runner.to_compact(),
                p1_advisories: Vec::new(),
            };
        }
    }

    // Rust production guard — P1 (quality advisory, not security block)
    // Per Meta-Harness: complex verification degrades performance.
    // unwrap/todo are quality issues, not security vulnerabilities.
    if ctx.is_rust && !ctx.is_test {
        if let Some(msg) = super::pre_write_rust_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[RUST_GUARD_P1] {msg}"));
        }
    }

    // TypeScript production guard — P1 (quality advisory)
    if ctx.is_frontend && !ctx.is_test {
        if let Some(msg) = super::pre_write_ts_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[TS_GUARD_P1] {msg}"));
        }
        if let Some(msg) = super::pre_write_ts_guard::check_component_monolith(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[TS_MONOLITH_P1] {msg}"));
        }
    }

    // SQL production guard — P0 (security: SQL injection)
    if !ctx.is_test {
        if let Some(block_msg) = super::pre_write_sql_guard::check(ctx.file_path, ctx.content) {
            return GuardResult {
                block: Some(block_msg),
                algo_advisory: None,
                runner_compact: runner.to_compact(),
                p1_advisories,
            };
        }
    }

    // DB security guard — P0 (RLS, SET LOCAL, UPDATE without WHERE, SQL concat)
    if !ctx.is_test {
        if let Some(block_msg) = kavach_patterns::db_security_guard::check(ctx.file_path, ctx.content) {
            return GuardResult {
                block: Some(block_msg),
                algo_advisory: None,
                runner_compact: runner.to_compact(),
                p1_advisories,
            };
        }
    }

    // OWASP guard — P0 (injection attacks)
    if !ctx.is_test {
        if let Some(block_msg) = kavach_patterns::owasp_guard::check(ctx.file_path, ctx.content) {
            return GuardResult {
                block: Some(block_msg),
                algo_advisory: None,
                runner_compact: runner.to_compact(),
                p1_advisories,
            };
        }
    }

    // Crypto guard — P0 (banned algorithms)
    if !ctx.is_test {
        if let Some(block_msg) = kavach_patterns::crypto_guard::check(ctx.file_path, ctx.content) {
            return GuardResult {
                block: Some(block_msg),
                algo_advisory: None,
                runner_compact: runner.to_compact(),
                p1_advisories,
            };
        }
    }

    // Frontend security guard — P0 (CSP, Tailwind arbitrary XSS)
    if ctx.is_frontend && !ctx.is_test {
        if let Some(block_msg) = kavach_patterns::frontend_security_guard::check(ctx.file_path, ctx.content) {
            return GuardResult {
                block: Some(block_msg),
                algo_advisory: None,
                runner_compact: runner.to_compact(),
                p1_advisories,
            };
        }
    }

    // Banned CSS guard — P1 (inline styles, hardcoded hex — quality, not security)
    if ctx.is_frontend && !ctx.is_test {
        if let Some(msg) = kavach_patterns::banned_css_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[CSS_GUARD_P1] {msg}"));
        }
    }

    // UX guard — P1 (design system consistency — quality, not security)
    if ctx.is_frontend && !ctx.is_test {
        if let Some(msg) = kavach_patterns::ux_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[UX_GUARD_P1] {msg}"));
        }
    }

    // Complexity guard — P1 (LOC, nesting — quality, not security)
    if !ctx.is_test {
        if let Some(msg) = kavach_patterns::complexity_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[COMPLEXITY_P1] {msg}"));
        }
    }

    // Advisories — algo complexity, secrecy, alloc patterns
    if !ctx.is_test {
        let mut advisories = String::new();
        if let Some(a) = kavach_patterns::algo_complexity_guard::advise(ctx.file_path, ctx.content) {
            advisories.push_str(&a);
        }
        if let Some(a) = kavach_patterns::secrecy_guard::advise(ctx.file_path, ctx.content) {
            advisories.push_str(&a);
        }
        if let Some(a) = kavach_patterns::alloc_guard::advise(ctx.file_path, ctx.content) {
            advisories.push_str(&a);
        }
        if let Some(a) = kavach_patterns::a11y_guard::advise(ctx.file_path, ctx.content) {
            advisories.push_str(&a);
        }
        if !advisories.is_empty() {
            algo_advisory = Some(advisories);
        }
    }

    // Algorithm Hunter guard
    if ctx.is_rust && !ctx.is_test {
        let diff_has_algo = ctx.content.contains("// ALGO:");
        let file_has_algo = !diff_has_algo && ctx.tool_name == "Edit"
            && std::fs::read_to_string(ctx.file_path)
                .map(|s| s.contains("// ALGO:"))
                .unwrap_or(false);
        let has_algo_comment = diff_has_algo || file_has_algo;
        let algo_satisfied = session.algo_hunter_invoked || has_algo_comment;
        match super::pre_write_algo_guard::check(
            ctx.file_path, ctx.content, algo_satisfied, &session.project,
        ) {
            super::pre_write_algo_guard::AlgoGuardOutcome::Block(msg) => {
                return GuardResult {
                    block: Some(msg),
                    algo_advisory: None,
                    runner_compact: runner.to_compact(),
                    p1_advisories,
                };
            }
            super::pre_write_algo_guard::AlgoGuardOutcome::AutoInject(inject_ctx) => {
                algo_advisory = Some(inject_ctx);
            }
            super::pre_write_algo_guard::AlgoGuardOutcome::Allow => {}
        }
    }

    // Architecture guard — requires /arch skill or // ARCH: comment
    if ctx.is_rust && !ctx.is_test {
        let diff_has_arch = ctx.content.contains("// ARCH:");
        let file_has_arch = !diff_has_arch && ctx.tool_name == "Edit"
            && std::fs::read_to_string(ctx.file_path)
                .map(|s| s.contains("// ARCH:"))
                .unwrap_or(false);
        let has_arch_comment = diff_has_arch || file_has_arch;
        let arch_satisfied = session.arch_skill_invoked || has_arch_comment;
        match super::pre_write_arch_guard::check(
            ctx.file_path, ctx.content, arch_satisfied, &session.project,
        ) {
            super::pre_write_arch_guard::ArchPreWriteOutcome::Block(msg) => {
                return GuardResult {
                    block: Some(msg),
                    algo_advisory: None,
                    runner_compact: runner.to_compact(),
                    p1_advisories,
                };
            }
            super::pre_write_arch_guard::ArchPreWriteOutcome::AutoInject(inject_ctx) => {
                if algo_advisory.is_none() {
                    algo_advisory = Some(inject_ctx);
                } else if let Some(ref mut existing) = algo_advisory {
                    existing.push_str("\n\n");
                    existing.push_str(&inject_ctx);
                }
            }
            super::pre_write_arch_guard::ArchPreWriteOutcome::Allow => {}
        }
    }

    // Universal platform guards — P1 (response, microservice, infra — quality, not security)
    if !ctx.is_test {
        let full_content_buf;
        let full_pc = if ctx.tool_name == "Edit" && !ctx.file_path.is_empty() {
            match std::fs::read_to_string(ctx.file_path) {
                Ok(existing) => { full_content_buf = existing; &full_content_buf as &str }
                Err(_) => ctx.content,
            }
        } else {
            ctx.content
        };
        // Merge suppression comments from edit into full file for microservice guard.
        // This prevents catch-22 where you can't add // split: because the edit is blocked.
        let merged_for_suppression;
        let ms_content = if ctx.tool_name == "Edit" {
            let edit_has_hub = ctx.content.contains("// hub:");
            let edit_has_split = ctx.content.contains("// split:");
            let file_has_hub = full_pc.contains("// hub:");
            let file_has_split = full_pc.contains("// split:");
            if (edit_has_hub && !file_has_hub) || (edit_has_split && !file_has_split) {
                merged_for_suppression = format!("{}\n{full_pc}", ctx.content);
                &merged_for_suppression as &str
            } else {
                full_pc
            }
        } else {
            full_pc
        };
        // Platform guards demoted to P1 (quality advisories)
        if let Some(msg) = super::pre_write_response_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[RESPONSE_P1] {msg}"));
        }
        if let Some(msg) = super::pre_write_microservice_guard::check(ctx.file_path, ms_content) {
            p1_advisories.push(format!("[MICROSERVICE_P1] {msg}"));
        }
        if let Some(msg) = super::pre_write_infra_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[INFRA_P1] {msg}"));
        }
    }

    // API Gateway guard — P1 (architectural pattern, not security)
    if !ctx.is_test {
        if let Some(msg) = super::api_gateway_guard::check(ctx.file_path, ctx.content) {
            p1_advisories.push(format!("[API_GATEWAY_P1] {msg}"));
        }
    }

    GuardResult {
        block: None,
        algo_advisory,
        runner_compact: runner.to_compact(),
        p1_advisories,
    }
}
