use std::path::Path;

/// Detect orphaned code: new .rs files missing mod.rs declarations,
/// new pub exports without wiring nudge.
/// Returns context string if orphan risk detected, None if clean.
pub(crate) fn check_orphan_risk(file_path: &str, content: &str) -> Option<String> {
    if file_path.is_empty() || content.is_empty() { return None; }
    let path = Path::new(file_path);
    let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
    match ext {
        "rs" => check_rust_orphan(file_path, content),
        "tsx" | "jsx" | "ts" | "js" => check_js_orphan(file_path, content),
        _ => None,
    }
}

/// Rust: check if file is declared in parent mod.rs, detect new pub exports.
fn check_rust_orphan(file_path: &str, content: &str) -> Option<String> {
    let path = Path::new(file_path);
    let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("");
    if stem == "mod" || stem == "lib" || stem == "main" { return None; }
    let mut warnings: Vec<String> = Vec::new();

    // Check mod.rs declaration
    if let Some(parent) = path.parent() {
        let mod_rs = parent.join("mod.rs");
        if mod_rs.exists()
            && let Ok(mod_content) = std::fs::read_to_string(&mod_rs)
        {
            let decl = format!("mod {stem}");
            if !mod_content.contains(&decl) {
                warnings.push(format!(
                    "ORPHAN: `{stem}.rs` not declared in `mod.rs`\n\
                     FIX: Add `pub mod {stem};` or `pub(crate) mod {stem};` to {}/mod.rs",
                    parent.display()
                ));
            }
        }
    }

    // Detect new pub exports that need wiring
    let pub_count = count_pub_exports(content);
    if pub_count > 0 {
        warnings.push(format!(
            "WIRE_CHECK: {pub_count} pub export(s) in `{stem}.rs`\n\
             ACTION: Ensure each is imported and used at its call site.\n\
             Rule: Create + Import + Use in the SAME turn."
        ));
    }

    if warnings.is_empty() { return None; }
    Some(format!("[ORPHAN_GUARD]\nfile: {file_path}\n\n{}", warnings.join("\n\n")))
}

/// Count pub fn, pub struct, pub enum, pub type, pub const declarations.
fn count_pub_exports(content: &str) -> usize {
    content.lines().filter(|line| {
        let trimmed = line.trim();
        (trimmed.starts_with("pub fn ")
            || trimmed.starts_with("pub struct ")
            || trimmed.starts_with("pub enum ")
            || trimmed.starts_with("pub type ")
            || trimmed.starts_with("pub const ")
            || trimmed.starts_with("pub(crate) fn "))
            && !trimmed.contains("#[test]")
    }).count()
}

/// JS/TS: detect exported items that need importing elsewhere.
fn check_js_orphan(file_path: &str, content: &str) -> Option<String> {
    let path = Path::new(file_path);
    let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("");
    if stem == "index" || stem == "mod" { return None; }
    let export_count = content.lines().filter(|line| {
        let trimmed = line.trim();
        trimmed.starts_with("export function ")
            || trimmed.starts_with("export const ")
            || trimmed.starts_with("export default ")
            || trimmed.starts_with("export class ")
            || trimmed.starts_with("export type ")
            || trimmed.starts_with("export interface ")
    }).count();
    if export_count == 0 { return None; }
    Some(format!(
        "[ORPHAN_GUARD]\nfile: {file_path}\n\n\
         WIRE_CHECK: {export_count} export(s) in `{stem}`\n\
         ACTION: Ensure each is imported at its use site.\n\
         Rule: Create + Import + Use in the SAME turn."
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_count_pub_exports() {
        let content = "pub fn foo() {}\npub struct Bar;\nfn private() {}";
        assert_eq!(count_pub_exports(content), 2);
    }

    #[test]
    fn test_count_pub_exports_private_fns() {
        let content = "fn private() {}\nfn also_private() {}";
        assert_eq!(count_pub_exports(content), 0);
    }

    #[test]
    fn test_skip_mod_lib_main() {
        assert!(check_rust_orphan("/src/mod.rs", "pub fn x() {}").is_none());
        assert!(check_rust_orphan("/src/lib.rs", "pub fn x() {}").is_none());
        assert!(check_rust_orphan("/src/main.rs", "pub fn x() {}").is_none());
    }

    #[test]
    fn test_js_export_detection() {
        let content = "export function Foo() {}\nexport const BAR = 1;";
        let result = check_js_orphan("/src/Foo.tsx", content);
        assert!(result.is_some());
        assert!(result.as_ref().map_or(false, |r| r.contains("2 export(s)")));
    }

    #[test]
    fn test_js_index_skipped() {
        assert!(check_js_orphan("/src/index.ts", "export const x = 1;").is_none());
    }

    #[test]
    fn test_no_orphan_for_empty() {
        assert!(check_orphan_risk("", "").is_none());
        assert!(check_orphan_risk("foo.rs", "").is_none());
    }

    #[test]
    fn test_non_code_files_skipped() {
        assert!(check_orphan_risk("README.md", "# Hello").is_none());
        assert!(check_orphan_risk("data.json", "{}").is_none());
    }
}
