/// Block commands that would expose env var values to the AI.
/// Allowed: listing variable names (`env`, `printenv` with no args, `declare -p`).
/// Blocked: reading a specific value (`printenv SECRET`, `echo $VAR`, `env | grep VAR`, `cat .env`).
pub fn check_env_value_read(command: &str) -> Option<String> {
    let lc = command.trim().to_lowercase();

    // printenv VAR — dumps value of a named variable
    let is_printenv_with_arg = {
        let after = lc.trim_start_matches("printenv").trim_start();
        lc.starts_with("printenv ") && !after.is_empty() && !after.starts_with('|')
    };
    if is_printenv_with_arg {
        return Some(
            "BLOCKED: `printenv VAR` exposes the secret value. \
             Variable names are visible — values are not. \
             Use `printenv | grep -o '^[^=]*'` to list names only."
                .into(),
        );
    }

    // echo $VAR or echo ${VAR} — expands and prints the value
    if lc.starts_with("echo ") && lc.contains('$') {
        return Some(
            "BLOCKED: `echo $VAR` exposes the secret value. \
             Reference the variable name in code without expanding it."
                .into(),
        );
    }

    // env | grep PATTERN or printenv | grep PATTERN — filters but still prints values.
    // Exempt: `grep -o '^[^=]*'` which strips values and lists names only.
    // Exempt: `awk -F= '{print $1}'` which prints only the key side.
    let is_names_only_grep = lc.contains("grep -o") && lc.contains("^[^=]*");
    let is_awk_names_only = lc.contains("awk") && lc.contains("print $1");
    // Match `env` only as a standalone command in command position (segment first word),
    // not as substring (`env-cross`, `environment`) nor argv flag (`cargo --env foo`).
    let has_env_cmd = first_word_is(&lc, "env");
    if (has_env_cmd || lc.contains("printenv")) && lc.contains("grep")
        && !is_names_only_grep && !is_awk_names_only
    {
        return Some(
            "BLOCKED: `env | grep PATTERN` exposes secret values. \
             To check which variables are present, use: \
             `awk -F= '/^[A-Z]/ {print $1}' .env | sort` (reads names from file) or \
             `env | grep -o '^[^=]*' | grep PATTERN` (filters names only from environment)."
                .into(),
        );
    }

    // source .env loads all values into shell.
    // ALLOWED: `source .env && <safe-cmd>` where the downstream command uses env vars
    // without printing them (migration runners, build tools, test runners).
    // Values stay in the shell process and never appear in Claude's context.
    // BLOCKED: bare `source .env` with no downstream command, or downstream that prints values.
    // `source` must be in command position — `sqlx --source migrations_local` is an argv
    // flag, not the builtin, and must not trigger the guard.
    if has_source_builtin(&lc) && lc.contains(".env") {
        let env_file = detect_env_filename(&lc);
        if let Some(downstream) = extract_post_source_command(command) {
            if is_safe_downstream(&downstream) {
                // Allow: env vars used by the subprocess, not printed to stdout.
                return None;
            }
            return Some(format!(
                "BLOCKED: `source {env_file} && {downstream}` — downstream command may expose values. \
                 Use a safe runner (sqlx, cargo, kavach, bun run, make) that takes env vars \
                 without printing them."
            ));
        }
        return Some(format!(
            "BLOCKED: bare `source {env_file}` with no downstream command loads secrets into context. \
             Use `source {env_file} && <cmd>` with a safe runner, or list names only with: \
             `awk -F= '/^[A-Z]/ {{print $1}}' {env_file} | sort`."
        ));
    }

    // set / declare — dumps all shell variables including secrets.
    let is_set_dump = lc == "set" || lc == "declare" || lc == "declare -p"
        || lc.starts_with("set ") || lc.starts_with("declare ");
    if is_set_dump {
        return Some(
            "BLOCKED: `set`/`declare` dumps all shell variables including secret values. \
             Use `awk -F= '/^[A-Z]/ {print $1}' .env | sort` to list names only."
                .into(),
        );
    }

    // python/python3 env dump — only block when values are explicitly printed/serialized.
    // `os.environ['KEY']` as a subprocess argument keeps values in process memory — allowed.
    // `print(os.environ)`, `json.dumps(os.environ)`, `str(os.environ)` expose all values — blocked.
    let has_python = lc.contains("python") || lc.contains("python3");
    let has_environ = lc.contains("os.environ") || lc.contains("os.getenv");
    let dumps_environ = lc.contains("print(os.environ")
        || lc.contains("print(os.getenv")
        || lc.contains("json.dumps(os.environ")
        || lc.contains("str(os.environ")
        || lc.contains("pprint(os.environ")
        || (lc.contains("os.environ)") && !lc.contains("os.environ['") && !lc.contains("os.environ[\""));
    if has_python && has_environ && dumps_environ {
        return Some(
            "BLOCKED: `os.environ`/`os.getenv` exposes secret values. \
             Read variable names with `awk -F= '/^[A-Z]/ {print $1}' .env | sort` instead."
                .into(),
        );
    }

    // /proc/self/environ — Linux process environment dump.
    if lc.contains("/proc/self/environ") || lc.contains("/proc/1/environ") {
        return Some(
            "BLOCKED: `/proc/self/environ` exposes all process environment variables. \
             Use `awk -F= '/^[A-Z]/ {print $1}' .env | sort` to list names only."
                .into(),
        );
    }

    // head/tail/less/more/strings/bat/cat reading a .env file — exposes values.
    // NOTE: the Read tool is NOT blocked — it bypasses this guard. Prefer Read for .env files.
    let dotenv_read_cmds = ["cat ", "bat ", "head ", "tail ", "less ", "more ", "strings "];
    let targets_dotenv = lc.contains(".env");
    if targets_dotenv && dotenv_read_cmds.iter().any(|cmd| lc.starts_with(cmd)) {
        return Some(
            "BLOCKED: Reading a .env file via Bash exposes all secret values. \
             Use the Read tool instead (it reads .env files directly). \
             Or `grep '^PUBLIC_' .env` to extract only public (non-sensitive) variables."
                .into(),
        );
    }

    // grep on .env file: block unless pattern targets only PUBLIC_ prefixed vars.
    // PUBLIC_ prefix is a framework convention (Astro, Vite, Expo) for non-sensitive
    // browser-exposed variables. These are safe to read — they ship in client bundles.
    if targets_dotenv && lc.contains("grep") && !is_names_only_grep && !is_awk_names_only {
        if is_public_prefix_grep(&lc) {
            return None;
        }
        return Some(
            "BLOCKED: `grep` on .env file exposes secret values. \
             Use `grep '^PUBLIC_' .env` to read only public (non-sensitive) vars, \
             or use the Read tool to read .env files directly."
                .into(),
        );
    }

    None
}

/// Return true when the downstream command uses env vars without printing them.
/// Matches on binary *basename* via std::path::Path::file_name, so absolute,
/// relative, and tilde-prefixed paths all resolve to the same safe-list lookup:
///   `sqlx migrate run`, `~/.cargo/bin/sqlx migrate run`, `/usr/local/bin/psql -f ...`.
fn is_safe_downstream(downstream: &str) -> bool {
    let lc = downstream.trim().to_lowercase();
    if lc.starts_with("database_url=") || lc.starts_with("cd ") {
        return true;
    }
    let first_token = match lc.split_whitespace().next() {
        Some(t) => t,
        None => return false,
    };
    let basename = match std::path::Path::new(first_token)
        .file_name()
        .and_then(|n| n.to_str())
    {
        Some(b) => b,
        None => first_token,
    };
    // Python BANNED per ~/.claude/rules/04-anti-patterns.md global Python ban.
    // Do NOT add python/python3 here — they bypass the kavach hook pipeline.
    // psql BANNED — it's the canonical escape hatch for bypassing sqlx checksum
    // validation. All DB ops go through sqlx (migrations) or kavach db pg-* (repair).
    // `kavach` is on the safe list so `source .env && kavach db pg-fix-checksum ...`
    // works — kavach sub-commands take DSN via --dsn flag and never print secrets.
    let safe_binaries = [
        "sqlx", "cargo", "bun", "make", "npm", "pnpm", "node", "deno",
        "go", "diesel", "flyway", "liquibase", "alembic",
        "migrate", "kavach",
    ];
    safe_binaries.contains(&basename)
}

/// Detect which `.env*` filename appears in a command for accurate error messages.
/// Scans for `.env`, `.envrc`, `.env.local`, `.env.development`, `.env.production`,
/// and any `.env.<suffix>` variant. Returns the most specific match found, or
/// `.env` as a fallback for the generic error message.
fn detect_env_filename(lc: &str) -> String {
    // Longest-prefix scan: more specific variants first.
    let variants = [
        ".env.local", ".env.development", ".env.production",
        ".env.test", ".env.staging", ".envrc",
    ];
    for v in variants {
        if lc.contains(v) {
            return v.to_owned();
        }
    }
    // Catch-all: .env.<anything> (e.g. .env.custom).
    if let Some(idx) = lc.find(".env.") {
        let after = &lc[idx..];
        let end = after.find(|c: char| c.is_whitespace() || c == ';' || c == '&' || c == '|')
            .unwrap_or(after.len());
        return after[..end].to_owned();
    }
    ".env".to_owned()
}

/// Return true when `lc` contains the shell `source` builtin (or `.`) in command position.
/// Command position = start-of-line, or after a command separator (`&&`, `||`, `;`, `|`, `(`, `{`).
/// `sqlx --source migrations_local` must NOT match — `--source` is an argv flag.
fn has_source_builtin(lc: &str) -> bool {
    first_word_matches(lc, &["source", "."])
}

/// Return true when any command-position segment in `lc` has first word equal to `name`.
fn first_word_is(lc: &str, name: &str) -> bool {
    first_word_matches(lc, &[name])
}

/// Generalized segment-split helper — splits on shell separators and checks
/// whether any segment's first word matches any of the given names.
fn first_word_matches(lc: &str, names: &[&str]) -> bool {
    let separators = ['&', '|', ';', '(', '{', '\n'];
    for segment in lc.split(|c: char| separators.contains(&c)) {
        let first_word = match segment.trim_start().split_whitespace().next() {
            Some(w) => w,
            None => continue,
        };
        if names.contains(&first_word) {
            return true;
        }
    }
    false
}

/// Skip shell redirect tokens at the start of `s`, returning the remaining slice.
/// Handles `2>/dev/null`, `>/dev/null`, `2>&1`, `&>/dev/null`, `>file`, `2>file`.
/// Stops at the first non-redirect token.
fn skip_shell_redirects(s: &str) -> &str {
    let mut cur = s.trim_start();
    loop {
        let before = cur;
        // Match any of: 2>, >, 2>&, &>, >>, 2>>
        let after_op = if let Some(rest) = cur.strip_prefix("2>&") {
            rest
        } else if let Some(rest) = cur.strip_prefix("&>") {
            rest
        } else if let Some(rest) = cur.strip_prefix("2>>") {
            rest
        } else if let Some(rest) = cur.strip_prefix(">>") {
            rest
        } else if let Some(rest) = cur.strip_prefix("2>") {
            rest
        } else if let Some(rest) = cur.strip_prefix('>') {
            rest
        } else {
            break;
        };
        // Consume the target (e.g. /dev/null, 1, &1, file.txt) up to next whitespace/separator.
        let target = after_op.trim_start();
        let end = target
            .find(|c: char| c.is_whitespace() || c == '&' || c == ';' || c == '|')
            .unwrap_or(target.len());
        cur = target[end..].trim_start();
        // Safety: if strip_prefix matched but we made no progress, stop.
        if cur == before {
            break;
        }
    }
    cur
}

/// Extract the command that follows a `source .env` or `. .env` invocation
/// in command position. Uses `has_source_builtin` segmentation indirectly:
/// finds the command-position occurrence of `source ` or `. ` (following a
/// shell separator or start-of-line), advances past the filename, skips any
/// shell redirects (`2>/dev/null`, `>/dev/null 2>&1`), then strips a
/// separator (`&&` or `;`) to return the downstream command.
/// Returns `None` if the match is not in command position (e.g. `--source flag`),
/// or if there is no downstream command.
fn extract_post_source_command(command: &str) -> Option<String> {
    let lc = command.to_lowercase();
    for needle in ["source ", ". "] {
        if let Some(rest) = find_downstream_after_needle(command, &lc, needle) {
            return Some(rest);
        }
    }
    None
}

/// Scan all occurrences of `needle` in `lc` and return the downstream command
/// after the FIRST command-position hit with a valid separator.
/// Uses a manual while-let loop so false-positive hits (`--source` argv flag)
/// `continue` to the next occurrence instead of short-circuiting to None.
fn find_downstream_after_needle(command: &str, lc: &str, needle: &str) -> Option<String> {
    let mut search_start = 0usize;
    while let Some(rel) = lc.get(search_start..)?.find(needle) {
        let abs = search_start + rel;
        search_start = abs + needle.len();

        if !is_command_position(lc.as_bytes(), abs) {
            continue;
        }
        let after_builtin_start = abs + needle.len();
        let after_builtin_raw = command.get(after_builtin_start..)?;
        let leading_ws = after_builtin_raw.len() - after_builtin_raw.trim_start().len();
        let after_builtin = after_builtin_raw.get(leading_ws..)?;
        let file_end_rel = after_builtin
            .find(|c: char| c.is_whitespace() || c == ';' || c == '|' || c == '&' || c == '(' || c == '{')
            .unwrap_or(after_builtin.len());
        if file_end_rel == 0 {
            continue;
        }
        let past_file = after_builtin.get(file_end_rel..)?;
        let past_redirects = skip_shell_redirects(past_file);
        let cmd = if let Some(s) = past_redirects.strip_prefix("&&") {
            s.trim_start()
        } else if let Some(s) = past_redirects.strip_prefix(';') {
            s.trim_start()
        } else {
            continue;
        };
        if !cmd.is_empty() {
            return Some(cmd.to_owned());
        }
    }
    None
}

/// Return true when byte position `abs` is in command position — preceded by
/// start-of-line, whitespace-leading-to-separator, or directly by a separator.
fn is_command_position(bytes: &[u8], abs: usize) -> bool {
    if abs == 0 {
        return true;
    }
    let mut i = abs;
    while i > 0 {
        match bytes.get(i - 1).copied() {
            Some(b' ') | Some(b'\t') => i -= 1,
            Some(b';') | Some(b'&') | Some(b'|') | Some(b'(') | Some(b'{') | Some(b'\n') => return true,
            _ => return false,
        }
    }
    true
}

/// Return true when the grep pattern targets only non-sensitive env vars.
/// Non-sensitive prefixes per framework convention:
///   PUBLIC_ (Astro/SvelteKit), VITE_ (Vite), NEXT_PUBLIC_ (Next.js),
///   EXPO_PUBLIC_ (Expo), REACT_APP_ (CRA), NUXT_PUBLIC_ (Nuxt 3)
/// Blocks if command also references known sensitive var name patterns.
fn is_public_prefix_grep(lc: &str) -> bool {
    let safe_prefixes = [
        "public_", "vite_", "next_public_", "expo_public_",
        "react_app_", "nuxt_public_",
    ];
    let has_safe = safe_prefixes.iter().any(|p| lc.contains(p));
    if !has_safe {
        return false;
    }
    let blocked = ["secret", "password", "database_url", "dsn", "credential"];
    !blocked.iter().any(|s| lc.contains(s))
}

/// Check if a bash command references env vars that may need sourcing.
/// Returns advisory context if env vars are used without a source/dotenv call.
/// Uses `has_source_builtin` so `sqlx --source migrations_local` (argv flag)
/// is never mistaken for the shell `source` builtin.
pub fn check_env_sourcing(command: &str) -> Option<String> {
    let uses_env_var = command.contains("$DATABASE_URL")
        || command.contains("$SECRET")
        || command.contains("$API_KEY")
        || command.contains("$JWT_SECRET")
        || command.contains("$REDIS_URL");
    let lc = command.to_lowercase();
    let sources_env = has_source_builtin(&lc) || lc.contains("dotenv") || lc.contains("direnv");
    if uses_env_var && !sources_env {
        Some("[ENV_GUARD]\nstatus: advisory\nreason: Command uses env var — ensure .env is sourced\n".into())
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_no_env_vars() {
        assert!(check_env_sourcing("ls -la").is_none());
    }

    #[test]
    fn test_env_var_without_source() {
        assert!(check_env_sourcing("psql $DATABASE_URL").is_some());
    }

    #[test]
    fn test_env_var_with_source() {
        assert!(check_env_sourcing("source .env && psql $DATABASE_URL").is_none());
    }

    // check_env_value_read tests
    #[test]
    fn blocks_printenv_with_arg() {
        assert!(check_env_value_read("printenv SECRET_KEY").is_some());
        assert!(check_env_value_read("printenv DATABASE_URL").is_some());
    }

    #[test]
    fn allows_printenv_no_arg() {
        assert!(check_env_value_read("printenv").is_none());
        assert!(check_env_value_read("printenv | grep -o '^[^=]*'").is_none());
        // awk names-only from .env is safe
        assert!(check_env_value_read("awk -F= '/^[A-Z]/ {print $1}' .env | sort").is_none());
        // names-only then filter is safe
        assert!(check_env_value_read("env | grep -o '^[^=]*' | grep PATTERN").is_none());
    }

    #[test]
    fn blocks_echo_dollar() {
        assert!(check_env_value_read("echo $SECRET").is_some());
        assert!(check_env_value_read("echo ${API_KEY}").is_some());
    }

    #[test]
    fn allows_echo_no_dollar() {
        assert!(check_env_value_read("echo hello").is_none());
    }

    #[test]
    fn blocks_env_grep() {
        assert!(check_env_value_read("env | grep SECRET").is_some());
        assert!(check_env_value_read("printenv | grep API").is_some());
    }

    #[test]
    fn blocks_cat_dotenv() {
        assert!(check_env_value_read("cat .env").is_some());
        assert!(check_env_value_read("cat /project/.env.local").is_some());
    }

    #[test]
    fn allows_grep_public_prefix_on_dotenv() {
        // PUBLIC_ vars are non-sensitive (browser-exposed, Astro/Vite convention)
        assert!(check_env_value_read("grep PUBLIC_ .env").is_none());
        assert!(check_env_value_read("grep '^PUBLIC_' .env").is_none());
        assert!(check_env_value_read(
            r#"grep -E "PUBLIC_(ACCOUNTS|DASHBOARD|API)_URL" .env"#
        ).is_none());
        assert!(check_env_value_read(
            r#"grep -E "^PUBLIC_(ACCOUNTS|DASHBOARD|RAINFIRE|JACOBS|SOUNDBAK|API|SITE|MAIN_SITE)_URL" .env"#
        ).is_none());
    }

    #[test]
    fn allows_grep_framework_prefixes_on_dotenv() {
        // VITE_ (Vite), NEXT_PUBLIC_ (Next.js), REACT_APP_ (CRA), etc.
        assert!(check_env_value_read("grep VITE_ .env").is_none());
        assert!(check_env_value_read("grep NEXT_PUBLIC_ .env").is_none());
        assert!(check_env_value_read("grep REACT_APP_ .env").is_none());
        assert!(check_env_value_read("grep EXPO_PUBLIC_ .env").is_none());
        assert!(check_env_value_read("grep NUXT_PUBLIC_ .env").is_none());
        assert!(check_env_value_read(
            r#"grep -E "^VITE_(API_URL|SITE_NAME)" .env"#
        ).is_none());
    }

    #[test]
    fn blocks_grep_secret_vars_on_dotenv() {
        // Non-prefixed grep on .env still blocked
        assert!(check_env_value_read("grep SECRET .env").is_some());
        assert!(check_env_value_read("grep DATABASE_URL .env").is_some());
        assert!(check_env_value_read("env | grep API_KEY").is_some());
        // No safe prefix at all
        assert!(check_env_value_read("grep PORT .env").is_some());
        assert!(check_env_value_read("grep STRIPE .env").is_some());
    }

    #[test]
    fn allows_unrelated_commands() {
        assert!(check_env_value_read("cargo build --release").is_none());
        assert!(check_env_value_read("git status").is_none());
        // "env" as substring of a word (env-cross, environment) must not trigger.
        assert!(check_env_value_read(
            r#"kavach db query --project nicole-carpenter --category decision 2>&1 | grep -E "phase[23]|migration|env-cross|routing-bug""#
        ).is_none());
        assert!(check_env_value_read("grep -r environment .").is_none());
    }

    #[test]
    fn blocks_bare_source_dotenv() {
        // bare source with no downstream is always blocked
        assert!(check_env_value_read("source .env").is_some());
        assert!(check_env_value_read("source /project/.env.local").is_some());
    }

    #[test]
    fn allows_source_dotenv_with_safe_downstream() {
        // sqlx migrate run uses DATABASE_URL but never prints it
        assert!(check_env_value_read(
            "source .env && sqlx migrate run --source migrations_local"
        ).is_none());
        // kavach db pg-fix-checksum takes --dsn flag and never prints secrets
        assert!(check_env_value_read(
            "source .env && kavach db pg-fix-checksum --dsn $DATABASE_URL --version 36 --file x.sql"
        ).is_none());
        // cargo test uses env without printing
        assert!(check_env_value_read(
            "source .env && cargo test"
        ).is_none());
    }

    #[test]
    fn blocks_source_dotenv_with_unsafe_downstream() {
        // echo $VAR after sourcing would expose values
        assert!(check_env_value_read(
            "source .env && echo $DATABASE_URL"
        ).is_some());
    }

    #[test]
    fn source_dotenv_without_downstream_uses_awk_hint() {
        let msg = check_env_value_read("source .env").expect("should block");
        assert!(
            msg.contains("awk"),
            "expected awk fallback hint in: {msg}"
        );
    }

    #[test]
    fn extract_post_source_command_basic() {
        assert_eq!(
            extract_post_source_command("source .env && psql $DATABASE_URL -f file.sql"),
            Some("psql $DATABASE_URL -f file.sql".to_owned())
        );
    }

    #[test]
    fn extract_post_source_command_semicolon() {
        assert_eq!(
            extract_post_source_command("source .env; cargo test"),
            Some("cargo test".to_owned())
        );
    }

    #[test]
    fn extract_post_source_command_no_downstream() {
        assert_eq!(extract_post_source_command("source .env"), None);
    }

    #[test]
    fn extract_post_source_command_dot_form() {
        assert_eq!(
            extract_post_source_command(". .env && make run"),
            Some("make run".to_owned())
        );
    }

    #[test]
    fn extract_post_source_command_with_stderr_redirect() {
        assert_eq!(
            extract_post_source_command("source ../.env 2>/dev/null; sqlx migrate info --source migrations_local"),
            Some("sqlx migrate info --source migrations_local".to_owned())
        );
        assert_eq!(
            extract_post_source_command("source .env 2>/dev/null && sqlx migrate run --source migrations_local"),
            Some("sqlx migrate run --source migrations_local".to_owned())
        );
        assert_eq!(
            extract_post_source_command("source .env >/dev/null 2>&1 && cargo test"),
            Some("cargo test".to_owned())
        );
    }

    #[test]
    fn allows_source_dotenv_with_redirect_and_safe_downstream() {
        // The exact pattern from the blocked command
        assert!(check_env_value_read(
            "source ../.env 2>/dev/null; sqlx migrate info --source migrations_local"
        ).is_none());
        assert!(check_env_value_read(
            "source .env 2>/dev/null && sqlx migrate run --source migrations_local"
        ).is_none());
    }

    #[test]
    fn allows_absolute_path_to_sqlx() {
        // Absolute paths to sqlx must work — `~/.cargo/bin/sqlx`, `/usr/local/bin/sqlx`.
        assert!(check_env_value_read(
            "source .env && ~/.cargo/bin/sqlx migrate run --source migrations_local"
        ).is_none());
        assert!(check_env_value_read(
            "source .env && /usr/local/bin/sqlx migrate info --source migrations_local"
        ).is_none());
        assert!(check_env_value_read(
            "source .env && ./target/release/sqlx migrate run"
        ).is_none());
    }

    #[test]
    fn has_source_builtin_recognizes_command_position() {
        // Command position — must trigger
        assert!(has_source_builtin("source .env"));
        assert!(has_source_builtin("source .env && cargo test"));
        assert!(has_source_builtin("cd foo && source .env && cargo run"));
        assert!(has_source_builtin(". .env"));
    }

    #[test]
    fn has_source_builtin_rejects_flag_argument() {
        // --source is a sqlx CLI flag, not the builtin
        assert!(!has_source_builtin("sqlx migrate run --source migrations_local"));
        assert!(!has_source_builtin("sqlx migrate info --source migrations"));
        // Word containing "source" must not match
        assert!(!has_source_builtin("echo opensource"));
        assert!(!has_source_builtin("ls /usr/src/source"));
    }

    #[test]
    fn allows_sqlx_with_source_flag_when_no_dotenv() {
        // Must not trigger the .env branch at all
        assert!(check_env_value_read(
            "sqlx migrate run --source migrations_local"
        ).is_none());
        assert!(check_env_value_read(
            "sqlx migrate info --source migrations_local"
        ).is_none());
    }

    #[test]
    fn allows_dot_form_with_sqlx_source_flag_regression() {
        // Regression for M-extract-skips-past-falsepos: `--source` is a false-positive hit for
        // the "source " needle. Parser must continue to the `. ./.env` command-position hit.
        assert!(check_env_value_read(
            "cd /tmp && . ./.env && ~/.cargo/bin/sqlx migrate run --source migrations_local"
        ).is_none());
        assert!(check_env_value_read(
            ". ./.env && sqlx migrate info --source migrations_local"
        ).is_none());
        assert_eq!(
            extract_post_source_command("cd /tmp && . ./.env && sqlx migrate run --source migrations_local"),
            Some("sqlx migrate run --source migrations_local".to_owned())
        );
    }

    #[test]
    fn allows_source_env_and_sqlx_with_source_flag() {
        // Real target command: source .env && sqlx migrate run --source migrations_local
        assert!(check_env_value_read(
            "source .env && sqlx migrate run --source migrations_local"
        ).is_none());
        assert!(check_env_value_read(
            "source ../.env && ~/.cargo/bin/sqlx migrate run --source migrations_local"
        ).is_none());
    }

    #[test]
    fn blocks_psql_completely() {
        // psql removed from safe_binaries — it was the canonical escape hatch for
        // bypassing sqlx checksum validation. All DB ops go through sqlx or
        // kavach db pg-* commands. Both -f (file) and -c (inline) are blocked.
        assert!(check_env_value_read(
            "source .env && psql -c \"SELECT version()\""
        ).is_some());
        assert!(check_env_value_read(
            "source .env && psql -f /tmp/query.sql"
        ).is_some());
        assert!(check_env_value_read(
            "source .env && /usr/local/bin/psql -c \"SELECT version()\""
        ).is_some());
    }

    #[test]
    fn skip_shell_redirects_handles_common_forms() {
        assert_eq!(skip_shell_redirects("2>/dev/null && cmd"), "&& cmd");
        assert_eq!(skip_shell_redirects(">/dev/null 2>&1 && cmd"), "&& cmd");
        assert_eq!(skip_shell_redirects("&>/dev/null; cmd"), "; cmd");
        assert_eq!(skip_shell_redirects("&& cmd"), "&& cmd");
        assert_eq!(skip_shell_redirects("; cmd"), "; cmd");
    }

    #[test]
    fn blocks_set_declare() {
        assert!(check_env_value_read("set").is_some());
        assert!(check_env_value_read("declare -p").is_some());
    }

    #[test]
    fn blocks_python_environ() {
        assert!(check_env_value_read("python3 -c \"import os; print(os.environ)\"").is_some());
        assert!(check_env_value_read("python3 -c \"import os,json; print(json.dumps(os.environ))\"").is_some());
    }

    #[test]
    fn allows_python_environ_as_subprocess_arg() {
        // os.environ['KEY'] passed to subprocess — value stays in process memory, never printed.
        assert!(check_env_value_read(
            "python3 -c \"import subprocess,os; subprocess.run(['psql', os.environ['DATABASE_URL']], input=sql, capture_output=True)\""
        ).is_none());
        assert!(check_env_value_read(
            "python3 -c \"import subprocess,os; subprocess.run(['psql', os.environ[\\\"DATABASE_URL\\\"]], capture_output=True)\""
        ).is_none());
    }

    #[test]
    fn blocks_proc_environ() {
        assert!(check_env_value_read("cat /proc/self/environ").is_some());
    }

    #[test]
    fn blocks_head_tail_on_dotenv() {
        assert!(check_env_value_read("head .env").is_some());
        assert!(check_env_value_read("tail -n 5 .env").is_some());
        assert!(check_env_value_read("less .env").is_some());
        assert!(check_env_value_read("strings .env").is_some());
    }
}
