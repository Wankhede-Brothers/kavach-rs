//! Response Security Guard — blocks privilege escalation via serde(default).
//! P0: serde(default) on role/permission fields enables privilege escalation via omission.
//! P1: PII fields, missing deny_unknown_fields, bool serde defaults.

use super::platform_guard_msg::{build_advisory, build_block};
use super::platform_guard_paths::is_test;

const PRIV_FIELDS: &[&str] = &[
    "is_admin", "is_moderator", "is_owner", "role", "permission",
];

const PII_FIELDS: &[&str] = &["email", "phone", "address", "ssn"];

fn is_backend_rs(path: &str) -> bool {
    if !path.ends_with(".rs") { return false; }
    path.contains("handler") || path.contains("route")
        || path.contains("controller") || path.contains("api")
}

pub fn check(file_path: &str, content: &str) -> Option<String> {
    if !is_backend_rs(file_path) || is_test(file_path) {
        return None;
    }
    let lc = content.to_lowercase();
    let mut p0: Vec<(&str, &str)> = Vec::new();

    let has_serde_default = lc.contains("serde(default")
        || lc.contains("serde( default");

    if has_serde_default {
        for field in PRIV_FIELDS {
            if lc.contains(field) {
                p0.push(("PRIV_FIELD_SERDE_DEFAULT",
                    "Remove #[serde(default)] from privilege fields (is_admin, role, permission) — \
                     a missing field defaults to false/empty, enabling privilege escalation via omission."));
                break;
            }
        }
    }

    if p0.is_empty() {
        return None;
    }
    Some(build_block("RESPONSE_SECURITY_GUARD", &p0))
}

pub fn format_advisory(file_path: &str, content: &str) -> Option<String> {
    if !file_path.ends_with(".rs") || is_test(file_path) {
        return None;
    }
    let lc = content.to_lowercase();
    let mut p1: Vec<(&str, &str)> = Vec::new();

    for field in PII_FIELDS {
        let plain = format!("pub {field}: string");
        if lc.contains(&plain) {
            p1.push(("PII_FIELD_UNENCRYPTED",
                "Wrap PII field (email/phone/address/ssn) in EncryptedField<T> or redact before serialization."));
            break;
        }
    }

    if (lc.contains("serde(default") || lc.contains("serde( default"))
        && lc.contains("bool")
        && !lc.contains("is_admin") && !lc.contains("is_moderator")
    {
        p1.push(("BOOL_SERDE_DEFAULT",
            "Change #[serde(default)] bool to Option<bool> — explicit None is safer than implicit false."));
    }

    if (lc.contains("struct") && (lc.contains("authrequest") || lc.contains("loginrequest")
        || lc.contains("grantrequest") || lc.contains("tokenclaim")))
        && !lc.contains("deny_unknown_fields")
    {
        p1.push(("MISSING_DENY_UNKNOWN",
            "Add #[serde(deny_unknown_fields)] to auth structs — rejects attacker-injected fields."));
    }

    if p1.is_empty() {
        return None;
    }
    Some(build_advisory("RESPONSE_SECURITY_GUARD", &p1))
}

#[cfg(test)]
mod tests {
    use super::*;

    const ADMIN_DEFAULT: &str = "#[serde(default)] is_admin: bool,";
    const ROLE_DEFAULT: &str = "#[serde(default)] pub role: String,";
    const PERM_DEFAULT: &str = "#[serde(default)] pub permission: String,";
    const MOD_DEFAULT: &str = "#[serde(default)] is_moderator: bool,";
    const OWNER_DEFAULT: &str = "#[serde(default)] is_owner: bool,";
    const PAGE_DEFAULT: &str = "#[serde(default)] pub page: u32,";

    #[test]
    fn should_block_serde_default_on_is_admin() {
        assert!(check("src/handlers/auth.rs", ADMIN_DEFAULT).is_some());
    }

    #[test]
    fn should_block_serde_default_on_role() {
        assert!(check("src/routes/user.rs", ROLE_DEFAULT).is_some());
    }

    #[test]
    fn should_block_serde_default_on_permission() {
        assert!(check("src/api/grant.rs", PERM_DEFAULT).is_some());
    }

    #[test]
    fn should_block_serde_default_on_is_moderator() {
        assert!(check("src/handlers/mod.rs", MOD_DEFAULT).is_some());
    }

    #[test]
    fn should_block_serde_default_on_is_owner() {
        assert!(check("src/api/resource.rs", OWNER_DEFAULT).is_some());
    }

    #[test]
    fn should_allow_when_option_used_instead() {
        assert!(check("src/handlers/auth.rs", "struct Req { is_admin: Option<bool> }").is_none());
    }

    #[test]
    fn should_allow_serde_default_on_unrelated_field() {
        assert!(check("src/handlers/search.rs", PAGE_DEFAULT).is_none());
    }

    #[test]
    fn should_skip_non_handler_paths() {
        assert!(check("src/models/user.rs", ADMIN_DEFAULT).is_none());
    }

    #[test]
    fn should_skip_test_files() {
        assert!(check("src/handlers/auth.test.rs", ADMIN_DEFAULT).is_none());
    }

    #[test]
    fn should_advise_pii_email_as_plain_string() {
        assert!(format_advisory("src/handlers/profile.rs", "pub email: string,").is_some());
    }

    #[test]
    fn should_advise_pii_ssn_as_plain_string() {
        assert!(format_advisory("src/api/kyc.rs", "pub ssn: string,").is_some());
    }

    #[test]
    fn should_advise_bool_serde_default() {
        assert!(format_advisory("src/handlers/settings.rs", "#[serde(default)] pub verified: bool,").is_some());
    }

    #[test]
    fn should_advise_missing_deny_unknown_on_auth_struct() {
        assert!(format_advisory("src/handlers/auth.rs", "struct AuthRequest { username: String }").is_some());
    }

    #[test]
    fn should_not_advise_when_deny_unknown_present() {
        assert!(format_advisory("src/handlers/auth.rs",
            "#[serde(deny_unknown_fields)] struct AuthRequest { username: String }").is_none());
    }

    #[test]
    fn should_skip_non_rs_files() {
        assert!(format_advisory("src/auth.ts", "pub email: String").is_none());
    }

    #[test]
    fn should_skip_test_files_in_advisory() {
        assert!(format_advisory("src/handlers/auth.test.rs", "pub email: String").is_none());
    }
}
