use kavach_session::SessionState;

/// Extract Rust crate name from an absolute file path.
/// Looks for `.../crates/<crate-name>/src/...` pattern.
/// Returns None when the pattern is not present (e.g. workspace root files).
fn crate_name_from_path(path: &str) -> Option<String> {
    let norm = path.replace('\\', "/");
    let marker = "/crates/";
    let pos = norm.find(marker)?;
    let after = &norm[pos + marker.len()..];
    let name = after.split('/').next()?;
    if name.is_empty() { None } else { Some(name.to_string()) }
}

/// Build test enforcement context to inject into intent gate output.
/// Returns None if no test debt, Some(context) if escalation is needed.
pub fn build_test_context(session: &mut SessionState) -> Option<String> {
    if !session.has_pending_tests() {
        return None;
    }
    let count = session.test_files_pending.len();
    let nudge = session.test_nudge_count;
    session.test_nudge_count += 1;
    let _ = session.save();

    let level = if nudge >= 10 {
        "URGENT"
    } else if nudge >= 6 {
        "strongly recommend (stop adding features)"
    } else if nudge >= 3 {
        "recommend"
    } else {
        "suggest"
    };

    let files = session.test_files_pending.join(", ");
    // Derive crate names from pending file paths — scope the test command to
    // affected crates only. Running --workspace on a 20-crate project takes
    // 19+ minutes; -p <crate> compiles and tests only what changed.
    // Path pattern: `.../crates/<crate-name>/src/...`
    let mut crate_names: Vec<String> = session
        .test_files_pending
        .iter()
        .filter_map(|p| crate_name_from_path(p))
        .collect();
    crate_names.sort();
    crate_names.dedup();
    let action = if crate_names.is_empty() {
        "cargo nextest run --workspace".to_string()
    } else {
        let flags = crate_names
            .iter()
            .map(|c| format!("-p {c}"))
            .collect::<Vec<_>>()
            .join(" ");
        format!("cargo nextest run {flags}")
    };
    Some(format!(
        "[TEST_ENFORCEMENT]\nstatus: {level}\npending: {count} file(s)\nfiles: {files}\naction: {action}\n"
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    use kavach_session::SessionState;

    #[test]
    fn test_no_pending() {
        let mut s = SessionState::default();
        assert!(build_test_context(&mut s).is_none());
    }

    #[test]
    fn test_with_pending_scopes_to_crate() {
        let mut s = SessionState::default();
        s.test_files_pending.push(
            "/Users/gauravwankhede/kavach-rs/crates/kavach-engine/src/gates/rag_router.rs".into(),
        );
        let ctx = build_test_context(&mut s).expect("should produce context");
        assert!(ctx.contains("TEST_ENFORCEMENT"));
        assert!(ctx.contains("-p kavach-engine"), "action must be scoped: {ctx}");
        assert!(!ctx.contains("--workspace"), "must not run full workspace: {ctx}");
    }

    #[test]
    fn test_with_two_crates_emits_both_flags() {
        let mut s = SessionState::default();
        s.test_files_pending.push(
            "/home/user/proj/crates/kavach-engine/src/gates/foo.rs".into(),
        );
        s.test_files_pending.push(
            "/home/user/proj/crates/kavach-db/src/memory.rs".into(),
        );
        let ctx = build_test_context(&mut s).expect("context");
        assert!(ctx.contains("-p kavach-db"), "missing kavach-db flag: {ctx}");
        assert!(ctx.contains("-p kavach-engine"), "missing kavach-engine flag: {ctx}");
    }

    #[test]
    fn test_workspace_fallback_for_non_crate_paths() {
        let mut s = SessionState::default();
        s.test_files_pending.push("src/main.rs".into());
        let ctx = build_test_context(&mut s).expect("context");
        assert!(ctx.contains("--workspace"), "non-crate path must fall back to workspace: {ctx}");
    }

    #[test]
    fn test_crate_name_from_path_extracts_name() {
        assert_eq!(
            crate_name_from_path("/Users/x/kavach-rs/crates/kavach-engine/src/gates/foo.rs"),
            Some("kavach-engine".into())
        );
        assert_eq!(crate_name_from_path("src/foo.rs"), None);
        assert_eq!(crate_name_from_path("/crates//src/foo.rs"), None);
    }
}
