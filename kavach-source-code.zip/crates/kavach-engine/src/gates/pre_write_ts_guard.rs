//! TypeScript Production Guard — pre-write gate for .ts/.tsx/.jsx/.astro files.
//! P0 violations (as any, hardcoded URLs, mock data, XSS) = HARD BLOCK.
//! P1 violations (console.log, direct DOM) = advisory warning.

use kavach_patterns::ts_guard::{TsSeverity, TsViolation};

pub fn check(file_path: &str, content: &str) -> Option<String> {
    let violations = kavach_patterns::ts_guard::detect(file_path, content);
    if violations.is_empty() {
        return None;
    }

    let p0: Vec<&TsViolation> = violations.iter()
        .filter(|v| v.severity == TsSeverity::P0Block)
        .collect();

    let p1: Vec<&TsViolation> = violations.iter()
        .filter(|v| v.severity == TsSeverity::P1Advisory)
        .collect();

    if !p0.is_empty() {
        let mut msg = String::from(
            "TS GUARD BLOCKED: Frontend production violations detected\n\n\
             P0 VIOLATIONS (HARD BLOCK):\n"
        );
        for v in &p0 {
            msg.push_str(&format!("  {} — {}\n", v.pattern, v.fix));
        }
        if !p1.is_empty() {
            msg.push_str("\nP1 ADVISORIES:\n");
            for v in &p1 {
                msg.push_str(&format!("  {} — {}\n", v.pattern, v.fix));
            }
        }
        msg.push_str(
            "\nREQUIRED: Fix all P0 violations before this write can proceed.\n\n\
             RESEARCH: WebSearch \"typescript type safety best practices {search_year}\"\n\
             SKILL: Invoke `interface-design` skill for frontend patterns.\n\
             FIX: Fetch data from API. Replace `as any` with explicit types.\n\
             Use Zod/io-ts for runtime validation at API boundaries."
        );
        return Some(msg);
    }

    None
}

const COMPONENT_FILE_LINE_LIMIT: usize = 100;

/// Universal component monolith detector for frontend files.
///
/// Triggers on ANY `.tsx/.jsx/.astro` file (not test, not config) when:
/// 1. File exceeds 100 lines
/// 2. Contains 2+ exported component functions
///
/// Universal: applies to `**/components/**`, `**/pages/**`, `**/layouts/**`,
/// `**/islands/**`, or any other directory. No hardcoded paths.
///
/// Escape hatch: `// split:` or `{/* split: */}` to suppress.
pub fn check_component_monolith(file_path: &str, content: &str) -> Option<String> {
    if !kavach_patterns::is_frontend_file(file_path) { return None; }
    if kavach_patterns::is_test_file(file_path) { return None; }
    if content.lines().count() <= COMPONENT_FILE_LINE_LIMIT { return None; }
    let lc = content.to_lowercase();
    if lc.contains("// split:") || lc.contains("{/* split:") { return None; }
    let export_count = count_exported_components(content);
    if export_count <= 1 { return None; }
    Some(format!(
        "COMPONENT_MONOLITH: File has {export_count} exported components over {} lines. \
         One component per file. Split each into its own file. \
         Add `// split:` comment to suppress if intentional.",
        content.lines().count()
    ))
}

/// Count exported component definitions in frontend code.
fn count_exported_components(content: &str) -> usize {
    let mut count = 0usize;
    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with("export type ")
            || trimmed.starts_with("export interface ")
        {
            continue;
        }
        if trimmed.starts_with("export function ")
            || trimmed.starts_with("export default function")
            || trimmed.starts_with("export async function ")
        {
            count = count.saturating_add(1);
            continue;
        }
        // export const ComponentName = (uppercase = component heuristic)
        if trimmed.starts_with("export const ") && trimmed.contains(" = ") {
            if let Some(rest) = trimmed.strip_prefix("export const ") {
                if let Some(c) = rest.chars().next() {
                    if c.is_uppercase() {
                        count = count.saturating_add(1);
                    }
                }
            }
        }
    }
    count
}

pub fn format_advisory(file_path: &str, content: &str) -> Option<String> {
    let violations = kavach_patterns::ts_guard::detect(file_path, content);
    let p1: Vec<&TsViolation> = violations.iter()
        .filter(|v| v.severity == TsSeverity::P1Advisory)
        .collect();
    if p1.is_empty() { return None; }
    let mut msg = String::from("[TS_GUARD_ADVISORY]\n");
    for v in &p1 {
        msg.push_str(&format!("  {} — {}\n", v.pattern, v.fix));
    }
    Some(msg)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_block_when_as_any_cast() {
        assert!(check("src/App.tsx", "const x = y as any;").is_some());
    }

    #[test]
    fn should_block_when_console_log() {
        assert!(check("src/App.tsx", "console.log('debug');").is_some());
    }

    #[test]
    fn should_allow_when_typed_fetch() {
        assert!(check("src/App.tsx", "const user: User = await fetchUser();").is_none());
    }

    #[test]
    fn should_skip_test_files() {
        assert!(check("src/App.test.tsx", "const x = y as any;").is_none());
    }

    #[test]
    fn should_skip_config_files() {
        assert!(check("vite.config.ts", "eval(x)").is_none());
    }

    #[test]
    fn should_emit_no_advisory_for_clean_code() {
        assert!(format_advisory("src/App.tsx", "const x = 1;").is_none());
    }

    // --- Component monolith tests ---

    #[test]
    fn should_block_component_monolith_with_multiple_exports() {
        let mut body = "export function Sidebar() { return <div/>; }\n\
                        export function Header() { return <div/>; }\n"
            .to_string();
        body.push_str(&"// padding\n".repeat(100));
        let result = check_component_monolith("src/components/Layout.tsx", &body);
        assert!(result.is_some());
        let msg = result.unwrap_or_default();
        assert!(msg.contains("COMPONENT_MONOLITH"));
        assert!(msg.contains('2'));
    }

    #[test]
    fn should_not_block_single_export_component() {
        let mut body = "export default function Dashboard() { return <div/>; }\n".to_string();
        body.push_str(&"// padding\n".repeat(110));
        assert!(check_component_monolith("src/pages/Dashboard.tsx", &body).is_none());
    }

    #[test]
    fn should_not_block_component_under_line_limit() {
        let body = "export function A() {}\nexport function B() {}\n".repeat(3);
        assert!(check_component_monolith("src/components/Small.tsx", &body).is_none());
    }

    #[test]
    fn should_not_block_with_split_escape_hatch() {
        let mut body = "// split: compound component\n".to_string();
        body.push_str(&"export function A() {}\nexport function B() {}\n".repeat(52));
        assert!(check_component_monolith("src/components/Compound.tsx", &body).is_none());
    }

    #[test]
    fn should_not_block_with_jsx_split_escape_hatch() {
        let mut body = "{/* split: compound component */}\n".to_string();
        body.push_str(&"export function A() {}\nexport function B() {}\n".repeat(52));
        assert!(check_component_monolith("src/components/Compound.jsx", &body).is_none());
    }

    #[test]
    fn should_not_count_type_or_interface_exports() {
        let mut body = "export type Props = { x: string };\n\
                        export interface Config { y: number; }\n\
                        export function App() { return <div/>; }\n"
            .to_string();
        body.push_str(&"// padding\n".repeat(100));
        assert!(check_component_monolith("src/App.tsx", &body).is_none());
    }

    #[test]
    fn should_count_uppercase_const_exports_as_components() {
        let mut body = "export const Sidebar = () => <div/>;\n\
                        export const Header = () => <div/>;\n"
            .to_string();
        body.push_str(&"// padding\n".repeat(100));
        assert!(check_component_monolith("src/Layout.tsx", &body).is_some());
    }

    #[test]
    fn should_not_count_lowercase_const_exports() {
        let mut body = "export const config = { theme: 'dark' };\n\
                        export const utils = { format: () => {} };\n\
                        export function App() { return <div/>; }\n"
            .to_string();
        body.push_str(&"// padding\n".repeat(100));
        assert!(check_component_monolith("src/App.tsx", &body).is_none());
    }

    #[test]
    fn should_block_in_any_directory() {
        let mut body = "export function A() {}\nexport function B() {}\n".to_string();
        body.push_str(&"// padding\n".repeat(100));
        assert!(check_component_monolith("src/pages/Home.tsx", &body).is_some());
        assert!(check_component_monolith("src/islands/Nav.tsx", &body).is_some());
        assert!(check_component_monolith("packages/shared/UI.jsx", &body).is_some());
        assert!(check_component_monolith("src/Layout.astro", &body).is_some());
    }

    #[test]
    fn should_skip_test_files_for_component_monolith() {
        let mut body = "export function A() {}\nexport function B() {}\n".to_string();
        body.push_str(&"// padding\n".repeat(100));
        assert!(check_component_monolith("src/App.test.tsx", &body).is_none());
    }

    #[test]
    fn should_skip_non_frontend_files_for_component_monolith() {
        let mut body = "export function A() {}\nexport function B() {}\n".to_string();
        body.push_str(&"// padding\n".repeat(100));
        assert!(check_component_monolith("src/main.rs", &body).is_none());
        assert!(check_component_monolith("src/config.json", &body).is_none());
    }
}
