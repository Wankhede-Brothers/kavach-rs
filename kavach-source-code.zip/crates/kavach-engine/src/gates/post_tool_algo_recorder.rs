//! Algorithm decision recorder — fires after Write/Edit on .rs files.
//!
//! Extracts the structured `// ALGO:` comment block from written content,
//! upserts the decision into `algorithm_decisions`, appends a kavach-db event,
//! writes graph edges (file→algorithm, algorithm→problem_class), and triggers
//! `kavach rag enrich` on the algorithm-hunter skill directory.
//!
//! All operations are fire-and-forget — a recorder failure never blocks the
//! post-write gate. Errors are silently dropped via `let _ =`.

use std::io::Write as _;
use std::process::Command;

/// Parsed fields from the structured `// ALGO:` comment block.
struct AlgoComment {
    chosen: String,
    problem_class: String,
    rejected_json: String,
    rationale: String,
    time_complexity: String,
    space_complexity: String,
    year_published: i64,
    search_year: i64,
    search_month: i64,
    benchmark_source: Option<String>,
}

/// Extract the `// ALGO:` structured comment block from file content.
/// Returns `None` if no valid block is present.
fn extract_algo_comment(content: &str) -> Option<AlgoComment> {
    // Required fields — abort if any are missing.
    let chosen = extract_field(content, "ALGO:")?;
    let problem_class = extract_field(content, "PROBLEM_CLASS:")?;

    // Optional fields with sensible defaults.
    let rejected_json = match extract_field(content, "REJECTED:") {
        Some(v) => v,
        None => "[]".into(),
    };
    let rationale = match extract_field(content, "TRADEOFF:") {
        Some(v) => v,
        None => String::new(),
    };
    // TIME format: "O(n log n) | SPACE: O(log n)" — take only the part before "|"
    let time_complexity = match extract_field(content, "TIME:") {
        Some(v) => match v.split('|').next() {
            Some(s) => s.trim().to_string(),
            None => "unknown".into(),
        },
        None => "unknown".into(),
    };
    let space_complexity = match extract_field(content, "SPACE:") {
        Some(v) => match v.split('|').next() {
            Some(s) => s.trim().to_string(),
            None => "unknown".into(),
        },
        None => "unknown".into(),
    };
    // YEAR field may carry an inline SEARCHED suffix:
    // "2021 | SEARCHED: 2026-04" — extract both in one pass.
    let (year_published, inline_searched) = match extract_field(content, "YEAR:") {
        Some(v) => {
            let mut parts = v.splitn(2, '|');
            let year_raw = match parts.next() {
                Some(s) => s.trim().to_string(),
                None => v.clone(),
            };
            let year = match year_raw.parse::<i64>() {
                Ok(y) => y,
                Err(_) => 0,
            };
            // Extract "SEARCHED: YYYY-MM" from the suffix after "|"
            let searched = parts.next().and_then(|suffix| {
                suffix.trim()
                    .strip_prefix("SEARCHED:")
                    .map(|s| s.trim().to_string())
            });
            (year, searched)
        }
        None => (0, None),
    };
    let benchmark_source = extract_field(content, "BENCHMARK:");

    // Standalone "// SEARCHED:" line takes precedence; fall back to inline suffix.
    let searched_raw = extract_field(content, "SEARCHED:").or(inline_searched);
    let (search_year, search_month) = match searched_raw {
        Some(v) => {
            let mut parts = v.splitn(2, '-');
            let y = match parts.next() {
                Some(s) => match s.trim().parse::<i64>() {
                    Ok(n) => n,
                    Err(_) => current_year(),
                },
                None => current_year(),
            };
            let m = match parts.next() {
                Some(s) => match s.trim().parse::<i64>() {
                    Ok(n) => n,
                    Err(_) => current_month(),
                },
                None => current_month(),
            };
            (y, m)
        }
        None => (current_year(), current_month()),
    };

    Some(AlgoComment {
        chosen,
        problem_class,
        rejected_json,
        rationale,
        time_complexity,
        space_complexity,
        year_published,
        search_year,
        search_month,
        benchmark_source,
    })
}

/// Extract the value after `// <field_key> ` on any line in the content.
fn extract_field(content: &str, field_key: &str) -> Option<String> {
    for line in content.lines() {
        let trimmed = line.trim();
        if !trimmed.starts_with("//") {
            continue;
        }
        let after_slashes = trimmed.trim_start_matches('/').trim();
        if let Some(rest) = after_slashes.strip_prefix(field_key) {
            let value = rest.trim().to_string();
            if !value.is_empty() {
                return Some(value);
            }
        }
    }
    None
}

fn current_year() -> i64 {
    match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
        Ok(d) => match i64::try_from(d.as_secs() / 31_557_600) {
            Ok(y) => 1970 + y,
            Err(_) => 2026,
        },
        Err(_) => 2026,
    }
}

fn current_month() -> i64 {
    // Approximate: seconds since epoch, mod 12 months per year.
    match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
        Ok(d) => {
            let days_since_epoch = d.as_secs() / 86_400;
            // Simplified: use day-of-year to estimate month (1-12).
            let day_of_year = (days_since_epoch % 365) + 1;
            let month = (day_of_year / 31).min(11) + 1;
            match i64::try_from(month) {
                Ok(m) => m,
                Err(_) => 1,
            }
        }
        Err(_) => 1,
    }
}

/// Verify the structured `// ALGO:` comment fields before recording.
///
/// Checks:
/// 1. `SEARCHED:` year is within [current_year-1, current_year] — not stale, not future.
/// 2. `YEAR:` publication year is plausible (1950 ≤ year ≤ current_year).
/// 3. `BENCHMARK:` URL returns a 2xx/3xx HTTP status via `curl --head`.
///
/// Returns `Ok(())` on pass, `Err(reason)` on failure.
fn verify_algo_comment(algo: &AlgoComment) -> Result<(), String> {
    let now_year = current_year();

    if algo.search_year < now_year - 1 {
        return Err(format!(
            "SEARCHED year {} is stale (current: {}). Re-run /algorithm-hunter.",
            algo.search_year, now_year
        ));
    }
    if algo.search_year > now_year {
        return Err(format!(
            "SEARCHED year {} is in the future (current: {}). Check SEARCHED field.",
            algo.search_year, now_year
        ));
    }
    if algo.year_published != 0
        && (algo.year_published < 1950 || algo.year_published > now_year)
    {
        return Err(format!(
            "YEAR {} is implausible (valid range: 1950–{}). Verify publication year.",
            algo.year_published, now_year
        ));
    }
    if let Some(ref url) = algo.benchmark_source {
        if !url.is_empty() {
            match verify_url(url) {
                Ok(true) => {}
                Ok(false) => {
                    return Err(format!(
                        "BENCHMARK URL returned 404 or unreachable: {}. \
                         Provide a valid crates.io or arXiv URL.",
                        url
                    ));
                }
                Err(e) => {
                    return Err(format!(
                        "BENCHMARK URL could not be verified ({}): {}. \
                         Check network or provide a reachable URL.",
                        e, url
                    ));
                }
            }
        }
    }
    Ok(())
}

/// Check URL reachability via `curl --head --max-time 5`.
/// Returns `Ok(true)` for 2xx/3xx, `Ok(false)` for 4xx/5xx, `Err` if curl fails.
fn verify_url(url: &str) -> Result<bool, String> {
    let output = Command::new("curl")
        .args([
            "--head",
            "--silent",
            "--max-time", "5",
            "--output", "/dev/null",
            "--write-out", "%{http_code}",
            url,
        ])
        .output()
        .map_err(|e| e.to_string())?;

    let code_str = String::from_utf8_lossy(&output.stdout);
    let code: u16 = match code_str.trim().parse() {
        Ok(n) => n,
        Err(_) => return Err(format!("unexpected curl output: {}", code_str.trim())),
    };
    Ok(code >= 200 && code < 400)
}

/// Record an algorithm decision after a Write/Edit to a .rs file.
/// Verifies comment fields before upsert — rejects stale/invalid decisions.
/// Fire-and-forget on DB/event errors — recorder failure never blocks the gate.
pub fn record(file_path: &str, content: &str, project_slug: &str, turn: i64) {
    if !file_path.ends_with(".rs") {
        return;
    }
    let algo = match extract_algo_comment(content) {
        Some(a) => a,
        None => return,
    };

    // Verification layer — reject before touching the DB.
    if let Err(reason) = verify_algo_comment(&algo) {
        if let Ok(conn) = kavach_db::open_default() {
            let payload = format!(
                r#"{{"chosen":"{}","file":"{}","reason":"{}"}}"#,
                algo.chosen, file_path, reason
            );
            let _ = kavach_db::events::append(
                &conn,
                None,
                "algorithm_decision_rejected",
                "post_write_algo_recorder",
                None,
                Some(payload.as_str()),
            );
        }
        // Write rejection reason to stderr so the post-write gate surfaces it.
        let _ = writeln!(std::io::stderr(), "[ALGO_VERIFY_FAIL] {}", reason);
        return;
    }

    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(_) => return,
    };

    // Resolve project_id from slug.
    let project_id = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p.id,
        Err(_) => return,
    };

    let simd_capable = content.contains("simd") || content.contains("avx") || content.contains("sse");
    let parallel_safe = content.contains("Send") || content.contains("Sync")
        || content.contains("par_iter") || content.contains("rayon");

    let input = kavach_db::algo_decisions::AlgoDecisionInput {
        project_id,
        problem_class: &algo.problem_class,
        chosen: &algo.chosen,
        rejected: &algo.rejected_json,
        rationale: &algo.rationale,
        time_complexity: &algo.time_complexity,
        space_complexity: &algo.space_complexity,
        year_published: algo.year_published,
        search_year: algo.search_year,
        search_month: algo.search_month,
        benchmark_source: algo.benchmark_source.as_deref(),
        simd_capable,
        parallel_safe,
        file_path,
        turn,
    };

    let _ = kavach_db::algo_decisions::upsert(&conn, &input);

    // Append event — triggers projections automatically.
    let payload = format!(
        r#"{{"chosen":"{}","problem_class":"{}","file":"{}"}}"#,
        algo.chosen, algo.problem_class, file_path
    );
    let _ = kavach_db::events::append(
        &conn,
        None,
        "algorithm_decision",
        "post_write_algo_recorder",
        Some(project_id),
        Some(payload.as_str()),
    );

    // Write graph edges: file→algorithm, algorithm→problem_class.
    // Upsert entities to get IDs, then add relationships.
    let file_id = kavach_db::graph_entity::upsert_entity(&conn, "file", file_path, None);
    let algo_id = kavach_db::graph_entity::upsert_entity(&conn, "algorithm", &algo.chosen, None);
    let class_id = kavach_db::graph_entity::upsert_entity(&conn, "problem_class", &algo.problem_class, None);
    if let (Ok(fid), Ok(aid)) = (file_id, algo_id) {
        let _ = kavach_db::graph::add_relationship(&conn, fid, aid, "uses_algorithm", 1.0);
    }
    if let (Ok(aid2), Ok(cid)) = (
        kavach_db::graph_entity::upsert_entity(&conn, "algorithm", &algo.chosen, None),
        class_id,
    ) {
        let _ = kavach_db::graph::add_relationship(&conn, aid2, cid, "solves", 1.0);
    }

    // Trigger RAG enrich on algorithm-hunter skill — non-blocking subprocess.
    let skills_dir = kavach_config::paths::skills_dir();
    let algo_skill_dir = skills_dir.join("algorithm-hunter");
    if algo_skill_dir.exists() {
        let _ = Command::new("kavach")
            .args([
                "rag", "enrich",
                "--source", &algo_skill_dir.to_string_lossy(),
                "--label", "skills",
            ])
            .spawn();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // No BENCHMARK field — avoids network calls in unit tests.
    // SEARCHED: is on its own line so extract_field can find it.
    fn full_comment(search_year: i64, search_month: i64, year_published: i64) -> String {
        format!(
            "// ALGO: pdqsort\n\
             // PROBLEM_CLASS: sorting\n\
             // REJECTED: [{{\"name\":\"quicksort\",\"reason\":\"unstable\"}}]\n\
             // TIME: O(n log n) | SPACE: O(log n)\n\
             // YEAR: {}\n\
             // SEARCHED: {}-{:02}\n\
             // TRADEOFF: not stable\n\
             fn sort_items() {{}}",
            year_published, search_year, search_month
        )
    }

    #[test]
    fn extracts_full_algo_comment() {
        let content = full_comment(2026, 4, 2021);
        let algo = match extract_algo_comment(&content) {
            Some(a) => a,
            None => panic!("expected Some"),
        };
        assert_eq!(algo.chosen, "pdqsort");
        assert_eq!(algo.problem_class, "sorting");
        assert_eq!(algo.search_year, 2026);
        assert_eq!(algo.search_month, 4);
        assert_eq!(algo.year_published, 2021);
        assert!(algo.benchmark_source.is_none());
    }

    #[test]
    fn returns_none_when_no_algo_comment() {
        assert!(extract_algo_comment("fn greet() {}").is_none());
    }

    #[test]
    fn returns_none_when_missing_required_field() {
        assert!(extract_algo_comment("// ALGO: pdqsort\nfn sort() {}").is_none());
    }

    #[test]
    fn extract_field_finds_value() {
        let content = "// ALGO: robin-hood-hashing\n// PROBLEM_CLASS: hash-map";
        assert_eq!(extract_field(content, "ALGO:").as_deref(), Some("robin-hood-hashing"));
        assert_eq!(extract_field(content, "PROBLEM_CLASS:").as_deref(), Some("hash-map"));
    }

    #[test]
    fn extract_field_returns_none_when_absent() {
        assert!(extract_field("fn main() {}", "ALGO:").is_none());
    }

    #[test]
    fn extracts_inline_searched_from_year_line() {
        // Skill template uses "YEAR: 2021 | SEARCHED: 2026-04" on one line.
        let content = "// ALGO: pdqsort\n\
                       // PROBLEM_CLASS: sorting\n\
                       // YEAR: 2021 | SEARCHED: 2026-04\n\
                       fn sort() {}";
        let algo = match extract_algo_comment(content) {
            Some(a) => a,
            None => panic!("expected Some"),
        };
        assert_eq!(algo.year_published, 2021);
        assert_eq!(algo.search_year, 2026);
        assert_eq!(algo.search_month, 4);
    }

    // --- Verification layer tests ---

    #[test]
    fn verify_rejects_stale_search_year() {
        let content = full_comment(2020, 1, 2019);
        let algo = match extract_algo_comment(&content) {
            Some(a) => a,
            None => panic!("expected Some"),
        };
        let result = verify_algo_comment(&algo);
        assert!(result.is_err());
        let msg = result.err().unwrap_or_default();
        assert!(msg.contains("stale"), "expected 'stale' in: {msg}");
    }

    #[test]
    fn verify_rejects_future_search_year() {
        let now = current_year();
        let content = full_comment(now + 2, 1, 2021);
        let algo = match extract_algo_comment(&content) {
            Some(a) => a,
            None => panic!("expected Some"),
        };
        let result = verify_algo_comment(&algo);
        assert!(result.is_err());
        let msg = result.err().unwrap_or_default();
        assert!(msg.contains("future"), "expected 'future' in: {msg}");
    }

    #[test]
    fn verify_rejects_implausible_publication_year() {
        let now = current_year();
        let content = full_comment(now, 4, 1900);
        let algo = match extract_algo_comment(&content) {
            Some(a) => a,
            None => panic!("expected Some"),
        };
        let result = verify_algo_comment(&algo);
        assert!(result.is_err());
        let msg = result.err().unwrap_or_default();
        assert!(msg.contains("implausible"), "expected 'implausible' in: {msg}");
    }

    #[test]
    fn verify_passes_valid_comment_no_benchmark() {
        let now = current_year();
        // No BENCHMARK field — skip URL check. SEARCHED: on its own line.
        let content = format!(
            "// ALGO: pdqsort\n\
             // PROBLEM_CLASS: sorting\n\
             // REJECTED: []\n\
             // TIME: O(n log n) | SPACE: O(log n)\n\
             // YEAR: 2021\n\
             // SEARCHED: {now}-04\n\
             // TRADEOFF: none\n\
             fn sort() {{}}"
        );
        let algo = match extract_algo_comment(&content) {
            Some(a) => a,
            None => panic!("expected Some"),
        };
        assert!(verify_algo_comment(&algo).is_ok());
    }
}
