//! Microservice Architecture Guard — enforces modular service structure.
//! Each service module must self-contain state, handlers, and types.
//! No dumping initialization logic into app.rs or lib.rs orchestrators.
//! mod.rs is a pure routing hub: no fn bodies, no struct/impl, max 100 lines.
//! Universal: applies to any Rust backend regardless of project layout.

use super::platform_guard_paths::is_test;
use super::platform_guard_msg::{build_block, build_advisory};

const MOD_RS_LINE_LIMIT: usize = 100;
/// Files over this threshold with struct+impl+async fn mixed are monoliths.
const MIXED_CONCERNS_LINE_LIMIT: usize = 200;

fn is_orchestrator(path: &str) -> bool {
    let lc = path.to_lowercase();
    lc.ends_with("app.rs") || lc.ends_with("main.rs") || lc.ends_with("lib.rs")
}

fn is_mod_rs(path: &str) -> bool {
    path.ends_with("mod.rs")
}

fn has_fn_body_in_mod(content: &str) -> bool {
    let lc = content.to_lowercase();
    // Allow files with an explicit hub marker comment — dispatch() in cmd/mod.rs is intentional.
    if lc.contains("// hub:") {
        return false;
    }
    (lc.contains("pub async fn ") || lc.contains("async fn ") || lc.contains("pub fn "))
        && lc.contains('{')
}

fn has_struct_or_impl_in_mod(content: &str) -> bool {
    let lc = content.to_lowercase();
    // Allow files with an explicit hub marker comment
    if lc.contains("// hub:") {
        return false;
    }
    lc.contains("pub struct ") || lc.contains("struct ") || lc.contains("impl ")
}

fn exceeds_mod_line_limit(content: &str) -> bool {
    content.lines().count() > MOD_RS_LINE_LIMIT
}

/// True when a non-mod, non-orchestrator file mixes struct definitions,
/// impl blocks, AND async handler functions — the classic monolith pattern.
/// Files under MIXED_CONCERNS_LINE_LIMIT may still be cohesive; over it they are not.
/// Escape hatch: add `// split:` anywhere in the file to suppress.
fn is_mixed_concerns_monolith(file_path: &str, content: &str) -> bool {
    if is_mod_rs(file_path) || is_orchestrator(file_path) { return false; }
    if content.lines().count() <= MIXED_CONCERNS_LINE_LIMIT { return false; }
    let lc = content.to_lowercase();
    if lc.contains("// split:") { return false; }
    let has_struct = lc.contains("pub struct ") || lc.contains("struct ");
    let has_impl   = lc.contains("impl ");
    let has_async  = lc.contains("pub async fn ") || lc.contains("async fn ");
    has_struct && has_impl && has_async
}

const HANDLER_FILE_LINE_LIMIT: usize = 100;

/// Universal handler monolith detector.
///
/// Triggers on ANY `.rs` file (not mod.rs, not orchestrator, not test) when:
/// 1. File exceeds 100 lines
/// 2. Contains 2+ `async fn` definitions
///
/// This is universal: applies to `**/middleware/**/*.rs`, `**/handler*/**/*.rs`,
/// `**/routes/**/*.rs`, `**/services/**/*.rs`, `**/*_middleware.rs`,
/// `**/*_handler.rs`, or ANY other directory layout. No hardcoded names.
///
/// Rationale: multiple async fn in one file = multiple handlers colocated.
/// Each handler/middleware should be its own file for single-responsibility.
///
/// Escape hatch: add `// split:` anywhere in the file to suppress.
fn is_handler_monolith(file_path: &str, content: &str) -> bool {
    if is_mod_rs(file_path) || is_orchestrator(file_path) { return false; }
    if content.lines().count() <= HANDLER_FILE_LINE_LIMIT { return false; }
    let lc = content.to_lowercase();
    if lc.contains("// split:") { return false; }
    lc.matches("async fn ").count() > 1
}

fn has_state_struct_in_orchestrator(content: &str) -> bool {
    let lc = content.to_lowercase();
    lc.contains("pub struct") && lc.contains("state")
        && (lc.contains("arc<") || lc.contains("pool") || lc.contains("pub fn new"))
}

fn has_inline_service_init(content: &str) -> bool {
    let lc = content.to_lowercase();
    (lc.contains("::from_env(") || lc.contains("::from_config(") || lc.contains("::init("))
        && lc.contains("router::new()")
        && lc.contains(".route(")
}

pub fn check(file_path: &str, content: &str) -> Option<String> {
    if !file_path.ends_with(".rs") || is_test(file_path) { return None; }
    let mut p0: Vec<(&str, &str)> = Vec::new();

    if is_mod_rs(file_path) {
        if has_fn_body_in_mod(content) {
            p0.push(("LOGIC_IN_MOD",
                "mod.rs is a pure routing hub. Move fn bodies to dedicated files \
                 (handler.rs, routes.rs, service.rs). mod.rs must only contain: \
                 mod declarations, pub use re-exports, use statements."));
        }
        if has_struct_or_impl_in_mod(content) {
            p0.push(("STRUCT_IN_MOD",
                "mod.rs must not define structs or impls. Move to state.rs, types.rs, \
                 or the relevant domain file. Add '// hub:' comment to suppress if intentional."));
        }
        if exceeds_mod_line_limit(content) && !content.to_lowercase().contains("// hub:") {
            p0.push(("MOD_TOO_LARGE",
                "mod.rs exceeds 100 lines. A hub file should only route — split logic \
                 into focused files (handler.rs, routes.rs, service.rs, types.rs). \
                 Add `// hub:` comment to suppress if this is an intentional dispatch hub."));
        }
    }

    if is_mixed_concerns_monolith(file_path, content) {
        p0.push(("FILE_MIXED_CONCERNS",
            "File mixes struct definitions, impl blocks, and async handlers over 200 lines. \
             Split into: types.rs (structs), service.rs (impl logic), handler.rs (async fn). \
             Add `// split:` comment to suppress if intentional."));
    }

    if is_handler_monolith(file_path, content) {
        p0.push(("HANDLER_MONOLITH",
            "Handler/middleware file exceeds 100 lines with multiple async fn. \
             Rule: one async fn per file. Split each handler into its own file \
             (e.g. auth_middleware.rs, request_context_middleware.rs). \
             Add `// split:` comment to suppress if intentional."));
    }

    if is_orchestrator(file_path) {
        if has_state_struct_in_orchestrator(content) {
            p0.push(("STATE_IN_ORCHESTRATOR",
                "Service state structs belong in the service module (e.g. media/state.rs), \
                 not in app.rs/main.rs/lib.rs. Each service self-contains its initialization."));
        }
        if has_inline_service_init(content) {
            p0.push(("INIT_IN_ORCHESTRATOR",
                "Service initialization (::from_env, ::from_config, ::init) belongs in the \
                 service module's routes() fn. Use: service::routes(deps)."));
        }
    }

    if p0.is_empty() { return None; }
    Some(build_block("MICROSERVICE_GUARD", &p0))
}

pub fn format_advisory(file_path: &str, content: &str) -> Option<String> {
    if !file_path.ends_with(".rs") || is_test(file_path) { return None; }
    // mod.rs violations are P0 hard blocks in check() — skip advisory for mod.rs
    if is_mod_rs(file_path) { return None; }
    if is_orchestrator(file_path) { return None; }
    let lc = content.to_lowercase();
    let mut p1: Vec<(&str, &str)> = Vec::new();

    if lc.contains("pub struct") && lc.contains("pub async fn")
        && lc.contains("impl") && (lc.contains("axum::") || lc.contains("router"))
    {
        p1.push(("MIXED_CONCERNS",
            "Split service: state.rs (struct), handler.rs (async fn), types.rs \
             (request/response). One concern per file."));
    }
    if p1.is_empty() { return None; }
    Some(build_advisory("MICROSERVICE_GUARD", &p1))
}

#[cfg(test)]
mod tests {
    use super::*;

    // --- orchestrator checks ---

    #[test]
    fn should_block_state_struct_in_app_rs() {
        assert!(check("src/app.rs",
            "pub struct AppState { pub fn new() {} arc<Pool> pool }").is_some());
    }

    #[test]
    fn should_allow_state_struct_in_service_module() {
        assert!(check("src/media/state.rs",
            "pub struct MediaState { pub fn new() {} arc<Pool> pool }").is_none());
    }

    #[test]
    fn should_block_inline_init_in_main_rs() {
        assert!(check("src/main.rs",
            "let svc = MyService::from_env(); let r = Router::new().route(\"/\", get(handler))").is_some());
    }

    #[test]
    fn should_skip_non_rs_files() {
        assert!(check("src/pages/feed.tsx",
            "pub struct AppState { arc<Pool> pool }").is_none());
    }

    #[test]
    fn should_skip_test_files() {
        assert!(check("src/app.test.rs",
            "pub struct AppState { pub fn new() {} }").is_none());
    }

    // --- mod.rs P0 hard blocks ---

    #[test]
    fn should_block_fn_body_in_mod_rs() {
        let msg = check("src/services/mod.rs",
            "pub mod auth;\npub use auth::AuthService;\npub fn helper() { do_thing(); }");
        assert!(msg.is_some());
        let m = msg.unwrap();
        assert!(m.contains("LOGIC_IN_MOD"));
    }

    #[test]
    fn should_block_async_fn_in_mod_rs() {
        let msg = check("src/services/mod.rs",
            "pub mod users;\npub async fn handle() { }");
        assert!(msg.is_some());
        assert!(msg.unwrap().contains("LOGIC_IN_MOD"));
    }

    #[test]
    fn should_block_struct_in_mod_rs() {
        let msg = check("src/services/mod.rs",
            "pub mod auth;\npub struct ServiceConfig { pub timeout: u64 }");
        assert!(msg.is_some());
        assert!(msg.unwrap().contains("STRUCT_IN_MOD"));
    }

    #[test]
    fn should_block_impl_in_mod_rs() {
        let msg = check("src/services/mod.rs",
            "pub mod auth;\nimpl Default for Foo { fn default() -> Self { Self } }");
        assert!(msg.is_some());
        assert!(msg.unwrap().contains("STRUCT_IN_MOD"));
    }

    #[test]
    fn should_block_mod_rs_over_100_lines() {
        let content = "pub mod a;\n".repeat(101);
        let msg = check("src/services/mod.rs", &content);
        assert!(msg.is_some());
        assert!(msg.unwrap().contains("MOD_TOO_LARGE"));
    }

    #[test]
    fn should_allow_clean_mod_rs_hub() {
        let content = "pub mod auth;\npub mod users;\npub use auth::AuthService;\nuse crate::error::Error;\n";
        assert!(check("src/services/mod.rs", content).is_none());
    }

    #[test]
    fn should_allow_hub_marker_bypass_for_struct_in_mod_rs() {
        // Explicit opt-out via // hub: comment
        let content = "// hub: intentional — legacy layout\npub mod auth;\npub struct LegacyConfig {}";
        assert!(check("src/services/mod.rs", content).is_none());
    }

    // --- advisory ---

    #[test]
    fn should_advise_mixed_concerns_in_service_file() {
        assert!(format_advisory("src/media/proxy.rs",
            "pub struct State {} impl State {} pub async fn handler() {} axum::Router").is_some());
    }

    #[test]
    fn should_not_advise_clean_handler_file() {
        assert!(format_advisory("src/media/handler.rs",
            "pub async fn media_handler(State(s): State<S>) -> impl IntoResponse {}").is_none());
    }

    #[test]
    fn should_not_advise_mod_rs_advisory_only_blocks() {
        // mod.rs violations are P0 blocks, not advisories
        assert!(format_advisory("src/services/mod.rs",
            "pub async fn handler() {}").is_none());
    }

    // --- FILE_MIXED_CONCERNS P0 blocks ---

    #[test]
    fn should_block_mixed_concerns_monolith_over_200_lines() {
        let body = "pub struct Svc {}\nimpl Svc {}\npub async fn handler() {}\n".repeat(70);
        let msg = check("src/services/registration.rs", &body);
        assert!(msg.is_some());
        assert!(msg.unwrap().contains("FILE_MIXED_CONCERNS"));
    }

    #[test]
    fn should_allow_mixed_concerns_under_200_lines() {
        // Under the line limit → not a monolith
        let body = "pub struct Svc {}\nimpl Svc {}\npub async fn handler() {}\n".repeat(5);
        assert!(check("src/services/registration.rs", &body).is_none());
    }

    #[test]
    fn should_allow_mixed_concerns_with_split_escape_hatch() {
        let mut body = "// split: intentional monolith, legacy\n".to_string();
        body.push_str(&"pub struct Svc {}\nimpl Svc {}\npub async fn handler() {}\n".repeat(70));
        assert!(check("src/services/registration.rs", &body).is_none());
    }

    #[test]
    fn should_not_block_orchestrator_with_mixed_concerns() {
        // app.rs / main.rs are excluded from FILE_MIXED_CONCERNS
        let body = "pub struct Svc {}\nimpl Svc {}\npub async fn handler() {}\n".repeat(70);
        // orchestrator may trigger STATE_IN_ORCHESTRATOR but not FILE_MIXED_CONCERNS
        let msg = check("src/app.rs", &body);
        if let Some(m) = msg {
            assert!(!m.contains("FILE_MIXED_CONCERNS"));
        }
    }

    // --- HANDLER_MONOLITH P0 blocks ---

    #[test]
    fn should_block_handler_monolith_in_middleware_dir() {
        // 2 async fn + enough lines to exceed 100-line threshold
        let mut body = "pub async fn auth_middleware() {}\npub async fn context_middleware() {}\n".to_string();
        body.push_str(&"fn helper() {}\n".repeat(100));
        let msg = check("src/middleware/request_context_middleware.rs", &body);
        assert!(msg.is_some());
        let m = msg.unwrap_or_default();
        assert!(m.contains("HANDLER_MONOLITH"));
    }

    #[test]
    fn should_block_handler_monolith_in_any_directory() {
        // Universal: not tied to middleware/ — any .rs file with 2+ async fn over 100 lines
        let body = "pub async fn foo() {}\npub async fn bar() {}\n".repeat(52);
        assert!(check("src/services/registration.rs", &body).is_some());
        assert!(check("src/routes/users.rs", &body).is_some());
        assert!(check("src/auth_middleware.rs", &body).is_some());
        assert!(check("src/api/v1/orders.rs", &body).is_some());
    }

    #[test]
    fn should_not_block_single_async_fn_over_100_lines() {
        // One async fn + many helpers = not a handler monolith (single responsibility)
        let mut body = "pub async fn request_context_middleware() {}\n".to_string();
        body.push_str(&"fn helper() {}\n".repeat(110));
        assert!(check("src/middleware/request_context.rs", &body).is_none());
    }

    #[test]
    fn should_not_block_handler_monolith_with_split_escape_hatch() {
        let mut body = "// split: two handlers intentionally colocated\n".to_string();
        body.push_str(&"pub async fn foo() {}\npub async fn bar() {}\n".repeat(52));
        assert!(check("src/services/combined.rs", &body).is_none());
    }

    #[test]
    fn should_not_block_handler_file_under_line_limit() {
        let body = "pub async fn foo() {}\npub async fn bar() {}\n".repeat(3);
        assert!(check("src/services/small.rs", &body).is_none());
    }

    #[test]
    fn should_not_block_mod_rs_with_mixed_concerns_rule() {
        // mod.rs violations are covered by LOGIC_IN_MOD / STRUCT_IN_MOD, not FILE_MIXED_CONCERNS
        let body = "pub struct Svc {}\nimpl Svc {}\npub async fn handler() {}\n".repeat(70);
        let msg = check("src/services/mod.rs", &body);
        if let Some(m) = msg {
            assert!(!m.contains("FILE_MIXED_CONCERNS"));
        }
    }
}
