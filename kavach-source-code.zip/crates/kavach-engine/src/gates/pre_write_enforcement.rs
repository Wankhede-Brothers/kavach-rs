// Stage 2: Enforcement checks — skills, research, evidence-chain, test debt, new crate, bulk checkbox.
// Requires &mut SessionState for test debt auto-clear and new crate confirmation.
use std::collections::HashSet;
use std::process::Command;

use kavach_types::HookInput;
use crate::gates::pre_write_context::WriteContext;

/// Run all enforcement checks. Returns Some(block_reason) on hard block, None on pass.
pub(crate) fn check(
    ctx: &WriteContext<'_>,
    input: &HookInput,
    session: &mut kavach_session::SessionState,
) -> Option<String> {
    let is_low_risk = session.intent_risk == "low";

    // 3. Skill enforcement
    if ctx.is_code && !session.required_skills.is_empty() && !session.all_skills_satisfied() {
        let skills_dir = kavach_config::paths::skills_dir();
        let missing: Vec<&str> = session.missing_skills()
            .into_iter()
            .filter(|s| skills_dir.join(s).join("SKILL.md").exists())
            .collect();
        let names = missing.join(", ");
        if !missing.is_empty() {
            if is_low_risk {
                session.add_case_fact(&format!("low-risk write skipped skill gate: [{names}]"));
            } else {
                return Some(format!(
                    "SKILL VIOLATION: Invoke required skills before writing code: [{names}]"
                ));
            }
        }
    }

    // 3b. File-pattern skill enforcement (Write always; Edit for frontend files)
    let is_frontend_file = ctx.file_path.ends_with(".tsx")
        || ctx.file_path.ends_with(".jsx")
        || ctx.file_path.ends_with(".astro");
    let should_check_patterns = ctx.is_code && !is_low_risk
        && (ctx.tool_name == "Write" || (ctx.tool_name == "Edit" && is_frontend_file));
    if should_check_patterns {
        if let Some(reason) = super::pre_write_patterns::check_file_pattern_skills(
            ctx.file_path, session,
        ) {
            return Some(reason);
        }
    }

    // 4. Research enforcement
    let is_subagent = !input.session_id.is_empty()
        && !session.session_id.is_empty()
        && input.session_id != session.session_id;
    let cfg = kavach_config::load_gates_config();
    let is_research_tool = cfg.research.code_tools.iter().any(|t| t == ctx.tool_name);
    if !is_low_risk && !is_subagent && ctx.is_code && !session.research_done
        && is_research_tool && cfg.research.enabled && cfg.research.require_before_code
    {
        let topic = if session.research_topic.is_empty() {
            "relevant topic"
        } else {
            &session.research_topic
        };
        return Some(format!(
            "RESEARCH VIOLATION: WebSearch required before writing code. Topic: {topic}"
        ));
    }

    // 4b. Evidence-chain correlated block
    if !is_low_risk && !is_subagent && ctx.is_code && !session.evidence_window_satisfied() {
        return Some(format!(
            "EVIDENCE_CHAIN VIOLATION: no WebSearch since t{}. Search before implement.",
            session.intent_set_turn
        ));
    }

    // 4c. Test debt enforcement
    let content_is_test_code = ctx.content.contains("#[cfg(test)]");
    let file_is_pending = session.test_files_pending.iter().any(|f| f == ctx.file_path);
    if ctx.is_code && !ctx.is_test
        && session.should_block_for_tests()
        && !(content_is_test_code && file_is_pending)
    {
        let broken = pending_files_with_compile_errors(
            &session.work_dir,
            &session.test_files_pending,
        );
        if !broken.is_empty() {
            session.test_files_pending.retain(|f| !broken.contains(f));
            if session.test_files_pending.is_empty() {
                session.test_nudge_count = 0;
            }
            let _ = session.save();
            if !session.should_block_for_tests() {
                // Deadlock resolved — allow this write through.
                return None;
            }
        }
        return Some(format!(
            "TEST GATE: {} files pending tests ({}/{}). Write tests first. Pending: {}",
            session.test_files_pending.len(),
            session.test_nudge_count,
            kavach_session::SessionState::TEST_BLOCK_THRESHOLD,
            session.test_files_pending.join(", "),
        ));
    }

    // 7. New package creation guard
    let pkg_warn = super::new_package_guard::check_new_package(ctx.file_path);
    if ctx.tool_name == "Write" && pkg_warn.is_some() {
        let in_session_workdir = !session.work_dir.is_empty()
            && ctx.file_path.starts_with(&session.work_dir);
        let env_value = std::env::var("KAVACH_ALLOW_NEW_CRATE").ok();
        let allowed = new_crate_allowed(
            session.new_crate_confirmed,
            env_value.as_deref(),
            ctx.content,
        );
        if in_session_workdir && !allowed {
            return Some(
                "NEW_CRATE_CONFIRMATION_REQUIRED\n\
                 \n\
                 FASTEST PATH — no shell commands needed:\n\
                 Add this as the FIRST LINE of the Cargo.toml content:\n\
                 # kavach: new-crate confirmed by user\n\
                 The gate reads this marker and allows automatically. No user input needed.\n\
                 \n\
                 ALTERNATIVE — if user already confirmed verbally:\n\
                 Ask: \"I need to create a new crate. Should I proceed?\"\n\
                 Wait for yes. Retry Write — the intent gate sets the flag.\n\
                 \n\
                 FORBIDDEN: env vars, kavach gates --hook invocations, telling user to run shell commands."
                    .to_string(),
            );
        }
        if in_session_workdir && session.new_crate_confirmed {
            session.clear_new_crate_confirmed();
        }
    }

    None
}

/// Detect compile errors in pending test files (deadlock breaker).
fn pending_files_with_compile_errors(
    work_dir: &str,
    pending_files: &[String],
) -> HashSet<String> {
    if work_dir.is_empty() || pending_files.is_empty() {
        return HashSet::new();
    }
    let output = match Command::new("cargo")
        .args(["check", "--message-format=short", "--quiet"])
        .current_dir(work_dir)
        .output()
    {
        Ok(o) => o,
        Err(_) => return HashSet::new(),
    };
    if output.status.success() {
        return HashSet::new();
    }
    let stderr = String::from_utf8_lossy(&output.stderr);
    let mut errored = HashSet::new();
    for line in stderr.lines() {
        if !line.contains(": error") {
            continue;
        }
        let rel = match line.split(':').next() {
            Some(r) => r.trim(),
            None => continue,
        };
        if rel.is_empty() {
            continue;
        }
        for pf in pending_files {
            if pf == rel || pf.ends_with(&format!("/{rel}")) {
                errored.insert(pf.clone());
            }
        }
    }
    errored
}

/// Check if new crate creation is allowed.
pub(crate) fn new_crate_allowed(
    session_confirmed: bool,
    env_value: Option<&str>,
    content: &str,
) -> bool {
    if session_confirmed {
        return true;
    }
    if matches!(env_value, Some("1")) {
        return true;
    }
    content.contains("# kavach: new-crate confirmed by user")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_return_empty_when_work_dir_is_empty() {
        let result = pending_files_with_compile_errors("", &["src/foo.rs".into()]);
        assert!(result.is_empty());
    }

    #[test]
    fn should_return_empty_when_pending_files_empty() {
        let result = pending_files_with_compile_errors("/some/dir", &[]);
        assert!(result.is_empty());
    }

    #[test]
    fn should_allow_new_crate_when_session_confirmed() {
        assert!(new_crate_allowed(true, None, ""));
    }

    #[test]
    fn should_allow_new_crate_when_env_set() {
        assert!(new_crate_allowed(false, Some("1"), ""));
    }

    #[test]
    fn should_allow_new_crate_when_marker_present() {
        assert!(new_crate_allowed(false, None, "# kavach: new-crate confirmed by user\n[package]"));
    }

    #[test]
    fn should_deny_new_crate_without_signal() {
        assert!(!new_crate_allowed(false, None, "[package]\nname = \"x\""));
    }

    #[test]
    fn should_deny_new_crate_wrong_env_value() {
        assert!(!new_crate_allowed(false, Some("0"), ""));
        assert!(!new_crate_allowed(false, Some("true"), ""));
    }
}
