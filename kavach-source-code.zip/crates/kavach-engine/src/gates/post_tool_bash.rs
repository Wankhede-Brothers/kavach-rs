use kavach_types::HookInput;

use crate::error::EngineError;

/// Handle bash done: sync events to memory (build, test, deploy tracking).
pub fn handle(
    input: &HookInput,
    session: &mut kavach_session::SessionState,
) -> Result<(), EngineError> {
    let _ = session;

    // Track test execution: resolve pending files when tests pass.
    // Detect empty test suites: "0 passed; 0 failed" is NOT a pass.
    let command = input.get_string("command");
    let output = input.tool_response.as_ref()
        .and_then(|r| r.get("output"))
        .and_then(|v| v.as_str());
    if is_test_command(command) {
        // Clear the active test run registration — command has completed.
        clear_test_run(session, command);
        if is_empty_test_suite(output) {
            session.add_case_fact("EMPTY_TEST_SUITE: 0 tests ran — not a pass");
            let context = "[EMPTY_TEST_SUITE] 0 tests ran. This is NOT a passing test suite. \
                 Either: (1) no tests exist for the modified code, or \
                 (2) test filtering excluded all tests. \
                 Do NOT claim \"all tests pass\" — zero tests ran.";
            kavach_hook::exit_post_tool_context(context);
            return Ok(());
        }
        resolve_tested_files(session, command);
    }

    // Track kavach db write calls — used by stop gate to enforce every-5-turn db write.
    if command.contains("kavach db write") && command.contains("--content") {
        session.last_db_write_turn = session.turn_count;
        let _ = session.save();
    }

    // Detect package install failures — hallucinated package names from training weights
    if is_package_install(command) && is_package_not_found(output) {
        session.add_case_fact("PACKAGE_NOT_FOUND: hallucinated package name");
        let context = "[PACKAGE_NOT_FOUND] Package does not exist on the registry. \
             You hallucinated the package name from training weights. \
             WebSearch the correct package name before retrying. \
             Do NOT guess — research it.";
        kavach_hook::exit_post_tool_context(context);
        return Ok(());
    }

    // No actionable signal — exit silently to avoid injecting noise.
    kavach_hook::exit_silent();

    Ok(())
}

/// Public accessor for trimming path (track_state_only).
pub fn is_test_command_pub(cmd: &str) -> bool {
    is_test_command(cmd)
}

/// Detect if a bash command is a test execution.
fn is_test_command(cmd: &str) -> bool {
    let test_patterns = [
        "cargo test", "cargo nextest", "bun test", "bun run test",
        "bunx playwright", "bunx --bun playwright",
        "npx playwright", "npx jest", "pytest", "go test", "mix test",
    ];
    test_patterns.iter().any(|p| cmd.contains(p))
}

/// Detect empty test suites: "0 passed; 0 failed" means no tests ran.
fn is_empty_test_suite(output: Option<&str>) -> bool {
    let text = match output {
        Some(t) if !t.is_empty() => t,
        _ => return false,
    };
    text.contains("0 passed; 0 failed")
        && !text.contains("1 passed")
        && !text.contains("2 passed")
}

/// Detect if a bash command is a package install.
fn is_package_install(cmd: &str) -> bool {
    let patterns = ["bun add", "bun install", "npm install", "npm i ", "yarn add", "pnpm add", "cargo add"];
    patterns.iter().any(|p| cmd.contains(p))
}

/// Detect if package install output indicates not found (404).
fn is_package_not_found(output: Option<&str>) -> bool {
    let text = match output {
        Some(t) if !t.is_empty() => t,
        _ => return false,
    };
    text.contains("404") || text.contains("not found")
        || text.contains("No matching version") || text.contains("no such package")
}

/// Remove the crate key from active_test_crates when a test command completes.
fn clear_test_run(session: &mut kavach_session::SessionState, command: &str) {
    let key = match extract_test_crate_key(command) {
        Some(k) => k,
        None => return,
    };
    session.active_test_crates.retain(|c| c != &key);
    let _ = session.save();
}

/// Extract crate key from a test command — mirrors pre_tool_bash logic.
fn extract_test_crate_key(cmd: &str) -> Option<String> {
    if !cmd.contains("cargo test") && !cmd.contains("cargo nextest") {
        return None;
    }
    if cmd.contains("--workspace") {
        return Some("__workspace__".into());
    }
    for flag in &["-p ", "--package "] {
        if let Some(pos) = cmd.find(flag) {
            let after = cmd[pos + flag.len()..].trim();
            if let Some(name) = after.split_whitespace().next() {
                return Some(name.to_string());
            }
        }
    }
    Some("__workspace__".into())
}

/// Clear only pending files matching the test scope.
/// `cargo test -p pkg-a` must NOT clear pending TypeScript files.
fn resolve_tested_files(session: &mut kavach_session::SessionState, command: &str) {
    if !session.has_pending_tests() { return; }
    let scope = extract_test_scope(command);
    if scope.is_empty() {
        session.clear_test_pending();
        return;
    }
    session.test_files_pending.retain(|f| {
        !scope.iter().any(|s| f.contains(s))
    });
    if session.test_files_pending.is_empty() {
        session.test_nudge_count = 0;
    }
    let _ = session.save();
}

fn extract_test_scope(cmd: &str) -> Vec<String> {
    let mut scopes = Vec::new();
    if let Some(pos) = cmd.find("-p ")
        && let Some(pkg) = cmd[pos + 3..].split_whitespace().next()
    {
        scopes.push(pkg.to_string());
    }
    for part in cmd.split_whitespace() {
        if part.contains('/') || part.ends_with(".ts") || part.ends_with(".tsx") {
            scopes.push(part.to_string());
        }
    }
    scopes
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect_cargo_test() {
        assert!(is_test_command("cargo test --workspace"));
        assert!(is_test_command("cargo nextest run"));
    }

    #[test]
    fn test_detect_bun_test() {
        assert!(is_test_command("bun test"));
        assert!(is_test_command("bun run test"));
        assert!(is_test_command("bunx playwright test"));
        assert!(is_test_command("bunx --bun playwright test"));
    }

    #[test]
    fn test_detect_npx_test() {
        assert!(is_test_command("npx playwright test"));
        assert!(is_test_command("npx jest --coverage"));
    }

    #[test]
    fn test_not_test_command() {
        assert!(!is_test_command("cargo build"));
        assert!(!is_test_command("git status"));
    }

    #[test]
    fn test_empty_test_suite_detected() {
        let output = "test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out";
        assert!(is_empty_test_suite(Some(output)));
    }

    #[test]
    fn test_non_empty_test_suite_ok() {
        let output = "test result: ok. 5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out";
        assert!(!is_empty_test_suite(Some(output)));
    }

    #[test]
    fn test_package_install_detected() {
        assert!(is_package_install("bun add @envelop/depth-limit"));
        assert!(is_package_install("npm install express"));
        assert!(is_package_install("cargo add serde"));
        assert!(!is_package_install("cargo build"));
    }

    #[test]
    fn test_package_not_found() {
        assert!(is_package_not_found(Some("error: GET https://registry.npmjs.org/foo - 404")));
        assert!(is_package_not_found(Some("No matching version found")));
        assert!(!is_package_not_found(Some("added 3 packages")));
        assert!(!is_package_not_found(None));
    }

    #[test]
    fn test_scope_extraction_cargo_p() {
        let s = extract_test_scope("cargo test -p my-service --lib");
        assert_eq!(s, vec!["my-service"]);
    }

    #[test]
    fn test_scope_extraction_bun_path() {
        let s = extract_test_scope("bun test packages/shared/src/lib/hooks.test.ts");
        assert!(s.iter().any(|p| p.contains("hooks.test.ts")));
    }

    #[test]
    fn test_scope_extraction_workspace_empty() {
        let s = extract_test_scope("cargo test --workspace");
        assert!(s.is_empty());
    }

    #[test]
    fn should_clear_active_test_crate_on_completion() {
        let mut session = kavach_session::SessionState::default();
        session.active_test_crates.push("kavach-engine".into());
        clear_test_run(&mut session, "cargo test -p kavach-engine --lib");
        assert!(session.active_test_crates.is_empty());
    }

    #[test]
    fn should_not_clear_unrelated_crate() {
        let mut session = kavach_session::SessionState::default();
        session.active_test_crates.push("kavach-db".into());
        clear_test_run(&mut session, "cargo test -p kavach-engine --lib");
        assert_eq!(session.active_test_crates.len(), 1);
    }

    #[test]
    fn test_empty_test_suite_none_output() {
        assert!(!is_empty_test_suite(None));
        assert!(!is_empty_test_suite(Some("")));
    }
}
