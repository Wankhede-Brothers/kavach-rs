/// Strategic deferral detectors for the stop gate.
/// Catches AI using business/technical judgment to postpone user-requested work:
/// "post-launch", "Phase 2", "premature", "adds zero value", scope sufficiency.
use super::stop_detect::{has_completion_signal, normalize_for_matching};

/// Detect deferral disguised as strategic prioritization.
/// Pattern: AI says "not now", "post-launch", "Phase 2 candidate", "premature"
/// instead of doing what the user explicitly asked for.
pub fn contains_strategic_deferral(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    // NOTE: patterns are matched against normalize_for_matching() output,
    // which strips hyphens between word chars. Patterns must not rely on
    // hyphens — use the dehyphenated form (e.g. "postlaunch" not "post-launch").
    let deferral_phrases = [
        "postlaunch", "post launch", "after launch",
        "postrelease", "post release", "after release",
        "phase 2 candidate", "phase 2 analytics", "phase 2 feature",
        "phase 3 candidate", "phase 3 feature", "phase ii",
        "v2 release", "v2 feature", "v3 release", "v3 feature",
        "next iteration", "next version", "next release",
        "future release", "future iteration", "future version",
        "verdict: not now", "verdict: no", "verdict: not yet",
        "not now.", "not now \u{2014}", "not now,",
        "not appropriate now", "not appropriate yet",
        "premature optimization", "premature to implement",
        "premature to add", "premature to build",
        "not critical now", "not needed now", "not needed yet",
        "not the right time", "can wait until",
        "later optimization", "future optimization",
        "noted for future", "noted for later",
        "not implemented \u{2014}", "not implemented\u{2014}",
        "not implemented\n", "out of scope",
        "deferred to", "backlog item", "add to backlog",
        "backlogged", "should be v2", "should be v3",
        // Invented priority tiers — AI categorizes work the user never asked to tier
        "postlaunch:", "postlaunch)", "post launch:",
        "prelaunch critical)", "prelaunch important)",
        "now (prelaunch", "next (prelaunch", "postlaunch (",
        "implementation order (", "implementation order:",
        "recommended order:", "recommended order (",
        "postlaunch (60", "postlaunch (90", "postlaunch (30",
    ];
    let doing_it = lower.contains("implementing now") || lower.contains("building now")
        || lower.contains("starting now") || lower.contains("doing it now")
        || lower.contains("building both") || lower.contains("let me build")
        || lower.contains("let me implement") || lower.contains("will implement");
    if doing_it { return false; }
    deferral_phrases.iter().any(|p| lower.contains(p))
}

/// Detect value-gating: AI decides user's request "adds zero value" or
/// dismisses work because current state is empty/insufficient.
pub fn contains_value_gating(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let patterns = [
        "adds zero value", "zero value until", "no value until",
        "minimal value until", "low value until", "little value until",
        "low roi", "marginal benefit", "minimal benefit",
        "would just be empty", "would just be noise",
        "would show a single", "would just show",
        "sufficient for launch", "enough for launch",
        "sufficient for now", "good enough for now",
        "sufficient as-is", "good enough as-is",
        "once there are", "once you have", "once there's",
        "until there are", "when there are enough",
        "not worth building until", "not worth adding until",
    ];
    let doing_it = lower.contains("but building it") || lower.contains("but i'll build")
        || lower.contains("implementing anyway") || lower.contains("building anyway");
    if doing_it { return false; }
    patterns.iter().any(|p| lower.contains(p))
}

/// Detect unsolicited reprioritization: AI redirects to what IT thinks
/// should be the priority instead of doing what the user asked.
pub fn contains_unsolicited_reprioritization(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let patterns = [
        "the priority right now is", "the priority should be",
        "more important right now", "better to focus on",
        "should focus on", "focus should be on",
        "better spent on", "time better spent",
        "instead, focus on", "instead focus on",
    ];
    let user_aligned = lower.contains("as you requested")
        || lower.contains("per your request") || lower.contains("as asked");
    if user_aligned { return false; }
    patterns.iter().any(|p| lower.contains(p))
}

#[cfg(test)]
mod tests {
    use super::*;

    // --- strategic deferral ---
    #[test]
    fn test_post_launch_blocked() {
        assert!(contains_strategic_deferral(
            "Both are Phase 2 analytics — add post-launch."
        ));
        assert!(contains_strategic_deferral("Verdict: NOT now. Add after launch."));
        assert!(contains_strategic_deferral(
            "This is premature optimization at this stage."
        ));
    }
    #[test]
    fn test_deferral_ok_if_implementing() {
        assert!(!contains_strategic_deferral("Was post-launch but building now."));
        assert!(!contains_strategic_deferral(
            "Let me implement the post-launch charts."
        ));
    }
    #[test]
    fn test_not_implemented_table_blocked() {
        assert!(contains_strategic_deferral(
            "Geographic pricing | Not implemented | NOT IMPLEMENTED — noted for future"
        ));
        assert!(contains_strategic_deferral("Feature X: noted for later implementation."));
        assert!(contains_strategic_deferral("This is out of scope for now."));
    }
    #[test]
    fn test_invented_priority_tiers_blocked() {
        assert!(contains_strategic_deferral(
            "POST-LAUNCH (60 days): Compliance AML Phase 1-5"
        ));
        assert!(contains_strategic_deferral(
            "NOW (pre-launch critical): Rainfire v2 Wave 1"
        ));
        assert!(contains_strategic_deferral(
            "IMPLEMENTATION ORDER (recommended)"
        ));
        assert!(contains_strategic_deferral(
            "Implementation order: 1. Rainfire 2. Soundbak"
        ));
    }
    #[test]
    fn test_timeframe_in_technical_context_ok() {
        // "60 days" in a technical context should NOT trigger
        assert!(!contains_strategic_deferral(
            "The SSL certificate expires in 60 days."
        ));
        assert!(!contains_strategic_deferral(
            "Token TTL is set to 30 days for rotation."
        ));
    }
    #[test]
    fn test_deferral_empty() { assert!(!contains_strategic_deferral("")); }

    // --- value gating ---
    #[test]
    fn test_value_gating_blocked() {
        assert!(contains_value_gating(
            "Adds zero value until there are 3+ campaigns."
        ));
        assert!(contains_value_gating("The chart would just be empty boxes."));
        assert!(contains_value_gating(
            "Sufficient for launch — no need to add more."
        ));
        assert!(contains_value_gating(
            "Once there are multiple campaign types running."
        ));
    }
    #[test]
    fn test_value_gating_ok_if_building() {
        assert!(!contains_value_gating("Adds zero value but building it anyway."));
    }
    #[test]
    fn test_value_gating_empty() { assert!(!contains_value_gating("")); }

    // --- unsolicited reprioritization ---
    #[test]
    fn test_reprioritization_blocked() {
        assert!(contains_unsolicited_reprioritization(
            "The priority right now is getting real traffic flowing."
        ));
        assert!(contains_unsolicited_reprioritization(
            "Better to focus on the core API first."
        ));
    }
    #[test]
    fn test_reprioritization_ok_if_aligned() {
        assert!(!contains_unsolicited_reprioritization(
            "As you requested, the priority right now is building charts."
        ));
    }
    #[test]
    fn test_reprioritization_empty() {
        assert!(!contains_unsolicited_reprioritization(""));
    }
}
