// Stage 1: Security checks — path blocking, secrets, python ban, memory file guard.
// Returns early on block or allow-with-context (agent files, sensitive files).
use crate::gates::pre_write_context::WriteContext;
use crate::gates::pre_write_checks::is_code_write;

/// Result of the security stage.
pub(crate) enum SecurityResult {
    /// Hard block — deny the write with this reason.
    Block(String),
    /// Allow early with advisory context (agent files, sensitive files).
    AllowEarly(String),
    /// No security issue — continue to next stage.
    Pass,
}

/// Run all security checks against the write context.
pub(crate) fn check(ctx: &WriteContext<'_>) -> SecurityResult {
    // Empty file_path bypasses every downstream guard.
    if ctx.file_path.is_empty() {
        return SecurityResult::Block(
            "BLOCKED: Write/Edit called with empty file_path. \
             All content guards would be bypassed. Malformed tool input."
                .to_string(),
        );
    }

    // System paths: /etc, /usr, /bin, /.ssh, /.aws
    if kavach_config::is_blocked_write_path(ctx.file_path) {
        return SecurityResult::Block(format!(
            "BLOCKED: system path: {}. /etc /usr /bin /.ssh /.aws are protected. \
             FIX: Write to project dir or ~/.local/bin/ for user binaries.",
            ctx.file_path
        ));
    }

    // Agent/skill/command files — allow but log.
    if ctx.file_path.contains("/.claude/agents/")
        || ctx.file_path.contains("/.claude/skills/")
        || ctx.file_path.contains("/.claude/commands/")
    {
        return SecurityResult::AllowEarly(format!(
            "[AGENT_FILE] Writing: {} — review permissionMode if present",
            ctx.file_path
        ));
    }

    // Sensitive files — allow but warn.
    if kavach_patterns::is_sensitive(ctx.file_path) {
        return SecurityResult::AllowEarly(format!(
            "[SENSITIVE] Writing to sensitive file: {}",
            ctx.file_path
        ));
    }

    // Python files banned in kavach-rs workspace.
    if ctx.file_path.ends_with(".py") {
        let session_wd = kavach_session::get_or_create_session().work_dir;
        if !session_wd.is_empty() && ctx.file_path.starts_with(&session_wd) {
            return SecurityResult::Block(
                "BLOCKED: .py files are banned in this workspace. \
                 Python bypasses the kavach hook pipeline. \
                 SQL ops: Write tool → .sql file → sqlx migrate run. \
                 Scripts: use Bash directly or implement as a Rust binary."
                    .to_string(),
            );
        }
    }

    // Hardcoded secrets in content.
    if !ctx.content.is_empty() && !ctx.is_test {
        if let Some(secret_msg) = kavach_config::has_secret_in_content(ctx.content) {
            return SecurityResult::Block(format!(
                "BLOCKED: {secret_msg} in {}. Move credentials to environment variables.",
                ctx.file_path
            ));
        }
    }

    // Empty content on Write to code files — all guards bypass silently.
    if ctx.tool_name == "Write" && is_code_write(ctx.file_path) && ctx.content.is_empty() {
        return SecurityResult::Block(
            "BLOCKED: Write called with empty content on a code file. \
             All content guards (rust, ts, sql, css) would be silently bypassed."
                .to_string(),
        );
    }

    // Memory file writes → force kavach-db usage.
    if super::memory_write_guard::is_memory_file(ctx.file_path) {
        let msg = super::memory_write_guard::block_message(ctx.file_path);
        return SecurityResult::Block(msg);
    }

    SecurityResult::Pass
}

#[cfg(test)]
mod tests {
    use super::*;
    use kavach_types::HookInput;

    #[test]
    fn should_block_empty_file_path() {
        let mut input = HookInput::default();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert!(matches!(check(&ctx), SecurityResult::Block(_)));
    }

    #[test]
    fn should_block_system_path() {
        let mut input = HookInput::default();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("/etc/passwd")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert!(matches!(check(&ctx), SecurityResult::Block(_)));
    }

    #[test]
    fn should_allow_early_for_agent_files() {
        let mut input = HookInput::default();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("/home/user/.claude/agents/test.md")),
            ("content".into(), serde_json::json!("agent config")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert!(matches!(check(&ctx), SecurityResult::AllowEarly(_)));
    }

    #[test]
    fn should_pass_for_normal_code_file() {
        let mut input = HookInput::default();
        input.tool_name = "Write".into();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("src/main.rs")),
            ("content".into(), serde_json::json!("fn main() {}")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert!(matches!(check(&ctx), SecurityResult::Pass));
    }

    #[test]
    fn should_block_empty_write_to_code_file() {
        let mut input = HookInput::default();
        input.tool_name = "Write".into();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("src/lib.rs")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert!(matches!(check(&ctx), SecurityResult::Block(_)));
    }
}
