/// Rules manifest: tracks loaded skill/rule files for context injection.
/// Returns a list of active rule file paths from the session.
pub fn active_rules() -> Vec<String> {
    let home = match std::env::var("HOME") {
        Ok(h) => h,
        Err(_) => return vec![],
    };
    let rules_dir = format!("{home}/.claude/rules");
    let mut rules = Vec::new();
    if let Ok(entries) = std::fs::read_dir(&rules_dir) {
        for entry in entries.flatten() {
            if let Some(name) = entry.file_name().to_str()
                && name.ends_with(".md")
            {
                rules.push(format!("{rules_dir}/{name}"));
            }
        }
    }
    rules.sort();
    rules
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_active_rules_returns_vec() {
        let rules = active_rules();
        assert!(rules.len() < 1000);
    }
}
