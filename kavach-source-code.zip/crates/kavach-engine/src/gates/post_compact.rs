use kavach_types::HookInput;

use crate::error::EngineError;

/// PostCompact gate: inject compact summary for context recovery.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let mut session = kavach_session::get_or_create_session();
    session.mark_post_compact();

    let summary = &input.compact_summary;
    let trigger = &input.trigger;

    let context = kavach_hook::context_block(
        "POST_COMPACT",
        &[
            ("trigger", if trigger.is_empty() { "auto" } else { trigger }),
        ],
    );

    let mut full_context = context;

    // Inject case facts FIRST — these are critical and must NOT be summarized.
    if !session.case_facts.is_empty() {
        full_context.push_str("\n[CASE_FACTS — DO NOT SUMMARIZE]\n");
        for fact in &session.case_facts {
            full_context.push_str("- ");
            full_context.push_str(fact);
            full_context.push('\n');
        }
    }

    if !summary.is_empty() {
        full_context.push_str("\n[COMPACT_SUMMARY]\n");
        let preview: String = summary.chars().take(500).collect();
        full_context.push_str(&preview);
        full_context.push('\n');
    }

    let module_ctx = session.inject_modules_once(&["agi-flow", "memory"]);
    full_context.push_str(&module_ctx);

    kavach_hook::exit_post_tool_context(&full_context);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_post_compact_default() {
        let input = HookInput::default();
        let _ = run(&input);
    }

    #[test]
    fn test_post_compact_with_summary() {
        let input = HookInput {
            compact_summary: "session was compacted".into(),
            trigger: "auto".into(),
            ..Default::default()
        };
        let _ = run(&input);
    }
}
