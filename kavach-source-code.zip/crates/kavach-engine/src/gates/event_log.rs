//! Event logging helper — wraps kavach_db::events::append with silent failure.
//! After logging, fires cross-module projections (graph, kanban, memory).
//! Gates must never fail because event logging is unavailable.

/// Open DB and resolve project slug to id. Returns None on any failure.
fn open_and_resolve(project_slug: &str) -> Option<(kavach_db::Connection, i64)> {
    let conn = kavach_db::open_default().ok()?;
    if project_slug.is_empty() {
        return Some((conn, 0));
    }
    let proj = kavach_db::projects::get_by_slug(&conn, project_slug).ok()?;
    Some((conn, proj.id))
}

/// Log an event to kavach-db. Silently drops on any failure.
fn log_raw(
    conn: &kavach_db::Connection,
    session_id: &str,
    event_type: &str,
    source: &str,
    project_id: Option<i64>,
    payload: Option<&str>,
) {
    let sid = if session_id.is_empty() { None } else { Some(session_id) };
    let _ = kavach_db::events::append(conn, sid, event_type, source, project_id, payload);
}

/// Log a file write event and project graph edges (file→skill, file→project, file→references).
/// `content` is the written file body — used for real-time [[wikilink]] and INVOKE edge extraction.
pub fn log_file_write(session_id: &str, file_path: &str, tool: &str, project_slug: &str, content: &str) {
    let (conn, pid) = match open_and_resolve(project_slug) {
        Some(v) => v,
        None => return,
    };
    let payload = format!(r#"{{"file":"{file_path}","tool":"{tool}"}}"#);
    log_raw(&conn, session_id, "file_write", "gate:post_write", Some(pid), Some(&payload));
    if pid > 0 {
        kavach_db::projections::project_file_write(&conn, file_path, pid, content);
    }
}

/// Log an intent classification and create kanban cards for high-risk intents.
pub fn log_intent(
    session_id: &str,
    intent_type: &str,
    risk: &str,
    project_slug: &str,
) {
    let (conn, pid) = match open_and_resolve(project_slug) {
        Some(v) => v,
        None => return,
    };
    let payload = format!(r#"{{"intent":"{intent_type}","risk":"{risk}"}}"#);
    log_raw(&conn, session_id, "intent_classified", "gate:intent", Some(pid), Some(&payload));
    if pid > 0 {
        kavach_db::projections::project_intent_to_kanban(&conn, pid, intent_type, risk);
    }
}

/// Log a session lifecycle event and create session→project graph edge.
pub fn log_session(session_id: &str, event_type: &str, model: &str, project_slug: &str) {
    let (conn, pid) = match open_and_resolve(project_slug) {
        Some(v) => v,
        None => return,
    };
    let payload = format!(r#"{{"model":"{model}"}}"#);
    log_raw(&conn, session_id, event_type, "gate:session", Some(pid), Some(&payload));
    if pid > 0 && event_type == "session_start" {
        kavach_db::projections::project_session_to_graph(&conn, session_id, pid);
    }
}

/// Log a gate decision and store blocks as memory patterns.
pub fn log_gate_decision(
    session_id: &str,
    gate: &str,
    decision: &str,
    reason: &str,
    project_slug: &str,
) {
    let (conn, pid) = match open_and_resolve(project_slug) {
        Some(v) => v,
        None => return,
    };
    let escaped = reason.replace('"', "'");
    let payload = format!(r#"{{"gate":"{gate}","decision":"{decision}","reason":"{escaped}"}}"#);
    log_raw(&conn, session_id, "gate_decision", gate, Some(pid), Some(&payload));
    if pid > 0 && decision == "block" {
        kavach_db::projections::project_gate_block_to_memory(&conn, pid, gate, reason);
    }
}

/// Log a tool failure and seed the self-evolution pattern store.
/// fix_strategy/imperative_rewrite/dsa_rationale are provided by the
/// post_tool_failure gate after classification; empty strings are allowed
/// for novel errors where research has not yet produced a fix.
pub fn log_tool_failure(
    session_id: &str,
    tool_name: &str,
    error: &str,
    fix_strategy: &str,
    imperative_rewrite: &str,
    dsa_rationale: &str,
    gate_name: &str,
    project_slug: &str,
) {
    let (conn, pid) = match open_and_resolve(project_slug) {
        Some(v) => v,
        None => return,
    };
    let escaped_error = error.replace('"', "'");
    let payload = format!(
        r#"{{"tool":"{tool_name}","error":"{escaped_error}","gate":"{gate_name}"}}"#
    );
    log_raw(&conn, session_id, "tool_failure", gate_name, Some(pid), Some(&payload));
    if pid > 0 && !error.is_empty() {
        kavach_db::projections::project_error_to_pattern(
            &conn, pid, error, fix_strategy,
            imperative_rewrite, dsa_rationale, tool_name, gate_name,
        );
    }
}
