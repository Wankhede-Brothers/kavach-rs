use kavach_types::HookInput;

use crate::error::EngineError;

/// PermissionRequest gate: fires when permission dialog is about to show.
/// Autonomous handling: auto-allow safe tools, auto-deny destructive patterns.
/// Distinct from PreToolUse permission gate — this fires at dialog time.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let tool_name = &input.tool_name;

    if is_safe_auto_allow(tool_name) {
        sync_event(input);
        kavach_hook::exit_permission_request_allow(&format!("auto-allowed: {tool_name}"));
        return Ok(());
    }

    if tool_name == "Bash" {
        let command = input.get_string("command");
        if is_kavach_command(command) {
            sync_event(input);
            kavach_hook::exit_permission_request_allow("kavach CLI: auto-allowed");
            return Ok(());
        }
        if is_destructive_command(command) {
            sync_event(input);
            kavach_hook::exit_permission_request_deny(&format!(
                "DENIED: destructive command blocked: `{command}`"
            ));
            return Ok(());
        }
        if is_safe_rm_target(command) {
            sync_event(input);
            kavach_hook::exit_permission_request_allow("safe cleanup: cache/build dir");
            return Ok(());
        }
    }

    // Default: Claude Code PermissionRequest format (hookSpecificOutput with permissionDecision)
    kavach_hook::exit_permission_request_allow(&format!("permitted: {tool_name}"));
    Ok(())
}

fn is_safe_auto_allow(tool: &str) -> bool {
    matches!(
        tool,
        "Read" | "Grep" | "Glob" | "WebSearch" | "WebFetch"
            | "Skill" | "ToolSearch" | "AskUserQuestion"
    )
}

fn is_kavach_command(cmd: &str) -> bool {
    let trimmed = cmd.trim();
    trimmed.starts_with("kavach ") || trimmed == "kavach"
}

fn is_destructive_command(cmd: &str) -> bool {
    let lower = cmd.to_lowercase();
    let normalized = lower.split_whitespace().collect::<Vec<_>>().join(" ");
    let patterns = [
        "rm -rf /", "mkfs", "dd if=", "drop table",
        "drop database", "truncate table", "format c:",
        "> /dev/sda", ":(){ :|:& };:",
    ];
    patterns.iter().any(|p| destructive_match(&normalized, p))
}

/// Boundary-aware match for destructive command patterns.
fn destructive_match(cmd: &str, pattern: &str) -> bool {
    let Some(pos) = cmd.find(pattern) else { return false };
    let after = pos + pattern.len();
    let at_end = after >= cmd.len();
    if pattern.ends_with('/') || pattern.ends_with('~') {
        return at_end || matches!(cmd.as_bytes()[after], b'*' | b' ');
    }
    if pattern.ends_with(" sh") || pattern.ends_with(" bash") {
        return at_end || matches!(cmd.as_bytes()[after], b' ' | b'\'' | b'"' | b';' | b'&');
    }
    true
}

/// Auto-allow rm targeting known safe cache/build directories.
/// Checks each rm argument's final path component (basename) to avoid
/// false matches on "build" or "dist" as substrings of unrelated paths.
fn is_safe_rm_target(cmd: &str) -> bool {
    let lower = cmd.to_lowercase();
    if !lower.contains("rm ") { return false; }
    let safe_names = [
        "node_modules", ".vite", ".next", ".astro", ".cache",
        ".turbo", ".parcel-cache", ".output", "__pycache__",
        "dist", "build",
    ];
    let safe_paths = ["target/debug", "target/release"];
    let parts: Vec<&str> = lower.split_whitespace().collect();
    let past_rm = parts.iter().skip_while(|p| !p.starts_with("rm")).skip(1);
    for arg in past_rm {
        if arg.starts_with('-') { continue; }
        let path = arg.trim_matches(|c: char| c == '"' || c == '\'');
        if safe_paths.iter().any(|s| path.ends_with(s)) { return true; }
        let basename = path.rsplit('/').next().unwrap_or(path);
        if safe_names.contains(&basename) { return true; }
    }
    false
}

fn sync_event(_input: &HookInput) {
    // kavach-db handles event persistence; file-based memory removed
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_safe_tools() {
        assert!(is_safe_auto_allow("Read"));
        assert!(is_safe_auto_allow("Grep"));
        assert!(is_safe_auto_allow("WebSearch"));
        assert!(!is_safe_auto_allow("Bash"));
        assert!(!is_safe_auto_allow("Write"));
    }

    #[test]
    fn test_kavach_command() {
        assert!(is_kavach_command("kavach db query --project foo"));
        assert!(is_kavach_command("kavach gates pre-write --hook"));
        assert!(!is_kavach_command("npm test"));
    }

    #[test]
    fn test_destructive() {
        assert!(is_destructive_command("rm -rf /"));
        assert!(is_destructive_command("rm -rf /*"));
        assert!(is_destructive_command("DROP TABLE users"));
        assert!(!is_destructive_command("rm -rf node_modules"));
        assert!(!is_destructive_command("npm test"));
    }

    #[test]
    fn test_destructive_safe_absolute_paths() {
        assert!(!is_destructive_command("rm -rf /Users/foo/node_modules"));
        assert!(!is_destructive_command("rm -rf /home/user/.vite"));
        assert!(!is_destructive_command("rm -rf /tmp/build"));
        assert!(!is_destructive_command("rm -r /Users/foo/.next"));
    }

    #[test]
    fn test_destructive_match_helper() {
        assert!(destructive_match("rm -rf /", "rm -rf /"));
        assert!(destructive_match("rm -rf /*", "rm -rf /"));
        assert!(!destructive_match("rm -rf /Users/foo", "rm -rf /"));
        // Non-slash patterns still use contains
        assert!(destructive_match("drop table users", "drop table"));
    }

    #[test]
    fn test_safe_rm_targets() {
        assert!(is_safe_rm_target("rm -rf node_modules"));
        assert!(is_safe_rm_target("rm -rf .vite"));
        assert!(is_safe_rm_target("rm -rf .next"));
        assert!(is_safe_rm_target("rm -rf .astro"));
        assert!(is_safe_rm_target("rm -r node_modules/.vite"));
        assert!(is_safe_rm_target("rm -rf /Users/foo/node_modules"));
        assert!(is_safe_rm_target("rm -rf packages/dashboard/.astro"));
        assert!(is_safe_rm_target("rm -rf target/debug"));
        assert!(is_safe_rm_target("rm -rf __pycache__"));
    }

    #[test]
    fn test_unsafe_rm_not_autoallowed() {
        assert!(!is_safe_rm_target("rm -rf src"));
        assert!(!is_safe_rm_target("rm -rf /etc/hosts"));
        assert!(!is_safe_rm_target("rm important_file.rs"));
        assert!(!is_safe_rm_target("cargo build"));
        // "build" and "dist" as substrings should NOT auto-allow
        assert!(!is_safe_rm_target("rm -rf /important/dist_backup"));
        assert!(!is_safe_rm_target("rm -rf /etc/important_build_config"));
        assert!(!is_safe_rm_target("rm -rf /home/user/.cache_important"));
    }

    #[test]
    fn test_safe_rm_exact_basenames() {
        // "dist" and "build" as exact basenames ARE safe
        assert!(is_safe_rm_target("rm -rf dist"));
        assert!(is_safe_rm_target("rm -rf build"));
        assert!(is_safe_rm_target("rm -rf ./dist"));
        assert!(is_safe_rm_target("rm -rf packages/app/build"));
    }

    #[test]
    fn test_permission_request_default() {
        let input = HookInput {
            tool_name: "Read".into(),
            ..Default::default()
        };
        let _ = run(&input);
    }
}
