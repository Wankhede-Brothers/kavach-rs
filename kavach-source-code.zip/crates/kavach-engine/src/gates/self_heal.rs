// ARCH: SelfHealingGate — auto-fix violations instead of just blocking
// PATTERN: self_healing | SCOPE: pre_write | CAP: AP | SEARCHED: 2026-04
// Per Harness Engineering + Gitar/DeepSource 2026: block + diagnose + fix in same turn.
// Gate outputs the fixed content ready to apply.

/// Self-healing result from a gate check.
#[derive(Debug, Clone)]
pub struct SelfHealFix {
    /// The line number (1-indexed) where the violation occurs.
    pub line: usize,
    /// The original line content.
    pub original: String,
    /// The fixed line content.
    pub fixed: String,
    /// Description of what was fixed.
    pub description: String,
}

/// Apply self-healing fixes to content and return the healed content.
/// Returns None if no fixes were applied.
pub fn apply_fixes(content: &str, fixes: &[SelfHealFix]) -> Option<String> {
    if fixes.is_empty() {
        return None;
    }
    let lines: Vec<&str> = content.lines().collect();
    let mut result_lines: Vec<String> = lines.iter().map(|s| s.to_string()).collect();

    for fix in fixes {
        if fix.line > 0 && fix.line <= result_lines.len() {
            result_lines[fix.line - 1] = fix.fixed.clone();
        }
    }

    Some(result_lines.join("\n"))
}

/// Generate self-healing fixes for common Rust patterns.
/// These are mechanical transformations that can be applied automatically.
pub fn rust_self_heal(content: &str) -> Vec<SelfHealFix> {
    let mut fixes = Vec::new();

    for (i, line) in content.lines().enumerate() {
        let line_num = i + 1;

        // .unwrap() → ?
        // Only if line ends with ; or ) and contains Result/Option context
        if line.contains(".unwrap()") && !line.contains("test") && !line.contains("assert") {
            let fixed = line.replace(".unwrap()", "?");
            // Only suggest if the transformation is simple
            if fixed.ends_with("?;") || fixed.ends_with("?)") {
                fixes.push(SelfHealFix {
                    line: line_num,
                    original: line.to_string(),
                    fixed,
                    description: ".unwrap() → ? operator".into(),
                });
            }
        }

        // .expect("...") → ?
        if line.contains(".expect(") && !line.contains("test") && !line.contains("assert") {
            // Extract and replace .expect("anything")
            if let Some(start) = line.find(".expect(") {
                if let Some(end) = line[start..].find(')') {
                    let before = &line[..start];
                    let after = &line[start + end + 1..];
                    let fixed = format!("{before}?{after}");
                    fixes.push(SelfHealFix {
                        line: line_num,
                        original: line.to_string(),
                        fixed,
                        description: ".expect() → ? operator".into(),
                    });
                }
            }
        }

        // dbg!(x) → x (remove debug macro)
        if line.contains("dbg!(") {
            fixes.push(SelfHealFix {
                line: line_num,
                original: line.to_string(),
                fixed: line.replace("dbg!", "/* removed dbg! */ "),
                description: "Remove dbg! macro".into(),
            });
        }

        // eprintln!(...) → tracing::warn!(...) — check first to avoid substring match
        if line.contains("eprintln!(") && !line.contains("test") {
            let fixed = line.replace("eprintln!(", "tracing::warn!(");
            fixes.push(SelfHealFix {
                line: line_num,
                original: line.to_string(),
                fixed,
                description: "eprintln! → tracing::warn!".into(),
            });
        } else if line.contains("println!(") && !line.contains("test") {
            // println!(...) → tracing::info!(...) — only if not eprintln
            let fixed = line.replace("println!(", "tracing::info!(");
            fixes.push(SelfHealFix {
                line: line_num,
                original: line.to_string(),
                fixed,
                description: "println! → tracing::info!".into(),
            });
        }
    }

    fixes
}

/// Format self-healing fixes as a gate message with copy-paste ready code.
pub fn format_self_heal_message(fixes: &[SelfHealFix], file_path: &str) -> String {
    if fixes.is_empty() {
        return String::new();
    }

    let mut msg = format!(
        "[SELF_HEAL] Auto-fix available for {}\n\n\
         The following fixes can be applied automatically:\n\n",
        file_path
    );

    for fix in fixes {
        msg.push_str(&format!(
            "Line {}: {}\n\
             - Original: {}\n\
             + Fixed:    {}\n\n",
            fix.line, fix.description, fix.original.trim(), fix.fixed.trim()
        ));
    }

    msg.push_str(
        "ACTION: Apply these fixes by using Edit tool with the fixed content.\n\
         The gate will auto-approve once violations are resolved."
    );

    msg
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_unwrap_to_question_mark() {
        let content = "let x = foo.unwrap();";
        let fixes = rust_self_heal(content);
        assert_eq!(fixes.len(), 1);
        assert_eq!(fixes[0].fixed, "let x = foo?;");
    }

    #[test]
    fn test_println_to_tracing() {
        let content = "println!(\"hello\");";
        let fixes = rust_self_heal(content);
        assert_eq!(fixes.len(), 1);
        assert!(fixes[0].fixed.contains("tracing::info!"));
    }

    #[test]
    fn test_apply_fixes() {
        let content = "line1\nlet x = foo.unwrap();\nline3";
        let fixes = vec![SelfHealFix {
            line: 2,
            original: "let x = foo.unwrap();".into(),
            fixed: "let x = foo?;".into(),
            description: "test".into(),
        }];
        let healed = apply_fixes(content, &fixes);
        assert!(healed.is_some());
        let healed_content = healed.unwrap_or_default();
        assert!(healed_content.contains("let x = foo?;"));
        assert!(!healed_content.contains("unwrap"));
    }

    #[test]
    fn test_skips_test_code() {
        let content = "assert!(foo.unwrap());";
        let fixes = rust_self_heal(content);
        assert!(fixes.is_empty());
    }

    #[test]
    fn test_eprintln_to_tracing_warn() {
        let content = "eprintln!(\"error\");";
        let fixes = rust_self_heal(content);
        assert_eq!(fixes.len(), 1);
        assert!(fixes[0].fixed.contains("tracing::warn!"));
    }
}
