use kavach_types::HookInput;

use super::intent_context::{
    append_db_query_required, append_forbidden, append_memory_db, append_verify_existing,
    extract_research_topic,
};
use crate::error::EngineError;

/// Intent gate: classify user prompt, set enforcement state, route to skills.
/// Triggered by UserPromptSubmit hook event.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let prompt = input.get_string("prompt");
    if prompt.is_empty() {
        kavach_hook::exit_prompt_context("");
        return Ok(());
    }

    let mut session = kavach_session::get_or_create_session();
    session.reset_research_for_new_prompt();
    session.reset_evidence_window();
    session.increment_turn();

    let intent = kavach_chain::analyze_intent(prompt);
    // Narrow the required_skills list through the vectorless RAG matcher.
    // When the prompt + intent_type match a specific skill with strong
    // signal, demand only that single skill instead of the full classifier
    // list. Falls through to the legacy behaviour when no persisted tree
    // exists or the matcher finds zero overlap.
    let skills_raw = collapse_required_via_rag(
        intent.required_skills,
        prompt,
        &intent.intent_type,
    );
    // Filter out non-user-invocable skills before requiring them.
    // A skill with `user-invocable: false` in its SKILL.md cannot be satisfied
    // via the Skill tool — requiring it creates an unresolvable gate deadlock.
    // Absent field defaults to invocable (backward-compatible).
    let skills_dir = kavach_config::paths::skills_dir();
    let skills: Vec<String> = skills_raw
        .into_iter()
        .filter(|name| {
            let skill_md = skills_dir.join(name).join("SKILL.md");
            match std::fs::read_to_string(&skill_md) {
                Ok(text) => !text.contains("user-invocable: false"),
                Err(_) => true, // missing — keep, phantom filter handles it downstream
            }
        })
        .collect();
    session.store_intent(
        &intent.intent_type,
        &intent.complexity,
        skills.clone(),
    );

    if !skills.is_empty() {
        session.set_required_skills(skills);
    }

    // Detect explicit user confirmation to create a new crate/package.
    if kavach_session::SessionState::detect_new_crate_confirmation(prompt) {
        session.confirm_new_crate();
    }

    if intent.requires_research {
        let topic = extract_research_topic(prompt, &intent.intent_type);
        session.set_research_topic(&topic);
    }

    // Store risk level for risk-based gate depth (Gap 4).
    session.set_intent_risk(&intent.risk_level);

    // Log intent classification to kavach-db events
    super::event_log::log_intent(&session.session_id, &intent.intent_type, &intent.risk_level, &session.project);

    let router = kavach_chain::SkillFirstRouter::new();
    let keywords: Vec<&str> = prompt.split_whitespace().collect();
    let routing = router.route(prompt, &keywords);

    let research_gate = kavach_chain::ResearchGate::new();
    let forbidden = research_gate.check_forbidden_phrases(prompt);

    // Extract temporal context for WebSearch query injection.
    // Claude must use these values in all searches and agent prompts — not its training cutoff.
    let search_year = kavach_hook::current_year().to_string();
    let search_month = kavach_hook::current_month().to_string();
    let search_week = kavach_hook::current_week().to_string();
    let confidence_str = format!("{:.2}", intent.confidence);
    let mut kvs: Vec<(&str, &str)> = vec![
        ("type", &intent.intent_type),
        ("confidence", &confidence_str),
        ("complexity", &intent.complexity),
        ("risk", &intent.risk_level),
    ];

    let skill_str;
    if routing.use_skill {
        skill_str = routing.skill_name.clone();
        kvs.push(("skill", &skill_str));
    }

    let agent_str;
    if !routing.agent_name.is_empty() {
        agent_str = routing.agent_name.clone();
        kvs.push(("agent", &agent_str));
    }

    if intent.requires_research && !session.research_done {
        kvs.push(("research", "REQUIRED"));
    }

    if intent.intent_type == "memory" {
        kvs.push(("memory_action", "USE kavach db write — NOT MEMORY.md files"));
    }

    kvs.push(("search_year", &search_year));
    kvs.push(("search_month", &search_month));
    kvs.push(("search_week", &search_week));
    let mut context = kavach_hook::context_block("INTENT", &kvs);
    // [TEMPORAL_CONTEXT] removed — year/month/week already in [INTENT] kvs above.
    // Saves ~80 tokens/turn. Agent prompts: use search_year from [INTENT] block.

    append_forbidden(&mut context, &forbidden);
    append_memory_db(&mut context, &intent.intent_type);
    append_verify_existing(&mut context, &intent.intent_type);
    append_db_query_required(&mut context, prompt);

    if let Some(test_ctx) = super::test_inject::build_test_context(&mut session) {
        context.push('\n');
        context.push_str(&test_ctx);
    }

    if !session.memory_queried && session.turn_count <= 2 {
        context.push_str("\n[MEMORY] status:PENDING action:kavach db kanban --project <slug>");
    }

    // Every 5 turns, remind the model to persist roadmap and context to kavach-db.
    // Single-line nudge — full prose was repeated token waste.
    if session.turn_count > 1 && session.turn_count % 5 == 0 {
        context.push_str(&format!(
            "\n[DB_WRITE_REMINDER] turn:{} — kavach db write for any decisions/roadmap this turn.\n",
            session.turn_count
        ));
    }

    // [SESSION] block: inject only on turn 1 (already in session-start context).
    // Subsequent turns have it in the transcript — repeating wastes ~80 tokens/turn.
    if session.turn_count <= 1 {
        let session_toon = session.to_compact();
        context.push('\n');
        context.push_str(&session_toon);
    }

    let module_ctx = session.inject_modules_once(&["agi-flow", "memory"]);
    context.push_str(&module_ctx);

    // Phase D: RAG skill routing — emit top skill name only, not full hit list.
    // Full hit content (~100B/turn) replaced with single top match (~20B/turn).
    let top_skill = super::rag_router::top_skill_names_all("", prompt, &intent.intent_type, 1);
    if let Some(skill) = top_skill.into_iter().next() {
        context.push_str(&format!("\n[RAG:skill] {skill}\n"));
    }

    kavach_hook::exit_prompt_context(&context);
    Ok(())
}

/// Collapse the classifier-produced required_skills list to the single top
/// RAG-picked entry, if the matcher returns at least one overlap. Returns
/// the original list unchanged when:
/// - it has 1 or 0 entries (nothing to collapse)
/// - the RAG matcher is cold / has no persisted tree
/// - no RAG hit matches any entry in the classifier list
fn collapse_required_via_rag(
    classifier_list: Vec<String>,
    prompt: &str,
    intent_type: &str,
) -> Vec<String> {
    if classifier_list.len() <= 1 {
        return classifier_list;
    }
    let ranking = super::rag_router::top_skill_names_all(
        "",
        prompt,
        intent_type,
        5,
    );
    if ranking.is_empty() {
        return classifier_list;
    }
    for name in &ranking {
        if classifier_list.iter().any(|c| c == name) {
            return vec![name.clone()];
        }
    }
    classifier_list
}

#[cfg(test)]
mod rag_collapse_tests {
    use super::collapse_required_via_rag;

    #[test]
    fn should_leave_empty_list_unchanged() {
        let out = collapse_required_via_rag(Vec::new(), "", "");
        assert!(out.is_empty());
    }

    #[test]
    fn should_leave_single_entry_list_unchanged() {
        let single = vec!["rust".into()];
        let out = collapse_required_via_rag(single.clone(), "irrelevant", "general");
        assert_eq!(out, single);
    }

    // Multi-entry collapse depends on a persisted tree being queryable from
    // the live kavach-db and is covered by the end-to-end smoke path. A
    // cold-matcher fallback path is tested implicitly by every session
    // where no skills tree exists — the list passes through unchanged.
}

#[cfg(test)]
#[path = "intent_tests.rs"]
mod tests;
