use std::sync::OnceLock;
use aho_corasick::AhoCorasick;

/// Pre-compiled Aho-Corasick automaton for deferral phrases.
/// Built once at first call, reused for every subsequent check.
/// Single-pass O(n) over the response text regardless of pattern count.
fn deferral_ac() -> &'static AhoCorasick {
    static AC: OnceLock<AhoCorasick> = OnceLock::new();
    AC.get_or_init(|| {
        AhoCorasick::new([
            "future session", "follow-up session", "follow up session",
            "remaining items to address", "in a future", "save for later",
            "continue later", "address later", "remaining work",
            "future enhancement", "defer to", "pick up later",
        ]).expect("deferral_ac patterns are valid")
    })
}

/// Pre-compiled automaton for completion signals.
fn completion_ac() -> &'static AhoCorasick {
    static AC: OnceLock<AhoCorasick> = OnceLock::new();
    AC.get_or_init(|| {
        AhoCorasick::new([
            "all work is complete", "all work is done",
            "nothing remaining", "zero remaining", "all tasks complete",
            "all checks passed", "fully aligned",
            "binary deployed", "0 errors", "0 failures",
            "all tests pass", "deployed",
            "plan is complete", "plan: complete", "all phases done",
            "all phases complete", "no remaining phases",
            "no active plan", "no active roadmap",
            "rewiring complete", "there are no remaining",
            "genuinely complete", "clean stopping point",
            "between plans", "deferred per your",
        ]).expect("completion_ac patterns are valid")
    })
}

/// Pre-compiled automaton for contradiction signals (used in completion check).
fn contradiction_ac() -> &'static AhoCorasick {
    static AC: OnceLock<AhoCorasick> = OnceLock::new();
    AC.get_or_init(|| {
        AhoCorasick::new([
            "remaining bug", "remaining issue", "remaining fix",
            "still need", "still needs", "todo:", "still pending",
            "not yet fixed", "bugs remaining", "issues remaining",
            // Mid-plan phase transitions — completion signal is partial, not full
            "next is p", "next phase", "next is phase",
            "continuing with p", "moving to p", "starting p",
            "p4.2", "p3.2", "p2.2", "p5.2", "p6.2",
        ]).expect("contradiction_ac patterns are valid")
    })
}

/// Pre-compiled automaton for sycophancy phrases.
fn sycophancy_ac() -> &'static AhoCorasick {
    static AC: OnceLock<AhoCorasick> = OnceLock::new();
    AC.get_or_init(|| {
        AhoCorasick::new([
            "great question", "excellent question", "great point",
            "excellent idea", "that's a great", "absolutely right",
            "you're right", "good thinking", "brilliant approach",
            "perfect question", "wonderful idea", "fantastic point",
            "very insightful", "great observation",
        ]).expect("sycophancy_ac patterns are valid")
    })
}

/// Pre-compiled automaton for shell delegation phrases.
fn shell_delegation_ac() -> &'static AhoCorasick {
    static AC: OnceLock<AhoCorasick> = OnceLock::new();
    AC.get_or_init(|| {
        AhoCorasick::new([
            "run this to", "run these", "run the following",
            "run this command", "run this yourself", "run it yourself",
            "execute this", "type this", "paste this",
            "copy and run", "copy this and run",
            "you'll need to run", "you need to run",
            "you can run this", "you can run these", "you can run the following",
            "you should run",
        ]).expect("shell_delegation_ac patterns are valid")
    })
}

/// Pre-compiled automaton for permission-seeking phrases.
fn permission_ac() -> &'static AhoCorasick {
    static AC: OnceLock<AhoCorasick> = OnceLock::new();
    AC.get_or_init(|| {
        AhoCorasick::new([
            "should i proceed", "shall i proceed", "want me to continue",
            "should i continue", "shall i continue", "want me to fix",
            "should i fix", "shall i fix", "ready for phase",
            "ready for the next", "want me to go ahead",
            "should i go ahead", "shall i go ahead",
            "would you like me to", "do you want me to",
            "which option do you prefer", "which approach do you prefer",
            "want to start", "want to try", "want to begin",
            "shall we start", "shall we begin", "shall we proceed",
            "shall we continue", "shall we implement", "shall we fix",
            "ready to start",
            "which matters most", "which would you like",
            "which do you prefer", "what would you like me",
            "which one should", "what should i focus on",
            "what is the next phase", "what's the next phase",
            "what is next", "what's next",
            "do you want implementation", "do you want me to start",
            "want me to implement", "want me to build", "want me to wire",
            "want me to create", "want me to write", "want me to add",
            "want me to set up", "want me to start with",
            "shall i implement", "shall i build", "shall i create",
            "shall i write", "shall i wire", "shall i add",
            "should i implement", "should i build", "should i create",
        ]).expect("permission_ac patterns are valid")
    })
}

/// Behavioral detectors for the stop gate.
/// Each function analyzes `last_assistant_message` for anti-patterns.
/// Completion signals that override all detectors (false positive reduction).
/// Covers both task-level completion and plan-level completion to prevent
/// false blocks when a multi-phase plan is genuinely finished.
///
/// Normalize text to defeat fragmentation bypass.
/// Strips hyphens/dashes between word chars so "next ses-sion" → "next session".
/// Collapses newlines to spaces and runs of whitespace to single space.
/// MUST be called on already-lowercased text to avoid double allocation.
pub fn normalize_for_matching(text: &str) -> String {
    let mut result = String::with_capacity(text.len());
    let mut chars = text.chars().peekable();
    while let Some(ch) = chars.next() {
        match ch {
            '-' | '\u{2013}' | '\u{2014}' => {
                if let Some(&next) = chars.peek()
                    && next.is_alphanumeric()
                {
                    continue; // skip hyphen — join fragments
                }
                result.push(ch);
            }
            '\n' | '\r' => result.push(' '),
            other => result.push(other),
        }
    }
    result.split_whitespace().collect::<Vec<_>>().join(" ")
}

pub(crate) fn has_completion_signal(lower: &str) -> bool {
    if !completion_ac().is_match(lower) { return false; }
    // Contradiction check: if the message ALSO contains work-remaining indicators,
    // the completion signal is not genuine — it's partial completion disguised.
    !contradiction_ac().is_match(lower)
}

pub fn contains_deferral_language(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let db_sync_deferral = (lower.contains("kavach db") || lower.contains("db sync")
        || lower.contains("db updated") || lower.contains("db write"))
        && (lower.contains("next session") || lower.contains("next time")
            || lower.contains("future session"));
    let has_next_session_deferral = lower.contains("next session")
        && (lower.contains("continue in") || lower.contains("save for")
            || lower.contains("defer") || lower.contains("address in")
            || lower.contains("pick up in") || lower.contains("tackle in")
            || lower.contains("documented") || lower.contains("for the next"));
    let remaining_next = (lower.contains("remaining bug") || lower.contains("remaining issue")
        || lower.contains("remaining fix"))
        && lower.contains("next session");
    let is_negated = lower.contains("don't defer") || lower.contains("do not defer")
        || lower.contains("not deferring") || lower.contains("not saving for later")
        || lower.contains("avoid defer") || lower.contains("won't defer")
        || lower.contains("no deferral");
    if is_negated { return false; }
    db_sync_deferral || has_next_session_deferral || remaining_next
        || deferral_ac().is_match(&lower)
}

pub fn contains_sycophancy(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    sycophancy_ac().is_match(&lower)
}

pub fn contains_false_inability(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    // First-person inability claims — must start with "i " to avoid matching descriptions.
    let first_person = [
        "i can't access", "i don't have access",
        "i cannot access", "i can't run", "i cannot run",
        "i don't have permission", "i can't execute",
        "i can't directly edit", "i cannot directly edit",
        "i'm unable to edit", "i am unable to edit",
        "i'm unable to directly", "i am unable to directly",
        "i can only", "i only have read",
    ];
    // Tool-level block signals — these only appear when Claude is explaining why it stopped.
    let tool_blocks = [
        "tools are blocked", "both read and write are blocked",
        "read and write tools are blocked", "read/write tools are blocked",
        "only way is for you",
    ];
    first_person.iter().any(|c| lower.contains(c))
        || tool_blocks.iter().any(|c| lower.contains(c))
}

pub fn contains_incomplete_work(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    let discovery = [
        "found python", "found issues", "found in ",
        "fixing now", "fixing both", "let me fix",
        "need to fix", "needs fixing", "need to remove",
        "let me remove", "removing them", "let me update",
    ];
    if !discovery.iter().any(|d| lower.contains(d)) { return false; }
    let completion = [
        "fixed", "removed", "updated", "applied", "replaced",
        "deployed", "done", "complete", "verified", "passed",
        "all checks", "0 errors", "0 failures", "clean compile",
    ];
    !completion.iter().any(|c| lower.contains(c))
}

pub fn contains_remaining_phases(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    // Negation check: "no remaining", "zero remaining", "0 remaining" = plan done
    let negated = lower.contains("no remaining")
        || lower.contains("zero remaining")
        || lower.contains("0 remaining")
        || lower.contains("there are no remaining");
    if negated { return false; }
    let has_remaining = lower.contains("remaining:")
        || lower.contains("phases remaining")
        || lower.contains("phases left")
        || lower.contains("bugs remaining")
        || lower.contains("issues remaining")
        || lower.contains("remaining bug")
        || lower.contains("remaining issue")
        || (lower.contains("remaining") && lower.contains("phase"));
    let started_next = lower.contains("starting phase")
        || lower.contains("moving to phase")
        || lower.contains("beginning phase")
        || lower.contains("now implementing");
    has_remaining && !started_next
}

/// Detect session summary used as exit ramp: numbered list + "what next?"
pub fn contains_summary_exit(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let has_summary = lower.contains("session summary")
        || lower.contains("summary so far")
        || lower.contains("here's what was done")
        || lower.contains("here is what was done")
        || lower.contains("commits this session")
        || lower.contains("bugs fixed this session")
        || lower.contains("fixed this session:");
    let has_what_next = lower.contains("what would you like")
        || lower.contains("what next")
        || lower.contains("what's next")
        || lower.contains("what do you want");
    // Table summary with remaining column = exit ramp even without "what next?"
    let has_table_exit = (lower.contains("| fixed") || lower.contains("fixed |"))
        && (lower.contains("| remaining") || lower.contains("remaining |"));
    (has_summary && has_what_next) || has_table_exit
}

pub fn contains_parallel_system(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let creation = ["new crate", "new package", "new module", "separate crate",
        "separate package", "standalone crate", "dedicated crate",
        "unified manager", "unified system", "new schema alongside",
        "add it alongside", "create a new"];
    let no_replace = !lower.contains("replac") && !lower.contains("remov")
        && !lower.contains("migrat") && !lower.contains("delet");
    creation.iter().any(|p| lower.contains(p)) && no_replace
}

/// Detect responses that passively ask user to provide information Claude can obtain itself.
/// Pattern: "share X and I'll ...", "tell me X and I'll ...", "what is your X",
///          "check with: <cmd>", "look in your dashboard", "provide the X".
/// Claude must run the tool (wrangler, curl, cargo, etc.) instead of asking the user.
pub fn contains_passive_info_request(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }

    // "share X and I'll give you" / "share X and I'll ..."
    let share_and_ill = lower.contains("share") && lower.contains("and i'll");
    // "tell me X and I'll" / "let me know X and I'll"
    let tell_and_ill = (lower.contains("tell me") || lower.contains("let me know"))
        && lower.contains("and i'll");
    // "check with: <cmd>" — telling user to run a CLI command themselves
    let check_with = lower.contains("check with:") || lower.contains("check with ");
    // "look in your dashboard / settings / console"
    let look_in = lower.contains("look in your") || lower.contains("check your dashboard")
        || lower.contains("check your console") || lower.contains("check your settings");
    // "provide the X" / "give me the X" when X is a value Claude could fetch
    let provide_x = (lower.contains("provide the") || lower.contains("give me the"))
        && (lower.contains("subdomain") || lower.contains("url") || lower.contains("secret")
            || lower.contains("token") || lower.contains("key") || lower.contains("value"));
    // "paste the output here" — user asked to relay command output instead of running it
    let paste_output = lower.contains("paste the output") || lower.contains("paste it here")
        || lower.contains("paste the result") || lower.contains("paste your output");

    share_and_ill || tell_and_ill || check_with || look_in || provide_x || paste_output
}

/// Detect responses that dump shell commands for the user to run instead of doing the work.
/// Pattern: "run this", "run these", "! cmd", "type this", "execute this" without prior action.
/// Claude is a worker — when a tool can do it, use the tool, never delegate to the user.
pub fn contains_shell_command_delegation(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    // Detect "run this/these N commands" + shell code block patterns
    let has_run_phrase = shell_delegation_ac().is_match(&lower);
    // Also detect "! cmd" delegation pattern — telling user to use ! prefix.
    // Only fire when the ! pattern appears OUTSIDE code fences (backtick blocks).
    // Inside code fences = documentation/example, not live delegation.
    let has_bang_delegation = if msg.contains("! wrangler ") || msg.contains("! npm ")
        || msg.contains("! npx ") || msg.contains("! cargo ")
        || msg.contains("! cat ") || msg.contains("! echo ")
        || msg.contains("! sed ") || msg.contains("! curl ")
    {
        !all_bang_inside_code_fence(msg)
    } else {
        lower.contains("! prefix") && lower.contains("prompt")
    };
    // Exempt: explaining kavach db sync commands (those are intentional user-runnable)
    let is_kavach_cmd = lower.contains("kavach db") || lower.contains("kavach session");
    if is_kavach_cmd { return false; }
    has_run_phrase || has_bang_delegation
}

/// Returns true if every `! <cmd>` occurrence in `msg` is inside a backtick code fence.
/// A code fence starts with ``` (optionally followed by a language tag) and ends with ```.
fn all_bang_inside_code_fence(msg: &str) -> bool {
    // Collect ranges of fenced code blocks.
    let mut fence_ranges: Vec<(usize, usize)> = Vec::new();
    let mut search = msg;
    let mut offset = 0usize;
    while let Some(start) = search.find("```") {
        let abs_start = offset + start;
        let after_open = start + 3;
        // Skip optional language tag to end of that line.
        let rest = &search[after_open..];
        let content_start = match rest.find('\n') {
            Some(nl) => after_open + nl + 1,
            None => break,
        };
        let content = &search[content_start..];
        match content.find("```") {
            Some(end_rel) => {
                let abs_end = offset + content_start + end_rel + 3;
                fence_ranges.push((abs_start, abs_end));
                let next = content_start + end_rel + 3;
                offset += next;
                search = &search[next..];
            }
            None => break,
        }
    }
    if fence_ranges.is_empty() { return false; }
    // Check every `! ` occurrence — if any is outside all fences, return false.
    let bang_patterns = ["! wrangler ", "! npm ", "! npx ", "! cargo ",
                         "! cat ", "! echo ", "! sed ", "! curl "];
    for pat in &bang_patterns {
        let mut haystack = msg;
        let mut h_offset = 0usize;
        while let Some(pos) = haystack.find(pat) {
            let abs_pos = h_offset + pos;
            let inside = fence_ranges.iter().any(|(s, e)| abs_pos >= *s && abs_pos < *e);
            if !inside { return false; }
            h_offset += pos + pat.len();
            haystack = &haystack[pos + pat.len()..];
        }
    }
    true
}

pub fn contains_permission_seeking(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    // Plan-transition: asking "what next" AFTER plan completion is legitimate
    let is_plan_transition = (lower.contains("what would you like to focus")
        || lower.contains("what would you like to work"))
        && (lower.contains("complete") || lower.contains("done")
            || lower.contains("finished") || lower.contains("no active"));
    if is_plan_transition { return false; }
    permission_ac().is_match(&lower)
}

/// Detect architecture assumptions stated without evidence of file reads.
/// Pattern: "X should stay Y" or "X is not needed" without file paths or code references.
pub fn contains_unverified_architecture_claim(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }

    let assumption_phrases = [
        // REST-only assumptions
        "should stay rest", "should remain rest", "keep rest for",
        "rest is correct for", "rest is fine for", "rest works fine",
        // Technology narrowing without evidence
        "don't need graphql", "don't need grpc", "don't need websocket",
        "doesn't need graphql", "doesn't need grpc", "doesn't need websocket",
        "not needed for", "is not needed here", "is overkill for",
        // Scope narrowing — assuming tech only applies to one page
        "only needed for the dashboard", "only needed for",
        "only for the dashboard", "only on the dashboard",
        "graphql is only", "grpc is only", "websocket is only",
        "not a full rewrite", "doesn't need a full rewrite",
        // Individual page REST assumptions
        "individual pages should stay", "single-service pages",
        "keep rest for everything else", "rest for single",
        "graphql adds value only", "only where one page",
        // Blanket technology dismissal
        "don't rewrite all", "do not rewrite all",
        "no need to migrate", "no need to convert",
        // gRPC assumption narrowing
        "grpc is only for internal", "grpc only for microservice",
        "don't need grpc for", "grpc is overkill",
        // WebSocket assumption narrowing
        "websocket is only for chat", "websocket only for real-time",
        "don't need websocket for", "sse is enough for",
        "polling is fine for", "polling works fine",
        // SSE assumption narrowing
        "sse is only for", "don't need sse",
        // HTTP/3 dismissal
        "http/3 is not needed", "http/2 is fine",
        "don't need http/3", "http/3 is overkill",
        // Protocol lock-in assumptions
        "rest is the standard", "rest is the default",
        "just use rest", "stick with rest",
        "rest for everything", "rest handles everything",
        // Performance dismissal without measurement
        "performance difference is negligible",
        "latency doesn't matter", "latency is not an issue",
    ];
    let has_assumption = assumption_phrases.iter().any(|p| lower.contains(p));
    if !has_assumption { return false; }

    let evidence_markers = [
        ".rs:", ".ts:", ".tsx:", ".toml:",
        "cargo.toml", "package.json",
        "reading the", "checked the", "grep found",
        "the file shows", "the code shows", "verified that",
    ];
    let has_evidence = evidence_markers.iter().any(|e| lower.contains(e));
    !has_evidence
}

/// Detect when model dismisses a user-reported bug instead of investigating.
/// Check if db write is overdue: returns true when turn_count >= 5 and
/// no `kavach db write` has been called in the last 5 turns.
/// Caller passes turn_count and last_db_write_turn from session.
/// Returns true when 10+ turns have elapsed since the last db write.
/// Threshold raised from 5→10: implementation loops (file splitting, refactoring)
/// legitimately span many turns before a natural checkpoint (card completion).
pub fn is_db_write_overdue(turn_count: i32, last_db_write_turn: i32) -> bool {
    turn_count >= 10 && (turn_count - last_db_write_turn) >= 10
}

/// Detect sleep+cat polling loops on task output paths.
/// The model loops calling `sleep N && cat /private/tmp/.../tasks/<id>.output`
/// because the output file never populates from raw Bash — only the TaskOutput tool
/// can read it. Each retry is identical and produces no progress.
pub fn contains_polling_loop(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    let has_sleep_cat = lower.contains("sleep") && lower.contains("cat ")
        || lower.contains("sleep && cat")
        || lower.contains("poll again in a moment")
        || lower.contains("still building. let me poll")
        || lower.contains("still building, let me poll");
    let has_task_path = lower.contains("/tasks/") && lower.contains(".output");
    has_sleep_cat && has_task_path
}

pub fn contains_user_report_dismissal(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }

    let dismissals = [
        "the page is rendered", "the page is functional",
        "is expected behavior", "is expected for local", "is expected in dev",
        "this is a known", "this is normal", "this is expected",
        "not your application", "does not affect your",
        "content is visible", "content is rendering",
        "it's not stuck", "is not stuck",
        "just waiting on", "should still be rendering",
        "hard refresh", "close the devtools",
    ];
    let has_dismissal = dismissals.iter().any(|p| lower.contains(p));
    if !has_dismissal { return false; }

    let has_root_cause = lower.contains("the cause is") || lower.contains("root cause")
        || lower.contains("error occurs because") || lower.contains("the fix is");
    !has_root_cause
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_deferral_true_positives() {
        assert!(contains_deferral_language("save for later"));
        assert!(contains_deferral_language("remaining work to do"));
        assert!(contains_deferral_language("in a future enhancement"));
        assert!(contains_deferral_language("continue in the next session"));
    }

    #[test]
    fn test_deferral_db_sync_as_exit() {
        assert!(contains_deferral_language(
            "Done. Kavach DB updated with 2 entries. Next session will start informed."
        ));
        assert!(contains_deferral_language(
            "kavach db sync complete. Continue in a future session."
        ));
    }

    #[test]
    fn test_deferral_db_sync_checkpoint_ok() {
        assert!(!contains_deferral_language(
            "kavach db sync complete. Now implementing Phase E."
        ));
    }

    #[test]
    fn test_deferral_false_positive_completion_override() {
        assert!(!contains_deferral_language(
            "Binary deployed. All checks passed. Your next session will use updated types."
        ));
    }

    #[test]
    fn test_deferral_next_session_needs_action_verb() {
        assert!(!contains_deferral_language("your next session will have this"));
        assert!(contains_deferral_language("defer to the next session"));
    }

    #[test]
    fn test_deferral_documented_for_next_session() {
        assert!(contains_deferral_language(
            "The remaining bugs documented in .claude/plans/file.md for the next session."
        ));
    }

    #[test]
    fn test_deferral_remaining_bugs_next_session() {
        assert!(contains_deferral_language(
            "Remaining bugs: BUG-001, BUG-006. Will fix in next session."
        ));
    }

    #[test]
    fn test_deferral_empty() { assert!(!contains_deferral_language("")); }

    #[test]
    fn test_incomplete_found_not_fixed() {
        assert!(contains_incomplete_work("Found Python in 2 files. Fixing now."));
        assert!(contains_incomplete_work("Need to remove the stale imports."));
    }

    #[test]
    fn test_incomplete_found_and_fixed() {
        assert!(!contains_incomplete_work("Found Python in 2 files. Removed both."));
        assert!(!contains_incomplete_work("Found issues. Fixed all of them. 0 errors."));
    }

    #[test]
    fn test_incomplete_no_discovery() {
        assert!(!contains_incomplete_work("Binary deployed at 4.5MB."));
        assert!(!contains_incomplete_work(""));
    }

    #[test]
    fn test_shell_delegation_run_this() {
        assert!(contains_shell_command_delegation(
            "Run this to append the missing ones:\n! cat >> .env << 'EOF'"
        ));
        assert!(contains_shell_command_delegation(
            "You need to run: sed -i '' 's/JLM_URL=/JACOBS_LADDER/' .env"
        ));
        assert!(contains_shell_command_delegation(
            "Run these 3 commands to fix the .env file."
        ));
    }

    #[test]
    fn test_shell_delegation_bang_prefix() {
        assert!(contains_shell_command_delegation(
            "Type this with the ! prefix in the prompt:\n! echo MY_VAR=value >> .env"
        ));
        assert!(contains_shell_command_delegation(
            "! cat >> \"/path/to/.env\" << 'EOF'"
        ));
    }

    #[test]
    fn test_shell_delegation_kavach_exempt() {
        assert!(!contains_shell_command_delegation(
            "Run kavach db sync to save progress."
        ));
        assert!(!contains_shell_command_delegation(
            "You can run kavach session end to close."
        ));
    }

    #[test]
    fn test_shell_delegation_normal_ok() {
        assert!(!contains_shell_command_delegation("Fixed the .env. 0 errors."));
        assert!(!contains_shell_command_delegation(""));
        // Technical description "you can run X inside a loop" is not delegation.
        assert!(!contains_shell_command_delegation(
            "call `prepare()` outside the hot render path, call `layout()` inside render — you can run inside a render loop."
        ));
        // "you can run this" IS delegation.
        assert!(contains_shell_command_delegation("you can run this command to fix it"));
    }

    #[test]
    fn test_passive_info_request_detected() {
        // The exact pattern from the nicole-carpenter session
        assert!(contains_passive_info_request(
            "Share the subdomain and I'll give you the exact value to put in .env."
        ));
        assert!(contains_passive_info_request(
            "Tell me your CF subdomain and I'll generate the URL."
        ));
        assert!(contains_passive_info_request(
            "Check with: wrangler whoami"
        ));
        assert!(contains_passive_info_request(
            "Look in your dashboard under Workers & Pages."
        ));
        assert!(contains_passive_info_request(
            "Provide the subdomain and I'll configure it."
        ));
        assert!(contains_passive_info_request(
            "Let me know the URL and I'll update the config."
        ));
    }

    #[test]
    fn test_passive_info_request_paste_output() {
        assert!(contains_passive_info_request(
            "Paste the output here — it'll show the workers.dev URL."
        ));
        assert!(contains_passive_info_request(
            "Run wrangler deploy and paste the output here."
        ));
        assert!(contains_passive_info_request("paste it here once done."));
    }

    #[test]
    fn test_shell_delegation_bang_wrangler() {
        // Outside code fence — must block
        assert!(contains_shell_command_delegation(
            "! wrangler deploy\nPaste the URL here."
        ));
        assert!(contains_shell_command_delegation(
            "cd packages/workers && ! wrangler deploy"
        ));
    }

    #[test]
    fn test_shell_delegation_bang_inside_code_fence_exempt() {
        // Inside ``` fence — documenting a pattern, not delegating — must NOT block
        let fenced = "Added `! wrangler` to blocked patterns:\n```bash\n! wrangler deploy\n```\nCommit done.";
        assert!(!contains_shell_command_delegation(fenced));
    }

    #[test]
    fn test_all_bang_inside_code_fence() {
        let inside = "```bash\n! wrangler deploy\n```";
        assert!(all_bang_inside_code_fence(inside));

        let outside = "Run: ! wrangler deploy";
        assert!(!all_bang_inside_code_fence(outside));

        let mixed = "```bash\n! wrangler deploy\n```\nAlso: ! npm install";
        assert!(!all_bang_inside_code_fence(mixed));
    }

    #[test]
    fn test_passive_info_request_not_triggered() {
        // Normal technical descriptions must not fire
        assert!(!contains_passive_info_request(
            "Ran wrangler whoami — subdomain is my-account. Updated .env."
        ));
        assert!(!contains_passive_info_request(
            "Fixed the URL in .env. 0 errors."
        ));
        assert!(!contains_passive_info_request(""));
        // "share" without "and I'll" is fine
        assert!(!contains_passive_info_request(
            "The worker will share state via KV."
        ));
    }

    #[test]
    fn test_permission_detected() {
        assert!(contains_permission_seeking("Should I proceed with the fix?"));
        assert!(contains_permission_seeking("Want me to continue with phase 2?"));
        assert!(contains_permission_seeking("Would you like me to run the tests?"));
        // Regression: mid-plan "done" + "next is P4.2" must NOT exempt permission-seeking
        assert!(contains_permission_seeking(
            "P4.1 done. Next is P4.2 — wire list_feed_keyset + ACL filter. Should I proceed?"
        ));
    }

    #[test]
    fn test_permission_allowed_when_done() {
        // "All done" is no longer a completion signal — it matches mid-plan partial completions.
        // Only full-plan signals like "all work is done" or "plan is complete" exempt.
        assert!(contains_permission_seeking("All done. Want me to continue?"));
        // "Deployed" is still a completion signal.
        assert!(!contains_permission_seeking("Deployed. Should I proceed?"));
    }

    #[test]
    fn test_permission_normal() {
        assert!(!contains_permission_seeking("Fixed the bug. 0 errors."));
        assert!(!contains_permission_seeking(""));
    }

    #[test]
    fn test_permission_ok_plan_transition() {
        assert!(!contains_permission_seeking(
            "Plan is complete. What would you like to focus on next?"
        ));
        assert!(!contains_permission_seeking(
            "All phases done. What would you like to work on next?"
        ));
    }

    #[test]
    fn test_completion_signal_plan_complete() {
        assert!(has_completion_signal("the plan is complete"));
        assert!(has_completion_signal("all phases done"));
        assert!(has_completion_signal("no remaining phases"));
        assert!(has_completion_signal("no active plan exists"));
        assert!(has_completion_signal("deferred per your instruction"));
    }

    #[test]
    fn test_inability_detected() {
        assert!(contains_false_inability("I can't access your .env file."));
        assert!(contains_false_inability("I don't have access to the database."));
        assert!(contains_false_inability("I can't directly edit the .env file."));
        assert!(contains_false_inability("I'm unable to edit this file directly."));
        assert!(contains_false_inability("both read and write tools are blocked"));
        assert!(contains_false_inability("only way is for you to run the command"));
    }

    #[test]
    fn test_inability_no_false_positive_on_description() {
        // Describing what the detector catches should NOT trigger it.
        assert!(!contains_false_inability("blocks Claude when it claims can't directly edit .env"));
        assert!(!contains_false_inability("The stop gate now blocks permission-blocked patterns."));
        assert!(!contains_false_inability("Deployed. The stop gate now blocks Claude when it claims deadlock"));
    }

    #[test]
    fn test_inability_normal() {
        assert!(!contains_false_inability("Fixed the connection issue."));
        assert!(!contains_false_inability(""));
    }

    #[test]
    fn test_sycophancy_detected() {
        assert!(contains_sycophancy("Great question! Let me look into that."));
        assert!(contains_sycophancy("That's a great point about the architecture."));
    }

    #[test]
    fn test_sycophancy_normal() {
        assert!(!contains_sycophancy("Fixed the bug. 0 errors."));
        assert!(!contains_sycophancy(""));
    }

    #[test]
    fn test_remaining_phases_blocked() {
        assert!(contains_remaining_phases(
            "Phase C complete. Remaining: D (eCPM), F (fraud), 12 (blocked), 13 (last)."
        ));
    }

    #[test]
    fn test_remaining_bugs_blocked() {
        assert!(contains_remaining_phases(
            "Fixed BUG-002. Remaining bugs: BUG-001, BUG-006, BUG-010."
        ));
    }

    #[test]
    fn test_remaining_issues_blocked() {
        assert!(contains_remaining_phases(
            "3 issues remaining from the audit."
        ));
    }

    #[test]
    fn test_remaining_phases_ok_if_starting_next() {
        assert!(!contains_remaining_phases(
            "Phase C complete. Remaining: D, F. Now implementing Phase D."
        ));
    }

    #[test]
    fn test_remaining_phases_ok_if_all_done() {
        assert!(!contains_remaining_phases(
            "All phases complete. All done. Deployed."
        ));
    }

    #[test]
    fn test_remaining_phases_ok_negated() {
        assert!(!contains_remaining_phases(
            "There are no remaining phases in this plan."
        ));
        assert!(!contains_remaining_phases(
            "No remaining phases. Plan is complete."
        ));
    }

    #[test]
    fn test_remaining_phases_ok_plan_complete() {
        assert!(!contains_remaining_phases(
            "UAM rewiring plan is complete. Phase 12 deferred per your instruction."
        ));
    }

    #[test]
    fn test_parallel_system_detected() {
        assert!(contains_parallel_system("I'll create a new crate for the ads manager."));
        assert!(contains_parallel_system("Let me build a separate package for this."));
        assert!(contains_parallel_system("Adding a unified manager alongside existing code."));
    }

    #[test]
    fn test_parallel_system_ok_if_replacing() {
        assert!(!contains_parallel_system("Create a new crate to replace the old one."));
        assert!(!contains_parallel_system("New package that removes the legacy system."));
    }

    #[test]
    fn test_parallel_system_normal() {
        assert!(!contains_parallel_system("Fixed the route handler. 0 errors."));
        assert!(!contains_parallel_system(""));
    }

    #[test]
    fn test_summary_exit_detected() {
        assert!(contains_summary_exit(
            "Session summary so far: 1. Fixed routes 2. Updated DB. What would you like to work on next?"
        ));
        assert!(contains_summary_exit(
            "Here's what was done: migrations applied. What next?"
        ));
    }

    #[test]
    fn test_summary_exit_table_format() {
        assert!(contains_summary_exit(
            "Done. Two commits this session:\n| Fixed | Remaining |\nBUG-002 | BUG-006"
        ));
    }

    #[test]
    fn test_summary_exit_bugs_fixed_session() {
        assert!(contains_summary_exit(
            "Bugs fixed this session: 17 total. What next?"
        ));
    }

    #[test]
    fn test_summary_exit_ok_no_question() {
        assert!(!contains_summary_exit(
            "Session summary so far: 1. Fixed routes 2. Updated DB. Now starting Phase 3."
        ));
    }

    #[test]
    fn test_summary_exit_ok_completion() {
        // "All done" no longer exempt — only full-plan signals like "all work is done"
        assert!(contains_summary_exit(
            "All done. Session summary: 3 commits. What would you like next?"
        ));
        // Full completion signal still exempts
        assert!(!contains_summary_exit(
            "All work is done. Session summary: 3 commits. What would you like next?"
        ));
    }

    #[test]
    fn test_summary_exit_normal() {
        assert!(!contains_summary_exit("Fixed the bug. 0 errors."));
        assert!(!contains_summary_exit(""));
    }

    // --- contains_polling_loop ---
    #[test]
    fn test_polling_loop_sleep_cat_task_path() {
        assert!(contains_polling_loop(
            "Still building. Let me poll again in a moment.\n\
             sleep 5 && cat /private/tmp/claude-501/tasks/bw3fj63xc.output | tail -60"
        ));
    }

    #[test]
    fn test_polling_loop_sleep_and_cat_variant() {
        assert!(contains_polling_loop(
            "sleep 30 && cat /private/tmp/claude-501/-Users/tasks/baldgr0i1.output 2>/dev/null | tail -60"
        ));
    }

    #[test]
    fn test_polling_loop_no_task_path() {
        // sleep+cat without a task output path is not the polling anti-pattern
        assert!(!contains_polling_loop("sleep 5 && cat /tmp/some_log.txt"));
    }

    #[test]
    fn test_polling_loop_empty() {
        assert!(!contains_polling_loop(""));
    }

    #[test]
    fn test_polling_loop_normal_cargo_ok() {
        assert!(!contains_polling_loop("cargo check finished. 0 errors."));
    }

    // --- is_db_write_overdue (threshold = 10) ---
    #[test]
    fn test_db_write_overdue_at_turn_10_no_write() {
        assert!(is_db_write_overdue(10, 0));
        assert!(is_db_write_overdue(20, 9));
    }

    #[test]
    fn test_db_write_not_overdue_within_threshold() {
        // 9 turns since last write — not overdue
        assert!(!is_db_write_overdue(10, 1));
        // wrote this turn
        assert!(!is_db_write_overdue(10, 10));
        // wrote 5 turns ago — still within 10
        assert!(!is_db_write_overdue(10, 5));
    }

    #[test]
    fn test_db_write_not_overdue_before_turn_10() {
        assert!(!is_db_write_overdue(9, 0));
        assert!(!is_db_write_overdue(0, 0));
    }

    // --- normalize_for_matching ---
    #[test]
    fn test_normalize_strips_hyphen_between_word_chars() {
        assert_eq!(normalize_for_matching("next ses-sion"), "next session");
        assert_eq!(normalize_for_matching("post-launch"), "postlaunch");
        assert_eq!(normalize_for_matching("pre-laun\u{2013}ch"), "prelaunch");
    }

    #[test]
    fn test_normalize_keeps_hyphen_before_space() {
        // hyphen at end of token (before space) must be preserved — not a fragment join
        let result = normalize_for_matching("foo- bar");
        assert!(result.contains('-'));
    }

    #[test]
    fn test_normalize_collapses_whitespace() {
        assert_eq!(normalize_for_matching("a  b   c"), "a b c");
        assert_eq!(normalize_for_matching("a\nb\rc"), "a b c");
    }

    // --- fragmentation bypass detection ---
    #[test]
    fn test_deferral_fragmented_next_session() {
        // "next ses-sion" should still be caught after normalization
        assert!(contains_deferral_language(
            "save for the next ses-sion"
        ));
    }

    #[test]
    fn test_strategic_fragmented_post_launch() {
        // "post-laun-ch" fragments should be caught by stop_detect_strategic via normalize
        // Tested indirectly here via deferral — direct strategic tests are in that module
        assert!(contains_deferral_language("remaining work for a fu-ture session"));
    }

    #[test]
    fn test_permission_fragmented_should_i() {
        assert!(contains_permission_seeking("shou-ld i pro-ceed with the fix?"));
    }
}
