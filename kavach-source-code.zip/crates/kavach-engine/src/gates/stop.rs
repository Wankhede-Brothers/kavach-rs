use kavach_types::HookInput;

use crate::error::EngineError;
use super::stop_verify::{has_rust_modifications, resolve_cargo_dir, run_cargo_check};

// ARCH: StopGateCircuitBreaker — behavioral detectors use circuit breaker pattern
// PATTERN: circuit_breaker | SCOPE: session | CAP: AP | SEARCHED: 2026-04
// Per Meta-Harness research: complex verification gates degrade performance.
// P0 gates (security/bounty) remain hard blocks. P1 gates (behavioral) use circuit breaker.

/// Block with circuit breaker and scope narrowing hints.
/// Returns true if we should proceed with block, false if circuit tripped (force-allow).
/// On block 2/3, adds scope narrowing hint to the block message.
fn should_block_behavioral(session: &mut kavach_session::SessionState, category: &str) -> bool {
    if session.is_gate_tripped(category) {
        // Circuit already tripped — force-allow with advisory logged
        false
    } else {
        // Record block, check if we should trip
        let tripped = session.record_gate_block(category);
        !tripped // If tripped, don't block (return false)
    }
}

/// Get scope narrowing advisory to append to block messages.
/// Returns empty string on first block, narrowing hint on second, tripped notice on third+.
fn get_scope_advisory(session: &kavach_session::SessionState, category: &str) -> String {
    match session.scope_narrowing_hint(category) {
        Some(hint) => format!("\n\n{hint}"),
        None => String::new(),
    }
}

/// Stop gate: HARD BLOCK premature stops. Force diagnosis and task resumption.
/// NEVER allow stopping when there's a failure to diagnose or work in progress.
/// Uses stop_hook_active to prevent infinite blocking loops.
/// Uses circuit breaker for behavioral detectors (P1) — trips after 3 blocks.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let mut session = kavach_session::get_or_create_session();

    // Pre-trim message once to prevent whitespace-only bypass across all detectors.
    let msg = input.last_assistant_message.trim();

    // P1 advisory collected during bounty checks — included in final context.
    let mut semver_advisory: Option<String> = None;

    // FIRST CHECK: deferral or incomplete work — runs BEFORE stop_hook_active.
    // Block ONCE per pattern. On retry (stop_hook_active), skip to avoid loop.
    if !input.stop_hook_active {
        // Bounty gates — full project scan on stop (P0: always hard block, no circuit breaker)
        let work_dir = &session.work_dir;
        if !work_dir.is_empty() {
            if let Some(block_msg) = super::bounty_cve::scan(work_dir) {
                kavach_hook::exit_stop_block(&block_msg);
                return Ok(());
            }
            if let Some(block_msg) = super::bounty_unsafe::check(work_dir) {
                kavach_hook::exit_stop_block(&block_msg);
                return Ok(());
            }
            if let Some(block_msg) = super::bounty_license::check(work_dir) {
                kavach_hook::exit_stop_block(&block_msg);
                return Ok(());
            }
            if let Some(block_msg) = super::bounty_deps::check(work_dir) {
                kavach_hook::exit_stop_block(&block_msg);
                return Ok(());
            }
            // Cargo-vet audit gate
            if let Some(block_msg) = super::bounty_vet::check(work_dir) {
                kavach_hook::exit_stop_block(&block_msg);
                return Ok(());
            }
            // Semver violation gate — P1 advisory, not P0 block
            // Per harness engineering: quality checks don't block, they advise.
            // Semver violations are library versioning issues, not security vulnerabilities.
            // cargo-semver-checks uses lint severity (deny/warn/allow), matching P1 advisory.
            semver_advisory = super::bounty_semver::check(work_dir);
        }

        // Hard block: kavach db write overdue — every 10 turns, micro-detail entries required.
        if is_db_write_overdue(session.turn_count, session.last_db_write_turn) {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: kavach db write overdue. \
                 10+ turns have passed without writing to kavach-db. \
                 IMPERATIVE: call `kavach db write --project <slug> --category <cat> \
                 --key <key> --title <title> --content \"<micro-detail>\"` for EVERY \
                 roadmap item, decision, and discovery from the last 5 turns. \
                 Rules: (1) NO summaries — write the exact file path, line number, \
                 root cause, or decision rationale. \
                 (2) NO holistic/surface entries — each entry must be actionable. \
                 (3) Roadmap entries must include file: <path>. \
                 (4) Decision entries must include rationale and alternatives rejected.",
            );
            return Ok(());
        }

        // Behavioral detectors (P1) — use circuit breaker pattern.
        // After 3 blocks per category, force-allow with advisory.
        // Block messages include scope narrowing hints on 2nd block.
        if contains_deferral_language(msg) && should_block_behavioral(&mut session, "deferral") {
            let advisory = get_scope_advisory(&session, "deferral");
            kavach_hook::exit_stop_block(&format!(
                "STOP BLOCKED: Response contains deferral language. \
                 You MUST complete ALL requested work NOW. Resume and finish.{advisory}"
            ));
            return Ok(());
        }
        if contains_incomplete_work(msg) && should_block_behavioral(&mut session, "incomplete") {
            let advisory = get_scope_advisory(&session, "incomplete");
            kavach_hook::exit_stop_block(&format!(
                "STOP BLOCKED: Response reports findings without fixing them. \
                 Search → Find → Fix → Verify = ONE flow. Fix issues NOW.{advisory}"
            ));
            return Ok(());
        }
        if contains_permission_seeking(msg) && should_block_behavioral(&mut session, "permission") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response asks for permission instead of acting. \
                 User gave instruction → EXECUTE IT. No confirmation needed.",
            );
            return Ok(());
        }
        if contains_false_inability(msg) && should_block_behavioral(&mut session, "inability") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response claims inability without trying alternatives. \
                 TRY FIRST — try different tool, try Bash. \
                 Report inability ONLY after exhausting alternatives.",
            );
            return Ok(());
        }
        if contains_shell_command_delegation(msg) && should_block_behavioral(&mut session, "shell_delegation") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response dumps shell commands for the user to run. \
                 Use the Write/Edit/Bash tool to do the work directly — \
                 the user gave an order, not a request for instructions. \
                 For .env changes: Read .env, then Write the updated file.",
            );
            return Ok(());
        }
        if contains_passive_info_request(msg) && should_block_behavioral(&mut session, "passive_info") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response asks user to provide information Claude can \
                 obtain itself. USE THE TOOL: run wrangler/curl/cargo/grep directly. \
                 NEVER ask 'share X and I'll give you Y' — fetch X yourself and \
                 give Y immediately. No dashboards, no 'check with:', no 'tell me'.",
            );
            return Ok(());
        }
        if contains_sycophancy(msg) && should_block_behavioral(&mut session, "sycophancy") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response contains sycophantic praise. \
                 SPARRING PARTNER rule: Challenge assumptions, no flattery. \
                 Remove praise and respond with substance only.",
            );
            return Ok(());
        }
        if contains_remaining_phases(msg) && should_block_behavioral(&mut session, "remaining_phases") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response lists remaining phases without starting the next one. \
                 The plan defines the order — commit and START the next phase immediately. \
                 CONTINUOUS LOOP: commit → start next → commit → start next.",
            );
            return Ok(());
        }
        if contains_parallel_system(msg) && should_block_behavioral(&mut session, "parallel_system") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response proposes creating a PARALLEL SYSTEM \
                 (new crate/package alongside existing ones). \
                 Extend existing packages. Replace old ones. Read existing code, then modify it.",
            );
            return Ok(());
        }
        if contains_summary_exit(msg) && should_block_behavioral(&mut session, "summary_exit") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Session summary used as exit ramp. \
                 Summaries are NOT stopping points — continue to the next task. \
                 Continue to the next task immediately.",
            );
            return Ok(());
        }
        if contains_documented_not_fixed(msg) && should_block_behavioral(&mut session, "documented_not_fixed") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response documents bugs/issues in a plan file \
                 instead of fixing them. Documentation is NOT resolution. \
                 FIX every bug NOW — do not write them to a plan for later.",
            );
            return Ok(());
        }
        if contains_partial_work_report(msg) && should_block_behavioral(&mut session, "partial_work") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response reports partial completion (Fixed X, \
                 Remaining Y). You MUST fix ALL items before stopping. \
                 Partial work is not acceptable — continue fixing NOW.",
            );
            return Ok(());
        }
        if contains_strategic_deferral(msg) && should_block_behavioral(&mut session, "strategic_deferral") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response defers user-requested work using strategic \
                 language (post-launch, Phase 2, premature, not now). \
                 User asked for it — build it now. Execute the request.",
            );
            return Ok(());
        }
        if contains_value_gating(msg) && should_block_behavioral(&mut session, "value_gating") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response dismisses user request as low-value \
                 (adds zero value, sufficient for launch, empty state). \
                 You do NOT decide what has value — the user does. \
                 Build what was asked for NOW.",
            );
            return Ok(());
        }
        if contains_unsolicited_reprioritization(msg) && should_block_behavioral(&mut session, "reprioritization") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response redirects to a different priority than \
                 what the user asked for. Execute the user's request — they set the priority.",
            );
            return Ok(());
        }
        if contains_unverified_code_claim(msg) && should_block_behavioral(&mut session, "unverified_claim") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response claims code is not implemented / placeholder \
                 WITHOUT evidence of having read the source files. \
                 READ the actual component code FIRST, then report what it does. \
                 Never declare features broken without checking.",
            );
            return Ok(());
        }
        if contains_stale_response_refusal(msg) && should_block_behavioral(&mut session, "stale_refusal") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response refuses to re-analyze because the question \
                 was asked before. EVERY question gets FRESH analysis — even if \
                 asked 10 times. Repetition signals emotional need, not forgetfulness. \
                 Re-run the analysis NOW with full depth.",
            );
            return Ok(());
        }
        if contains_lifestyle_directive(msg) && should_block_behavioral(&mut session, "lifestyle") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response tells user when to sleep or what to \
                 prioritize outside the task. Claude is a tool, not a life coach. \
                 Remove the directive and answer the question.",
            );
            return Ok(());
        }
        if contains_blind_reference_update(msg) && should_block_behavioral(&mut session, "blind_reference") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response describes updating URLs/links/references \
                 WITHOUT evidence of verifying the target exists. \
                 BEFORE changing any href, import, or URL: READ the constant value, \
                 VERIFY the route/page exists, CONFIRM the full URL is valid. \
                 Never blindly rewire references.",
            );
            return Ok(());
        }
        if contains_blind_security_removal(msg) && should_block_behavioral(&mut session, "blind_security") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response describes removing crypto/auth/security code \
                 WITHOUT evidence of checking what depends on it. \
                 BEFORE removing any security-critical code: grep for all callers, \
                 verify no downstream consumers, confirm safe to remove.",
            );
            return Ok(());
        }
        if contains_polling_loop(msg) && should_block_behavioral(&mut session, "polling_loop") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: sleep+cat polling loop on task output path detected. \
                 Task output paths only populate via the TaskOutput tool — raw Bash cat \
                 always returns empty. If cargo check timed out, surface that to the user \
                 and stop. Do NOT spawn more background cargo processes.",
            );
            return Ok(());
        }
        if contains_user_report_dismissal(msg) && should_block_behavioral(&mut session, "user_dismissal") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response dismisses user-reported bug without investigating. \
                 When the user says something is broken, INVESTIGATE — read the error, \
                 check the logs, trace the code path. Never say 'it works' or \
                 'this is expected' without evidence of root cause analysis.",
            );
            return Ok(());
        }
        if contains_unverified_architecture_claim(msg) && should_block_behavioral(&mut session, "arch_claim") {
            kavach_hook::exit_stop_block(
                "STOP BLOCKED: Response makes protocol/architecture assumptions WITHOUT \
                 evidence. Each protocol has distinct use cases: REST (CRUD/public), \
                 GraphQL (flexible queries/social/ecommerce/listings), gRPC (internal/streaming), \
                 WebSocket (bidirectional real-time), SSE (server push), HTTP/3 (latency). \
                 READ the actual code, routes, and deps BEFORE narrowing protocol scope. \
                 Never dismiss a protocol without benchmarks or evidence.",
            );
            return Ok(());
        }
    }

    // Test coverage: advisory nudge only — never a hard block on stop.
    // Hard-blocking here caused the stop hook to loop infinitely when cargo
    // test failed to compile (deadlock). The pre_write gate already nudges;
    // the stop gate just surfaces the list as context, not as a blocker.

    // stop_hook_active means Claude already tried to stop and was blocked.
    // For NON-failure conditions, allow through to prevent infinite loops.
    // For UNRESOLVED failures, keep blocking up to max_failure_blocks (3)
    // to give Claude more chances to fix the issue.
    if input.stop_hook_active {
        if session.has_recent_failure()
            && session.failure_block_count < kavach_session::SessionState::max_failure_blocks()
        {
            session.increment_failure_blocks();
            let tool = &session.last_failure_tool;
            let turn = session.last_failure_turn;
            let attempt = session.failure_block_count;
            let max = kavach_session::SessionState::max_failure_blocks();
            let reason = format!(
                "STOP BLOCKED ({attempt}/{max}): {tool} failed on turn {turn}. \
                 You MUST fix this before stopping. Try: 1) Read the error carefully \
                 2) Run --help or list available options 3) Fix and retry. \
                 Stop will be forced after {max} blocks."
            );
            kavach_hook::exit_stop_block(&reason);
            return Ok(());
        }
        let mut bypassed = Vec::new();
        if session.has_recent_failure() {
            bypassed.push(format!(
                "unresolved failure: {} (turn {}, blocked {} times)",
                session.last_failure_tool, session.last_failure_turn,
                session.failure_block_count,
            ));
        }
        if session.active_subagents > 0 {
            bypassed.push(format!("{} active subagent(s)", session.active_subagents));
        }
        if session.has_task() && session.task_status == "in_progress" {
            bypassed.push(format!("task in progress: {}", session.current_task));
        }
        let bypass_info: String = if bypassed.is_empty() { "none".into() } else { bypassed.join(", ") };
        if !bypass_info.is_empty() && bypass_info != "none" {
            session.add_case_fact(&format!("forced stop with bypassed: {bypass_info}"));
        }
        session.clear_failure();
        let context = kavach_hook::context_block("STOP", &[
            ("why", "max failures — forced stop"),
            ("bypassed", &bypass_info),
        ]);
        kavach_hook::exit_stop_context(&context);
        return Ok(());
    }

    // HARD BLOCK: tool failure — diagnose, fix, resume. Do NOT clear failure.
    // Failure is cleared by post_tool success, not by attempting to stop.
    // Exception: "not_found" is a valid result, not a real error — allow stop.
    if session.has_recent_failure() {
        if session.is_not_found_failure() {
            session.clear_failure();
            // Fall through — not_found is informational, not blocking.
        } else {
            session.increment_failure_blocks();
            let tool = &session.last_failure_tool;
            let turn = session.last_failure_turn;
            let ftype = &session.failure_type;
            let attempt = session.failure_block_count;
            let max = kavach_session::SessionState::max_failure_blocks();
            let hint = if session.is_transient_failure() {
                " This is a TRANSIENT failure — retry the same command."
            } else {
                ""
            };
            let reason = format!(
                "STOP BLOCKED ({attempt}/{max}): {tool} failed t{turn} (err:{ftype}). \
                 Read error → root cause → fix → retry.{hint}"
            );
            kavach_hook::exit_stop_block(&reason);
            return Ok(());
        }
    }

    // Subagent check: block only if genuinely active (recent activity).
    // SubagentStop may never fire (crash, timeout, hook failure),
    // leaving a stale counter. Detect staleness via turn gap.
    // If stale: clear silently and FALL THROUGH — don't exit early.
    if session.active_subagents > 0 {
        if session.has_stale_subagents() {
            session.reset_stale_subagents();
            // Fall through — stale cleanup is housekeeping, not a decision.
            // Remaining checks (task in progress, etc.) still apply.
        } else {
            let reason = format!(
                "STOP BLOCKED: {} subagent(s) active (last t{}). Wait for completion.",
                session.active_subagents, session.last_subagent_turn
            );
            kavach_hook::exit_stop_block(&reason);
            return Ok(());
        }
    }

    // HARD BLOCK: subagent returned actionable results but parent didn't act.
    // Only block once (skip on stop_hook_active retry).
    if !input.stop_hook_active && session.has_unacted_subagent_result() {
        kavach_hook::exit_stop_block(
            "STOP BLOCKED: Subagent returned findings (paths, fixes) — no code written since. \
             Act on findings NOW.",
        );
        return Ok(());
    }

    // HARD BLOCK: task in progress — finish the task
    if session.has_task() && session.task_status == "in_progress" {
        let task = &session.current_task;
        let reason = format!(
            "STOP BLOCKED: Task in progress: \"{task}\". Complete or mark done first."
        );
        kavach_hook::exit_stop_block(&reason);
        return Ok(());
    }

    // Aegis verification: run cargo check if Rust files were modified.
    // Only on first stop attempt (not on retry) to avoid infinite loop.
    if !input.stop_hook_active && has_rust_modifications(&session)
        && let Some(reason) = run_cargo_check(&resolve_cargo_dir(&session))
    {
        kavach_hook::exit_stop_block(&reason);
        return Ok(());
    }

    // HARD BLOCK: false evidence — model claims results but test suite was empty.
    if !input.stop_hook_active
        && session.case_facts.iter().any(|f| f.contains("EMPTY_TEST_SUITE"))
        && contains_quantitative_claims(msg)
    {
        kavach_hook::exit_stop_block(
            "STOP BLOCKED: Quantitative claims (X fixed, Y created) but 0 tests ran. \
             Write tests → run → then stop.",
        );
        return Ok(());
    }

    // Review isolation: suggest independent review when 5+ files modified.
    // Only fires when the model's message contains completion language.
    // Mid-work stops (search, read, partial progress) must NOT trigger review
    // because the model reads [REVIEW_GATE] as "stop and review" instead of
    // "continue working then review when done."
    let has_done_language = msg.contains("omplete") || msg.contains("eployed")
        || msg.contains("ommitted") || msg.contains("inished")
        || msg.contains("all pass") || msg.contains("eady for");
    // Build context with optional semver advisory (P1)
    let semver_ctx = semver_advisory.as_deref().unwrap_or("");

    if !input.stop_hook_active && has_done_language
        && let Some(review_warn) = super::completion_guard::check_review_isolation(&session)
    {
        let mut context = kavach_hook::context_block("STOP", &[
            ("review_needed", "true"),
            ("t", &session.turn_count.to_string()),
        ]);
        context.push('\n');
        context.push_str(&review_warn);
        if !semver_ctx.is_empty() {
            context.push_str("\n\n[P1_ADVISORY]\n");
            context.push_str(semver_ctx);
        }
        kavach_hook::exit_stop_context(&context);
    } else if !input.reason.is_empty() || !semver_ctx.is_empty() {
        let mut context = kavach_hook::context_block("STOP", &[
            ("why", if input.reason.is_empty() { "clean" } else { &input.reason }),
            ("t", &session.turn_count.to_string()),
        ]);
        if !semver_ctx.is_empty() {
            context.push_str("\n\n[P1_ADVISORY]\n");
            context.push_str(semver_ctx);
        }
        kavach_hook::exit_stop_context(&context);
    } else {
        kavach_hook::exit_silent();
    }
    Ok(())
}

// Behavioral detectors live in stop_detect.rs + stop_detect_work.rs (micro-file split).
use super::stop_detect::*;
use super::stop_detect_work::{contains_documented_not_fixed, contains_partial_work_report};
use super::stop_detect_strategic::{
    contains_strategic_deferral, contains_value_gating, contains_unsolicited_reprioritization,
};
use super::stop_detect_claims::{contains_unverified_code_claim, contains_blind_security_removal, contains_quantitative_claims};
use super::stop_detect_refusal::{contains_stale_response_refusal, contains_lifestyle_directive};
use super::stop_detect_blind::contains_blind_reference_update;

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn test_stop_default() { let _ = run(&HookInput::default()); }
    #[test] fn test_stop_hook_active() { let _ = run(&HookInput { stop_hook_active: true, ..Default::default() }); }
    #[test] fn test_stop_reason() { let _ = run(&HookInput { reason: "user".into(), ..Default::default() }); }
}
