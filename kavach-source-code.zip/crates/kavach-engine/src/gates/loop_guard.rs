//! Detect repeated/looping tool calls that waste tokens.
//!
//! Tracks recent bash commands in session state. Blocks if the same
//! command (or near-duplicate) is executed 3+ times within a sliding
//! window of WINDOW_TURNS turns.
//!
//! Storage format: `"<turn>:<command>"` — turn prefix encoded inline in
//! the existing Vec<String> field so serialization is unchanged.
//! Legacy entries without a turn prefix are assigned turn 0 and fall
//! outside the window after WINDOW_TURNS turns pass.
//! Sliding window scan is O(HISTORY_SIZE) = O(20), bounded constant.

use kavach_session::SessionState;

const MAX_REPEATS: usize = 3;
const HISTORY_SIZE: usize = 20;
/// Only count repeats within the last N turns (sliding window).
const WINDOW_TURNS: i32 = 10;

/// Check if a bash command is being repeated too many times within the
/// sliding window. Returns Some(block_reason) if loop detected.
pub fn check_bash_loop(session: &SessionState, command: &str) -> Option<String> {
    let normalized = normalize_command(command);
    let window_start = session.turn_count.saturating_sub(WINDOW_TURNS);

    let count = session
        .recent_commands
        .iter()
        .filter(|entry| {
            let (turn, cmd) = parse_entry(entry);
            turn >= window_start && normalize_command(cmd) == normalized
        })
        .count();

    if count >= MAX_REPEATS {
        return Some(format!(
            "[LOOP_DETECTED]\n\
             Command executed {count}x in last {WINDOW_TURNS} turns: `{}`\n\
             BLOCKED: Repeating the same command won't produce different results.\n\
             FIX: 1) Diagnose WHY it fails, don't just retry.\n\
             2) Try a different approach or tool.\n\
             3) Use /clear if context is polluted with failed attempts.",
            truncate(command, 80)
        ));
    }
    None
}

/// Record a command in the session's recent history as `"<turn>:<command>"`.
/// Bounded ring: evicts the oldest entry when HISTORY_SIZE is exceeded.
/// Uses swap_remove-then-rotate to avoid O(N) shifting — amortized O(1).
pub fn record_command(session: &mut SessionState, command: &str) {
    let entry = format!("{}:{}", session.turn_count, command);
    session.recent_commands.push(entry);
    if session.recent_commands.len() > HISTORY_SIZE {
        // Remove index 0 without shifting: swap with last, pop, then rotate
        // so the oldest entry leaves and insertion order is preserved.
        // Vec::remove(0) is O(N); this is O(1) amortized.
        session.recent_commands.rotate_left(1);
        session.recent_commands.pop();
    }
}

/// Parse a history entry into (turn, command_str).
/// Format: `"<turn>:<command>"`. Legacy bare entries (no colon-prefixed
/// integer) are returned as turn 0 so they age out of the window naturally.
fn parse_entry(entry: &str) -> (i32, &str) {
    if let Some(colon) = entry.find(':') {
        if let Ok(turn) = entry[..colon].parse::<i32>() {
            return (turn, &entry[colon + 1..]);
        }
    }
    (0, entry)
}

/// Normalize command for comparison: trim, collapse whitespace, strip timestamps.
fn normalize_command(cmd: &str) -> String {
    cmd.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn truncate(s: &str, max: usize) -> &str {
    if s.len() <= max { s } else { &s[..max] }
}

#[cfg(test)]
mod tests {
    use super::*;
    use kavach_session::SessionState;

    fn make_session(turn: i32) -> SessionState {
        let mut s = SessionState::default();
        s.turn_count = turn;
        s
    }

    #[test]
    fn normalize_whitespace() {
        assert_eq!(normalize_command("cargo  build  --release"), "cargo build --release");
    }

    #[test]
    fn truncate_short() {
        assert_eq!(truncate("hello", 10), "hello");
    }

    #[test]
    fn truncate_long() {
        assert_eq!(truncate("hello world", 5), "hello");
    }

    #[test]
    fn parse_entry_with_turn() {
        assert_eq!(parse_entry("5:cargo check"), (5, "cargo check"));
    }

    #[test]
    fn parse_entry_legacy_no_turn() {
        assert_eq!(parse_entry("cargo check"), (0, "cargo check"));
    }

    #[test]
    fn no_block_before_threshold() {
        let mut session = make_session(5);
        record_command(&mut session, "cargo check");
        record_command(&mut session, "cargo check");
        assert!(check_bash_loop(&session, "cargo check").is_none());
    }

    #[test]
    fn blocks_at_threshold_within_window() {
        let mut session = make_session(5);
        record_command(&mut session, "cargo check");
        record_command(&mut session, "cargo check");
        record_command(&mut session, "cargo check");
        assert!(check_bash_loop(&session, "cargo check").is_some());
    }

    #[test]
    fn no_block_when_old_entries_outside_window() {
        let mut session = make_session(1);
        // Record 2 commands at turn 1
        record_command(&mut session, "cargo check");
        record_command(&mut session, "cargo check");
        // Advance turn beyond window
        session.turn_count = 1 + WINDOW_TURNS + 1;
        // Only 2 old entries exist, both outside window — no block even if we add 1 more
        record_command(&mut session, "cargo check");
        // Only 1 entry inside the window → no block
        assert!(check_bash_loop(&session, "cargo check").is_none());
    }

    #[test]
    fn record_command_bounds_history() {
        let mut session = make_session(0);
        for i in 0..HISTORY_SIZE + 5 {
            session.turn_count = i as i32;
            record_command(&mut session, &format!("cmd{i}"));
        }
        assert!(session.recent_commands.len() <= HISTORY_SIZE);
    }
}
