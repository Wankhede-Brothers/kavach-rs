//! PreCompact gate — injects custom instructions context before compaction.

use kavach_types::HookInput;

use crate::error::EngineError;

pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let ci = &input.custom_instructions;
    if !ci.is_empty() {
        let context = kavach_hook::context_block(
            "PRE_COMPACT",
            &[("custom_instructions", ci), ("date", &kavach_hook::today())],
        );
        kavach_hook::exit_notification_context(&context);
    } else {
        kavach_hook::exit_silent();
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_instructions_is_silent() {
        let input = HookInput::default();
        assert!(run(&input).is_ok());
    }
}
