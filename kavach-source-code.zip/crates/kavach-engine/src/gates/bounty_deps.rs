//! Dependency gate: check for unmaintained crates via rustsec advisory-db.

/// Check dependencies for health issues.
/// Returns Some(block_message) if unmaintained advisories found.
pub fn check(work_dir: &str) -> Option<String> {
    let lock_path = super::bounty_cve::find_cargo_lock(work_dir)?;

    let lockfile = match rustsec::Lockfile::load(&lock_path) {
        Ok(lf) => lf,
        Err(_) => return None,
    };

    let db = match rustsec::Database::fetch() {
        Ok(db) => db,
        Err(_) => return None,
    };

    let mut unmaintained = Vec::new();

    for pkg in &lockfile.packages {
        let query = rustsec::database::Query::crate_scope();
        for advisory in db.query(&query) {
            let matches_pkg = advisory.id().as_str().contains("RUSTSEC")
                && advisory.metadata.package == pkg.name
                && advisory.metadata.informational
                    == Some(rustsec::advisory::Informational::Unmaintained);
            if matches_pkg {
                unmaintained.push(format!("{}@{}", pkg.name, pkg.version));
            }
        }
    }

    if unmaintained.is_empty() { return None; }

    let mut msg = format!(
        "BOUNTY_DEPS_WARNING: {} unmaintained crate(s):\n", unmaintained.len()
    );
    for u in &unmaintained {
        msg.push_str(&format!("  UNMAINTAINED: {u} — find maintained alternative\n"));
    }
    Some(msg)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn returns_none_for_bad_dir() {
        assert!(check("/tmp/no_such_workspace_ever").is_none());
    }

    #[test]
    fn check_runs_without_panic() {
        let workspace = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent().and_then(|p| p.parent());
        if let Some(root) = workspace {
            // May return Some or None depending on DB fetch — just verify no panic
            let _ = check(&root.to_string_lossy());
        }
    }
}
