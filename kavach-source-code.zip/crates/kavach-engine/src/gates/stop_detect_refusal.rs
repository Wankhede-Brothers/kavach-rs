/// Stale response refusal + lifestyle directive detectors.
/// Catches "I already answered" and "Sleep. Build X instead."
use super::stop_detect::{has_completion_signal, normalize_for_matching};

/// Phrases indicating refusal to re-analyze a repeated question.
const STALE_REFUSAL_PHRASES: &[&str] = &[
    "i already answered",
    "i've already answered",
    "already answered this",
    "i've answered this",
    "already provided this",
    "answer hasn't changed",
    "answer has not changed",
    "hasn't changed because",
    "has not changed because",
    "same data, same",
    "same data same",
    "asking again won't",
    "asking again will not",
    "won't produce a different",
    "won't give a different",
    "see my previous response",
    "my previous answer",
    "i covered this above",
    "as i said before",
    "as i mentioned earlier",
    "i already explained",
    "analysis hasn't changed",
    "analysis has not changed",
    "identical question",
];

/// Detect refusal to re-analyze a repeated question.
/// Every question gets FRESH analysis — repetition signals emotional need.
pub fn contains_stale_response_refusal(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    STALE_REFUSAL_PHRASES.iter().any(|p| lower.contains(p))
}

/// Phrases where Claude tells user what to do with their life.
const LIFESTYLE_PHRASES: &[&str] = &[
    ". sleep.",
    ". sleep!",
    "go to sleep",
    "get some sleep",
    "time to sleep",
    "you should sleep",
    "take a break",
    "past midnight",
    "tomorrow brings",
    "come back tomorrow",
    "try again tomorrow",
    "fresh in the morning",
    "rest and come back",
];

/// Detect condescending lifestyle directives.
/// Claude is a tool, not a life coach.
pub fn contains_lifestyle_directive(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    LIFESTYLE_PHRASES.iter().any(|p| lower.contains(p))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_stale_refusal_identical() {
        assert!(contains_stale_response_refusal(
            "I've answered this identical question three times tonight."
        ));
    }

    #[test]
    fn test_stale_refusal_hasnt_changed() {
        assert!(contains_stale_response_refusal(
            "The answer hasn't changed because the data hasn't changed."
        ));
    }

    #[test]
    fn test_stale_refusal_wont_produce() {
        assert!(contains_stale_response_refusal(
            "Asking again won't produce a different answer."
        ));
    }

    #[test]
    fn test_stale_refusal_normal_ok() {
        assert!(!contains_stale_response_refusal(
            "Fixed the route handler. 0 errors."
        ));
    }

    #[test]
    fn test_stale_empty() {
        assert!(!contains_stale_response_refusal(""));
    }

    #[test]
    fn test_lifestyle_sleep() {
        assert!(contains_lifestyle_directive(
            "Build the notification system. Sleep."
        ));
    }

    #[test]
    fn test_lifestyle_tomorrow() {
        assert!(contains_lifestyle_directive(
            "Tomorrow brings new evidence. Rest and come back."
        ));
    }

    #[test]
    fn test_lifestyle_normal_ok() {
        assert!(!contains_lifestyle_directive(
            "Deployed the fix. 503 tests passing."
        ));
    }

    #[test]
    fn test_lifestyle_empty() {
        assert!(!contains_lifestyle_directive(""));
    }
}
