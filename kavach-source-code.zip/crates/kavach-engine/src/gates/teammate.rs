use kavach_types::HookInput;

use crate::error::EngineError;

/// Handle TeammateIdle event — enforce quality gates before teammate stops.
/// Per CC 2.1: "Use this to enforce quality gates before a teammate stops working."
pub fn run_idle(input: &HookInput) -> Result<(), EngineError> {
    let teammate_name = &input.teammate_name;
    let mut session = kavach_session::get_or_create_session();

    // Track teammate going idle
    session.track_teammate_stop(teammate_name);

    // Quality gate: block idle if recent failure — force fix before stopping
    if session.has_recent_failure() {
        let tool = session.last_failure_tool.clone();
        let reason = format!(
            "IDLE BLOCKED: {tool} failed. {teammate_name} fix before idle."
        );
        kavach_hook::exit_stop_block(&reason);
        return Ok(());
    }

    let context = kavach_hook::context_block(
        "TEAMMATE_IDLE",
        &[
            ("teammate", teammate_name),
        ],
    );
    kavach_hook::exit_notification_context(&context);
    Ok(())
}

/// Handle TaskCompleted event — enforce completion criteria, track task details.
/// Per CC 2.1: "Use this to enforce completion criteria before a task can close."
pub fn run_task_completed(input: &HookInput) -> Result<(), EngineError> {
    let task_id = &input.task_id;
    let task_subject = &input.task_subject;

    let mut session = kavach_session::get_or_create_session();
    session.tasks_completed += 1;
    if !task_subject.is_empty() {
        session.set_task(task_subject, "completed");
    }
    let _ = session.save();

    let completed_str = session.tasks_completed.to_string();
    let context = kavach_hook::context_block(
        "TASK_COMPLETED",
        &[
            ("id", task_id),
            ("subject", task_subject),
            ("n", &completed_str),
        ],
    );
    kavach_hook::exit_notification_context(&context);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_run_idle() {
        let input = HookInput {
            teammate_name: "researcher".into(),
            ..Default::default()
        };
        assert!(run_idle(&input).is_ok());
    }

    #[test]
    fn test_task_completed_with_subject() {
        let input = HookInput {
            task_id: "task-123".into(),
            task_subject: "implement auth".into(),
            ..Default::default()
        };
        assert!(run_task_completed(&input).is_ok());
    }
}
