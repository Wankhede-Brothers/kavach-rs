/// Work-completion detectors for the stop gate.
/// Catches "documented not fixed" and "partial work report" anti-patterns.
/// Ref: AgentSpec (ICSE '26) — runtime enforcement with triggers + predicates.
use super::stop_detect::{has_completion_signal, normalize_for_matching};

/// Detect when bugs/issues are documented in a plan file instead of being fixed.
/// Pattern: "documented in", "recorded in", "tracked in" + plan/file reference.
/// Override: "and fixed", "and resolved" — if both documented AND fixed, allow.
pub fn contains_documented_not_fixed(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let doc_patterns = [
        "documented in", "recorded in", "tracked in", "noted in",
        "written to", "logged in", "saved to", "captured in",
        "listed in", "added to the plan", "added to plan",
    ];
    let has_doc_ref = doc_patterns.iter().any(|p| lower.contains(p))
        && (lower.contains("plan") || lower.contains(".md")
            || lower.contains("next session") || lower.contains("later"));
    if !has_doc_ref { return false; }
    let also_fixed = lower.contains("and fixed") || lower.contains("and resolved")
        || lower.contains("all fixed") || lower.contains("all resolved")
        || lower.contains("all bugs fixed");
    // Override: external/upstream issues outside our codebase
    let is_external = lower.contains("outside kavach") || lower.contains("outside our")
        || lower.contains("platform bug") || lower.contains("platform issue")
        || lower.contains("platform limitation") || lower.contains("upstream bug")
        || lower.contains("upstream issue") || lower.contains("claude code platform")
        || lower.contains("github.com/anthropics") || lower.contains("already addressed")
        || lower.contains("already covered") || lower.contains("already enforced");
    !also_fixed && !is_external
}

/// Detect partial-completion reports: "Fixed 5/20", remaining bugs tables,
/// "N of M" patterns where the response explicitly acknowledges incomplete work.
pub fn contains_partial_work_report(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }
    let has_remaining_work = (lower.contains("remaining bug")
        || lower.contains("remaining issue")
        || lower.contains("remaining fix")
        || lower.contains("bugs remaining")
        || lower.contains("issues remaining")
        || lower.contains("still need fixing")
        || lower.contains("still needs fixing")
        || lower.contains("bugs that still"))
        && !lower.contains("0 remaining")
        && !lower.contains("no remaining")
        && !lower.contains("zero remaining");
    let has_partial_table = lower.contains("fixed") && lower.contains("remaining")
        && (lower.contains("bug-") || lower.contains("| remaining"));
    let has_session_count = ["bugs fixed this session", "fixed this session:",
        "fixes this session"]
        .iter().any(|p| lower.contains(p));
    let has_partial_count = has_session_count
        && (lower.contains("remaining") || lower.contains("still need"));
    has_remaining_work || has_partial_table || has_partial_count
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_documented_plan_for_next_session() {
        assert!(contains_documented_not_fixed(
            "The remaining bugs are documented in .claude/plans/bright-chasing-badger.md for the next session."
        ));
    }

    #[test]
    fn test_documented_in_plan_file() {
        assert!(contains_documented_not_fixed(
            "Remaining issues documented in the plan file for later review."
        ));
    }

    #[test]
    fn test_tracked_in_plan() {
        assert!(contains_documented_not_fixed(
            "BUG-007 tracked in .claude/plans/bugs.md for the next session."
        ));
    }

    #[test]
    fn test_documented_and_fixed_ok() {
        assert!(!contains_documented_not_fixed(
            "All bugs documented in the plan and fixed in this session."
        ));
    }

    #[test]
    fn test_documented_all_resolved_ok() {
        assert!(!contains_documented_not_fixed(
            "Issues noted in plan and resolved. All bugs fixed."
        ));
    }

    #[test]
    fn test_documented_no_plan_ref_ok() {
        assert!(!contains_documented_not_fixed(
            "I documented the API changes in the response above."
        ));
    }

    #[test]
    fn test_documented_empty() {
        assert!(!contains_documented_not_fixed(""));
    }

    #[test]
    fn test_documented_external_issue_ok() {
        assert!(!contains_documented_not_fixed(
            "This is a Claude Code platform bug tracked in github.com/anthropics/claude-code. Outside our codebase."
        ));
        assert!(!contains_documented_not_fixed(
            "Upstream issue logged in .md file. Platform limitation — kavach can't fix this."
        ));
    }

    #[test]
    fn test_documented_already_addressed_ok() {
        assert!(!contains_documented_not_fixed(
            "Already addressed by our earlier commits. Noted in plan."
        ));
    }

    #[test]
    fn test_documented_completion_override() {
        assert!(!contains_documented_not_fixed(
            "All done. Documented in plan. All phases complete."
        ));
    }

    #[test]
    fn test_partial_remaining_bugs() {
        assert!(contains_partial_work_report(
            "Fixed BUG-003 and BUG-004. Remaining bugs: BUG-001, BUG-007, BUG-010."
        ));
    }

    #[test]
    fn test_partial_table_format() {
        assert!(contains_partial_work_report(
            "Fixed | Remaining\nBUG-002 (rate limiter) | BUG-006 (REST/SSE divergence)"
        ));
    }

    #[test]
    fn test_partial_bugs_fixed_this_session() {
        assert!(contains_partial_work_report(
            "Bugs fixed this session: 17 total\nFixed: BUG-002\nRemaining: BUG-001"
        ));
    }

    #[test]
    fn test_partial_still_need_fixing() {
        assert!(contains_partial_work_report(
            "BUG-001 and BUG-010 still need fixing in a future session."
        ));
    }

    #[test]
    fn test_partial_zero_remaining_ok() {
        assert!(!contains_partial_work_report("All bugs fixed. 0 remaining issues."));
    }

    #[test]
    fn test_partial_no_remaining_ok() {
        assert!(!contains_partial_work_report("Fixed all issues. No remaining bugs."));
    }

    #[test]
    fn test_partial_completion_override() {
        assert!(!contains_partial_work_report(
            "All done. All phases complete. Remaining: none."
        ));
    }

    #[test]
    fn test_partial_empty() {
        assert!(!contains_partial_work_report(""));
    }

    #[test]
    fn test_exact_transcript_pattern() {
        let msg = "Bugs fixed this session: 17 total\n\
            Fixed: BUG-002 (rate limiter), BUG-003 (commission error propagation)\n\
            Remaining: BUG-001 full (wrap in transaction), BUG-006 (REST/SSE divergence)";
        assert!(contains_partial_work_report(msg));
    }
}
