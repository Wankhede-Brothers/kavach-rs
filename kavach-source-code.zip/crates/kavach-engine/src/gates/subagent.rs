use kavach_types::HookInput;

use crate::error::EngineError;

/// SubagentStart gate: track agent lifecycle, inject budget context.
pub fn run_start(input: &HookInput) -> Result<(), EngineError> {
    let agent_id = &input.agent_id;
    let agent_type = &input.agent_type;

    let mut session = kavach_session::get_or_create_session();
    session.track_subagent_start(agent_id);

    // Build budget context for the subagent
    let limits = kavach_config::load_output_limits();
    let effective_limit = session.get_effective_output_limit(
        agent_type,
        &limits
            .agent_limits
            .iter()
            .map(|(k, v)| (k.clone(), *v as i32))
            .collect(),
    );

    let limit_str = effective_limit.to_string();
    let active_str = session.active_subagents.to_string();
    let phase = session.context_phase.clone();
    let mut context = kavach_hook::context_block(
        "SUBAGENT_START",
        &[
            ("id", agent_id),
            ("type", agent_type),
            ("limit", &limit_str),
            ("active", &active_str),
            ("phase", &phase),
        ],
    );

    let modules = kavach_config::load_modules(&["agents", "model-routing"]);
    if !modules.is_empty() {
        context.push_str("\n[MODULE:LAZY_LOADED]\n");
        context.push_str(&modules);
    }

    kavach_hook::exit_subagent_start(&context);
    Ok(())
}

/// SubagentStop gate: record output size, update tracking.
pub fn run_stop(input: &HookInput) -> Result<(), EngineError> {
    let agent_id = &input.agent_id;

    let mut session = kavach_session::get_or_create_session();

    // Estimate output size from tool response
    let output_size = input
        .tool_response
        .as_ref()
        .map(|r| serde_json::to_string(r).unwrap_or_default().len() as i32)
        .unwrap_or(0);

    session.track_subagent_stop(agent_id, output_size);

    let size_str = output_size.to_string();
    let active_str = session.active_subagents.to_string();
    let context = kavach_hook::context_block(
        "SUBAGENT_STOP",
        &[
            ("id", agent_id),
            ("chars", &size_str),
            ("agents", &active_str),
        ],
    );

    kavach_hook::exit_subagent_stop(&context);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_run_start_default() {
        let input = HookInput {
            agent_id: "test-agent".into(),
            agent_type: "Explore".into(),
            ..Default::default()
        };
        // Should succeed
        let _ = run_start(&input);
    }
}
