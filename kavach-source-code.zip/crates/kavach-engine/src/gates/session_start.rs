use kavach_types::HookInput;

use crate::error::EngineError;

/// SessionStart gate: detect model ID, set token budget, init session.
/// Claude Code sends `model` field in SessionStart hook input.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let mut session = kavach_session::get_or_create_session();

    // Detect model from hook input (CC 2.1 sends model field)
    let model = &input.model;
    if !model.is_empty() {
        session.set_model(model);
    } else if let Ok(env_model) = std::env::var("CLAUDE_MODEL")
        && !env_model.is_empty()
    {
        session.set_model(&env_model);
    }

    // Reset stale subagent tracking from prior sessions.
    // SubagentStop may never fire (crash, timeout, abrupt end),
    // leaving active_subagents > 0 and blocking the Stop gate.
    // See: github.com/anthropics/claude-code/issues/7881
    session.active_subagents = 0;
    session.subagent_outputs.clear();
    session.active_teammates = 0;

    // Clear stale test locks from prior sessions or timed-out background tasks.
    // Background tasks that complete via notification bypass PostToolUse:Bash,
    // so clear_test_run never fires. Fresh session = no tests running.
    session.active_test_crates.clear();

    // Reset context phase on fresh session start
    session.update_context_phase();

    build_skill_registry();
    refresh_all_rag_trees();
    rebuild_bloom_cache(&session.project);

    let cfg = kavach_config::ModelConfig::from_model_id(&session.model_id);
    let mut context = format!(
        "[SESSION_START]\nmodel: {}\ncontext_window: {}\nusable_budget: {}\nphase: {}\n",
        session.model_id, cfg.context_window, cfg.usable_budget, session.context_phase,
    );

    // Auto memory query: inject project context from kavach-db
    if !session.project.is_empty()
        && let Some(mem_ctx) = auto_query_memory(&session.project)
    {
        context.push_str(&mem_ctx);
        session.memory_queried = true;
    }

    let module_ctx = session.inject_modules_once(&["critical-rules", "date"]);
    context.push_str(&module_ctx);

    // Inject hot autonomous patterns so Claude sees cached fixes immediately.
    if let Some(hot_ctx) = hot_pattern_context(&session.project) {
        context.push_str(&hot_ctx);
    }

    // [ALGO_EVOLUTION] removed — ~1kB/session token waste.
    // Algo decisions are on-demand: kavach db query --project <slug> --category decision

    super::event_log::log_session(&session.session_id, "session_start", &session.model_id, &session.project);

    kavach_hook::exit_session_start_context(&context);
    Ok(())
}

/// Auto-query kavach-db for project context at session start.
/// Injects titles from child project AND all ancestors (parent inheritance).
/// Injects titles only — no content bodies — saving ~2kB/session.
/// Full content is on-demand: `kavach db get --project <slug> --category <cat> --key <key>`.
fn auto_query_memory(project: &str) -> Option<String> {
    // Resolve ancestry chain: child first, then parent, grandparent, ...
    let ancestry = resolve_ancestry(project);

    let mut all_roadmap = String::new();
    let mut all_decisions = String::new();
    let mut ancestor_slugs: Vec<String> = Vec::new();

    for slug in &ancestry {
        if let Some(r) = query_category_titles(slug, "roadmap") {
            all_roadmap.push_str(&r);
            all_roadmap.push('\n');
        }
        if let Some(d) = query_category_titles(slug, "decision") {
            all_decisions.push_str(&d);
            all_decisions.push('\n');
        }
        ancestor_slugs.push(slug.clone());
    }

    // Keep only the last 5 decision titles.
    let decisions_trimmed = all_decisions
        .lines()
        .rev()
        .take(5)
        .collect::<Vec<_>>()
        .into_iter()
        .rev()
        .collect::<Vec<_>>()
        .join("\n");

    let combined = format!("{all_roadmap}\n{decisions_trimmed}").trim().to_string();
    if combined.is_empty() {
        return None;
    }

    let mut ctx = String::from("\n[MEMORY_BANK]\n");
    ctx.push_str("status: titles-only (use kavach db get for content)\n");
    ctx.push_str(&format!("project: {}\n", ancestor_slugs.join(" → ")));
    ctx.push_str(&combined);
    ctx.push('\n');
    Some(ctx)
}

/// Resolve the full ancestry chain for a project slug.
/// Returns [child_slug, parent_slug, ...] — child first.
/// Falls back to [project] if DB is unavailable or project not found.
fn resolve_ancestry(project: &str) -> Vec<String> {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(_) => return vec![project.to_owned()],
    };
    let proj = match kavach_db::projects::get_by_slug(&conn, project) {
        Ok(p) => p,
        Err(_) => return vec![project.to_owned()],
    };
    match kavach_db::projects::get_ancestry(&conn, proj.id) {
        Ok(chain) => chain.into_iter().map(|p| p.slug).collect(),
        Err(_) => vec![project.to_owned()],
    }
}

/// Query kavach-db titles only via DB API — no content bodies fetched.
/// Uses list_titles_by_project with LIMIT 10 per category.
fn query_category_titles(project: &str, category: &str) -> Option<String> {
    let conn = kavach_db::open_default().ok()?;
    let proj = kavach_db::projects::get_by_slug(&conn, project).ok()?;
    let entries = kavach_db::memory::list_titles_by_project(
        &conn, proj.id, Some(category), 10,
    ).ok()?;
    if entries.is_empty() {
        return None;
    }
    let lines: Vec<String> = entries
        .iter()
        .map(|e| format!("[{}] {} — {}", e.category, e.entry_key, e.title))
        .collect();
    Some(lines.join("\n"))
}

/// Refresh all registered RAG trees on session start. Queries kavach-db
/// for labels with a stored source_dir, then runs `kavach rag refresh-if-stale`
/// for each. Falls back to skills-only if the DB query fails.
/// Failure is silent — the gate must never block session init on RAG maintenance.
fn refresh_all_rag_trees() {
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(_) => {
            refresh_single_tree("skills", &kavach_config::skills_dir());
            return;
        }
    };
    let labels = match kavach_db::rag_trees::list_refreshable(&conn) {
        Ok(rows) => rows,
        Err(_) => {
            refresh_single_tree("skills", &kavach_config::skills_dir());
            return;
        }
    };
    if labels.is_empty() {
        // First run or no labels registered yet — bootstrap with skills
        refresh_single_tree("skills", &kavach_config::skills_dir());
        return;
    }
    for (label, source_dir) in &labels {
        let path = std::path::PathBuf::from(source_dir);
        refresh_single_tree(label, &path);
    }
}

fn refresh_single_tree(label: &str, source_dir: &std::path::Path) {
    let source = match source_dir.to_str() {
        Some(s) => s,
        None => return,
    };
    let _ = std::process::Command::new("kavach")
        .args(["rag", "refresh-if-stale", "--source", source, "--label", label])
        .output();
}

/// Load top autonomous gate patterns for the project and format as context.
/// Injected at session start so Claude immediately knows cached fixes without
/// waiting for a tool failure to trigger the Tier 1 lookup path.
/// Returns None if the DB is unavailable or no autonomous patterns exist.
fn hot_pattern_context(project_slug: &str) -> Option<String> {
    if project_slug.is_empty() {
        return None;
    }
    let conn = kavach_db::open_default().ok()?;
    let proj = kavach_db::projects::get_by_slug(&conn, project_slug).ok()?;
    let patterns = kavach_db::gate_patterns::list_hot(&conn, proj.id, 5).ok()?;
    if patterns.is_empty() {
        return None;
    }
    let mut ctx = String::from("\n[SELF_EVOLVE_PATTERNS]\nstatus: autonomous\n");
    for p in &patterns {
        ctx.push_str(&format!(
            "pattern: {tokens} | fix: {fix} | occurrences: {n}\n",
            tokens = p.error_tokens,
            fix = p.fix_strategy,
            n = p.occurrence_count,
        ));
    }
    Some(ctx)
}

/// Rebuild the mmap'd bloom filter cache for the current project's gate patterns.
/// Failure is silent — bloom cache is a pre-screening optimisation, not a hard dependency.
fn rebuild_bloom_cache(project_slug: &str) {
    if project_slug.is_empty() {
        return;
    }
    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(_) => return,
    };
    let proj = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p,
        Err(_) => return,
    };
    let _ = kavach_db::bloom_cache::build(&conn, proj.id);
}

/// Scan ~/.claude/skills/, build registry, cache if stale.
fn build_skill_registry() {
    let skills_dir = kavach_config::skills_dir();
    let cache_path = kavach_config::registry_cache_path();

    let mut store = kavach_rule_storage::RuleStore::new(skills_dir);
    if store.load_all().is_err() {
        return;
    }

    let rules: Vec<_> = store
        .list()
        .iter()
        .filter_map(|name| store.get(name).cloned())
        .collect();

    let registry = kavach_rule_storage::build_from_rules(&rules);

    if kavach_rule_storage::is_stale(&cache_path, &registry.hash) {
        let _ = kavach_rule_storage::save_registry(&cache_path, &registry);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_session_start_with_model() {
        let input = HookInput {
            model: "claude-opus-4-6".into(),
            ..Default::default()
        };
        assert!(run(&input).is_ok());
    }

    #[test]
    fn test_session_start_empty_model() {
        let input = HookInput::default();
        assert!(run(&input).is_ok());
    }
}
