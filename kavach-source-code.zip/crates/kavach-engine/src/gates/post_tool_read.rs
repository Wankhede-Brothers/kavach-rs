use kavach_types::HookInput;

use crate::error::EngineError;

/// Extract skill name from a local skill SKILL.md path.
/// `~/.claude/skills/testing/SKILL.md` → `Some("testing")`
fn extract_local_skill_name(path: &str) -> Option<&str> {
    // Path form: .../skills/<skill-name>/SKILL.md
    let before_skill_md = path.strip_suffix("/SKILL.md")?;
    let slash = before_skill_md.rfind('/')?;
    let name = &before_skill_md[slash + 1..];
    if name.is_empty() { None } else { Some(name) }
}

/// Handle read done: warn on sensitive files + track duplicates.
pub fn handle(
    input: &HookInput,
    session: &mut kavach_session::SessionState,
) -> Result<(), EngineError> {
    let file_path = input.get_string("file_path");
    let tool_name = &input.tool_name;
    let target = if !file_path.is_empty() {
        file_path
    } else {
        input.get_string("pattern")
    };

    let mut parts: Vec<String> = Vec::new();

    // Check for sensitive file access
    if !file_path.is_empty() && kavach_patterns::is_sensitive(file_path) {
        parts.push(kavach_hook::context_block(
            "POST_TOOL:READ",
            &[
                ("file", file_path),
                ("reason", "sensitive file was read"),
            ],
        ));
    }

    // Track file reads for attention dilution detection
    if tool_name == "Read" {
        session.increment_files_read();
    }

    // Satisfy skill gate when a local skill's SKILL.md is read directly.
    // Local skills (e.g. ~/.claude/skills/testing/SKILL.md) cannot be loaded via
    // the Skill tool — reading their SKILL.md is the only available invocation path.
    if tool_name == "Read" && file_path.contains("/skills/") && file_path.ends_with("SKILL.md") {
        if let Some(skill_name) = extract_local_skill_name(file_path) {
            session.record_skill_invoked(skill_name);
        }
    }

    // Check for attention dilution (12+ files in one pass)
    if let Some(attention_warn) = super::attention_guard::check_attention(session) {
        parts.push(attention_warn);
    }

    // Check for duplicate reads/searches
    if let Some(dup_warn) =
        super::duplicate_tool_guard::check_duplicate_tool(session, tool_name, target)
    {
        parts.push(dup_warn);
    }
    super::duplicate_tool_guard::record_tool_call(session, tool_name, target);

    if parts.is_empty() {
        kavach_hook::exit_silent();
    } else {
        kavach_hook::exit_post_tool_context(&parts.join("\n\n"));
    }

    Ok(())
}
