// hub: pre_write pipeline orchestrator — calls 4 stages in order.
// Stage 1: Security (path, secrets, python, memory)
// Stage 2: Enforcement (skills, research, evidence, tests, new crate)
// Stage 3: Guards (chain, rust, ts, sql, algo, platform P0 blocks)
// Stage 4: Advisory (RAG, P1 warnings, Karpathy, tailwind, algo inject)
use kavach_types::HookInput;

use crate::error::EngineError;
use crate::gates::pre_write_context::WriteContext;
use crate::gates::pre_write_security::SecurityResult;

/// Pre-write pipeline: security → enforcement → guards → advisory → approve.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let ctx = WriteContext::extract(input);

    // Stage 1: Security
    match super::pre_write_security::check(&ctx) {
        SecurityResult::Block(reason) => {
            kavach_hook::exit_pre_tool_deny(&reason);
            return Ok(());
        }
        SecurityResult::AllowEarly(warn) => {
            kavach_hook::exit_pre_tool_allow(Some(&warn));
            return Ok(());
        }
        SecurityResult::Pass => {}
    }

    let mut session = kavach_session::get_or_create_session();

    // Stage 2: Enforcement
    if let Some(block) = super::pre_write_enforcement::check(&ctx, input, &mut session) {
        kavach_hook::exit_pre_tool_deny(&block);
        return Ok(());
    }

    // Stage 3: Language guards (P0 blocks)
    let guard_result = super::pre_write_guards::check(&ctx, input, &session);
    if let Some(block) = guard_result.block {
        kavach_hook::exit_pre_tool_deny(&block);
        return Ok(());
    }

    // Track file modification
    if !ctx.file_path.is_empty() {
        session.add_file_modified(ctx.file_path);
        if !session.files_modified_this_turn.contains(&ctx.file_path.to_string()) {
            session.files_modified_this_turn.push(ctx.file_path.to_string());
        }
    }

    // Stage 4: Advisory collection (includes P1 advisories from tiered guards)
    let mut context = super::pre_write_advisory::collect(
        &ctx,
        input,
        &mut session,
        &guard_result.runner_compact,
        guard_result.algo_advisory.as_deref(),
    );

    // Append P1 advisories from tiered guard system
    if !guard_result.p1_advisories.is_empty() {
        context.push_str("\n\n[P1_ADVISORIES]\n");
        for advisory in &guard_result.p1_advisories {
            context.push_str(advisory);
            context.push('\n');
        }
    }

    super::event_log::log_gate_decision(
        &session.session_id, "pre_write", "allow", ctx.file_path, &session.project,
    );
    kavach_hook::exit_pre_tool_allow(Some(&context));
    Ok(())
}
