//! Verify completion claims before allowing "done" declarations.
//!
//! Detects premature completion claims by checking if the agent has
//! actually run tests, verified builds, or checked results before
//! claiming work is finished.

use kavach_session::SessionState;

/// Phrases that indicate premature completion claims.
const PREMATURE_DONE_PHRASES: &[&str] = &[
    "all tests pass",
    "everything works",
    "implementation is complete",
    "all done",
    "task completed",
    "successfully implemented",
    "fix is in place",
    "changes are ready",
    "ready for review",
    "should work now",
    "that should fix",
];

/// Check if content claims completion without evidence.
/// Returns Some(warning) if premature completion detected.
pub fn check_completion_claim(
    content: &str,
    session: &SessionState,
) -> Option<String> {
    let lower = content.to_lowercase();

    let has_claim = PREMATURE_DONE_PHRASES
        .iter()
        .any(|phrase| lower.contains(phrase));

    if !has_claim {
        return None;
    }

    if has_verification_evidence(session) {
        return None;
    }

    Some(
        "[COMPLETION_CHECK]\n\
         Completion claimed but no verification evidence found.\n\
         Run `cargo test` and `cargo check`, then show the actual output as evidence.\n\
         Report completion only after verified output confirms success."
            .into(),
    )
}

/// Check session for evidence of recent verification commands.
fn has_verification_evidence(session: &SessionState) -> bool {
    session.recent_commands.iter().any(|cmd| {
        let c = cmd.to_lowercase();
        c.contains("cargo test")
            || c.contains("cargo check")
            || c.contains("cargo clippy")
            || c.contains("cargo build")
            || c.contains("npm test")
            || c.contains("pytest")
            || c.contains("go test")
    })
}

/// Threshold of modified files that triggers review isolation suggestion.
const REVIEW_ISOLATION_THRESHOLD: usize = 5;

/// Check if session has enough modified files to warrant independent review.
/// Returns Some(suggestion) when 5+ files modified.
pub fn check_review_isolation(session: &SessionState) -> Option<String> {
    let count = session.files_modified.len();
    if count < REVIEW_ISOLATION_THRESHOLD {
        return None;
    }

    Some(format!(
        "[REVIEW_GATE]\n\
         You modified {count} files this session. Before claiming completion:\n\
         0. Run `kavach db kanban --project <slug>` — mark completed items done\n\
         1. Spawn a code-reviewer agent with ONLY the diff (no conversation history)\n\
         2. The reviewer must NOT know what you intended — only what the code does\n\
         3. Use isolation: \"worktree\" for a clean, unbiased review copy\n\
         4. If reviewer finds issues, fix before stopping"
    ))
}

#[cfg(test)]
#[path = "completion_guard_tests.rs"]
mod tests;
