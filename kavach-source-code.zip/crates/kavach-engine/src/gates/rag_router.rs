//! Phase C bridge between kavach-db `rag_trees` storage and the
//! kavach-rag matcher. Runs purely read-only in hook hot paths.
//!
//! The router is **advisory** — it never blocks or denies. It loads a
//! persisted tree by label, runs the matcher, and returns a context block
//! that the pre_write gate appends alongside existing skill enforcement.
//! Any failure (missing db row, parse error, empty result) degrades to an
//! empty string so the gate never fails because rag is unavailable.
//!
//! A per-process `OnceLock` cache per label avoids re-opening the SQLite
//! connection and re-parsing the tree JSON when multiple gates fire within
//! the same hook invocation (UserPromptSubmit → PreToolUse → PostToolUse
//! chain). Each kavach CLI invocation still starts cold, but inside one
//! process every call after the first is free.

use std::sync::{Mutex, OnceLock};

use std::collections::HashMap;

use kavach_db::{graph, open_default, rag_trees};
use kavach_db::graph_entity::upsert_entity;
use kavach_db::graph::add_relationship;
use kavach_db::rag::{MatchResult, Matcher, Query, RagTree, compute_graph_boosts};

/// Query a persisted tree and format the top-k hits as a context block
/// suitable for injection into a gate approval context.
///
/// Returns an empty string if:
/// - kavach-db cannot be opened
/// - no row exists for `label`
/// - the blob fails to parse as JSON
/// - the matcher returns zero hits
///
/// Return the top-k matching node titles ranked by score, without any
/// formatting. Used by the skill enforcement path to collapse an otherwise
/// too-strict critical-skill list down to the single RAG-picked winner.
/// Titles are the SKILL.md root node titles, e.g. "rust/SKILL.md", so the
/// caller strips the `/SKILL.md` suffix to obtain the skill name.
pub fn top_skill_names(
    label: &str,
    file_path: &str,
    raw_text: &str,
    intent: &str,
    top_k: usize,
) -> Vec<String> {
    let trees = load_trees(label);
    if trees.is_empty() {
        return Vec::new();
    }
    let effective_k = top_k.max(1);
    let query = Query::new(file_path, raw_text, intent);
    let boosts = load_graph_boosts(&trees);
    let mut pooled: Vec<MatchResult> = Vec::new();
    for tree in &trees {
        let mut matcher = Matcher::new(tree).with_top_k(effective_k);
        if let Some(ref b) = boosts {
            matcher = matcher.with_graph_boosts(b.clone());
        }
        for hit in matcher.run(&query) {
            pooled.push(hit);
        }
    }
    pooled.sort_by(|a, b| b.score.cmp(&a.score));
    pooled.truncate(effective_k);
    let mut direct: Vec<String> = pooled
        .into_iter()
        .map(|h| skill_name_from_title(&h.title))
        .filter(|n| !n.is_empty())
        .collect();
    // Layer 3: imperative NLU — inject cluster skills based on intent type
    inject_intent_cluster(&mut direct, intent);
    // NLP keyword routing — scan raw text for skill-specific keywords
    for kw_skill in kavach_patterns::skill_keyword_router::skills_from_keywords(raw_text) {
        if !direct.iter().any(|s| s == &kw_skill) {
            direct.push(kw_skill);
        }
    }
    // Phase 3: feedback loop — write session→uses_skill edges
    write_skill_feedback_edges(&direct);
    expand_with_graph_neighbors(direct)
}

/// Load graph boosts for all skill entities. Returns None if DB unavailable.
fn load_graph_boosts(trees: &[RagTree]) -> Option<HashMap<String, u32>> {
    let conn = match open_default() {
        Ok(c) => c,
        Err(_) => return None,
    };
    let mut skill_names: Vec<&str> = Vec::new();
    for tree in trees {
        collect_skill_names(&tree.root, &mut skill_names);
    }
    if skill_names.is_empty() {
        return None;
    }
    let boosts = compute_graph_boosts(&conn, &skill_names);
    let map: HashMap<String, u32> = boosts.into_iter().collect();
    if map.values().all(|&v| v == 0) {
        return None;
    }
    Some(map)
}

fn collect_skill_names<'a>(node: &'a kavach_db::rag::TreeNode, out: &mut Vec<&'a str>) {
    let stripped = node.id.trim_end_matches("/SKILL.md");
    if let Some(name) = stripped.rsplit('/').next() {
        if !name.is_empty() {
            out.push(name);
        }
    }
    for child in &node.children {
        collect_skill_names(child, out);
    }
}

/// Phase 3 feedback: write session→uses_skill edges for resolved skills.
/// Fire-and-forget — errors are silently ignored to never block the gate.
fn write_skill_feedback_edges(skills: &[String]) {
    if skills.is_empty() {
        return;
    }
    let conn = match open_default() {
        Ok(c) => c,
        Err(_) => return,
    };
    // Prefer env var; fall back to kavach session state (set by SessionStart gate).
    // CLAUDE_SESSION_ID is not reliably set by Claude Code in hook subprocesses.
    let session_id = std::env::var("CLAUDE_SESSION_ID").ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| kavach_session::get_or_create_session().session_id.clone());
    if session_id.is_empty() {
        return;
    }
    let sess_eid = match upsert_entity(&conn, "session", &session_id, None) {
        Ok(id) => id,
        Err(_) => return,
    };
    for skill in skills {
        if let Ok(skill_eid) = upsert_entity(&conn, "skill", skill, None) {
            let _ = add_relationship(&conn, sess_eid, skill_eid, "uses_skill", 1.0);
        }
    }
}

/// Imperative NLU: intent type → mandatory cluster skills.
/// These skills are always injected for the given intent, regardless of RAG score.
/// The gate enforces these — not advisory.
/// INVARIANT: must not include skills with `user-invocable: false` —
/// those cannot be satisfied via the Skill tool and cause deadlock.
/// security-analyst and arch are excluded here; they are advisory-only.
fn intent_cluster_skills(intent: &str) -> &'static [&'static str] {
    match intent {
        "implement" => &["rust", "evidence-chain"],
        "debug" => &["deep-bug-hunter", "rust"],
        "security" => &["evidence-chain"],
        "deploy" => &["cloud-ops"],
        "refactor" => &["rust"],
        "architecture" => &["arch", "evidence-chain"],
        _ => &["evidence-chain"],
    }
}

/// Inject cluster skills from intent mapping into the result set.
/// Skills already present are not duplicated.
fn inject_intent_cluster(skills: &mut Vec<String>, intent: &str) {
    let cluster = intent_cluster_skills(intent);
    for &skill in cluster {
        if !skills.iter().any(|s| s == skill) {
            skills.push(skill.to_string());
        }
    }
}

/// Expand a list of skill names with their `cross_invoke` graph neighbors.
/// Neighbors are appended after direct hits; duplicates are excluded via
/// a `HashSet`. Degrades silently if kavach-db is unavailable.
fn expand_with_graph_neighbors(skills: Vec<String>) -> Vec<String> {
    use std::collections::HashSet;
    let conn = match open_default() {
        Ok(c) => c,
        Err(_) => return skills,
    };
    let mut seen: HashSet<String> = skills.iter().cloned().collect();
    let mut expanded = skills;
    for skill in expanded.clone() {
        let entity = match kavach_db::graph_entity::find_entity(&conn, "skill", &skill) {
            Ok(e) => e,
            Err(_) => continue,
        };
        let related = match graph::get_related(&conn, entity.id, 50) {
            Ok(r) => r,
            Err(_) => continue,
        };
        for (rel, target) in related {
            if rel.rel_type == "cross_invoke" && seen.insert(target.name.clone()) {
                expanded.push(target.name);
            }
        }
    }
    expanded
}

/// Extract the bare skill name from a tree root title. Enriched trees use
/// the SKILL.md path (`rust/SKILL.md`) as the title; the skill name is the
/// first path component.
fn skill_name_from_title(title: &str) -> String {
    match title.split('/').next() {
        Some(first) => first.to_string(),
        None => String::new(),
    }
}

pub fn advisory_context(
    label: &str,
    file_path: &str,
    raw_text: &str,
    intent: &str,
    top_k: usize,
) -> String {
    let trees = load_trees(label);
    if trees.is_empty() {
        return String::new();
    }
    let effective_k = top_k.max(1);
    let query = Query::new(file_path, raw_text, intent);
    let mut pooled: Vec<MatchResult> = Vec::new();
    for tree in &trees {
        let matcher = Matcher::new(tree).with_top_k(effective_k);
        for hit in matcher.run(&query) {
            pooled.push(hit);
        }
    }
    if pooled.is_empty() {
        return String::new();
    }
    pooled.sort_by(|a, b| b.score.cmp(&a.score));
    pooled.truncate(effective_k);
    format_hits(label, &pooled, effective_k)
}

fn format_hits(
    label: &str,
    hits: &[kavach_db::rag::MatchResult],
    max_lines: usize,
) -> String {
    let mut out = String::with_capacity(128);
    out.push_str("[RAG:");
    out.push_str(label);
    out.push_str("]\n");
    for hit in hits.iter().take(max_lines) {
        out.push_str(&format!(
            "{} {} ({})\n",
            hit.score.0, hit.title, hit.node_id
        ));
    }
    out
}

/// Query ALL registered labels and return merged advisory context.
/// Each label's results are grouped under its own `[RAG:<label>]` header.
pub fn advisory_context_all(
    file_path: &str,
    raw_text: &str,
    intent: &str,
    top_k: usize,
) -> String {
    let labels = all_labels();
    if labels.is_empty() {
        // Fallback: query skills only
        return advisory_context("skills", file_path, raw_text, intent, top_k);
    }
    let mut combined = String::new();
    for label in &labels {
        let ctx = advisory_context(label, file_path, raw_text, intent, top_k);
        if !ctx.is_empty() {
            combined.push_str(&ctx);
        }
    }
    combined
}

/// Return all skill names from ALL registered labels.
pub fn top_skill_names_all(
    file_path: &str,
    raw_text: &str,
    intent: &str,
    top_k: usize,
) -> Vec<String> {
    let labels = all_labels();
    if labels.is_empty() {
        return top_skill_names("skills", file_path, raw_text, intent, top_k);
    }
    let mut all: Vec<String> = Vec::new();
    for label in &labels {
        let names = top_skill_names(label, file_path, raw_text, intent, top_k);
        all.extend(names);
    }
    all
}

/// List all labels stored in kavach-db.
fn all_labels() -> Vec<String> {
    let conn = match open_default() {
        Ok(c) => c,
        Err(_) => return Vec::new(),
    };
    match rag_trees::list(&conn) {
        Ok(rows) => rows.into_iter().map(|(source, _, _)| source).collect(),
        Err(_) => Vec::new(),
    }
}

/// Process-wide cache: `label -> Vec<RagTree>`. Empty Vec means "we tried
/// and there was no row / parse failed". Subsequent calls short-circuit
/// without re-hitting sqlite. Shared across every gate in a single hook
/// process invocation (intent + pre_write + post_write all share one parse).
type TreeCache = Mutex<Vec<(String, Vec<RagTree>)>>;

fn cache() -> &'static TreeCache {
    static CACHE: OnceLock<TreeCache> = OnceLock::new();
    CACHE.get_or_init(|| Mutex::new(Vec::new()))
}

fn load_trees(label: &str) -> Vec<RagTree> {
    if let Ok(guard) = cache().lock()
        && let Some((_, cached)) = guard.iter().find(|(k, _)| k == label)
    {
        return cached.clone();
    }
    let fetched = fetch_and_parse_all(label);
    if let Ok(mut g) = cache().lock()
        && !g.iter().any(|(k, _)| k == label)
    {
        g.push((label.to_string(), fetched.clone()));
    }
    fetched
}

fn fetch_and_parse_all(label: &str) -> Vec<RagTree> {
    let conn = match open_default() {
        Ok(c) => c,
        Err(_) => return Vec::new(),
    };
    let stored = match rag_trees::get(&conn, label) {
        Ok(Some(s)) => s,
        Ok(None) => return Vec::new(),
        Err(_) => return Vec::new(),
    };
    let body = match std::str::from_utf8(&stored.tree_json) {
        Ok(s) => s,
        Err(_) => return Vec::new(),
    };
    let mut out: Vec<RagTree> = Vec::new();
    for line in body.lines() {
        if line.trim().is_empty() {
            continue;
        }
        if let Ok(tree) = RagTree::from_json(line) {
            out.push(tree);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_return_empty_when_label_missing() {
        // No row with this label in any live db — function must degrade
        // gracefully to empty string rather than panic or return context.
        let ctx = advisory_context(
            "kavach-rag-test-nonexistent-label-xyz-42",
            "src/lib.rs",
            "fix unwrap",
            "implement",
            3,
        );
        assert!(ctx.is_empty());
    }
}
