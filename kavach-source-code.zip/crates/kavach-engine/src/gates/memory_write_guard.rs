//! HARD BLOCK: Force memory operations through kavach-db, not MEMORY.md.
//!
//! When the agent writes to memory files (MEMORY.md, /memory/*.md),
//! this guard blocks the write and directs to kavach db commands.
//! kavach-db (SQLite) is the permanent store — MEMORY.md is session cache.

/// Check if a file path is a memory file that should use kavach-db.
/// Returns false for agent-memory paths — subagents write structured
/// per-agent memory under ~/.claude/agent-memory/<name>/ and those
/// writes are intentional, not kavach-db bypass attempts.
pub fn is_memory_file(file_path: &str) -> bool {
    if file_path.contains("agent-memory/") {
        return false;
    }
    file_path.contains("/memory/")
        || file_path.ends_with("MEMORY.md")
        || file_path.ends_with("/memory.md")
}

/// Generate the block message for memory file writes.
pub fn block_message(file_path: &str) -> String {
    format!(
        "MEMORY_DB_VIOLATION: Writing to `{file_path}` is BLOCKED.\n\
         \n\
         kavach-db (SQLite) is the PERMANENT store — MEMORY.md is session cache only.\n\
         \n\
         USE THESE COMMANDS INSTEAD:\n\
         \n\
         # Write a memory entry\n\
         kavach db write --project <slug> --category <cat> --key <key> --title <title>\n\
         \n\
         # Query existing memories\n\
         kavach db query --project <slug>\n\
         kavach db query --project <slug> --category decision\n\
         \n\
         # Sync session state to database\n\
         kavach db sync\n\
         \n\
         CATEGORIES: decision, pattern, research, architecture, debug, config\n\
         \n\
         Use `kavach db write` to persist memories — MEMORY.md is session cache only.\n\
         EXCEPTION: Only Claude Code auto-memory (system-initiated) may write MEMORY.md."
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn memory_md_detected() {
        assert!(is_memory_file(
            "/Users/x/.claude/projects/foo/memory/MEMORY.md"
        ));
    }

    #[test]
    fn memory_dir_detected() {
        assert!(is_memory_file(
            "/Users/x/.claude/projects/foo/memory/topic.md"
        ));
    }

    #[test]
    fn normal_file_passes() {
        assert!(!is_memory_file("/Users/x/project/src/main.rs"));
    }

    #[test]
    fn agent_memory_dir_exempt() {
        assert!(!is_memory_file(
            "/Users/x/.claude/agent-memory/backend-engineer/user_role.md"
        ));
        assert!(!is_memory_file(
            "/Users/x/.claude/agent-memory/frontend-engineer/MEMORY.md"
        ));
    }

    #[test]
    fn block_message_has_commands() {
        let msg = block_message("MEMORY.md");
        assert!(msg.contains("kavach db write"));
        assert!(msg.contains("kavach db query"));
        assert!(msg.contains("MEMORY_DB_VIOLATION"));
    }
}
