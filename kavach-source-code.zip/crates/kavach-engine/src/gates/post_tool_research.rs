use kavach_types::HookInput;

use crate::error::EngineError;

/// Handle research done: mark research in session, inject tracking context.
pub fn handle_research_done(input: &HookInput) -> Result<(), EngineError> {
    let mut session = kavach_session::get_or_create_session();
    let query = input.get_string("query");

    if !query.is_empty() {
        session.mark_research_done_with_topic(query);
    } else {
        session.mark_research_done();
    }
    session.record_websearch();

    let context = kavach_hook::context_block("POST_TOOL:RESEARCH", &[]);
    kavach_hook::exit_post_tool_context(&context);
    Ok(())
}

pub fn handle(input: &HookInput, _session: &mut kavach_session::SessionState) -> Result<(), EngineError> {
    handle_research_done(input)
}
