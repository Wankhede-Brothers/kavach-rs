// Stage 4: Advisory collection — all section-8 non-blocking advisories.
// RAG, rust P1, ts P1, sql P1, platform P1, think-first, simplicity, surgical, tailwind, algo-inject.
use kavach_types::HookInput;
use crate::gates::pre_write_context::WriteContext;
use crate::gates::pre_write_checks::build_approval_context;

/// Collect all advisory context for the approval response.
pub(crate) fn collect(
    ctx: &WriteContext<'_>,
    input: &HookInput,
    session: &mut kavach_session::SessionState,
    runner_compact: &str,
    algo_advisory: Option<&str>,
) -> String {
    let mut context = build_approval_context(ctx.tool_name, runner_compact, session);

    // New package warning
    let pkg_warn = super::new_package_guard::check_new_package(ctx.file_path);
    if let Some(ref warn) = pkg_warn {
        context.push('\n');
        context.push_str(warn);
    }

    // RAG advisory
    let rag_advisory = super::rag_router::advisory_context_all(
        ctx.file_path,
        ctx.content,
        &session.intent_type,
        3,
    );
    if !rag_advisory.is_empty() {
        context.push('\n');
        context.push_str(&rag_advisory);
    }

    // Bulk checkbox warning
    let checkbox_warn = super::pre_write_checks::detect_bulk_checkbox(
        ctx.file_path,
        input.get_string("content"),
        input.get_string("new_string"),
    );
    if let Some(ref warn) = checkbox_warn {
        context.push('\n');
        context.push_str(warn);
    }

    // Rust guard P1 advisory
    if ctx.is_rust && !ctx.is_test {
        if let Some(ref advisory) = super::pre_write_rust_guard::format_advisory(
            ctx.file_path, ctx.content,
        ) {
            context.push('\n');
            context.push_str(advisory);
        }
    }

    // TS guard P1 advisory
    if ctx.is_frontend && !ctx.is_test {
        if let Some(ref advisory) = super::pre_write_ts_guard::format_advisory(
            ctx.file_path, ctx.content,
        ) {
            context.push('\n');
            context.push_str(advisory);
        }
    }

    // SQL guard P1 advisory
    if !ctx.is_test {
        if let Some(ref advisory) = super::pre_write_sql_guard::format_advisory(
            ctx.file_path, ctx.content,
        ) {
            context.push('\n');
            context.push_str(advisory);
        }
    }

    // Platform guards P1 advisory
    if !ctx.is_test {
        let platform_advisories: [Option<String>; 3] = [
            super::pre_write_response_guard::format_advisory(ctx.file_path, ctx.content),
            super::pre_write_microservice_guard::format_advisory(ctx.file_path, ctx.content),
            super::pre_write_infra_guard::format_advisory(ctx.file_path, ctx.content),
        ];
        for advisory in platform_advisories.into_iter().flatten() {
            context.push('\n');
            context.push_str(&advisory);
        }
    }

    // API Gateway P1 advisory (protocol leakage, missing aggregation)
    if !ctx.is_test {
        if let Some(ref advisory) = super::api_gateway_guard::format_advisory(
            ctx.file_path, ctx.content,
        ) {
            context.push('\n');
            context.push_str(advisory);
        }
    }

    // Karpathy Principle 1: Think First
    if let Some(ref tf) = super::elicitation::think_first_advisory(
        &session.intent_type,
        &session.intent_risk,
        session.think_first_injected,
    ) {
        context.push('\n');
        context.push_str(tf);
        session.think_first_injected = true;
        let _ = session.save();
    }

    // Karpathy Principle 2: Simplicity
    if ctx.is_rust && !ctx.is_test {
        if let Some(ref advisory) = super::pre_write_simplicity_guard::advisory(
            ctx.file_path, ctx.content,
        ) {
            context.push('\n');
            context.push_str(advisory);
        }
    }

    // Harness Engineering: Counterfactual Analysis
    // Per verification gate research: "What if this change were NOT made?"
    // Detects unnecessary abstractions, premature optimization, speculative code.
    if let Some(cf) = counterfactual_advisory(ctx.content) {
        context.push('\n');
        context.push_str(&cf);
    }

    // Karpathy Principle 3: Surgical
    {
        let ns = input.get_string("new_string");
        if let Some(ref surg) = super::pre_write_surgical_guard::diff_advisory(ctx.tool_name, ns) {
            context.push('\n');
            context.push_str(surg);
        }
        if let Some(ref scope) = super::pre_write_surgical_guard::scope_advisory(
            &session.files_modified_this_turn,
        ) {
            context.push('\n');
            context.push_str(scope);
        }
    }

    // Tailwind Plus component reference
    if ctx.is_frontend {
        if let Some(ref tw) = super::pre_write_tailwind_guard::advisory(
            ctx.file_path, ctx.content,
        ) {
            context.push('\n');
            context.push_str(tw);
        }
    }

    // Algo hunter auto-inject
    if let Some(algo_ctx) = algo_advisory {
        context.push('\n');
        context.push_str(algo_ctx);
    }

    // Self-healing: generate auto-fixes for Rust violations
    // Per Harness Engineering: block + diagnose + fix in same turn.
    if ctx.is_rust && !ctx.is_test {
        let fixes = super::self_heal::rust_self_heal(ctx.content);
        if !fixes.is_empty() {
            let heal_msg = super::self_heal::format_self_heal_message(&fixes, ctx.file_path);
            context.push('\n');
            context.push_str(&heal_msg);
        }
    }

    context
}

// ARCH: CounterfactualAnalysis — "What if this change were NOT made?"
// PATTERN: counterfactual | SCOPE: pre_write | CAP: AP | SEARCHED: 2026-04
// Per verification gate research: detect unnecessary complexity before it lands.

/// Counterfactual advisory: detect patterns that suggest unnecessary complexity.
/// Returns None if code looks necessary, Some(advisory) if speculative/premature.
fn counterfactual_advisory(content: &str) -> Option<String> {
    let mut issues: Vec<&str> = Vec::new();

    // Detect speculative abstractions
    if content.contains("impl<T>") && content.contains("where T:") && content.len() < 500 {
        issues.push("Generic impl on small code — is the abstraction needed now?");
    }

    // Detect premature feature flags
    if content.contains("feature_flag") || content.contains("FEATURE_") {
        issues.push("Feature flag detected — is this needed for current task?");
    }

    // Detect empty implementations
    if content.contains("todo!()") || content.contains("unimplemented!()") {
        issues.push("Placeholder detected — implement fully or don't add yet");
    }

    // Detect over-engineering signals
    if content.contains("Factory") && content.contains("Builder") {
        issues.push("Factory+Builder pattern — is this complexity warranted?");
    }

    // Detect backwards-compatibility shims
    if content.contains("_deprecated") || content.contains("// DEPRECATED") {
        issues.push("Deprecated marker — can you remove instead of deprecate?");
    }

    if issues.is_empty() {
        None
    } else {
        let mut advisory = String::from("[COUNTERFACTUAL] What if this were NOT made?\n");
        for issue in issues {
            advisory.push_str("  - ");
            advisory.push_str(issue);
            advisory.push('\n');
        }
        advisory.push_str("Principle: The right complexity is what the task requires.");
        Some(advisory)
    }
}
