use kavach_types::HookInput;

use crate::error::EngineError;

/// Handle task done: track subagent lifecycle.
/// No actionable context to inject — exit silently.
pub fn handle_task_done(_input: &HookInput) -> Result<(), EngineError> {
    kavach_hook::exit_silent();
    Ok(())
}

pub fn handle(input: &HookInput, _session: &kavach_session::SessionState) -> Result<(), EngineError> {
    handle_task_done(input)
}
