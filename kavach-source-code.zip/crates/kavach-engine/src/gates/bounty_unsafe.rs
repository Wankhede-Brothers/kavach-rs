//! Unsafe gate: scan .rs files for unsafe blocks without // SAFETY: comment.

use std::path::Path;

/// Scan project for unsafe blocks without SAFETY comments.
/// Returns Some(block_message) if violations found.
pub fn check(work_dir: &str) -> Option<String> {
    let mut violations = Vec::new();
    scan_dir(Path::new(work_dir), &mut violations);

    if violations.is_empty() { return None; }

    let mut msg = format!(
        "BOUNTY_UNSAFE_BLOCK: {} unsafe block(s) without // SAFETY: comment:\n",
        violations.len()
    );
    for (file, line) in &violations {
        msg.push_str(&format!("  {file}:{line}\n"));
    }
    msg.push_str("  FIX: Add `// SAFETY: <explain invariant>` before each unsafe block.");
    Some(msg)
}

fn scan_dir(dir: &Path, violations: &mut Vec<(String, usize)>) {
    let Ok(entries) = std::fs::read_dir(dir) else { return };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
            if matches!(name, "target" | ".git" | "node_modules") { continue; }
            scan_dir(&path, violations);
        } else if path.extension().and_then(|e| e.to_str()) == Some("rs") {
            scan_file(&path, violations);
        }
    }
}

/// Walk back up to 10 lines from an unsafe block looking for // SAFETY: comment.
/// Allows intervening comment lines, blank lines, and #[...] attributes.
fn scan_back_for_safety(lines: &[&str], unsafe_line: usize) -> bool {
    let max_lookback = unsafe_line.min(10);
    for offset in 1..=max_lookback {
        let idx = unsafe_line.wrapping_sub(offset);
        let prev = match lines.get(idx) {
            Some(l) => l.trim(),
            None => return false,
        };
        if prev.contains("// SAFETY:") {
            return true;
        }
        // Continue through comments, blanks, attributes
        if prev.is_empty() || prev.starts_with("//") || prev.starts_with("#[") {
            continue;
        }
        // Hit actual code — stop looking
        return false;
    }
    false
}

fn scan_file(path: &Path, violations: &mut Vec<(String, usize)>) {
    let Ok(content) = std::fs::read_to_string(path) else { return };
    let path_str = path.to_string_lossy();

    // Skip test files
    if path_str.contains("/tests/") || path_str.contains("_test.rs") || path_str.contains("_tests.rs") {
        return;
    }

    let lines: Vec<&str> = content.lines().collect();
    for (i, line) in lines.iter().enumerate() {
        let trimmed = line.trim();
        if !trimmed.starts_with("unsafe ") && trimmed != "unsafe {" {
            continue;
        }
        // Walk back up to 10 lines through comments, blanks, and attributes
        let has_safety = scan_back_for_safety(&lines, i);

        if !has_safety {
            violations.push((path_str.to_string(), i + 1));
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn scanner_runs_on_project() {
        let dir = env!("CARGO_MANIFEST_DIR");
        let _ = check(dir);
    }

    #[test]
    fn detects_unsafe_without_safety() {
        let tmp = std::env::temp_dir().join("kavach_unsafe_test");
        let _ = std::fs::create_dir_all(&tmp);
        let file = tmp.join("bad.rs");
        std::fs::write(&file, "fn f() {\n    unsafe {\n        core::ptr::null::<u8>();\n    }\n}\n")
            .ok();
        let mut v = Vec::new();
        scan_file(&file, &mut v);
        let _ = std::fs::remove_dir_all(&tmp);
        assert!(!v.is_empty(), "should detect unsafe without SAFETY");
    }

    #[test]
    fn allows_unsafe_with_safety_comment() {
        let tmp = std::env::temp_dir().join("kavach_unsafe_ok");
        let _ = std::fs::create_dir_all(&tmp);
        let file = tmp.join("good.rs");
        std::fs::write(&file, "fn f() {\n    // SAFETY: pointer is valid\n    unsafe {\n        core::ptr::null::<u8>();\n    }\n}\n")
            .ok();
        let mut v = Vec::new();
        scan_file(&file, &mut v);
        let _ = std::fs::remove_dir_all(&tmp);
        assert!(v.is_empty(), "should allow unsafe with SAFETY comment");
    }
}
