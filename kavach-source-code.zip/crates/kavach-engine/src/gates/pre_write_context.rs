// WriteContext — shared context extracted once from HookInput, passed to all pipeline stages.
// Eliminates the repeated content extraction pattern across pre_write stages.
use kavach_types::HookInput;
use crate::gates::pre_write_checks::{is_code_write, is_test_or_exempt};

/// Shared context for the pre-write pipeline. Extracted once, read by all stages.
pub(crate) struct WriteContext<'a> {
    pub file_path: &'a str,
    pub tool_name: &'a str,
    /// Write content (`content` for Write tool, `new_string` for Edit tool).
    pub content: &'a str,
    pub is_code: bool,
    pub is_test: bool,
    pub is_rust: bool,
    pub is_frontend: bool,
}

impl<'a> WriteContext<'a> {
    pub fn extract(input: &'a HookInput) -> Self {
        let file_path = input.get_string("file_path");
        let tool_name = &input.tool_name;
        let wr = input.get_string("content");
        let ed = input.get_string("new_string");
        let content = if !wr.is_empty() { wr } else { ed };
        Self {
            file_path,
            tool_name,
            content,
            is_code: is_code_write(file_path),
            is_test: is_test_or_exempt(file_path),
            is_rust: kavach_patterns::is_rust_file(file_path),
            is_frontend: kavach_patterns::is_frontend_file(file_path),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_extract_content_from_write_tool() {
        let mut input = HookInput::default();
        input.tool_name = "Write".into();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("src/main.rs")),
            ("content".into(), serde_json::json!("fn main() {}")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert_eq!(ctx.file_path, "src/main.rs");
        assert_eq!(ctx.content, "fn main() {}");
        assert!(ctx.is_code);
        assert!(ctx.is_rust);
        assert!(!ctx.is_frontend);
        assert!(!ctx.is_test);
    }

    #[test]
    fn should_extract_new_string_from_edit_tool() {
        let mut input = HookInput::default();
        input.tool_name = "Edit".into();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("src/App.tsx")),
            ("new_string".into(), serde_json::json!("export default App")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert_eq!(ctx.content, "export default App");
        assert!(ctx.is_frontend);
        assert!(!ctx.is_rust);
    }

    #[test]
    fn should_prefer_content_over_new_string() {
        let mut input = HookInput::default();
        input.tool_name = "Write".into();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("src/lib.rs")),
            ("content".into(), serde_json::json!("// content")),
            ("new_string".into(), serde_json::json!("// new_string")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert_eq!(ctx.content, "// content");
    }

    #[test]
    fn should_detect_test_file() {
        let mut input = HookInput::default();
        input.tool_input = Some(std::collections::HashMap::from([
            ("file_path".into(), serde_json::json!("src/gates/intent_tests.rs")),
            ("content".into(), serde_json::json!("test code")),
        ]));
        let ctx = WriteContext::extract(&input);
        assert!(ctx.is_test);
    }
}
