use kavach_types::HookInput;

use crate::error::EngineError;

/// Notification gate: handle Notification events.
/// Injects context based on notification type.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let message = &input.message;
    let notification_type = &input.notification_type;

    // Do NOT increment_turn() for notifications. They are informational,
    // not tool interactions. Incrementing would defeat failure staleness:
    // a notification between failure and stop check would let Claude stop
    // despite unresolved failures (has_recent_failure uses turn equality).

    let msg_preview: String = message.chars().take(200).collect();
    let context = kavach_hook::context_block(
        "NOTIFICATION",
        &[
            ("type", notification_type),
            ("message", &msg_preview),
        ],
    );

    kavach_hook::exit_notification_context(&context);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_notification_default() {
        let input = HookInput {
            message: "test notification".into(),
            notification_type: "info".into(),
            ..Default::default()
        };
        let _ = run(&input);
    }
}
