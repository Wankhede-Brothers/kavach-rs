// Karpathy Principle 1: "Think Before Coding"
// On implement intent with risk >= medium, inject [THINK_FIRST] advisory once per intent window.
use kavach_types::HookInput;

use crate::error::EngineError;

/// Elicitation gate: inject [THINK_FIRST] advisory on medium/high-risk implement intents.
/// Advisory-only — never blocks. Fires once per intent window via think_first_injected flag.
pub fn run(_input: &HookInput) -> Result<(), EngineError> {
    kavach_hook::exit_silent();
    Ok(())
}

/// Elicitation result gate: handle result of an elicitation prompt.
pub fn run_result(_input: &HookInput) -> Result<(), EngineError> {
    kavach_hook::exit_silent();
    Ok(())
}

/// Returns [THINK_FIRST] advisory string if conditions are met, None otherwise.
/// Called from pre_write gate section 8 (advisory zone).
pub fn think_first_advisory(intent_type: &str, intent_risk: &str, already_injected: bool) -> Option<String> {
    if already_injected {
        return None;
    }
    if intent_type != "implement" {
        return None;
    }
    if intent_risk == "low" {
        return None;
    }
    Some(
        "[THINK_FIRST]\n\
         action: State assumptions explicitly. If multiple interpretations exist, present them.\n\
         action: If a simpler approach exists, say so. If unclear, ask — don't guess.\n"
            .to_string(),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_run() { let _ = run(&HookInput::default()); }

    #[test]
    fn test_run_result() { let _ = run_result(&HookInput::default()); }

    #[test]
    fn should_inject_on_implement_medium_risk() {
        let result = think_first_advisory("implement", "medium", false);
        assert!(result.is_some());
        let s = result.unwrap_or_default();
        assert!(s.contains("[THINK_FIRST]"));
    }

    #[test]
    fn should_not_inject_when_already_done() {
        assert!(think_first_advisory("implement", "medium", true).is_none());
    }

    #[test]
    fn should_not_inject_for_low_risk() {
        assert!(think_first_advisory("implement", "low", false).is_none());
    }

    #[test]
    fn should_not_inject_for_non_implement_intent() {
        assert!(think_first_advisory("refactor", "high", false).is_none());
        assert!(think_first_advisory("debug", "medium", false).is_none());
        assert!(think_first_advisory("general", "high", false).is_none());
    }

    #[test]
    fn should_inject_on_high_risk_implement() {
        let result = think_first_advisory("implement", "high", false);
        assert!(result.is_some());
    }
}
