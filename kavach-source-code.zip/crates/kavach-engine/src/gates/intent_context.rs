/// Append forbidden phrase warnings to context.
pub fn append_forbidden(context: &mut String, forbidden: &[String]) {
    if forbidden.is_empty() {
        return;
    }
    context.push_str("\n[FORBIDDEN_PHRASES]\n");
    for phrase in forbidden {
        context.push_str("  - ");
        context.push_str(phrase);
        context.push('\n');
    }
}

/// Append memory DB reminder for memory-type intents.
pub fn append_memory_db(context: &mut String, intent_type: &str) {
    if intent_type == "memory" {
        context.push_str("\n[MEMORY_DB] Use kavach db write — NOT MEMORY.md files\n");
    }
}

/// Append verify-existing reminder for implement-type intents.
pub fn append_verify_existing(context: &mut String, intent_type: &str) {
    if intent_type == "implement" || intent_type == "debug" {
        context.push_str("\n[VERIFY_EXISTING] Read existing routes/handlers/models before planning\n");
    }
}

/// Append DB query requirement for status/progress/resume prompts.
/// Claude MUST run `kavach db kanban` before answering — chat history is not authoritative.
pub fn append_db_query_required(context: &mut String, prompt: &str) {
    let lower = prompt.to_lowercase();
    let is_status_query = lower.contains("progress")
        || lower.contains("status")
        || lower.contains("what have we done")
        || lower.contains("what did we")
        || lower.contains("what was done")
        || lower.contains("what's done")
        || lower.contains("whats done")
        || lower.contains("what is done")
        || lower.contains("resume")
        || lower.contains("where did we leave")
        || lower.contains("where were we")
        || lower.contains("catch me up")
        || lower.contains("what phases")
        || lower.contains("which phases")
        || lower.contains("roadmap")
        || lower.contains("next step")
        || lower.contains("next phase");
    if is_status_query {
        context.push_str(
            "\n[DB_QUERY_REQUIRED]\n\
             MANDATORY: Run `kavach db kanban --project <slug>` BEFORE answering.\n\
             Chat history is NOT authoritative — it may be truncated, compressed, or wrong.\n\
             The kavach-db SQLite store is the single source of truth for project state.\n\
             Steps: 1) kavach db list-projects  2) kavach db kanban --project <slug>  3) Answer from kanban output.\n\
             Answering from chat history without querying DB is a protocol violation.\n",
        );
    }
}

/// Extract research topic from prompt and intent type.
pub fn extract_research_topic(prompt: &str, intent_type: &str) -> String {
    let words: Vec<&str> = prompt.split_whitespace().take(6).collect();
    if words.is_empty() {
        return intent_type.to_string();
    }
    words.join(" ")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_append_forbidden_empty() {
        let mut ctx = String::new();
        append_forbidden(&mut ctx, &[]);
        assert!(ctx.is_empty());
    }

    #[test]
    fn test_append_forbidden_items() {
        let mut ctx = String::new();
        append_forbidden(&mut ctx, &["bad phrase".into()]);
        assert!(ctx.contains("bad phrase"));
    }

    #[test]
    fn test_extract_research_topic() {
        let topic = extract_research_topic("fix the auth bug in login", "debug");
        assert!(topic.contains("fix"));
    }

    #[test]
    fn test_db_query_required_progress() {
        let mut ctx = String::new();
        append_db_query_required(&mut ctx, "Now provide me the Progress of the project since Phase 1");
        assert!(ctx.contains("DB_QUERY_REQUIRED"));
        assert!(ctx.contains("kavach db kanban"));
    }

    #[test]
    fn test_db_query_required_status() {
        let mut ctx = String::new();
        append_db_query_required(&mut ctx, "What is the current status?");
        assert!(ctx.contains("DB_QUERY_REQUIRED"));
    }

    #[test]
    fn test_db_query_required_resume() {
        let mut ctx = String::new();
        append_db_query_required(&mut ctx, "Resume the migration task");
        assert!(ctx.contains("DB_QUERY_REQUIRED"));
    }

    #[test]
    fn test_db_query_not_required_for_code() {
        let mut ctx = String::new();
        append_db_query_required(&mut ctx, "Fix the compile error in auth.rs");
        assert!(ctx.is_empty());
    }
}
