/// Blind reference update detector for the stop gate.
/// Catches responses that describe updating URLs, hrefs, imports, or references
/// WITHOUT evidence of having verified the target exists and resolves correctly.
use super::stop_detect::{has_completion_signal, normalize_for_matching};

/// Phrases indicating a reference/link/URL was updated.
const UPDATE_PHRASES: &[&str] = &[
    "updated links to", "changed links to", "updated all links",
    "changed href", "updated href", "rewired href",
    "links now point to", "links point to", "all links point",
    "changed /create", "updated /create", "rewired /create",
    "changed url to", "updated url to", "rewired url to",
    "changed the url", "updated the url", "rewired the url",
    "points to dashboard", "point to dashboard",
    "redirect to dashboard", "redirects to dashboard",
    "now links to", "now points to", "now redirects to",
    "changed import", "updated import", "rewired import",
    "changed endpoint", "updated endpoint", "rewired endpoint",
    "changed api url", "updated api url",
    "start mission\" links", "start mission\" point",
    "create\" links", "/create links",
];

/// Evidence that the target was actually verified before updating.
const VERIFICATION_EVIDENCE: &[&str] = &[
    "verified", "confirmed", "checked that", "resolves to",
    "route exists", "endpoint exists", "path exists", "page exists",
    "dashboard_url is", "dashboard_url =", "dashboard_url resolves",
    "the constant is", "the variable is", "the value is",
    "grep found the route", "read the route", "read the constant",
    "i read", "i checked", "after reading", "after verifying",
    "navigated to", "tested the url", "tested the link",
    "the url resolves", "the link resolves", "url is correct",
    "which resolves to", "which points to http",
];

/// Detect blind reference updates: changing URLs/links without verification.
pub fn contains_blind_reference_update(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }

    let has_update = UPDATE_PHRASES.iter().any(|p| lower.contains(p));
    if !has_update { return false; }

    let has_evidence = VERIFICATION_EVIDENCE.iter().any(|e| lower.contains(e));
    if has_evidence { return false; }

    // Override: if actively verifying (not just describing the update)
    let is_verifying = lower.contains("let me verify")
        || lower.contains("verifying now")
        || lower.contains("checking the route");
    if is_verifying { return false; }

    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_blind_href_update() {
        assert!(contains_blind_reference_update(
            "Updated all /create links to point to Dashboard URL."
        ));
    }

    #[test]
    fn test_blind_href_change() {
        assert!(contains_blind_reference_update(
            "Changed href from /create to DASHBOARD_URL. Start Mission now links to dashboard."
        ));
    }

    #[test]
    fn test_verified_update_ok() {
        assert!(!contains_blind_reference_update(
            "Updated links to Dashboard. I checked that DASHBOARD_URL resolves to https://app.example.com/."
        ));
    }

    #[test]
    fn test_verified_with_read_ok() {
        assert!(!contains_blind_reference_update(
            "Changed href to DASHBOARD_URL. After reading the constant, it resolves to the correct path."
        ));
    }

    #[test]
    fn test_no_update_language() {
        assert!(!contains_blind_reference_update(
            "Fixed the route handler. 0 errors. All tests pass."
        ));
    }

    #[test]
    fn test_empty() {
        assert!(!contains_blind_reference_update(""));
    }

    #[test]
    fn test_blind_import_update() {
        assert!(contains_blind_reference_update(
            "Changed import paths to use the new module structure."
        ));
    }

    #[test]
    fn test_blind_endpoint_update() {
        assert!(contains_blind_reference_update(
            "Updated endpoint references to point to the new API URL."
        ));
    }
}
