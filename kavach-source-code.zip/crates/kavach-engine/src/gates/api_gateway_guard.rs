//! API Gateway Guard — pre-write gate for handler/route files.
//! P0 violations (missing gateway layer) = HARD BLOCK.
//! P1 violations (protocol leakage, missing aggregation) = advisory.

use kavach_patterns::api_gateway::{self, Severity, Violation};

/// Check for P0 violations (MissingGatewayLayer).
/// Returns Some(block_message) if blocked, None if allowed.
pub fn check(file_path: &str, content: &str) -> Option<String> {
    let violations = api_gateway::detect(file_path, content);
    let p0: Vec<&Violation> = violations
        .iter()
        .filter(|v| v.severity == Severity::P0Block)
        .collect();

    if p0.is_empty() {
        return None;
    }

    let mut msg = String::from("API_GATEWAY_GUARD BLOCKED: Missing gateway layer\n\n");
    for v in &p0 {
        msg.push_str(&format!("  file: {}\n", file_path));
        msg.push_str(&format!("  violation: {}\n", v.message));
        msg.push_str(&format!("  fix: {}\n\n", v.fix));
    }
    msg.push_str("REQUIRED: Add auth/rate-limit middleware before this write can proceed.\n\n");
    msg.push_str("RESEARCH: WebSearch \"api gateway middleware patterns {search_year}\"\n");
    msg.push_str("SKILL: Invoke `arch` skill for gateway layer design.\n");
    msg.push_str("FIX: Add auth layer before routes. Use tower middleware for rate limiting.");
    Some(msg)
}

/// Format P1 advisory for additionalContext injection.
pub fn format_advisory(file_path: &str, content: &str) -> Option<String> {
    let violations = api_gateway::detect(file_path, content);
    let p1: Vec<&Violation> = violations
        .iter()
        .filter(|v| v.severity == Severity::P1Advisory)
        .collect();

    if p1.is_empty() {
        return None;
    }

    let mut msg = String::from("[API_GATEWAY_ADVISORY]\n");
    for v in &p1 {
        let kind_str = match v.kind {
            api_gateway::ViolationKind::ProtocolLeakage => "ProtocolLeakage",
            api_gateway::ViolationKind::MissingAggregation => "MissingAggregation",
            api_gateway::ViolationKind::MissingGatewayLayer => "MissingGatewayLayer",
        };
        msg.push_str(&format!("  {}: {}\n", kind_str, v.message));
    }
    msg.push_str("  skill: web-stack (API Gateway section)\n");
    Some(msg)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn blocks_handler_without_gateway_layer() {
        let content = r#"
use axum::Router;
use axum::routing::get;

pub fn routes() -> Router {
    Router::new().route("/orders", get(get_orders))
}
"#;
        let result = check("src/handlers/order.rs", content);
        assert!(result.is_some());
        let msg = result.unwrap_or_default();
        assert!(msg.contains("API_GATEWAY_GUARD BLOCKED"));
        assert!(msg.contains("Missing gateway layer"));
    }

    #[test]
    fn allows_handler_with_auth() {
        let content = r#"
use axum::Router;
use crate::middleware::auth;

pub fn routes() -> Router {
    Router::new()
        .route("/orders", get(get_orders))
        .layer(auth::layer())
}
"#;
        let result = check("src/handlers/order.rs", content);
        assert!(result.is_none());
    }

    #[test]
    fn formats_advisory_for_protocol_leakage() {
        let content = r#"
use axum::Router;
use tonic::Request;
use crate::auth;

pub async fn handler() {}
"#;
        let result = format_advisory("src/handlers/order.rs", content);
        assert!(result.is_some());
        let msg = result.unwrap_or_default();
        assert!(msg.contains("[API_GATEWAY_ADVISORY]"));
        assert!(msg.contains("ProtocolLeakage"));
    }
}
