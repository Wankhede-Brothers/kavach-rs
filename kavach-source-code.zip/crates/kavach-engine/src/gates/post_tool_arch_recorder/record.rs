//! Architecture decision recording logic.

use super::extract::extract_arch_comment;

/// Record an architecture decision after Write/Edit.
pub fn record(file_path: &str, content: &str, project_slug: &str, turn: i64) {
    if !file_path.ends_with(".rs") {
        return;
    }
    let arch = match extract_arch_comment(content) {
        Some(a) => a,
        None => return,
    };

    let conn = match kavach_db::open_default() {
        Ok(c) => c,
        Err(_) => return,
    };

    let project_id = match kavach_db::projects::get_by_slug(&conn, project_slug) {
        Ok(p) => p.id,
        Err(_) => return,
    };

    let input = kavach_db::arch_decisions::ArchDecisionInput {
        project_id,
        pattern: &arch.pattern,
        scope: &arch.scope,
        cap_choice: arch.cap_choice.as_deref(),
        qps_estimate: arch.qps_estimate.as_deref(),
        peak_multiplier: arch.peak_multiplier,
        storage_estimate: arch.storage_estimate.as_deref(),
        failure_mode: &arch.failure_mode,
        tradeoff: &arch.tradeoff,
        search_year: arch.search_year,
        search_month: arch.search_month,
        reference_url: arch.reference_url.as_deref(),
        file_path,
        turn,
    };

    let _ = kavach_db::arch_decisions::upsert(&conn, &input);

    let payload = format!(
        r#"{{"pattern":"{}","scope":"{}","file":"{}"}}"#,
        arch.pattern, arch.scope, file_path
    );
    let _ = kavach_db::events::append(
        &conn,
        None,
        "architecture_decision",
        "post_tool_arch_recorder",
        Some(project_id),
        Some(payload.as_str()),
    );

    write_graph_edges(&conn, file_path, &arch.pattern, &arch.scope);
}

fn write_graph_edges(
    conn: &kavach_db::Connection,
    file_path: &str,
    pattern: &str,
    scope: &str,
) {
    let file_id = kavach_db::graph_entity::upsert_entity(conn, "file", file_path, None);
    let pattern_id = kavach_db::graph_entity::upsert_entity(conn, "arch_pattern", pattern, None);
    let scope_id = kavach_db::graph_entity::upsert_entity(conn, "arch_scope", scope, None);

    if let (Ok(fid), Ok(pid)) = (&file_id, &pattern_id) {
        let _ = kavach_db::graph::add_relationship(conn, *fid, *pid, "uses_pattern", 1.0);
    }
    if let (Ok(pid), Ok(sid)) = (&pattern_id, &scope_id) {
        let _ = kavach_db::graph::add_relationship(conn, *pid, *sid, "in_scope", 1.0);
    }
}
