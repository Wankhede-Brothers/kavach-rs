//! Time utilities for arch recorder.

/// Seconds per year (approximate).
const SECS_PER_YEAR: u64 = 31_557_600;
/// Seconds per day.
const SECS_PER_DAY: u64 = 86_400;
/// Days per year.
const DAYS_PER_YEAR: u64 = 365;
/// Days per month (approximate).
const DAYS_PER_MONTH: u64 = 31;
/// Unix epoch year.
const EPOCH_YEAR: i64 = 1970;
/// Fallback year.
const FALLBACK_YEAR: i64 = 2026;

pub fn current_year() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .ok()
        .and_then(|d| i64::try_from(d.as_secs() / SECS_PER_YEAR).ok())
        .map(|y| EPOCH_YEAR + y)
        .unwrap_or(FALLBACK_YEAR)
}

pub fn current_month() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .ok()
        .map(|d| {
            let day_of_year = (d.as_secs() / SECS_PER_DAY) % DAYS_PER_YEAR + 1;
            (day_of_year / DAYS_PER_MONTH).min(11) + 1
        })
        .and_then(|m| i64::try_from(m).ok())
        .unwrap_or(1)
}
