//! Detect dangerous grep patterns that cause 30+ minute hangs.
//!
//! Problems caught:
//!  1. `grep -r` without --exclude-dir for .git/target/node_modules
//!  2. `grep -r` scanning binary files (missing -I flag)
//!  3. `grep -r` on large paths without file-type filters
//!  4. Using `grep` in Bash when the Grep tool is available

/// Returns Some(context) with fix instructions, or None if safe.
pub fn check_grep_command(command: &str) -> Option<String> {
    let lower = command.to_lowercase();
    if !lower.contains("grep ") && !lower.starts_with("grep") {
        return None;
    }

    if is_recursive_grep(&lower) {
        return check_recursive_grep(&lower, command);
    }

    Some(grep_tool_reminder())
}

fn is_recursive_grep(lower: &str) -> bool {
    let flags = [
        "grep -r", "grep -rn", "grep -rl", "grep -ri",
        "grep -rni", "grep -rin", "grep -rnil",
        "grep -rn ", "grep -rl ",
    ];
    flags.iter().any(|f| lower.contains(f))
}

fn check_recursive_grep(lower: &str, original: &str) -> Option<String> {
    let mut issues: Vec<&str> = Vec::new();

    if !lower.contains("--binary-files") && !has_dash_cap_i(original) {
        issues.push("scans binary files (missing -I flag)");
    }

    if !lower.contains("--exclude-dir") {
        issues.push("no --exclude-dir (scans .git, target, node_modules)");
    }

    if !lower.contains("--include") {
        issues.push("no --include filter (scans ALL file types)");
    }

    if issues.is_empty() {
        return None;
    }

    let issue_list = issues.join(", ");
    Some(format!(
        "[GREP_PERFORMANCE_BLOCK]\n\
         Recursive grep: {issue_list}\n\
         This causes 30+ minute hangs on large codebases.\n\n\
         USE the Grep tool instead — it skips .git, binaries, and \
         respects .gitignore automatically.\n\n\
         If you MUST use Bash grep:\n\
         grep -rI --exclude-dir=.git --exclude-dir=target \
         --exclude-dir=node_modules --include='*.rs' PATTERN PATH"
    ))
}

/// Check for -I flag (skip binary files) — distinct from -i (case insensitive).
/// Uses original (non-lowered) command to distinguish -I from -i.
fn has_dash_cap_i(original: &str) -> bool {
    // Check the original command for capital -I (binary skip)
    // Split by whitespace and look for flags containing -I but not -i
    original.split_whitespace().any(|arg| {
        arg.starts_with('-') && !arg.starts_with("--") && arg.contains('I')
    })
}

fn grep_tool_reminder() -> String {
    "[GREP_TOOL_REMINDER]\n\
     You used `grep` in Bash. Use the dedicated Grep tool instead:\n\
     - Skips .git, target, node_modules automatically\n\
     - Skips binary files by default\n\
     - Has timeout handling (no 30-min hangs)\n\
     - Output is structured and reviewable"
        .into()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn non_grep_passes() {
        assert!(check_grep_command("cargo build").is_none());
    }

    #[test]
    fn simple_grep_gets_reminder() {
        let r = check_grep_command("grep foo bar.txt");
        assert!(r.is_some());
        assert!(r.unwrap().contains("GREP_TOOL_REMINDER"));
    }

    #[test]
    fn recursive_grep_no_exclusions_blocks() {
        let r = check_grep_command(r#"grep -r "pattern" /home/project"#);
        assert!(r.is_some());
        assert!(r.unwrap().contains("GREP_PERFORMANCE_BLOCK"));
    }

    #[test]
    fn recursive_grep_with_all_flags_passes() {
        let cmd = "grep -r --binary-files=without-match \
                   --exclude-dir=.git --exclude-dir=target \
                   --exclude-dir=node_modules --include='*.rs' pat src/";
        assert!(check_grep_command(cmd).is_none());
    }
}
