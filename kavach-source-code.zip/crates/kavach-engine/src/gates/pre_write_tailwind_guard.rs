//! Tailwind Plus advisory gate — injects matching component reference on frontend writes.
//! Trigger: PreToolUse:Write|Edit where file_path ends in .tsx/.jsx/.astro
//! Output: [TAILWIND_PLUS_REF] advisory block — never a hard block.
use std::fs;
use std::path::Path;

use kavach_config::{tailwind_plus_dir, tailwind_plus_index};

/// Returns an advisory context block if a matching Tailwind Plus component is found,
/// or a "no match" nudge pointing at the catalog. Always `None`-safe (index absent = skip).
pub fn advisory(file_path: &str, content: &str) -> Option<String> {
    if !is_frontend_file(file_path) {
        return None;
    }
    let index_path = tailwind_plus_index();
    if !index_path.exists() {
        return None;
    }
    let index_json = match fs::read_to_string(&index_path) {
        Ok(s) => s,
        Err(_) => return None,
    };
    let index: serde_json::Value = match serde_json::from_str(&index_json) {
        Ok(v) => v,
        Err(_) => return None,
    };
    let components = match index.get("components").and_then(|v| v.as_array()) {
        Some(arr) => arr,
        None => return None,
    };
    let query_kw = extract_query_keywords(file_path, content);
    let best = find_best_match(components, &query_kw);
    match best {
        Some((score, component)) if score >= 0.3 => {
            let file_field = component.get("file").and_then(|v| v.as_str())?;
            let preview = read_component_preview(file_field);
            let mut block = format!(
                "[TAILWIND_PLUS_REF]\nmatch: {file_field} (score: {score:.2})\n\
                 action: Use as base structure. Replace colors with semantic tokens. Wire Motion.\n"
            );
            if !preview.is_empty() {
                block.push('\n');
                block.push_str(&preview);
            }
            Some(block)
        }
        _ => Some(
            "[TAILWIND_PLUS_REF]\nmatch: none\n\
             action: Check tailwindcss.com/plus for matching component before writing custom UI\n"
                .to_string(),
        ),
    }
}

fn is_frontend_file(path: &str) -> bool {
    path.ends_with(".tsx") || path.ends_with(".jsx") || path.ends_with(".astro")
}

/// Extract query keywords from the file path segments and first 20 lines of content.
fn extract_query_keywords(file_path: &str, content: &str) -> Vec<String> {
    let mut kw: Vec<String> = Vec::new();
    // file path segments
    let stem = Path::new(file_path)
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("");
    for part in stem.split(|c: char| !c.is_alphanumeric()) {
        let p = part.trim().to_lowercase();
        if p.len() > 2 {
            kw.push(p);
        }
    }
    // path directory segments
    if let Some(parent) = Path::new(file_path).parent().and_then(|p| p.to_str()) {
        for seg in parent.split('/') {
            for part in seg.split('-') {
                let p = part.trim().to_lowercase();
                if p.len() > 2 {
                    kw.push(p);
                }
            }
        }
    }
    // first 20 lines of content
    for line in content.lines().take(20) {
        for token in line.split(|c: char| !c.is_alphanumeric() && c != '-') {
            let t = token.trim().to_lowercase();
            if t.len() > 3 && !is_noise(t.as_str()) {
                kw.push(t);
            }
        }
    }
    // dedup
    let mut seen = std::collections::HashSet::new();
    kw.retain(|k| seen.insert(k.clone()));
    kw
}

fn is_noise(t: &str) -> bool {
    matches!(
        t,
        "import" | "from" | "const" | "function" | "return" | "export"
            | "default" | "react" | "props" | "type" | "interface" | "class"
            | "string" | "number" | "boolean" | "void" | "null" | "true" | "false"
    )
}

/// Jaccard similarity between query keywords and component keywords.
fn jaccard(a: &[String], b: &[String]) -> f64 {
    if a.is_empty() && b.is_empty() {
        return 0.0;
    }
    let set_a: std::collections::HashSet<&str> = a.iter().map(String::as_str).collect();
    let set_b: std::collections::HashSet<&str> = b.iter().map(String::as_str).collect();
    let intersection = set_a.intersection(&set_b).count();
    let union = set_a.union(&set_b).count();
    if union == 0 {
        return 0.0;
    }
    intersection as f64 / union as f64
}

fn find_best_match<'a>(
    components: &'a [serde_json::Value],
    query_kw: &[String],
) -> Option<(f64, &'a serde_json::Value)> {
    let mut best_score = 0.0_f64;
    let mut best: Option<&serde_json::Value> = None;
    for comp in components {
        let comp_kw: Vec<String> = match comp.get("keywords").and_then(|v| v.as_array()) {
            Some(arr) => arr
                .iter()
                .filter_map(|v| v.as_str().map(str::to_lowercase))
                .collect(),
            None => continue,
        };
        let score = jaccard(query_kw, &comp_kw);
        if score > best_score {
            best_score = score;
            best = Some(comp);
        }
    }
    best.map(|c| (best_score, c))
}

/// Read first 80 lines of a component file from ~/.claude/tailwind-plus/<file>.
fn read_component_preview(file_field: &str) -> String {
    let path = tailwind_plus_dir().join(file_field);
    match fs::read_to_string(&path) {
        Ok(body) => {
            let preview: String = body.lines().take(80).collect::<Vec<_>>().join("\n");
            format!("```jsx\n{preview}\n```")
        }
        Err(_) => String::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_return_none_for_non_frontend_files() {
        assert!(advisory("src/main.rs", "").is_none());
        assert!(advisory("styles.css", "").is_none());
    }

    #[test]
    fn should_return_none_for_missing_index() {
        // Index doesn't exist in test env — gate must be silent.
        let result = advisory("/tmp/test/Sidebar.tsx", "export default function Sidebar() {}");
        // Either None (no index) or Some (found index) — must not panic.
        let _ = result;
    }

    #[test]
    fn should_detect_frontend_extensions() {
        assert!(is_frontend_file("Component.tsx"));
        assert!(is_frontend_file("Page.jsx"));
        assert!(is_frontend_file("Layout.astro"));
        assert!(!is_frontend_file("util.ts"));
        assert!(!is_frontend_file("main.rs"));
    }

    #[test]
    fn should_compute_jaccard_correctly() {
        let a = vec!["sidebar".to_string(), "navigation".to_string(), "dark".to_string()];
        let b = vec!["sidebar".to_string(), "navigation".to_string(), "light".to_string()];
        let score = jaccard(&a, &b);
        // intersection=2, union=4 → 0.5
        assert!((score - 0.5).abs() < f64::EPSILON);
    }

    #[test]
    fn should_return_zero_jaccard_for_empty_inputs() {
        assert_eq!(jaccard(&[], &[]), 0.0);
        assert_eq!(jaccard(&["a".to_string()], &[]), 0.0);
    }

    #[test]
    fn should_extract_keywords_from_path_and_content() {
        let kw = extract_query_keywords(
            "src/components/navigation/Sidebar.tsx",
            "import { useState } from 'react'\n// dark sidebar with nav links",
        );
        assert!(kw.contains(&"sidebar".to_string()));
        assert!(kw.contains(&"navigation".to_string()));
    }
}
