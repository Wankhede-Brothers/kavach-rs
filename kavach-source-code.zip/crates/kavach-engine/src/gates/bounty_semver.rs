//! Semver gate: detect semver violations if cargo-semver-checks is installed.

use std::process::Command;

/// Check for semver violations. Returns Some(block) if violations found.
pub fn check(work_dir: &str) -> Option<String> {
    let output = Command::new("cargo")
        .args(["semver-checks", "check-release"])
        .current_dir(work_dir)
        .output();

    let output = match output {
        Ok(o) => o,
        Err(_) => return None, // not installed
    };

    if output.status.success() {
        return None;
    }

    let stderr = String::from_utf8_lossy(&output.stderr);
    if stderr.contains("not found")
        || stderr.contains("no such subcommand")
        || stderr.contains("no such command")
    {
        return None; // not installed
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    Some(format!(
        "BOUNTY_SEMVER_WARNING: Semver violations detected.\n  {stdout}"
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn returns_none_for_bad_dir() {
        assert!(check("/tmp/no_such_workspace_ever").is_none());
    }

    #[test]
    fn runs_without_panic() {
        let workspace = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent().and_then(|p| p.parent());
        if let Some(root) = workspace {
            let _ = check(&root.to_string_lossy());
        }
    }
}
