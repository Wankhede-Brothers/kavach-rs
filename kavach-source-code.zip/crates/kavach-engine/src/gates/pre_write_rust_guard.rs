//! Rust Production Guard — pre-write gate for .rs files.
//! P0 violations (unwrap, _var, panic, as-cast) = HARD BLOCK.
//! P1 violations (clone, catch-all, allow) = advisory warning.

use kavach_patterns::rust_guard::{RustSeverity, RustViolation};

pub fn check(file_path: &str, content: &str) -> Option<String> {
    let violations = kavach_patterns::rust_guard::detect(file_path, content);
    if violations.is_empty() {
        return None;
    }

    let p0: Vec<&RustViolation> = violations.iter()
        .filter(|v| v.severity == RustSeverity::P0Block)
        .collect();

    let p1: Vec<&RustViolation> = violations.iter()
        .filter(|v| v.severity == RustSeverity::P1Advisory)
        .collect();

    if !p0.is_empty() {
        let mut msg = String::from(
            "RUST GUARD BLOCKED: Production code violations detected\n\n\
             P0 VIOLATIONS (HARD BLOCK):\n"
        );
        for v in &p0 {
            msg.push_str(&format!("  {} — {}\n", v.pattern, v.fix));
        }
        if !p1.is_empty() {
            msg.push_str("\nP1 ADVISORIES:\n");
            for v in &p1 {
                msg.push_str(&format!("  {} — {}\n", v.pattern, v.fix));
            }
        }
        msg.push_str(
            "\nREQUIRED: Fix all P0 violations before this write can proceed.\n\n\
             RESEARCH: WebSearch \"rust error handling best practices {search_year}\"\n\
             SKILL: Invoke `error` skill for propagation patterns.\n\
             FIX: Use `?` operator for propagation, `thiserror` for custom types,\n\
             `map_err` to add context. Never `unwrap`/`expect` in production."
        );
        return Some(msg);
    }

    None
}

pub fn format_advisory(file_path: &str, content: &str) -> Option<String> {
    let violations = kavach_patterns::rust_guard::detect(file_path, content);
    let p1: Vec<&RustViolation> = violations.iter()
        .filter(|v| v.severity == RustSeverity::P1Advisory)
        .collect();
    if p1.is_empty() { return None; }
    let mut msg = String::from("[RUST_GUARD_ADVISORY]\n");
    for v in &p1 {
        msg.push_str(&format!("  {} — {}\n", v.pattern, v.fix));
    }
    Some(msg)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn j(parts: &[&str]) -> String { parts.concat() }

    #[test]
    fn should_block_when_unwrap_in_production_code() {
        let code = j(&["let x = foo.unw", "rap();"]);
        assert!(check("src/lib.rs", &code).is_some());
    }

    #[test]
    fn should_allow_when_clean_arithmetic() {
        assert!(check("src/lib.rs", "fn add(a: i32, b: i32) -> i32 { a + b }").is_none());
    }

    #[test]
    fn should_allow_when_result_used() {
        assert!(check("src/lib.rs", "fn add(a: i32, b: i32) -> Result<i32, Error> { Ok(a + b) }").is_none());
    }

    #[test]
    fn should_skip_test_files() {
        let code = j(&["foo.unw", "rap()"]);
        assert!(check("tests/test_api.rs", &code).is_none());
    }

    #[test]
    fn should_emit_advisory_for_dbg_macro() {
        assert!(format_advisory("src/lib.rs", "fn f(x: i32) -> i32 { dbg!(x) }").is_some());
    }

    #[test]
    fn should_emit_no_advisory_for_clean_code() {
        assert!(format_advisory("src/lib.rs", "fn f() {}").is_none());
    }
}
