/// Advisory check for conventional commit message format.
/// Returns Some(advisory) if the message lacks a recognized prefix.
/// Never blocks — git commits are too workflow-critical for P0 blocks.
pub(crate) fn check_commit_message(cmd: &str) -> Option<String> {
    let lower = cmd.trim().to_lowercase();
    if !lower.contains("git commit") {
        return None;
    }
    let msg_start = lower.find("-m ")?;
    let raw = &cmd.trim()[msg_start + 3..];
    let msg = raw.trim_start_matches('"').trim_start_matches('\'');
    let prefixes = [
        "feat", "fix", "refactor", "docs", "test", "chore",
        "perf", "ci", "build", "style", "spec", "plan", "revert",
    ];
    if prefixes.iter().any(|p| msg.starts_with(p)) {
        return None;
    }
    Some(
        "[COMMIT_FORMAT] Advisory: commit message should use conventional commits format.\n\
         Recognized prefixes: feat | fix | refactor | docs | test | chore | perf | ci | build | style\n\
         Example: `git commit -m \"feat(auth): add PASETO token validation\"`"
            .to_string(),
    )
}

/// Advisory: warn when cargo check/build targets multiple -p crates at once.
pub(crate) fn check_multi_crate(cmd: &str) -> Option<String> {
    let is_check_or_build = cmd.contains("cargo check") || cmd.contains("cargo build");
    if !is_check_or_build {
        return None;
    }
    let p_count = cmd.split_whitespace()
        .filter(|t| *t == "-p" || *t == "--package")
        .count();
    if p_count < 2 {
        return None;
    }
    Some(format!(
        "[MULTI_CRATE_CHECK] {p_count} -p flags detected on a single cargo invocation.\n\
         Cargo resolves the full dependency graph for all targets in one process — \
         this is the slowest way to check multiple crates.\n\
         FIX: Run one command per crate so Cargo can parallelise:\n\
             cargo check -p crate-a\n\
             cargo check -p crate-b\n\
         Or use --workspace to let Cargo schedule the full graph optimally."
    ))
}

/// Advisory: suggest `cargo nextest run` when plain `cargo test` is used.
pub(crate) fn check_nextest_advisory(cmd: &str) -> Option<String> {
    if !cmd.contains("cargo test") || cmd.contains("cargo nextest") {
        return None;
    }
    Some(
        "[NEXTEST_ADVISORY] `cargo test` detected. Consider `cargo nextest run` instead.\n\
         nextest runs each test in a separate process in parallel — up to 3x faster.\n\
         Install: `cargo install cargo-nextest --locked`\n\
         Run: `cargo nextest run` (or `cargo nextest run -p <crate>` for a single crate)"
            .to_string(),
    )
}

/// Detect `git add .`, `git add -A`, `git add --all` — blanket staging.
pub(crate) fn is_git_add_all(cmd: &str) -> bool {
    let parts: Vec<&str> = cmd.trim().split_whitespace().collect();
    if parts.len() < 3 { return false; }
    if parts.first().is_some_and(|p| *p != "git") { return false; }
    if parts.get(1).is_some_and(|p| *p != "add") { return false; }
    let arg = parts.get(2).copied().unwrap_or("");
    arg == "." || arg == "-A" || arg == "--all"
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_git_add_all_detected() {
        assert!(is_git_add_all("git add ."));
        assert!(is_git_add_all("git add -A"));
        assert!(is_git_add_all("git add --all"));
    }

    #[test]
    fn test_git_add_specific_allowed() {
        assert!(!is_git_add_all("git add src/main.rs"));
        assert!(!is_git_add_all("git add Backend/Cargo.toml"));
        assert!(!is_git_add_all("git commit -m 'fix'"));
        assert!(!is_git_add_all("cargo test"));
    }

    #[test]
    fn test_commit_message_conventional_passes() {
        assert!(check_commit_message("git commit -m \"feat(auth): add token validation\"").is_none());
        assert!(check_commit_message("git commit -m \"fix: correct session reset\"").is_none());
        assert!(check_commit_message("git commit -m \"chore: bump deps\"").is_none());
        assert!(check_commit_message("git commit -m 'test: add memory guard tests'").is_none());
    }

    #[test]
    fn test_commit_message_missing_prefix_advises() {
        assert!(check_commit_message("git commit -m \"update stuff\"").is_some());
        assert!(check_commit_message("git commit -m \"WIP changes\"").is_some());
        assert!(check_commit_message("git commit -m 'initial commit'").is_some());
    }

    #[test]
    fn test_commit_message_non_commit_ignored() {
        assert!(check_commit_message("cargo build").is_none());
        assert!(check_commit_message("git status").is_none());
    }

    #[test]
    fn should_warn_when_multiple_p_flags_on_cargo_check() {
        assert!(check_multi_crate("cargo check -p soundbak-social-service -p user-service").is_some());
    }

    #[test]
    fn should_not_warn_for_single_p_flag() {
        assert!(check_multi_crate("cargo check -p kavach-engine").is_none());
    }

    #[test]
    fn should_suggest_nextest_for_plain_cargo_test() {
        assert!(check_nextest_advisory("cargo test --workspace").is_some());
    }

    #[test]
    fn should_not_suggest_nextest_when_already_using_it() {
        assert!(check_nextest_advisory("cargo nextest run").is_none());
    }
}
