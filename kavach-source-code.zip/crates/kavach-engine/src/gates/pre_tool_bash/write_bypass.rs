/// Return true when any segment of `lower` has `name` as its first word.
/// Split uses shell separators so `sed`, `&& sed`, `| sed`, `(sed` all match
/// but `sedan`, `grep sediment` do not.
fn segment_first_word_is(lower: &str, name: &str) -> bool {
    let separators = ['&', '|', ';', '(', '{', '\n'];
    for segment in lower.split(|c: char| separators.contains(&c)) {
        if segment.trim_start().split_whitespace().next() == Some(name) {
            return true;
        }
    }
    false
}

/// Check each subcommand in a compound command for file redirects.
/// Splits on && ; || to prevent /dev/null in one part exempting another.
pub(crate) fn has_file_redirect(lower: &str) -> bool {
    let parts = lower.split("&&").flat_map(|p| p.split("||"))
        .flat_map(|p| p.split(';')).flat_map(|p| p.split('&'));
    for part in parts {
        let p = part.trim();
        let has_redirect = p.contains(" > ") || p.contains(" >> ");
        if !has_redirect {
            continue;
        }
        let safe = p.contains("2>&1") || p.contains(">/dev/null")
            || p.contains("> /dev/null") || p.contains("> /tmp/kavach")
            || is_numeric_comparison(p);
        if !safe {
            return true;
        }
    }
    false
}

/// Return true when every ` > ` occurrence in the part is a numeric comparison
/// (e.g. `len > 80`, `count > 0`), not a shell redirect.
/// A redirect has a path/word after `>`; a numeric comparison has a digit.
fn is_numeric_comparison(part: &str) -> bool {
    let bytes = part.as_bytes();
    let mut i = 0;
    let mut found_redirect_gt = false;
    while i < bytes.len() {
        if bytes[i] == b'>' && i > 0 && bytes[i - 1] == b' ' {
            // Check char after `>`
            let after = bytes.get(i + 1).copied();
            match after {
                // `> digit` or `>digit` — numeric comparison, safe
                Some(b'0'..=b'9') => {}
                Some(b' ') => {
                    // `> ` — check what follows the space
                    match bytes.get(i + 2).copied() {
                        Some(b'0'..=b'9') => {} // `> 80` — numeric, safe
                        _ => { found_redirect_gt = true; }
                    }
                }
                _ => { found_redirect_gt = true; }
            }
        }
        i += 1;
    }
    !found_redirect_gt
}

/// HARD BLOCK: bare `psql` commands. Only `sqlx migrate` is allowed for DB ops.
/// `psql` bypasses the sqlx migration pipeline — untracked schema changes.
/// sqlx CLI has no `exec` command (issue #1375), so for ad-hoc queries
/// use `sqlx::query!` in a Rust integration test instead.
pub(crate) fn check_psql_blocked(cmd: &str) -> Option<String> {
    let lower = cmd.trim().to_lowercase();
    if !segment_first_word_is(&lower, "psql")
        && !lower.contains("| psql")
        && !lower.contains("|psql")
    {
        return None;
    }
    Some(
        "PSQL_BLOCKED: `psql` is banned. Use `sqlx` for all database operations.\n\
         Schema changes: `sqlx migrate run --source <dir>`\n\
         Check status: `sqlx migrate info --source <dir>`\n\
         Verify schema: write a Rust integration test with `sqlx::query!`\n\
         Ad-hoc queries: use `sqlx::query_as` in a test or one-off binary."
            .to_string(),
    )
}

/// Detect Bash commands that modify files, bypassing Write/Edit hooks.
/// Covers: sed -i, awk with redirect, echo/cat/tee/python to file.
pub(crate) fn is_write_bypass(cmd: &str) -> bool {
    let trimmed = cmd.trim();
    let lower = trimmed.to_lowercase();
    // `sed` must be in command position — a segment's first word. Catches `sed`,
    // `sed ...`, `&& sed ...`, `| sed ...`, `(sed ...)`. Rejects substrings like
    // `sedan`, `grep sediment`.
    let has_sed = segment_first_word_is(&lower, "sed");
    if has_sed && (lower.contains(" -i") || lower.contains(" -i'") || lower.contains(" -i\"")) {
        return true;
    }
    if has_file_redirect(&lower) {
        return true;
    }
    if lower.contains("| tee ") {
        return true;
    }
    let has_python = lower.starts_with("python") || lower.contains("python3 -c")
        || lower.contains("python -c") || lower.contains("/python3")
        || lower.contains("/python ") || lower.contains("env python");
    // Block Python piped to a DB client — bypasses SQL file hooks.
    // Correct pattern: Write tool → .sql file → psql -f <file>.
    if has_python && (lower.contains("| psql") || lower.contains("|psql")) {
        return true;
    }
    // Only block Python when it explicitly opens a file in write/append mode.
    if has_python && lower.contains("open(")
        && (lower.contains("'w'") || lower.contains("\"w\"")
            || lower.contains("'a'") || lower.contains("\"a\"")
            || lower.contains("'wb'") || lower.contains("\"wb\"")
            || lower.contains("'ab'") || lower.contains("\"ab\""))
    {
        return true;
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_write_bypass_blocked() {
        assert!(is_write_bypass("sed -i 's/old/new/' file.rs"));
        assert!(is_write_bypass("echo 'data' > output.txt"));
        assert!(is_write_bypass("cat template.txt >> config.toml"));
        assert!(is_write_bypass("cmd | tee /path/to/file"));
        assert!(is_write_bypass("python3 -c \"open('f','w').write('x')\""));
        assert!(is_write_bypass("python3 -c \"open('out.txt','wb').write(b'x')\""));
    }

    #[test]
    fn test_python_pipe_to_psql_blocked() {
        assert!(is_write_bypass("python3 -c \"print('SELECT 1')\" | psql $DATABASE_URL"));
        assert!(is_write_bypass("python3 -c \"import hashlib; print(sql)\" |psql $URL"));
    }

    #[test]
    fn test_write_bypass_allowed() {
        assert!(!is_write_bypass("cargo test 2>&1"));
        assert!(!is_write_bypass("echo hello"));
        assert!(!is_write_bypass("cargo check 2>&1 | tail -5"));
        assert!(!is_write_bypass("cat file.rs"));
        assert!(!is_write_bypass("grep pattern file.rs"));
        assert!(!is_write_bypass("kavach db query > /tmp/kavach_out.txt"));
        assert!(!is_write_bypass("grep -i 'sedan' file.txt"));
        assert!(!is_write_bypass("grep -i sediment log.txt"));
    }

    #[test]
    fn python_subprocess_with_open_in_arg_not_blocked() {
        // subprocess.run(['psql', os.environ['DATABASE_URL']]) contains no file write.
        // The old check falsely matched `open(` inside string args.
        assert!(!is_write_bypass(
            "python3 -c \"import subprocess,os; subprocess.run(['psql', os.environ['DATABASE_URL']], input=sql, capture_output=True)\""
        ));
        // Reading a file (open for read) is not a write bypass.
        assert!(!is_write_bypass(
            "python3 -c \"content = open('file.sql','r').read()\""
        ));
        // hashlib usage with open (read mode) must not block.
        assert!(!is_write_bypass(
            "python3 -c \"import hashlib; ck = hashlib.sha384(open('f.sql','rb').read()).hexdigest()\""
        ));
    }

    #[test]
    fn test_numeric_comparison_not_redirect() {
        // `> digit` in --content args must not be treated as redirect
        assert!(!is_write_bypass(
            "kavach db write --project x --content \"len > 80 chars\""
        ));
        assert!(!is_write_bypass(
            "kavach db write --project x --content \"count > 0\""
        ));
        assert!(!is_write_bypass(
            "kavach db write --project x --content \"cmd[..80] when len > 80\""
        ));
    }

    #[test]
    fn test_real_redirect_still_blocked() {
        assert!(is_write_bypass("echo hello > output.txt"));
        assert!(is_write_bypass("cat file >> log.txt"));
    }
}
