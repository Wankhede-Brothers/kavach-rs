// hub: pre_tool_bash dispatch — handle_bash() is the top-level router for Bash commands
mod advisories;
mod test_tracker;
mod write_bypass;

use advisories::{check_commit_message, check_multi_crate, check_nextest_advisory, is_git_add_all};
use test_tracker::{check_duplicate_test_run, check_unscoped_test_run, register_test_run};
use write_bypass::{check_psql_blocked, is_write_bypass};

use kavach_types::HookInput;
use crate::error::EngineError;

/// Handle Bash tool pre-check: command blocklist + pattern blocklist.
pub fn handle_bash(input: &HookInput) -> Result<(), EngineError> {
    let command = input.get_string("command");

    // Fast-exit for kavach CLI calls — internal bookkeeping, no enforcement needed.
    if is_kavach_cli(command) {
        kavach_hook::exit_pre_tool_allow(None);
        return Ok(());
    }

    if kavach_config::is_blocked_command(command) {
        kavach_hook::exit_pre_tool_deny(&format!(
            "BLOCKED: destructive command detected: `{command}`. \
             This matches the blocklist (rm -rf /, fork bombs, pipe-to-shell). \
             FIX: 1) Use targeted paths instead of root-level destructors. \
             2) Download scripts with curl -o first, review, then execute. \
             3) Use `cargo clean` or `git clean -fd` for project cleanup."
        ));
        return Ok(());
    }

    if kavach_patterns::is_blocked(command) {
        kavach_hook::exit_pre_tool_deny(&format!(
            "BLOCKED: dangerous pattern in command: `{command}`. \
             The command matches a known dangerous pattern. \
             FIX: 1) Review the command for unintended side effects. \
             2) Break compound commands into individual safe steps. \
             3) Use `eza` instead of `ls`, `bat` instead of `cat`. \
             4) Avoid piping untrusted output to shell interpreters."
        ));
        return Ok(());
    }

    if kavach_config::is_blocked_bash_pattern(command) {
        kavach_hook::exit_pre_tool_deny(&format!(
            "BLOCKED: security pattern detected: `{command}`. \
             Matches a config-defined blocked_patterns regex. \
             These patterns detect reverse shells, ssh key exfiltration, \
             and credential harvesting commands."
        ));
        return Ok(());
    }

    if is_write_bypass(command) {
        kavach_hook::exit_pre_tool_deny(
            "BLOCKED: File modification via Bash bypasses Write/Edit hooks. \
             Use the Write or Edit tool for file changes.",
        );
        return Ok(());
    }

    if is_git_add_all(command) {
        kavach_hook::exit_pre_tool_deny(
            "BLOCKED: `git add .` stages ALL files including unrelated changes. \
             FIX: Use `git add <specific-files>` to stage only changed files.",
        );
        return Ok(());
    }

    // HARD BLOCK: psql banned — only sqlx for DB operations.
    if let Some(block_reason) = check_psql_blocked(command) {
        kavach_hook::exit_pre_tool_deny(&block_reason);
        return Ok(());
    }

    // HARD BLOCK: unscoped cargo test/nextest without -p <crate>
    if let Some(block_reason) = check_unscoped_test_run(command) {
        kavach_hook::exit_pre_tool_deny(&block_reason);
        return Ok(());
    }

    let grep_ctx = super::grep_guard::check_grep_command(command);
    let commit_ctx = check_commit_message(command);
    let check_ctx = check_multi_crate(command);
    let nextest_ctx = check_nextest_advisory(command);

    if let Some(block_reason) = super::env_guard::check_env_value_read(command) {
        kavach_hook::exit_pre_tool_deny(&block_reason);
        return Ok(());
    }

    let env_ctx = super::env_guard::check_env_sourcing(command);
    let prod_ctx = super::prod_guard::check_prod_ops(command);
    let mut session = kavach_session::get_or_create_session();

    if let Some(block_reason) = super::loop_guard::check_bash_loop(&session, command) {
        kavach_hook::exit_pre_tool_deny(&block_reason);
        return Ok(());
    }
    super::loop_guard::record_command(&mut session, command);

    if let Some(block_reason) = check_duplicate_test_run(&session, command) {
        kavach_hook::exit_pre_tool_deny(&block_reason);
        return Ok(());
    }
    register_test_run(&mut session, command);

    let module_ctx = session.inject_modules_once(&["commands"]);
    let mut parts: Vec<&str> = Vec::new();
    if !module_ctx.is_empty() { parts.push(&module_ctx); }
    if let Some(ref g) = grep_ctx { parts.push(g); }
    if let Some(ref ch) = check_ctx { parts.push(ch); }
    if let Some(ref c) = commit_ctx { parts.push(c); }
    if let Some(ref n) = nextest_ctx { parts.push(n); }
    if let Some(ref e) = env_ctx { parts.push(e); }
    if let Some(ref p) = prod_ctx { parts.push(p); }

    if parts.is_empty() {
        kavach_hook::exit_pre_tool_allow(None);
    } else {
        kavach_hook::exit_pre_tool_allow(Some(&parts.join("\n\n")));
    }
    Ok(())
}

/// Return true for kavach CLI invocations — internal bookkeeping, no enforcement.
/// Matches: `kavach <subcommand>`, `~/.local/bin/kavach <subcommand>`
fn is_kavach_cli(cmd: &str) -> bool {
    let t = cmd.trim();
    t.starts_with("kavach ") || t.starts_with("~/.local/bin/kavach ")
        || t.contains("/kavach db ") || t.contains("/kavach status")
        || t.contains("/kavach rag ") || t.contains("/kavach rules ")
        || t.contains("/kavach session ") || t.contains("/kavach gates ")
}
