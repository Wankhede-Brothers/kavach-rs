/// Extract the crate/package name from a test command, or `None` if not determinable.
/// Only inspects the command portion BEFORE any --content flag to avoid false positives
/// when `kavach db write --content "...cargo test..."` is run.
pub(crate) fn extract_test_crate_key(cmd: &str) -> Option<String> {
    // Strip content after --content to avoid false positives on kavach db write
    // whose body happens to contain "cargo test" or "test" keywords.
    let command_portion = match cmd.find("--content") {
        Some(pos) => match cmd.get(..pos) {
            Some(prefix) => prefix,
            None => cmd,
        },
        None => cmd,
    };
    if !command_portion.contains("cargo test") && !command_portion.contains("cargo nextest") {
        return None;
    }
    if cmd.contains("--workspace") {
        return Some("__workspace__".into());
    }
    for flag in &["-p ", "--package "] {
        if let Some(pos) = cmd.find(flag) {
            let after = cmd[pos + flag.len()..].trim();
            if let Some(name) = after.split_whitespace().next() {
                return Some(name.to_string());
            }
        }
    }
    Some("__workspace__".into())
}

/// HARD BLOCK: unscoped `cargo test`/`cargo nextest run` without `-p <crate>`.
/// Full workspace tests take 10-20 min. Force `-p <crate>` for the modified crate.
/// Allows explicit `--workspace` flag (intentional full run).
pub(crate) fn check_unscoped_test_run(cmd: &str) -> Option<String> {
    let key = match extract_test_crate_key(cmd) {
        Some(k) => k,
        None => return None,
    };
    if key != "__workspace__" {
        return None;
    }
    if cmd.contains("--workspace") {
        return None;
    }
    Some(
        "UNSCOPED_TEST_BLOCKED: `cargo test`/`cargo nextest run` without `-p <crate>` \
         runs the FULL workspace (10-20 min), blocking all other operations.\n\
         FIX: Scope to the crate you modified:\n\
         cargo nextest run -p <crate-name>\n\
         Or use -E filterset: cargo nextest run -E 'test(my_test)'\n\
         Only use --workspace for final pre-merge verification."
            .to_string(),
    )
}

/// Block if this crate is already under a running test process.
/// Auto-expires stale entries: clears active_test_crates if 5+ turns
/// have passed since last_write_turn (test likely timed out or was interrupted).
pub(crate) fn check_duplicate_test_run(
    session: &kavach_session::SessionState,
    cmd: &str,
) -> Option<String> {
    let key = match extract_test_crate_key(cmd) {
        Some(k) => k,
        None => return None,
    };
    // Auto-expire: if 5+ turns have passed since last_write_turn,
    // the tracked test likely timed out — skip the block (don't mutate here;
    // register_test_run will overwrite on next real test start).
    if !session.active_test_crates.is_empty() {
        let stale_threshold = session.turn_count.saturating_sub(5);
        if session.last_write_turn < stale_threshold {
            return None;
        }
    }
    if !session.active_test_crates.iter().any(|c| c == &key) {
        return None;
    }
    let display = if key == "__workspace__" {
        "the workspace".to_string()
    } else {
        format!("crate `{key}`")
    };
    Some(format!(
        "TEST_ALREADY_RUNNING: cargo test for {display} is already in progress.\n\
         Wait for the current run to complete before launching another.\n\
         Parallel test runs on the same crate fight for Cargo's artifact lock,\n\
         causing all but one to block indefinitely on 'Blocking waiting for file lock'.\n\
         FIX: Check the background tasks panel and wait for the running test to finish."
    ))
}

/// Register a test run start — adds crate key to active_test_crates.
pub(crate) fn register_test_run(session: &mut kavach_session::SessionState, cmd: &str) {
    if let Some(key) = extract_test_crate_key(cmd) {
        if !session.active_test_crates.iter().any(|c| c == &key) {
            session.active_test_crates.push(key);
            let _ = session.save();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_extract_crate_key_from_p_flag() {
        assert_eq!(extract_test_crate_key("cargo test -p kavach-engine --lib"), Some("kavach-engine".into()));
    }

    #[test]
    fn should_extract_workspace_key_when_no_p_flag() {
        assert_eq!(extract_test_crate_key("cargo test --workspace"), Some("__workspace__".into()));
        assert_eq!(extract_test_crate_key("cargo test 2>&1 | tail -20"), Some("__workspace__".into()));
    }

    #[test]
    fn should_return_none_for_non_test_command() {
        assert_eq!(extract_test_crate_key("cargo build --release"), None);
        assert_eq!(extract_test_crate_key("git status"), None);
    }

    #[test]
    fn should_not_match_test_keyword_in_content_body() {
        // Regression: kavach db write --content "...cargo test..." must NOT trigger
        assert_eq!(extract_test_crate_key(
            r#"kavach db write --project foo --content "6 files pending cargo test execution""#
        ), None);
        assert_eq!(extract_test_crate_key(
            r#"kavach db write --content "run cargo test -p service-soundbak next session""#
        ), None);
    }

    #[test]
    fn should_block_duplicate_test_run() {
        let mut session = kavach_session::SessionState::default();
        session.active_test_crates.push("kavach-engine".into());
        assert!(check_duplicate_test_run(&session, "cargo test -p kavach-engine --lib").is_some());
    }

    #[test]
    fn should_allow_test_run_when_no_active_run() {
        let session = kavach_session::SessionState::default();
        assert!(check_duplicate_test_run(&session, "cargo test -p kavach-engine --lib").is_none());
    }

    #[test]
    fn should_allow_different_crate_test_run() {
        let mut session = kavach_session::SessionState::default();
        session.active_test_crates.push("kavach-db".into());
        assert!(check_duplicate_test_run(&session, "cargo test -p kavach-engine --lib").is_none());
    }

    #[test]
    fn should_block_unscoped_cargo_test() {
        assert!(check_unscoped_test_run("cargo test 2>&1 | tail -20").is_some());
        assert!(check_unscoped_test_run("cargo nextest run --no-fail-fast").is_some());
    }

    #[test]
    fn should_allow_scoped_cargo_test() {
        assert!(check_unscoped_test_run("cargo test -p kavach-engine").is_none());
        assert!(check_unscoped_test_run("cargo nextest run -p kavach-db").is_none());
    }

    #[test]
    fn should_allow_explicit_workspace_flag() {
        assert!(check_unscoped_test_run("cargo nextest run --workspace").is_none());
    }

    #[test]
    fn should_auto_expire_stale_test_tracking() {
        let mut session = kavach_session::SessionState::default();
        session.active_test_crates.push("kavach-engine".into());
        session.turn_count = 20;
        session.last_write_turn = 10; // 10 turns ago — stale
        // Stale entries are skipped (not blocked)
        assert!(check_duplicate_test_run(&session, "cargo test -p kavach-engine").is_none());
    }
}
