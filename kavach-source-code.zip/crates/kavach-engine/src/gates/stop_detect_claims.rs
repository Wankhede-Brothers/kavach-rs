/// Unverified code claim detector for the stop gate.
/// Catches responses that declare code "not implemented" / "placeholder"
/// without evidence of having read the actual source files.
use super::stop_detect::{has_completion_signal, normalize_for_matching};

/// Phrases that claim code doesn't work or isn't implemented.
const CLAIM_PHRASES: &[&str] = &[
    // Direct "not implemented" variants
    "not implemented yet",
    "not yet implemented",
    "not wired to",
    "not connected to",
    "placeholder for",
    "placeholders for",
    "need to be built",
    "needs to be built",
    "need to be implemented",
    "needs to be implemented",
    "doesn't exist yet",
    "does not exist yet",
    "not built yet",
    "not yet built",
    "feature not built",
    "haven't been implemented",
    "hasn't been implemented",
    "has not been implemented",
    "not functional yet",
    "not yet functional",
    "are just placeholders",
    "is just a placeholder",
    "just open the same",
    "these are not simple",
    // Missing functionality claims
    "don't have picker",
    "don't have handler",
    "don't have implementation",
    "doesn't have any handler",
    "doesn't have functionality",
    "no handler for",
    "no click handler",
    "need click handler",
    "need handler",
    "ui-ready but",
    "only work when",
    "only works when",
    // Blanket dismissal patterns
    "these features need",
    "features that need",
    "next phase of",
    "requires full feature",
    "require full feature",
];

/// Evidence markers that indicate the claim was ACTUALLY verified.
/// Must be file-specific — generic code tokens don't count.
const EVIDENCE_MARKERS: &[&str] = &[
    // File path with line number (strongest evidence)
    ".rs:", ".ts:", ".tsx:", ".js:", ".jsx:",
    ".py:", ".go:", ".vue:", ".svelte:",
    "at line", "on line",
    // Code block with actual source
    "```",
    // Explicit verification statements
    "grep found", "read the file", "reading the file",
    "the source shows", "the code shows",
    "reading the component", "checked the implementation",
    "i read", "i checked", "after reading",
    "the file shows", "the component shows",
];

/// Detect unverified claims about code not working or not being implemented.
/// Fires when response claims features are missing WITHOUT showing evidence.
pub fn contains_unverified_code_claim(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }

    let has_claim = CLAIM_PHRASES.iter().any(|p| lower.contains(p));
    if !has_claim { return false; }

    let has_evidence = EVIDENCE_MARKERS.iter().any(|e| lower.contains(e));
    if has_evidence { return false; }

    // Override: if actively building (not just describing), allow
    let is_building = lower.contains("implementing now")
        || lower.contains("building now")
        || lower.contains("creating now")
        || lower.contains("writing the");
    if is_building { return false; }

    true
}

/// Detect blind removal of security-critical code without dependency analysis.
/// Pattern: AI describes removing crypto/auth/security code without showing
/// evidence of checking what depends on it.
pub fn contains_blind_security_removal(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());
    if has_completion_signal(&lower) { return false; }

    // Must contain a removal action + a security domain
    let has_removal = lower.contains("removed") || lower.contains("deleted")
        || lower.contains("stripped") || lower.contains("eliminated");
    let has_security_domain = lower.contains("ed25519") || lower.contains("crypto")
        || lower.contains("signing") || lower.contains("verification")
        || lower.contains("authentication") || lower.contains("encryption")
        || lower.contains("key type") || lower.contains("algorithm");

    if !has_removal || !has_security_domain { return false; }

    // Check for evidence of dependency analysis
    let has_evidence = lower.contains("grep") || lower.contains("searched for")
        || lower.contains("checked all") || lower.contains("verified no")
        || lower.contains("no downstream") || lower.contains("dependency analysis")
        || lower.contains("nothing depends") || lower.contains("safe to remove");

    // Block if removal + security domain but NO evidence of checking
    !has_evidence
}

/// Detect quantitative completion claims: "X bugs fixed", "Y indexes created".
/// These are high-confidence signals of false evidence when paired with empty tests.
pub fn contains_quantitative_claims(msg: &str) -> bool {
    if msg.is_empty() { return false; }
    let lower = normalize_for_matching(&msg.to_lowercase());

    let quant_patterns = [
        "bugs fixed", "bug fixed", "indexes created", "index created",
        "issues resolved", "issue resolved", "errors fixed", "error fixed",
        "queries optimized", "query optimized", "n+1 eliminated",
        "files modified", "endpoints added", "routes added",
        "migrations created", "tables created",
    ];

    // Match "N <pattern>" where N is a digit
    for pattern in &quant_patterns {
        if let Some(pos) = lower.find(pattern) {
            let before = &lower[..pos];
            if before.chars().rev().find(|c| !c.is_whitespace())
                .is_some_and(|c| c.is_ascii_digit())
            {
                return true;
            }
        }
    }
    false
}

#[cfg(test)]
mod tests {
    use super::*;

    // --- contains_blind_security_removal tests ---

    #[test]
    fn test_blind_removal_ed25519_no_evidence() {
        assert!(contains_blind_security_removal(
            "Removed the Ed25519 key type from the config struct."
        ));
    }

    #[test]
    fn test_blind_removal_crypto_no_evidence() {
        assert!(contains_blind_security_removal(
            "Deleted the crypto signing module — it was unused."
        ));
    }

    #[test]
    fn test_blind_removal_algorithm_no_evidence() {
        assert!(contains_blind_security_removal(
            "Stripped the algorithm field from the token header."
        ));
    }

    #[test]
    fn test_blind_removal_authentication_no_evidence() {
        assert!(contains_blind_security_removal(
            "Eliminated the authentication verification step to simplify the flow."
        ));
    }

    #[test]
    fn test_removal_with_grep_evidence() {
        assert!(!contains_blind_security_removal(
            "Removed Ed25519 support. Grep found zero callers — safe to remove."
        ));
    }

    #[test]
    fn test_removal_with_dependency_analysis_evidence() {
        assert!(!contains_blind_security_removal(
            "Deleted the encryption module after dependency analysis confirmed nothing depends on it."
        ));
    }

    #[test]
    fn test_removal_with_searched_for_evidence() {
        assert!(!contains_blind_security_removal(
            "Removed the signing key type. Searched for all usages — verified no downstream consumers."
        ));
    }

    #[test]
    fn test_no_removal_verb() {
        assert!(!contains_blind_security_removal(
            "The Ed25519 algorithm is configured in the auth module."
        ));
    }

    #[test]
    fn test_no_security_domain() {
        assert!(!contains_blind_security_removal(
            "Removed the unused logging helper function."
        ));
    }

    #[test]
    fn test_blind_removal_empty() {
        assert!(!contains_blind_security_removal(""));
    }

    #[test]
    fn test_completion_signal_bypasses() {
        assert!(!contains_blind_security_removal(
            "All tests pass. Removed the Ed25519 key type. cargo test: PASS"
        ));
    }

    // --- contains_quantitative_claims tests ---

    #[test]
    fn test_quantitative_bugs_fixed() {
        assert!(contains_quantitative_claims("4 bugs fixed, 12 indexes created"));
    }

    #[test]
    fn test_quantitative_n_plus_1() {
        assert!(contains_quantitative_claims("2 N+1 eliminated, queries optimized"));
    }

    #[test]
    fn test_quantitative_no_number() {
        assert!(!contains_quantitative_claims("Fixed the login bug and created an index"));
    }

    #[test]
    fn test_quantitative_empty() {
        assert!(!contains_quantitative_claims(""));
    }

    #[test]
    fn test_quantitative_normal_response() {
        assert!(!contains_quantitative_claims("The service is production-ready."));
    }

    // --- contains_unverified_code_claim tests ---

    #[test]
    fn test_unverified_placeholder_claim() {
        assert!(contains_unverified_code_claim(
            "The icons are just placeholders for features that need to be built."
        ));
    }

    #[test]
    fn test_unverified_not_implemented() {
        assert!(contains_unverified_code_claim(
            "Poll creation is not implemented yet. The backend needs work."
        ));
    }

    #[test]
    fn test_unverified_not_wired() {
        assert!(contains_unverified_code_claim(
            "They're not wired to actual media upload functionality."
        ));
    }

    #[test]
    fn test_verified_with_file_path() {
        assert!(!contains_unverified_code_claim(
            "The icons are not wired to upload. See CreatePost.tsx:45 — onClick is empty."
        ));
    }

    #[test]
    fn test_verified_with_code_block() {
        assert!(!contains_unverified_code_claim(
            "Not yet built. The current code:\n```\nfn handle() { unfinished() }\n```"
        ));
    }

    #[test]
    fn test_verified_with_grep() {
        assert!(!contains_unverified_code_claim(
            "Not yet built — grep found no handler for this route."
        ));
    }

    #[test]
    fn test_building_override() {
        assert!(!contains_unverified_code_claim(
            "The upload feature needs to be built. Implementing now."
        ));
    }

    #[test]
    fn test_empty() {
        assert!(!contains_unverified_code_claim(""));
    }

    #[test]
    fn test_normal_code_response() {
        assert!(!contains_unverified_code_claim(
            "Fixed the route handler. 0 errors. All tests pass."
        ));
    }

    #[test]
    fn test_missing_handler_claim() {
        assert!(contains_unverified_code_claim(
            "The emoji buttons don't have handler implementations — they need click handlers."
        ));
    }

    #[test]
    fn test_ui_ready_but_claim() {
        assert!(contains_unverified_code_claim(
            "The buttons are UI-ready but don't have picker functionality."
        ));
    }

    #[test]
    fn test_next_phase_claim() {
        assert!(contains_unverified_code_claim(
            "These features need backend integration. Next phase of work."
        ));
    }

    #[test]
    fn test_verified_with_i_read() {
        assert!(!contains_unverified_code_claim(
            "The buttons don't have handler code. I checked the component — onClick is empty."
        ));
    }
}
