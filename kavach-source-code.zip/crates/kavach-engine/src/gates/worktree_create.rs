use kavach_types::HookInput;

use crate::error::EngineError;

/// WorktreeCreate gate: track active worktrees in session.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let worktree_name = &input.name;

    if !worktree_name.is_empty() {
        let context = kavach_hook::context_block(
            "WORKTREE_CREATE",
            &[
                ("name", worktree_name),
            ],
        );
        kavach_hook::exit_notification_context(&context);
    } else {
        kavach_hook::exit_silent();
    }
    Ok(())
}
