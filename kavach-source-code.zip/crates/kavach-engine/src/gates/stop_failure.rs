use kavach_types::HookInput;

use crate::error::EngineError;

/// Stop-failure gate: handle the stop-failure hook event.
pub fn run(_input: &HookInput) -> Result<(), EngineError> {
    kavach_hook::exit_silent();
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn test_run() { let _ = run(&HookInput::default()); }
}
