use kavach_types::HookInput;

use crate::error::EngineError;

/// Handle Skill tool pre-check: record invocation + inject context.
/// CRITICAL: Skill invocation is recorded HERE (PreToolUse) because
/// PostToolUse may not receive tool_input for the Skill tool.
pub fn handle_skill(input: &HookInput) -> Result<(), EngineError> {
    let skill_name = input.get_string("skill");

    if !skill_name.is_empty() {
        let mut session = kavach_session::get_or_create_session();
        session.record_skill_invoked(skill_name);
    }
    kavach_hook::exit_pre_tool_allow(None);

    Ok(())
}
