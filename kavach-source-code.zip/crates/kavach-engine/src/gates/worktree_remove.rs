use kavach_types::HookInput;

use crate::error::EngineError;

/// WorktreeRemove gate: clean up worktree state.
pub fn run(input: &HookInput) -> Result<(), EngineError> {
    let worktree_path = &input.worktree_path;

    if !worktree_path.is_empty() {
        let context = kavach_hook::context_block(
            "WORKTREE_REMOVE",
            &[
                ("path", worktree_path),
            ],
        );
        kavach_hook::exit_notification_context(&context);
    } else {
        kavach_hook::exit_silent();
    }
    Ok(())
}
