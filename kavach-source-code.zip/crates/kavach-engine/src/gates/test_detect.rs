/// Detect if a source file is missing a corresponding test file.
/// Returns the source file path if no test file exists, None if covered.
pub fn detect_missing_tests(file_path: &str) -> Option<String> {
    if is_test_exempt(file_path) {
        return None;
    }
    let test_path = infer_test_path(file_path)?;
    if std::path::Path::new(&test_path).exists() {
        return None;
    }
    Some(file_path.to_string())
}

fn is_test_exempt(file_path: &str) -> bool {
    file_path.contains("_test")
        || file_path.contains("test_")
        || file_path.contains("/tests/")
        || file_path.ends_with("_tests.rs")
        || file_path.contains("mod.rs")
        || file_path.contains("lib.rs")
        || file_path.contains("main.rs")
}

fn infer_test_path(file_path: &str) -> Option<String> {
    if file_path.ends_with(".rs") {
        let base = file_path.trim_end_matches(".rs");
        return Some(format!("{base}_tests.rs"));
    }
    if file_path.ends_with(".ts") || file_path.ends_with(".tsx") {
        let base = file_path.trim_end_matches(if file_path.ends_with(".tsx") { ".tsx" } else { ".ts" });
        return Some(format!("{base}.test.ts"));
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_exempt_test_file() {
        assert!(detect_missing_tests("src/foo_test.rs").is_none());
    }

    #[test]
    fn test_exempt_lib() {
        assert!(detect_missing_tests("src/lib.rs").is_none());
    }

    #[test]
    fn test_non_rs_exempt() {
        assert!(detect_missing_tests("config.toml").is_none());
    }
}
