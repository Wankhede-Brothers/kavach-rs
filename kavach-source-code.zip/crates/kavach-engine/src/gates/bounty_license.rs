//! License gate: check dependency licenses against blocklist.
//! Uses `cargo metadata` for license info.

use std::process::Command;

const BLOCKED: &[&str] = &[
    "AGPL-3.0", "AGPL-3.0-only", "AGPL-3.0-or-later",
    "GPL-3.0", "GPL-3.0-only", "GPL-3.0-or-later",
    "SSPL", "BSL", "BUSL-1.1",
];

/// Scan dependencies for blocked licenses.
/// Returns Some(block_message) if violations found.
pub fn check(work_dir: &str) -> Option<String> {
    let output = Command::new("cargo")
        .args(["metadata", "--format-version", "1", "--no-deps"])
        .current_dir(work_dir)
        .output();

    let output = match output {
        Ok(o) if o.status.success() => o,
        _ => return None,
    };

    let json: serde_json::Value = match serde_json::from_slice(&output.stdout) {
        Ok(v) => v,
        Err(_) => return None,
    };

    let packages = json.get("packages").and_then(|p| p.as_array())?;

    let mut violations = Vec::new();
    for pkg in packages {
        let name = pkg.get("name").and_then(|n| n.as_str()).unwrap_or("");
        let version = pkg.get("version").and_then(|v| v.as_str()).unwrap_or("");
        let license = pkg.get("license").and_then(|l| l.as_str()).unwrap_or("UNKNOWN");

        let is_blocked = BLOCKED.iter().any(|b| license.contains(b));
        if is_blocked {
            violations.push(format!("  {name}@{version} — license: {license}"));
        }
    }

    if violations.is_empty() { return None; }

    let mut msg = format!(
        "BOUNTY_LICENSE_BLOCK: {} blocked license(s):\n", violations.len()
    );
    for v in &violations {
        msg.push_str(v);
        msg.push('\n');
    }
    msg.push_str("  FIX: Replace dependency or obtain license exception.");
    Some(msg)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn current_project_clean() {
        let workspace = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .parent().and_then(|p| p.parent());
        if let Some(root) = workspace {
            assert!(check(&root.to_string_lossy()).is_none());
        }
    }

    #[test]
    fn returns_none_for_bad_dir() {
        assert!(check("/tmp/no_such_workspace_ever").is_none());
    }

    #[test]
    fn blocked_list_contains_agpl() {
        assert!(BLOCKED.iter().any(|b| b.contains("AGPL")));
    }

    #[test]
    fn blocked_list_contains_gpl() {
        assert!(BLOCKED.iter().any(|b| b.contains("GPL-3.0")));
    }
}
