use std::fmt;
use std::io;

/// Structured error context for gate failures.
/// Enables chain runner to make retry/skip/escalate decisions.
#[derive(Debug, Clone)]
pub struct GateErrorContext {
    pub gate_name: String,
    pub error_category: ErrorCategory,
    pub attempted_action: String,
    pub is_retryable: bool,
}

/// Failure categories for structured error propagation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ErrorCategory {
    /// Timeout, rate limit, connection refused — worth retrying.
    Transient,
    /// Bad input, format error — fix input then retry.
    Validation,
    /// Policy violation, blocked by gate — not retryable.
    Policy,
    /// Access denied — escalate to user.
    Permission,
}

impl fmt::Display for GateErrorContext {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f, "gate={} category={:?} action={} retryable={}",
            self.gate_name, self.error_category,
            self.attempted_action, self.is_retryable,
        )
    }
}

#[derive(Debug, thiserror::Error)]
pub enum EngineError {
    #[error("unknown gate: {0}")]
    UnknownGate(String),

    #[error("session error: {0}")]
    Session(String),

    #[error("io error: {0}")]
    Io(#[from] io::Error),

    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("gate blocked: {0}")]
    Blocked(String),

    #[error("gate error: {0}")]
    GateError(GateErrorContext),
}
