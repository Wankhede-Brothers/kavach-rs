//! Architecture guard check and advisory logic.

use super::detect::{count_arch_fields, detect, has_arch_comment};
use super::types::ArchGuardOutcome;

const REQUIRED_FIELDS: usize = 9;

/// Generate advisory message for arch patterns detected.
pub fn advise(file_path: &str, content: &str) -> Option<String> {
    let findings = detect(file_path, content);
    if findings.is_empty() {
        return None;
    }

    let mut msg = String::from("ARCH_ADVISORY:\n");
    for f in &findings {
        msg.push_str(&format!(
            "  Pattern '{}' (scope: {}) at L{}\n",
            f.keyword,
            f.scope.as_str(),
            f.line
        ));
    }
    msg.push_str("\nREQUIRED: Invoke /arch skill before implementation.\n");
    msg.push_str("DOCUMENT: Add // ARCH: comment with 9 fields.\n");
    Some(msg)
}

/// Check arch guard — returns outcome.
pub fn check(file_path: &str, content: &str, arch_skill_invoked: bool) -> ArchGuardOutcome {
    let findings = detect(file_path, content);

    // No patterns → allow
    if findings.is_empty() {
        return ArchGuardOutcome::Allow;
    }

    // Skill already invoked this turn → allow
    if arch_skill_invoked {
        return ArchGuardOutcome::Allow;
    }

    // Valid ARCH comment present → allow
    if has_arch_comment(content) {
        let field_count = count_arch_fields(content);
        if field_count >= REQUIRED_FIELDS {
            return ArchGuardOutcome::AllowWithComment;
        }
        // Incomplete comment — block with guidance
        return ArchGuardOutcome::Block(format!(
            "ARCH_BLOCK: // ARCH: comment incomplete ({}/{} fields).\n\
             REQUIRED: ARCH, SCOPE, CAP, QPS, STORAGE, FAILURE_MODE, TRADEOFF, SEARCHED, REFERENCE",
            field_count, REQUIRED_FIELDS
        ));
    }

    // No comment, no skill → block
    let scopes: Vec<&str> = findings.iter().map(|f| f.scope.as_str()).collect();
    let unique_scopes: std::collections::HashSet<_> = scopes.iter().collect();
    let scope_list = unique_scopes.into_iter().copied().collect::<Vec<_>>().join(", ");

    ArchGuardOutcome::Block(format!(
        "ARCH_BLOCK: Architectural patterns detected (scopes: {}).\n\
         RESEARCH: WebSearch \"{{pattern}} architecture {{search_year}}\"\n\
         SKILL: Invoke /arch skill before implementation.\n\
         DOCUMENT: Add // ARCH: comment with 9 required fields.",
        scope_list
    ))
}
