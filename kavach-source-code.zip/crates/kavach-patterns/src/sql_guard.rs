use crate::sql_patterns::SQL_P;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SqlSeverity {
    P0Block,
    P1Advisory,
}

#[derive(Debug, Clone)]
pub struct SqlViolation {
    pub severity: SqlSeverity,
    pub pattern: String,
    pub fix: String,
    pub line: usize,
}

pub fn detect(file_path: &str, content: &str) -> Vec<SqlViolation> {
    if content.is_empty() {
        return vec![];
    }
    let ext = file_path.to_lowercase();
    let is_sql = ext.ends_with(".sql")
        || ext.ends_with(".rs")
        || ext.ends_with(".ts")
        || ext.ends_with(".go");
    if !is_sql {
        return vec![];
    }

    let r = &*SQL_P;
    let mut violations = Vec::new();

    for (i, line) in content.lines().enumerate() {
        if r.first().is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P0Block,
                pattern: "format!() with SQL".into(),
                fix: "Replace with sqlx::query!() using $1 params. Invoke /sql".into(),
                line: i + 1,
            });
        }
        if r.get(1).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P0Block,
                pattern: "SELECT *".into(),
                fix: "List columns explicitly — SELECT col1, col2 FROM".into(),
                line: i + 1,
            });
        }
        if r.get(2).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P0Block,
                pattern: "DELETE without WHERE".into(),
                fix: "Add WHERE clause to scope the deletion".into(),
                line: i + 1,
            });
        }
        if r.get(3).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P0Block,
                pattern: "GRANT ALL/SUPERUSER".into(),
                fix: "Grant specific privileges only — least-privilege principle".into(),
                line: i + 1,
            });
        }
        if r.get(4).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P0Block,
                pattern: "hardcoded PASSWORD".into(),
                fix: "Read password from environment variable instead".into(),
                line: i + 1,
            });
        }
        if r.get(5).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P1Advisory,
                pattern: "OFFSET pagination".into(),
                fix: "Replace OFFSET with keyset/cursor pagination. Invoke /sql".into(),
                line: i + 1,
            });
        }
        if r.get(6).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P1Advisory,
                pattern: "DROP TABLE".into(),
                fix: "Move to a migration file — no DROP in application code".into(),
                line: i + 1,
            });
        }
        if r.get(7).is_some_and(|re| re.is_match(line)) {
            violations.push(SqlViolation {
                severity: SqlSeverity::P1Advisory,
                pattern: "TRUNCATE".into(),
                fix: "Replace TRUNCATE with DELETE WHERE for safe row removal".into(),
                line: i + 1,
            });
        }
    }

    violations
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn p0_select_star() {
        let v = detect("migrate.sql", "SELECT * FROM users;");
        assert!(v.iter().any(|x| x.severity == SqlSeverity::P0Block));
    }
    #[test]
    fn p0_format_sql() {
        let v = detect(
            "repo.rs",
            r#"format!("SELECT * FROM {} WHERE id = {}", table, id)"#,
        );
        assert!(v.iter().any(|x| x.severity == SqlSeverity::P0Block));
    }
    #[test]
    fn clean_sql() {
        let v = detect(
            "repo.rs",
            r#"sqlx::query!("SELECT id, name FROM users WHERE id = $1")"#,
        );
        assert!(v.is_empty());
    }
}
