mod config;
mod file_types;
mod checks;
mod regex_patterns;
mod detect;
pub(crate) mod rust_patterns;
pub(crate) mod ts_patterns;
pub(crate) mod sql_patterns;
pub mod rust_guard;
pub mod ts_guard;
pub mod sql_guard;

pub use config::{AntiProdLevel, AntiProdResult, Config, load, reload};
pub use file_types::{
    is_frontend_file, is_backend_file, is_rust_file, is_go_file,
    is_python_file, is_java_file, is_astro_file, is_dockerfile,
    is_shell_file, is_test_file, is_handler_file, is_non_config_file,
    is_api_client_file,
};
pub use checks::{
    is_sensitive, is_blocked, is_code_file, is_infra_file, is_large_file,
    is_valid_agent, classify_intent, sanitize_path, validate_identifier,
};
pub use detect::{detect_mock_data, detect_antiprod};

pub mod owasp_guard;
pub mod crypto_guard;
pub mod complexity_guard;
pub mod algo_complexity_guard;
pub mod secrecy_guard;
pub mod alloc_guard;
pub mod frontend_security_guard;
pub mod a11y_guard;
pub mod banned_css_guard;
pub mod ux_guard;
pub mod db_security_guard;
pub mod arch_guard;

pub mod skill_keyword_router;
pub mod api_gateway;
