use crate::config::j;
use regex::Regex;
use std::sync::LazyLock;

fn mk(p: &str) -> Regex {
    Regex::new(p).expect("rust pattern must compile")
}

fn build() -> Vec<Regex> {
    let unwrp = j(&[".unw", "rap()"]);
    let uwor = j(&[".unw", r"rap_or\("]);
    let uworelse = j(&[".unw", r"rap_or_else\("]);
    let uwordef = j(&[".unw", r"rap_or_default\(\)"]);
    let pln = j(&["pri", "nt", "ln!"]);
    let epln = j(&["epr", "int", "ln!"]);
    let prt = j(&["pri", "nt!"]);
    let eprt = j(&["epr", "int!"]);
    let s1 = j(&["to", "do!"]);
    let s2 = j(&["uni", "mple", "mented!"]);
    let pe = j(&["pro", "cess", "::", "exit"]);
    let dbm = j(&["db", "g!"]);
    let pnc = j(&["pan", "ic!"]);
    let mc = r"\s*\(";

    vec![
        mk(&format!(r"\{unwrp}")),                            // 0 P0
        mk(&format!(r"\b{pnc}{mc}")),                         // 1 P0
        mk(&format!(r"(?:std::)?{pe}{mc}")),                  // 2 P0
        mk(r" as\s+(?:u8|i16|u16|i32|u32)\b"),                // 3 P0 narrowing cast
        mk(&format!(r"\b{dbm}{mc}")),                         // 4 P1
        mk(&format!(r"\b(?:{pln}|{epln}|{prt}|{eprt}){mc}")), // 5 P1
        mk(&format!(r"\b(?:{s1}|{s2}){mc}")),                 // 6 P1
        mk(r"\bunsafe\s*\{"),                                 // 7 P1 (without SAFETY comment)
        mk(r"#\[allow\(dead_code\)\]"),                       // 8 P3
        mk(r"#\[allow\(unused"),                              // 9 P3
        mk(r"#\[allow\(clippy::"),                            // 10 P3
        mk(r#"\.expect\(\s*"[^"]{0,20}"\s*\)"#),              // 11 P2
        mk(r"\.clone\(\)"),                                   // 12 P2 (excessive)
        mk(&format!(r"\{uwor}")),                              // 13 P1 hides errors behind defaults
        mk(&format!(r"\{uworelse}")),                         // 14 P1 swallows error context
        mk(&format!(r"\{uwordef}")),                          // 15 P1 hides errors behind default
        mk(r"\.ok\(\)"),                                      // 16 P1 silently discards Err→None
        mk(r"\w+\[\w+\]"),                                   // 17 P2 direct indexing — use .get()
        mk(r"\.\.\s*Default::default\(\)"),                    // 18 P0 hidden fields via Default
        mk(r"^\s*_\s*=>"),                                       // 19 P0 wildcard catch-all in match
        mk(r#"#\[serde\(default\)\]\s*\n?\s*pub\s+\w+:\s*bool"#), // 20 P0 serde default on bool
        mk(r"(?m)^\s*(?:pub\s+)?fn\s+\w+\s*\([^)]*\)\s*(?:->\s*\S+\s*)?\{\s*\}"), // 21 P0 empty fn body
        mk(r"(?i)(?:StatusCode::OK|200)\s*.*(?:error|err|fail|invalid|unauthorized|denied)"), // 22 P0 200 with error
        mk(r"(?i)StatusCode::INTERNAL_SERVER_ERROR\s*.*(?:valid|input|missing|required|format)"), // 23 P0 500 for validation
        // Encapsulation: pub fields on structs that should use accessors
        mk(r"(?m)^\s*pub\s+\w+\s*:\s*(?:String|Vec|HashMap|Option|bool|i32|i64|u32|u64|f64|usize)"), // 24 P1 pub field
        // Optimization: Vec::new() followed by push in loop without with_capacity
        mk(r"(?s)let\s+(?:mut\s+)?\w+\s*=\s*Vec::new\(\)\s*;[^;]{0,200}(?:for|while|loop)\b"), // 25 P1 vec no capacity
        // Abstraction: concrete type in function param instead of trait/generic
        mk(r"fn\s+\w+\s*\([^)]*:\s*&(?:Vec|String|HashMap)<"), // 26 P1 concrete type param
        // Polymorphism: downcast or type check instead of trait dispatch
        mk(r"(?:\.downcast|TypeId::of|Any::type_id|is::<)"), // 27 P1 manual type dispatch
        // Validation: handler with extract but no validate/check/verify
        mk(r"(?s)(?:Json|Query|Path|Form)<[^>]+>\s*\)\s*(?:->.*?)?\{[^}]{0,300}\}"), // 28 P1 no validation
        // Bool parameter anti-pattern — use enums instead
        mk(r"fn\s+\w+\s*\([^)]*:\s*bool\s*[,)]"), // 29 P1 bool param
        // API protocol presence markers
        mk(r"WebSocketUpgrade|ws::Message|WebSocket"), // 30 WebSocket
        mk(r"Sse::new|sse::Event|SseStream"),          // 31 SSE
        mk(&format!(r"(?:async_{}|juniper|MergedObject)", j(&["gra","ph"]))), // 32 GQL
        mk(&format!(r"(?:{}::|{}Service|\.proto\b)", j(&["ton","ic"]), j(&["Gr","pc"]))), // 33 RPC
        mk(&format!(r"(?:{}::|{}::|{})", j(&["h","3"]), j(&["qui","nn"]), j(&["Http","3"]))), // 34 H3
        // REST-only router (presence marker for advisory)
        mk(r"Router::new\(\)\s*(?:\.route\()+"), // 35 Router
        // Async: mutex lock held across await point (deadlock)
        mk(r"(?s)\.lock\(\)[^;]{0,100}\.await"), // 36 P0 lock across await
        // Async: no timeout on external call
        mk(r"(?:reqwest|hyper|Client).*\.send\(\)\.await"), // 37 P1 no timeout
        // Microservice: body limit layer presence marker (checked inversely)
        mk(r"\.layer\(.*(?:DefaultBodyLimit|RequestBodyLimit)"), // 38 body limit present
        // DSA: .contains() on Vec inside loop — O(n²)
        mk(r#"(?s)for\s+\w+\s+in\s+.*\{[^}]*\.contains\("#), // 39 P0 linear search in loop
        // DSA: String concatenation in loop (use push_str or with_capacity)
        mk(r#"(?s)for\s+\w+\s+in\s+.*\{[^}]*(?:format!\(|String::from\()"#), // 40 P1 string alloc in loop
        // Unbounded allocation: Vec::push in handler without capacity limit
        mk(r#"(?s)(?:async\s+fn|pub\s+async\s+fn)\s+\w+.*\.push\("#), // 41 P1 unbounded push in handler
        // HTTP client timeout presence marker (checked inversely)
        mk(r"\.timeout\("), // 42 timeout present
        // Chatty service: multiple sequential .await to same base URL
        mk(r#"(?s)\.await.{0,5};.{0,100}\.await.{0,5};.{0,100}\.await"#), // 43 P1 chatty sequential awaits
        // God class: too many fn in one impl block (presence marker — counted)
        mk(r"(?m)^\s*(?:pub\s+)?(?:async\s+)?fn\s+\w+"), // 44 fn count marker
        // Magic numbers: bare numeric literals in logic (not const/let binding)
        mk(r"(?:if|while|match|==|!=|>=|<=|>|<)\s*\d{2,}"), // 45 P1 magic number
        // Long if/else chain — use enum/match instead
        mk(r#"(?s)if\s+.*\{[^}]*\}\s*else\s+if\s+.*\{[^}]*\}\s*else\s+if"#), // 46 P1 if/else chain
        // Hardcoded string in logic (not const)
        mk(r#"(?:==|!=)\s*"[a-zA-Z_]{3,}""#), // 47 P1 magic string
        // Blanket sqlx error to 500: #[from] sqlx::Error without code inspection
        mk(r#"#\[from\]\s*(?:sqlx::Error|SqlxError)"#), // 48 P1 blanket sqlx→500
        // INTERNAL_SERVER_ERROR in Err arm without matching on error variant
        mk(r#"(?s)Err\s*\(\s*\w+\s*\)\s*=>\s*\{[^}]{0,200}INTERNAL_SERVER_ERROR"#), // 49 P1 blanket 500 in Err
    ]
}

pub(crate) static RUST_P: LazyLock<Vec<Regex>> = LazyLock::new(build);
