use regex::Regex;
use crate::config::{AntiProdLevel, AntiProdResult};
use crate::file_types::*;
use crate::regex_patterns::{P, fbase};
fn ck(v: &mut Vec<AntiProdResult>, re: &Regex, c: &str, lv: AntiProdLevel, code: &'static str, mt: &str, msg: &'static str) { if re.is_match(c) { a(v,lv,code,mt,msg); } }
fn a(v: &mut Vec<AntiProdResult>, lv: AntiProdLevel, code: &'static str, mt: &str, msg: &'static str) { v.push(AntiProdResult{level:lv,code,match_text:mt.into(),message:msg}); }
pub fn detect_mock_data(fp: &str, content: &str) -> Option<String> {
    if content.is_empty()||is_allowlisted(fp) { return None; }
    let r = &*P;
    if is_frontend_file(fp) {
        if let Some(m) = r[46].find(content) { return Some(format!("frontend_mock_const:{}", m.as_str().trim())); }
        if r[47].is_match(content) { return Some("frontend_hardcoded_array".into()); }
        if r[48].is_match(content) { return Some("frontend_useState_hardcoded".into()); }
        if let Some(m) = r[49].find(content) { return Some(format!("frontend_fake_engagement:{}", m.as_str())); }
    }
    if is_backend_file(fp) && r[50].is_match(content) { return Some("backend_hardcoded_json_vec".into()); }
    None
}

pub fn detect_antiprod(fp: &str, content: &str) -> Vec<AntiProdResult> {
    if content.is_empty()||is_allowlisted(fp) { return vec![]; }
    let (mut res, r) = (Vec::new(), &*P);
    if let Some(reason) = detect_mock_data(fp, content) { a(&mut res, AntiProdLevel::P0MockData, "MOCK_DATA", &reason, "Replace hardcoded data."); }
    if is_frontend_file(fp) {
        ck(&mut res,&r[0],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","console.log","Remove debug output.");
        for line in content.lines() { if r[3].is_match(line)&&!has_env_fallback(line) { a(&mut res,AntiProdLevel::P1ProdLeak,"PROD_LEAK","proc.env no fallback","Add ?? fallback."); break; } }
        ck(&mut res,&r[13],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","eval()","Code injection.");
        ck(&mut res,&r[14],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","new Function()","eval equiv.");
        ck(&mut res,&r[15],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","document.write","XSS risk.");
        ck(&mut res,&r[11],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","dangerousSetHTML","XSS risk.");
        ck(&mut res,&r[12],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","innerHTML =","XSS risk.");
    }
    // Task-marker check: skip lines where the match is inside a quoted string literal.
    // String-literal status values like "todo" / "done" are legitimate — only flag
    // bare markers in comments or identifiers (e.g. `// TODO:`, `todo!()`, `FIXME`).
    {
        let has_bare_marker = content.lines().any(|line| {
            r[1].is_match(line) && !is_marker_inside_string(line)
        });
        if has_bare_marker {
            a(&mut res, AntiProdLevel::P1ProdLeak, "PROD_LEAK", "task-marker", "Implement or create ticket.");
        }
    }
    if is_non_config_file(fp) { ck(&mut res,&r[2],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","localhost","Use config var."); }
    // 501 NOT_IMPLEMENTED detection is valid for any file mentioning HTTP.
    ck(&mut res,&r[51],content,AntiProdLevel::P0MockData,"STUB_501","501 NOT_IMPLEMENTED","Implement handler NOW — no 501 stubs.");
    // STUB_BODY / STATUS_MISUSE / EMPTY_RESPONSE / NESTED_LOOP / N_PLUS_1 are
    // handler-shaped anti-patterns. They produce false positives on ordinary
    // library/CLI code (e.g. Ok(()) terminators, string literals containing
    // "placeholder", tree-traversal nested iteration). Only fire them when
    // the file looks like an HTTP handler / route module.
    if is_handler_file(fp) {
        ck(&mut res,&r[52],content,AntiProdLevel::P0MockData,"STUB_BODY","stub response body","Implement real response — no placeholder text.");
        ck(&mut res,&r[53],content,AntiProdLevel::P0MockData,"STATUS_MISUSE","500 for auth","Use 401/403 not 500 for auth failures.");
        ck(&mut res,&r[54],content,AntiProdLevel::P0MockData,"STATUS_MISUSE","404 for forbidden","Use 403 not 404 for authorization failures.");
        ck(&mut res,&r[55],content,AntiProdLevel::P0MockData,"STATUS_MISUSE","200+error body","Return proper 4xx/5xx, not 200 with error JSON.");
        ck(&mut res,&r[56],content,AntiProdLevel::P0MockData,"N_PLUS_1","query inside loop","Extract query before loop — N+1 causes O(n) DB round trips.");
        ck(&mut res,&r[57],content,AntiProdLevel::P1ProdLeak,"NESTED_LOOP","nested loop O(n²)","Use HashMap lookup, index, or single-pass algorithm.");
        ck(&mut res,&r[58],content,AntiProdLevel::P0MockData,"EMPTY_RESPONSE","empty response body","Return meaningful data — empty responses hide unimplemented handlers.");
    }
    if is_rust_file(fp) {
        ck(&mut res,&r[17],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","debug-macro","Remove debug macro.");
        ck(&mut res,&r[18],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","print-macro","Use tracing/log.");
        ck(&mut res,&r[19],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","stub-macro","Implement first.");
        let b = fbase(fp);
        if r[21].is_match(content)&&b!="main.rs" { a(&mut res,AntiProdLevel::P1ProdLeak,"PROD_LEAK","rs-abort-macro","Return Result."); }
        if r[22].is_match(content)&&b!="main.rs" { a(&mut res,AntiProdLevel::P1ProdLeak,"PROD_LEAK","proc-exit","Skips destructors."); }
        if r[20].is_match(content)&&!content.contains("// SAFETY:") { a(&mut res,AntiProdLevel::P1ProdLeak,"PROD_LEAK","unsafe block","Add // SAFETY:."); }
    }
    if is_go_file(fp) {
        ck(&mut res,&r[28],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","fmt.Print","Use structured logger.");
        if r[32].is_match(content)&&fbase(fp)!="main.go" { a(&mut res,AntiProdLevel::P1ProdLeak,"PROD_LEAK","os.Exit outside main","Return error."); }
    }
    if is_python_file(fp) { ck(&mut res,&r[33],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","print()","Use logging."); ck(&mut res,&r[37],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","eval/exec","Injection risk."); }
    if is_java_file(fp) { ck(&mut res,&r[38],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","System.out","Use SLF4J."); }
    if is_dockerfile(fp) {
        ck(&mut res,&r[41],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","FROM :latest","Pin version.");
        if !r[45].is_match(content) { a(&mut res,AntiProdLevel::P1ProdLeak,"PROD_LEAK","no USER directive","Runs as root."); }
    }
    ck(&mut res,&r[42],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","broad-perms","Use least-privilege.");
    if is_dockerfile(fp)||is_shell_file(fp) { ck(&mut res,&r[43],content,AntiProdLevel::P1ProdLeak,"PROD_LEAK","curl|bash","Verify first."); }
    if is_frontend_file(fp) {
        ck(&mut res,&r[4],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND",".catch(()=>{})","Handle errors.");
        ck(&mut res,&r[5],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","non-null (!.)","Use ?..");
        if r[6].is_match(content)&&!content.contains(".catch")&&!content.contains("try") { a(&mut res,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","fetch no error","try/catch."); }
    }
    // API contract drift: NOT_IMPLEMENTED comment in a frontend API client file.
    // Scoped to API client files only — not UI components, hooks, or utilities.
    // These comments survive after the backend route is wired — stale forever.
    // P1: the UI silently returns empty data; users see blank screens, not errors.
    if is_api_client_file(fp) {
        ck(&mut res,&r[59],content,AntiProdLevel::P1ProdLeak,"API_DRIFT","NOT_IMPLEMENTED comment","Backend may be implemented — verify route exists and remove stale comment.");
        // Pattern 60 matches any https?:// in a fetch/axios call; filter localhost here
        // since localhost is already caught by PROD_LEAK (pattern 2).
        if r[60].is_match(content) && !content.contains("localhost") {
            a(&mut res,AntiProdLevel::P1ProdLeak,"HARDCODED_URL","hardcoded API base URL","Use env var (import.meta.env.VITE_API_URL) — hardcoded URLs break env promotion.");
        }
        ck(&mut res,&r[61],content,AntiProdLevel::P1ProdLeak,"EMPTY_FETCH","async fn returns hardcoded empty","Fetch from API — hardcoded [] or {} hides unimplemented routes.");
        // AUTH_LEAK: token variable declared but no Authorization header in fetch calls.
        // Two conditions must both be true: token-like var exists AND fetch is called without headers.
        {
            let has_token_var = content.contains("accessToken") || content.contains("authToken") || content.contains("bearerToken");
            let has_fetch = content.contains("fetch(") || content.contains("axios.");
            let has_auth_header = content.contains("Authorization") || content.contains("authorization");
            if has_token_var && has_fetch && !has_auth_header {
                a(&mut res,AntiProdLevel::P1ProdLeak,"AUTH_LEAK","token defined but not forwarded","Add Authorization header to fetch — token is in scope but not sent.");
            }
        }
    }
    if is_rust_file(fp) {
        if r[16].is_match(content)&&is_handler_file(fp) { a(&mut res,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","unwrap-in-handler","Use ?."); }
        ck(&mut res,&r[26],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","expect-generic","Rich message.");
        if r[27].find_iter(content).count()>10 { a(&mut res,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","excessive-clone","Borrow instead."); }
    }
    if is_go_file(fp) {
        if r[29].is_match(content)&&fbase(fp)!="main.go" { a(&mut res,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","go-abort","Return error."); }
        ck(&mut res,&r[30],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","_ = (discard)","Handle error.");
    }
    if is_python_file(fp) { ck(&mut res,&r[34],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","bare except","Handle explicitly."); ck(&mut res,&r[35],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","type: ignore","Add annotation."); }
    if is_java_file(fp) { ck(&mut res,&r[39],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","empty catch","Handle exception."); }
    if is_dockerfile(fp) { ck(&mut res,&r[44],content,AntiProdLevel::P2ErrorBlind,"ERROR_BLIND","ADD not COPY","Use COPY."); }
    if is_frontend_file(fp) {
        ck(&mut res,&r[7],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","as any","Type narrow.");
        ck(&mut res,&r[8],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","@ts-ignore","Fix type.");
        ck(&mut res,&r[9],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","eslint-disable","Fix lint.");
        ck(&mut res,&r[10],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","@ts-nocheck","Fix types.");
    }
    if is_go_file(fp) { ck(&mut res,&r[31],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","nolint","Fix lint."); }
    if is_python_file(fp) { ck(&mut res,&r[36],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","noqa","Fix lint."); }
    if is_java_file(fp) { ck(&mut res,&r[40],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","@SuppressWarnings","Fix types."); }
    if is_rust_file(fp) {
        ck(&mut res,&r[23],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","allow(dead_code)","Remove dead.");
        ck(&mut res,&r[24],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","allow(unused)","Use or remove.");
        ck(&mut res,&r[25],content,AntiProdLevel::P3TypeLoose,"TYPE_LOOSE","allow(clippy::)","Fix warning.");
    }
    res
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::j;
    #[test] fn test_p1() { let m=j(&["// ","TO","DO",": later"]); assert!(detect_antiprod("a.ts",&m).iter().any(|x| x.level==AntiProdLevel::P1ProdLeak)); }
    #[test] fn test_p2() { assert!(detect_antiprod("a.ts","promise.catch(() => {})").iter().any(|x| x.level==AntiProdLevel::P2ErrorBlind)); }
    #[test] fn test_p3() { assert!(detect_antiprod("a.ts","const x = foo as any;").iter().any(|x| x.level==AntiProdLevel::P3TypeLoose)); }
    #[test] fn test_allow() { let m=j(&["// ","TO","DO"]); assert!(detect_antiprod("src/tests/a.test.ts",&m).is_empty()); }
    #[test] fn test_docker() { let r=detect_antiprod("Dockerfile","FROM node:latest\nRUN npm i"); assert!(r.iter().any(|x| x.match_text.contains("latest"))); }
    #[test] fn test_mock() { assert!(detect_mock_data("a.tsx","const mockUsers = [").is_some()); }
    #[test] fn test_501_rust() { assert!(detect_antiprod("h.rs","StatusCode::NOT_IMPLEMENTED").iter().any(|x| x.code=="STUB_501")); }
    #[test] fn test_501_ts() { assert!(detect_antiprod("h.ts","res.status(501)").iter().any(|x| x.code=="STUB_501")); }
    #[test] fn test_stub_body_in_handler() { assert!(detect_antiprod("src/handler.rs",r#""not implemented""#).iter().any(|x| x.code=="STUB_BODY")); }
    #[test] fn test_n_plus_1_in_handler() {
        let code = "for user in users {\n    let posts = query(\"SELECT id, name FROM posts WHERE user_id = $1\");\n}";
        assert!(detect_antiprod("src/handler.rs", code).iter().any(|x| x.code == "N_PLUS_1"));
    }
    #[test] fn test_nested_loop_in_handler() {
        let code = "for a in items {\n    for b in items {\n        if a == b { count += 1; }\n    }\n}";
        assert!(detect_antiprod("src/handler.rs", code).iter().any(|x| x.code == "NESTED_LOOP"));
    }
    #[test] fn test_empty_response_in_handler() {
        let j = crate::config::j;
        let code = j(&["Ok(Json(json!(", "{})))"]);
        assert!(detect_antiprod("src/handler.rs", &code).iter().any(|x| x.code == "EMPTY_RESPONSE"));
    }
    #[test] fn test_status_misuse_in_handler() {
        assert!(detect_antiprod("src/handler.rs", "StatusCode::NOT_IMPLEMENTED").iter().any(|x| x.level == AntiProdLevel::P0MockData));
    }

    // Context-aware negative tests: these patterns produce false positives on
    // ordinary library/CLI code. They must NOT fire on non-handler paths.
    #[test] fn should_not_flag_empty_response_in_library_module() {
        // A Result terminator in a non-handler file is legitimate, not a stub.
        let code = "pub fn sync() -> Result<()> { Ok(()) }";
        let hits = detect_antiprod("src/sync_logic.rs", code);
        assert!(!hits.iter().any(|x| x.code == "EMPTY_RESPONSE"));
    }

    #[test] fn should_not_flag_nested_loop_in_tree_traversal_module() {
        // Recursive tree iteration is unavoidably nested; not an O(n^2) smell.
        let code = "for tree in &trees {\n    for child in &tree.children {\n        visit(child);\n    }\n}";
        let hits = detect_antiprod("src/walker.rs", code);
        assert!(!hits.iter().any(|x| x.code == "NESTED_LOOP"));
    }

    #[test] fn should_not_flag_stub_body_in_doc_comment() {
        // A string literal containing the word "placeholder" inside a library
        // module comment/fixture is not a handler stub.
        let code = r#"/// Matches "placeholder" keyword in the RAG metadata."#;
        let hits = detect_antiprod("src/matcher.rs", code);
        assert!(!hits.iter().any(|x| x.code == "STUB_BODY"));
    }
    #[test] fn test_api_drift_frontend() {
        let content = "/** NOT_IMPLEMENTED: Backend route /soundbak/users/{id}/likes — returns empty array fallback */\ngetUserLikes: async () => adaptResponse(data, 'posts');";
        let hits = detect_antiprod("src/lib/api/soundbak.ts", content);
        assert!(hits.iter().any(|x| x.code == "API_DRIFT"), "should flag NOT_IMPLEMENTED in frontend API file");
    }
    #[test] fn test_api_drift_not_fired_in_rust() {
        // NOT_IMPLEMENTED in a Rust file (e.g. StatusCode comment) must not trigger API_DRIFT
        let content = "// NOT_IMPLEMENTED: placeholder";
        let hits = detect_antiprod("src/handler.rs", content);
        assert!(!hits.iter().any(|x| x.code == "API_DRIFT"), "API_DRIFT must not fire on Rust files");
    }
    #[test] fn test_api_drift_not_fired_in_ui_component() {
        // NOT_IMPLEMENTED in a UI component — not an API client file — must not trigger API_DRIFT
        let content = "// NOT_IMPLEMENTED yet";
        let hits = detect_antiprod("src/components/Button.tsx", content);
        assert!(!hits.iter().any(|x| x.code == "API_DRIFT"), "API_DRIFT must not fire on UI components");
    }
    #[test] fn test_hardcoded_url_in_api_client() {
        let content = r#"fetch("https://api.example.com/users")"#;
        let hits = detect_antiprod("src/api/users.ts", content);
        assert!(hits.iter().any(|x| x.code == "HARDCODED_URL"), "should flag hardcoded https URL in API client");
    }
    #[test] fn test_hardcoded_url_not_fired_for_localhost() {
        // localhost URLs are already caught by PROD_LEAK — not HARDCODED_URL
        let content = r#"fetch("http://localhost:3000/users")"#;
        let hits = detect_antiprod("src/api/users.ts", content);
        assert!(!hits.iter().any(|x| x.code == "HARDCODED_URL"), "localhost must not trigger HARDCODED_URL");
    }
    #[test] fn test_empty_fetch_in_api_client() {
        let content = "async function getUsers() {\n  return [];\n}";
        let hits = detect_antiprod("src/api/users.ts", content);
        assert!(hits.iter().any(|x| x.code == "EMPTY_FETCH"), "should flag hardcoded empty return in API client");
    }
    #[test] fn test_print_macro_rust() {
        let j = crate::config::j;
        let p = j(&["pri","nt!","(\"leak\")"]);
        assert!(detect_antiprod("h.rs", &p).iter().any(|x| x.match_text.contains("print-macro")));
    }
    #[test] fn test_eprint_macro_rust() {
        let j = crate::config::j;
        let e = j(&["epr","int!","(\"err\")"]);
        assert!(detect_antiprod("h.rs", &e).iter().any(|x| x.match_text.contains("print-macro")));
    }
}
