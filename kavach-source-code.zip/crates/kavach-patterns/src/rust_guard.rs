use crate::rust_patterns::RUST_P;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RustSeverity {
    P0Block,
    P1Advisory,
    P2Warning,
    P3Info,
}

#[derive(Debug, Clone)]
pub struct RustViolation {
    pub severity: RustSeverity,
    pub pattern: String,
    pub fix: String,
    pub line: usize,
}

pub fn detect(file_path: &str, content: &str) -> Vec<RustViolation> {
    if !crate::file_types::is_rust_file(file_path) || content.is_empty() {
        return vec![];
    }
    if crate::file_types::is_test_file(file_path)
        || crate::file_types::is_allowlisted(file_path)
    {
        return vec![];
    }

    let r = &*RUST_P;
    let mut violations = Vec::new();
    let base = crate::regex_patterns::fbase(file_path);
    let has_safety = content.contains("// SAFETY:");

    for (i, line) in content.lines().enumerate() {
        if r.first().is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "unwrap()".into(),
                fix: "Replace with ? or match. Invoke /m06-error-handling for propagation patterns".into(),
                line: i + 1,
            });
        }
        if r.get(1).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "panic!".into(),
                fix: "Return Result<T, E> instead. Invoke /m06-error-handling".into(),
                line: i + 1,
            });
        }
        if r.get(2).is_some_and(|re| re.is_match(line)) && base != "main.rs" {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "process::exit".into(),
                fix: "Return Err from main instead. Invoke /m06-error-handling".into(),
                line: i + 1,
            });
        }
        if r.get(3).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "narrowing cast".into(),
                fix: "Replace with TryFrom::try_from() or .try_into()".into(),
                line: i + 1,
            });
        }
        if r.get(4).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "dbg!".into(),
                fix: "Remove dbg! macro before committing".into(),
                line: i + 1,
            });
        }
        if r.get(5).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "print macro".into(),
                fix: "Replace with writeln!(io::stdout().lock(), ...) or tracing".into(),
                line: i + 1,
            });
        }
        if r.get(6).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "todo!/unimplemented!".into(),
                fix: "Implement the logic now — no stubs allowed".into(),
                line: i + 1,
            });
        }
        if r.get(7).is_some_and(|re| re.is_match(line)) && !has_safety {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "unsafe block".into(),
                fix: "Add // SAFETY: comment explaining the invariant. Invoke /unsafe-checker".into(),
                line: i + 1,
            });
        }
        if r.get(13).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "unwrap_or".into(),
                fix: "Propagate with map_err + ? to preserve error context".into(),
                line: i + 1,
            });
        }
        if r.get(14).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "unwrap_or_else".into(),
                fix: "Propagate with map_err + ? instead of swallowing errors".into(),
                line: i + 1,
            });
        }
        if r.get(15).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "unwrap_or_default".into(),
                fix: "Handle with match or ok_or + ? — defaults hide failures".into(),
                line: i + 1,
            });
        }
        if r.get(16).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "result.ok()".into(),
                fix: "Log or propagate the error — .ok() silently discards Err".into(),
                line: i + 1,
            });
        }
        if r.get(17).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "direct indexing".into(),
                fix: "Replace v[i] with .get(i) and handle None".into(),
                line: i + 1,
            });
        }
        if r.get(18).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "..Default::default()".into(),
                fix: "Destructure every field explicitly — hidden defaults mask unset fields".into(),
                line: i + 1,
            });
        }
        if r.get(19).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "_ => catch-all".into(),
                fix: "Enumerate every variant — catch-all hides unhandled cases".into(),
                line: i + 1,
            });
        }
        if r.get(8).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P0Block,
                pattern: "allow(dead_code)".into(),
                fix: "Delete dead code instead of suppressing the warning".into(),
                line: i + 1,
            });
        }
        if r.get(9).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P3Info,
                pattern: "allow(unused)".into(),
                fix: "Use the value or delete the binding".into(),
                line: i + 1,
            });
        }
        if r.get(10).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P3Info,
                pattern: "allow(clippy::)".into(),
                fix: "Fix the clippy warning instead of suppressing it".into(),
                line: i + 1,
            });
        }
    }

    // Multiline: #[serde(default)] on bool fields (index 20)
    if r.get(20).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "#[serde(default)] on bool".into(),
            fix: "Use Option<bool> — serde default on bool creates privilege escalation vector".into(),
            line: 0,
        });
    }

    // Multiline: empty function body (index 21)
    if r.get(21).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "empty function body".into(),
            fix: "Implement the function — empty bodies silently pass as complete".into(),
            line: 0,
        });
    }

    // Multiline: 200 with error content (index 22)
    if r.get(22).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "200 OK with error".into(),
            fix: "Return proper 4xx/5xx status code — 200 with error body breaks clients".into(),
            line: 0,
        });
    }

    // Multiline: 500 for validation errors (index 23)
    if r.get(23).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "500 for validation".into(),
            fix: "Use 400/422 for validation errors — 500 indicates server bug, not bad input".into(),
            line: 0,
        });
    }

    if r.get(11).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "expect-generic".into(),
            fix: "Replace .expect() with ? or map_err for structured errors".into(),
            line: 0,
        });
    }

    let clone_count: usize = match r.get(12) {
        Some(re) => re.find_iter(content).count(),
        None => 0,
    };
    if clone_count > 10 {
        violations.push(RustViolation {
            severity: RustSeverity::P2Warning,
            pattern: "excessive-clone".into(),
            fix: "Borrow instead of cloning. Invoke /m01-ownership for borrow patterns".into(),
            line: 0,
        });
    }

    // Encapsulation: pub fields on structs (index 24)
    // Count pub field declarations — more than 3 suggests missing encapsulation
    let pub_field_count: usize = match r.get(24) {
        Some(re) => re.find_iter(content).count(),
        None => 0,
    };
    if pub_field_count > 3 {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "pub fields (encapsulation)".into(),
            fix: "Make fields private, add constructor returning Result, use accessor methods".into(),
            line: 0,
        });
    }

    // Optimization: Vec::new() before loop without with_capacity (index 25)
    if r.get(25).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "Vec without capacity hint".into(),
            fix: "Use Vec::with_capacity(n) when size is known — avoids repeated reallocations".into(),
            line: 0,
        });
    }

    // Abstraction: concrete type in function param (index 26)
    if r.get(26).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "concrete type in param".into(),
            fix: "Accept &[T] instead of &Vec<T>, &str instead of &String — trait-based params".into(),
            line: 0,
        });
    }

    // Polymorphism: manual type dispatch instead of trait (index 27)
    if r.get(27).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "manual type dispatch".into(),
            fix: "Use trait objects or generics instead of downcasting — let the type system dispatch".into(),
            line: 0,
        });
    }

    // Validation: handler extracts input but no validation (index 28)
    if r.get(28).is_some_and(|re| re.is_match(content))
        && !content.contains("validate")
        && !content.contains("check_")
        && !content.contains("verify")
        && !content.contains("is_valid")
    {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "handler without input validation".into(),
            fix: "Validate input at API boundary — use validator crate or manual checks before processing".into(),
            line: 0,
        });
    }

    // Bool parameter: use enums for self-documenting intent (index 29)
    if r.get(29).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "bool parameter".into(),
            fix: "Replace bool param with enum — foo(true) is unclear, foo(Mode::Fast) is self-documenting".into(),
            line: 0,
        });
    }

    // API protocol: REST-only Router without WebSocket/SSE/GraphQL/gRPC/HTTP3
    let has_router = r.get(35).is_some_and(|re| re.is_match(content));
    if has_router {
        let has_ws = r.get(30).is_some_and(|re| re.is_match(content));
        let has_sse = r.get(31).is_some_and(|re| re.is_match(content));
        let has_gql = r.get(32).is_some_and(|re| re.is_match(content));
        let has_rpc = r.get(33).is_some_and(|re| re.is_match(content));
        let has_h3 = r.get(34).is_some_and(|re| re.is_match(content));
        if !has_ws && !has_sse && !has_gql && !has_rpc && !has_h3 {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "REST-only router".into(),
                fix: "Consider WebSocket, SSE, GraphQL, gRPC, or HTTP/3 — REST is not the only protocol".into(),
                line: 0,
            });
        }
    }

    // Microservice: Router without body limit layer (index 38 = presence marker)
    if has_router && !r.get(38).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "router without body limit".into(),
            fix: "Add .layer(DefaultBodyLimit::max(bytes)) — unbounded body = DoS (CVE-2026-27729)".into(),
            line: 0,
        });
    }

    // Async safety: mutex lock held across await (index 36) — deadlock
    if r.get(36).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "lock held across await".into(),
            fix: "Release lock before .await — use tokio::sync::Mutex or scope the guard".into(),
            line: 0,
        });
    }

    // Async safety: HTTP call without timeout (index 37)
    if r.get(37).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "HTTP call without timeout".into(),
            fix: "Wrap with tokio::time::timeout() — unbounded awaits cause thread starvation".into(),
            line: 0,
        });
    }

    // DSA: .contains() on Vec inside loop — O(n²) (index 39)
    if r.get(39).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "linear search in loop".into(),
            fix: "Use HashSet for O(1) lookup instead of Vec::contains() in a loop".into(),
            line: 0,
        });
    }

    // DSA: String allocation in loop (index 40)
    if r.get(40).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "string allocation in loop".into(),
            fix: "Pre-allocate with String::with_capacity() or use write! macro".into(),
            line: 0,
        });
    }

    // Security: unbounded push in handler (index 41) — DoS vector
    if r.get(41).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "unbounded push in handler".into(),
            fix: "Limit collection size in handlers — unbounded allocation is a DoS vector (CVE-2026-26061)".into(),
            line: 0,
        });
    }

    // Security: HTTP client without timeout (index 42 = presence marker)
    // If content has ClientBuilder/Client::new but no .timeout() → missing
    let has_http_client = content.contains("ClientBuilder") || content.contains("Client::new");
    let has_timeout = r.get(42).is_some_and(|re| re.is_match(content));
    if has_http_client && !has_timeout {
        violations.push(RustViolation {
            severity: RustSeverity::P0Block,
            pattern: "HTTP client no timeout".into(),
            fix: "Add .timeout(Duration::from_secs(30)) to ClientBuilder — no-timeout clients cause cascading failures".into(),
            line: 0,
        });
    }

    // Microservice: chatty sequential awaits (index 43)
    if r.get(43).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "chatty sequential awaits".into(),
            fix: "Use tokio::join! or futures::join! for parallel calls — sequential awaits multiply latency".into(),
            line: 0,
        });
    }

    // God class: >15 fn declarations in one file (index 44 = count marker)
    let fn_count: usize = match r.get(44) {
        Some(re) => re.find_iter(content).count(),
        None => 0,
    };
    if fn_count > 15 {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "god class (too many functions)".into(),
            fix: "Split into smaller modules — >15 functions suggests mixed responsibilities".into(),
            line: 0,
        });
    }

    // Magic numbers in logic (index 45)
    for (i, line) in content.lines().enumerate() {
        if r.get(45).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "magic number".into(),
                fix: "Extract to a named constant — bare numbers in logic are unreadable".into(),
                line: i + 1,
            });
            break; // one warning is enough
        }
    }

    // Long if/else chain (index 46) — use enum/match
    if r.get(46).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "long if/else chain".into(),
            fix: "Use enum + match instead of if/else if/else if — exhaustive matching catches missing cases".into(),
            line: 0,
        });
    }

    // Magic strings in comparisons (index 47)
    for (i, line) in content.lines().enumerate() {
        if r.get(47).is_some_and(|re| re.is_match(line)) {
            violations.push(RustViolation {
                severity: RustSeverity::P1Advisory,
                pattern: "magic string".into(),
                fix: "Extract to a named constant or use an enum variant — string comparisons are fragile".into(),
                line: i + 1,
            });
            break;
        }
    }

    // Blanket #[from] sqlx::Error without error code inspection (index 48)
    if r.get(48).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "blanket sqlx error conversion".into(),
            fix: "Match on sqlx::Error variants and PostgreSQL SQLSTATE codes (23505→409, 23503→422, RowNotFound→404). Invoke /m13-domain-error".into(),
            line: 0,
        });
    }

    // INTERNAL_SERVER_ERROR in Err match arm without error variant inspection (index 49)
    if r.get(49).is_some_and(|re| re.is_match(content)) {
        violations.push(RustViolation {
            severity: RustSeverity::P1Advisory,
            pattern: "blanket 500 in error handler".into(),
            fix: "Match on error variants — RowNotFound→404, unique violation→409, FK→422, PoolTimeout→503. Only unknown errors are 500".into(),
            line: 0,
        });
    }

    violations
}

#[cfg(test)]
mod tests {
    use super::*;
    fn j(parts: &[&str]) -> String {
        parts.concat()
    }

    #[test]
    fn p0_unwrap() {
        let code = j(&["let x = foo.unw", "rap();"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block));
    }

    #[test]
    fn p0_panic() {
        let v = detect("src/lib.rs", "panic!(\"boom\")");
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block));
    }

    #[test]
    fn clean_allows() {
        let v = detect(
            "src/lib.rs",
            "fn add(a: i32, b: i32) -> Result<i32, Error> { Ok(a + b) }",
        );
        assert!(v.is_empty());
    }

    #[test]
    fn test_file_skipped() {
        let code = j(&["foo.unw", "rap()"]);
        let v = detect("/project/tests/api.rs", &code);
        assert!(v.is_empty());
    }

    #[test]
    fn p1_dbg() {
        let v = detect("src/lib.rs", "dbg!(x);");
        assert!(v.iter().any(|x| x.severity == RustSeverity::P1Advisory));
    }

    #[test]
    fn p0_unwrap_or() {
        let code = j(&["let x = foo.unw", "rap_or(\"\");"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern == "unwrap_or"));
    }

    #[test]
    fn p0_unwrap_or_default() {
        let code = j(&["let x = foo.unw", "rap_or_default();"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern == "unwrap_or_default"));
    }

    #[test]
    fn p0_ok_discard() {
        let code = j(&["let _ = save().o", "k();"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern == "result.ok()"));
    }

    #[test]
    fn p0_todo() {
        let code = j(&["to", "do!()"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block));
    }

    #[test]
    fn p0_default_fill() {
        let code = j(&["    ..Defa", "ult::default()"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern.contains("Default")));
    }

    #[test]
    fn p0_catch_all() {
        let v = detect("src/lib.rs", "        _ => {}");
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern.contains("catch-all")));
    }

    #[test]
    fn p0_direct_indexing() {
        let v = detect("src/lib.rs", "let x = v[i];");
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern == "direct indexing"));
    }

    #[test]
    fn p0_no_false_positive_on_tfidf_cosine_similarity() {
        // Regression: old binary had a stale pattern that false-positived on
        // TF-IDF cosine similarity code. This test locks that in.
        let content = r#"fn tfidf_best_match(
    candidates: Vec<GatePattern>,
    query_vec: &[&str],
    query_tokens: &str,
) -> Result<Option<GatePattern>> {
    let n = candidates.len() as f64;
    let mut df = std::collections::HashMap::new();
    for token in query_vec {
        let count = candidates
            .iter()
            .filter(|p| p.error_tokens.split_whitespace().any(|t| t == *token))
            .count() as f64;
        if count > 0.0 {
            df.insert(*token, count);
        }
    }
    let idf = |token: &str| -> f64 {
        df.get(token).map_or(0.0, |&d| (n / d).ln())
    };
    let query_norm: f64 = query_vec.iter()
        .map(|t| { let w = idf(t); w * w })
        .sum::<f64>()
        .sqrt();
    if query_norm == 0.0 {
        return Ok(None);
    }
    const MIN_SIM: f64 = 0.35;
    let best = candidates
        .into_iter()
        .filter(|c| c.bloom_bytes.as_ref().map_or(true, |b| bloom_might_match(b, query_tokens)))
        .filter_map(|candidate| {
            let pat_str = candidate.error_tokens.clone();
            let pat_tokens: Vec<&str> = pat_str.split_whitespace().collect();
            let dot: f64 = query_vec.iter()
                .filter(|t| pat_tokens.iter().any(|p| p == *t))
                .map(|t| { let w = idf(t); w * w })
                .sum();
            let pat_sq: f64 = pat_tokens.iter()
                .filter(|t| query_vec.iter().any(|q| q == *t))
                .map(|t| { let w = idf(t); w * w })
                .sum();
            let pat_norm = pat_sq.sqrt();
            if pat_norm == 0.0 { return None; }
            let sim = dot / (query_norm * pat_norm);
            if sim >= MIN_SIM { Some((sim, candidate)) } else { None }
        })
        .reduce(|(best_sim, best_pat), (sim, pat)| {
            if sim > best_sim { (sim, pat) } else { (best_sim, best_pat) }
        })
        .map(|(_, pat)| pat);
    Ok(best)
}"#;
        let v = detect("src/gate_patterns.rs", content);
        let p0: Vec<_> = v.iter().filter(|x| x.severity == RustSeverity::P0Block).collect();
        assert!(p0.is_empty(), "P0 violations found: {p0:?}");
    }

    #[test]
    fn p0_allow_dead_code() {
        let code = j(&["#[allow(dead_co", "de)]\nfn f() {}"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern == "allow(dead_code)"));
    }

    #[test]
    fn p0_serde_default_bool() {
        let code = j(&["#[serde(defa", "ult)]\n    pub is_admin: bool"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern.contains("serde")));
    }

    #[test]
    fn p0_empty_fn_body() {
        let v = detect("src/lib.rs", "pub fn handle_request() {}");
        assert!(v.iter().any(|x| x.severity == RustSeverity::P0Block && x.pattern == "empty function body"));
    }

    #[test]
    fn p0_empty_fn_with_return_type() {
        let v = detect("src/lib.rs", "fn process(input: &str) -> bool {}");
        assert!(v.iter().any(|x| x.pattern == "empty function body"));
    }

    #[test]
    fn nonempty_fn_ok() {
        let v = detect("src/lib.rs", "fn process() { do_work(); }");
        assert!(!v.iter().any(|x| x.pattern == "empty function body"));
    }

    #[test]
    fn p1_pub_fields_encapsulation() {
        let code = "pub name: String,\npub age: i32,\npub email: String,\npub active: bool,";
        let v = detect("src/lib.rs", code);
        assert!(v.iter().any(|x| x.pattern.contains("encapsulation")));
    }

    #[test]
    fn p1_vec_no_capacity() {
        let code = "let mut items = Vec::new();\nfor x in data {\n    items.push(x);\n}";
        let v = detect("src/lib.rs", code);
        assert!(v.iter().any(|x| x.pattern.contains("capacity")));
    }

    #[test]
    fn p1_concrete_type_param() {
        let v = detect("src/lib.rs", "fn process(data: &Vec<String>) {}");
        assert!(v.iter().any(|x| x.pattern.contains("concrete type")));
    }

    #[test]
    fn p1_manual_type_dispatch() {
        let v = detect("src/lib.rs", "if val.downcast::<Foo>().is_ok() {}");
        assert!(v.iter().any(|x| x.pattern.contains("type dispatch")));
    }

    #[test]
    fn p1_bool_param() {
        let v = detect("src/lib.rs", "fn send_email(user: &User, urgent: bool) {}");
        assert!(v.iter().any(|x| x.pattern == "bool parameter"));
    }

    #[test]
    fn p0_lock_across_await() {
        let code = "let guard = mutex.lock().await;\ndo_work(guard).await;";
        let v = detect("src/lib.rs", code);
        assert!(v.iter().any(|x| x.pattern == "lock held across await"));
    }

    #[test]
    fn p0_linear_search_in_loop() {
        let code = "for item in items {\n    if seen.contains(&item) { skip(); }\n}";
        let v = detect("src/lib.rs", code);
        assert!(v.iter().any(|x| x.pattern == "linear search in loop"));
    }

    #[test]
    fn p1_string_alloc_in_loop() {
        let code = "for name in names {\n    let msg = format!(\"hello {}\", name);\n}";
        let v = detect("src/lib.rs", code);
        assert!(v.iter().any(|x| x.pattern == "string allocation in loop"));
    }

    #[test]
    fn p1_chatty_sequential_awaits() {
        let code = "let a = svc.get_user().await?;\nlet b = svc.get_wallet().await?;\nlet c = svc.get_missions().await?;";
        let v = detect("src/lib.rs", code);
        assert!(v.iter().any(|x| x.pattern == "chatty sequential awaits"));
    }

    #[test]
    fn p3_allow_unused() {
        let code = j(&["#[allow(unus", "ed)]"]);
        let v = detect("src/lib.rs", &code);
        assert!(v.iter().any(|x| x.severity == RustSeverity::P3Info));
    }
}
