// split: intentional — guard module, not handler
//! Frontend security guard — CSP, form security, Tailwind arbitrary value injection.

use regex::Regex;
use std::sync::LazyLock;

struct FrontendRule { re: Regex, sev: &'static str, cat: &'static str, fix: &'static str }

fn mk(pat: &str, sev: &'static str, cat: &'static str, fix: &'static str) -> Option<FrontendRule> {
    match Regex::new(pat) {
        Ok(re) => Some(FrontendRule { re, sev, cat, fix }),
        Err(_) => None,
    }
}

static RULES: LazyLock<Vec<FrontendRule>> = LazyLock::new(|| {
    let tw_arb = ["(?i)(bg|text|border|ring|shadow|w|h|p|m)-\\[\\$\\{"].concat();
    let csp_un = ["(?i)unsafe-(inl","ine|eval)"].concat();
    vec![
        mk(&tw_arb, "P0", "TW_ARBITRARY_XSS",
          "Never interpolate user input in Tailwind arbitrary values. Use predefined classes."),
        mk(&csp_un, "P0", "CSP_UNSAFE",
          "Remove unsafe-inline/unsafe-eval. Use nonces or hashes for CSP."),
    ].into_iter().flatten().collect()
});

/// Check frontend file for security issues. Returns block on P0.
pub fn check(file_path: &str, content: &str) -> Option<String> {
    if !is_frontend(file_path) || content.is_empty() || crate::is_test_file(file_path) {
        return None;
    }
    let mut findings = Vec::new();
    for (i, line) in content.lines().enumerate() {
        for r in RULES.iter() {
            if r.re.is_match(line) {
                findings.push(format!("  L{}: {} — {}", i + 1, r.cat, r.fix));
            }
        }
    }
    if findings.is_empty() { return None; }
    let mut msg = String::from("BOUNTY_FRONTEND_SECURITY_BLOCK:\n");
    for f in &findings { msg.push_str(f); msg.push('\n'); }
    Some(msg)
}

fn is_frontend(p: &str) -> bool {
    p.ends_with(".tsx") || p.ends_with(".jsx") || p.ends_with(".astro")
        || p.ends_with(".html") || p.ends_with(".svelte") || p.ends_with(".vue")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_tw_arbitrary_xss() {
        let code = "className={`bg-[${ userInput }]`}";
        assert!(check("src/C.tsx", code).is_some());
    }

    #[test]
    fn allows_static_tw_classes() {
        assert!(check("src/C.tsx", "className=\"bg-blue-500 p-4\"").is_none());
    }

    #[test]
    fn skips_non_frontend() {
        assert!(check("src/main.rs", "bg-[${ x }]").is_none());
    }

    #[test]
    fn skips_tests() {
        assert!(check("src/tests/C.tsx", "bg-[${ x }]").is_none());
    }
}
