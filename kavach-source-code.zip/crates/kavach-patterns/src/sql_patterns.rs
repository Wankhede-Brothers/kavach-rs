use std::sync::LazyLock;
use regex::Regex;
use crate::config::j;

fn mk(p: &str) -> Regex {
    Regex::new(p).expect("static sql regex must compile")
}

pub static SQL_P: LazyLock<Vec<Regex>> = LazyLock::new(|| {
    let sel_star  = j(&[r"SEL","ECT","\\s+","\\*"]);
    let del_nowhr = j(&[r"DEL","ETE","\\s+","FR","OM","\\s+","\\w+","\\s*;"]);
    let grnt_all  = j(&[r"GRA","NT","\\s+(?:","ALL","|SUPERUSER)"]);
    let pwd_hard  = j(&["PASSWORD","\\s*=\\s*'[^']+'"]);
    let drp_tbl   = j(&[r"DR","OP","\\s+","TAB","LE"]);
    let trunc     = j(&[r"\bTRUN","CAT","E\\b"]);
    let fmt_sql   = j(&[r"format!\s*\([^)]*(?:SEL","ECT|INS","ERT|UPD","ATE|DEL","ETE|FR","OM|WH","ERE)"]);
    let offset    = j(&[r"\bOFF","SET","\\s+","\\d+"]);

    vec![
        mk(&fmt_sql),
        mk(&sel_star),
        mk(&del_nowhr),
        mk(&grnt_all),
        mk(&pwd_hard),
        mk(&offset),
        mk(&drp_tbl),
        mk(&trunc),
    ]
});
