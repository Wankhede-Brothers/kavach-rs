/// NLP keyword→skill routing using Aho-Corasick multi-pattern matching.
///
/// Dynamically loads keywords from ~/.claude/skills/*/SKILL.md frontmatter.
/// Single-pass O(n) scan of prompt text detects keywords that map to skills.
// ALGO: AhoCorasick
// PROBLEM_CLASS: string_match
// REJECTED: [{"name":"HashMap_per_word","reason":"O(k*n) per-word lookup, no single-pass"},{"name":"RegexAlternation","reason":"O(n*k) backtracking, cache-hostile"}]
// TIME: O(n+m+z) single pass | SPACE: O(Σ·k)
// YEAR: 1975 (Aho, Corasick) | SEARCHED: 2026-04
// TRADEOFF: filesystem read at startup — cached via OnceLock
// BENCHMARK: https://docs.rs/aho-corasick/latest/aho_corasick/
use std::sync::OnceLock;
use aho_corasick::AhoCorasick;

struct SkillRoute {
    skill: String,
    ac: AhoCorasick,
}

fn skills_dir() -> std::path::PathBuf {
    dirs::home_dir()
        .map(|h: std::path::PathBuf| h.join(".claude/skills"))
        .unwrap_or_default()
}

fn build_route(skill_name: String, keywords: Vec<String>) -> Option<SkillRoute> {
    let ac = AhoCorasick::builder()
        .ascii_case_insensitive(true)
        .build(&keywords)
        .ok()?;
    Some(SkillRoute { skill: skill_name, ac })
}

fn load_skill_keywords(path: &std::path::Path) -> Option<(String, Vec<String>)> {
    let skill_name = path.file_name()?.to_str()?.to_string();
    let content = std::fs::read_to_string(path.join("SKILL.md")).ok()?;
    let keywords = extract_keywords(&content);
    if keywords.is_empty() { return None; }
    Some((skill_name, keywords))
}

fn build_routes() -> Vec<SkillRoute> {
    let dir = skills_dir();
    let entries = match std::fs::read_dir(&dir) {
        Ok(e) => e,
        Err(_) => return Vec::new(),
    };

    entries
        .flatten()
        .filter(|e| e.path().is_dir())
        .filter_map(|e| load_skill_keywords(&e.path()))
        .filter_map(|(name, kws)| build_route(name, kws))
        .collect()
}

fn extract_triggers_array(line: &str) -> Vec<String> {
    let start = match line.find('[') { Some(i) => i, None => return Vec::new() };
    let end = match line.find(']') { Some(i) => i, None => return Vec::new() };
    let arr = &line[start + 1..end];
    arr.split(',')
        .map(|kw| kw.trim().trim_matches('"').trim_matches('\'').to_string())
        .filter(|s| !s.is_empty())
        .collect()
}

fn extract_trigger_on(line: &str) -> Vec<String> {
    let lower = line.to_lowercase();
    // Look for "Trigger on:" or "Invoke on:" patterns
    let markers = ["trigger on:", "invoke on:", "triggers on:"];
    let (pos, marker_len) = markers.iter()
        .filter_map(|m| lower.find(m).map(|p| (p, m.len())))
        .next()
        .unwrap_or((0, 0));
    if marker_len == 0 { return Vec::new(); }
    let after = &line[pos + marker_len..];
    let end = after.find('"').unwrap_or(after.len());
    after[..end].split(',')
        .map(|kw| kw.trim().trim_matches('.').to_string())
        .filter(|s| s.len() > 2)
        .collect()
}

fn extract_keywords(content: &str) -> Vec<String> {
    let lines: Vec<&str> = content.lines().collect();
    if lines.first() != Some(&"---") { return Vec::new(); }

    let end_idx = lines.iter().skip(1).position(|l| *l == "---");
    let fm_end = match end_idx { Some(i) => i + 1, None => return Vec::new() };
    let frontmatter = &lines[1..fm_end];

    let mut keywords = Vec::new();
    for line in frontmatter {
        if line.trim().starts_with("triggers:") {
            keywords.extend(extract_triggers_array(line));
        }
        if line.contains("description:") {
            keywords.extend(extract_trigger_on(line));
        }
    }
    keywords
}

fn routes() -> &'static Vec<SkillRoute> {
    static ROUTES: OnceLock<Vec<SkillRoute>> = OnceLock::new();
    ROUTES.get_or_init(build_routes)
}

/// Scan prompt text and return all skills whose keywords matched.
/// Returns deduplicated skill names in match-priority order (first match wins).
pub fn skills_from_keywords(text: &str) -> Vec<String> {
    if text.is_empty() {
        return Vec::new();
    }
    let lower = text.to_lowercase();
    let mut matched: Vec<String> = Vec::new();
    for route in routes() {
        if route.ac.is_match(&lower) && !matched.iter().any(|s| s == &route.skill) {
            matched.push(route.skill.clone());
        }
    }
    matched
}

#[cfg(test)]
mod tests {
    use super::*;

    fn has_skill(skills: &[String], name: &str) -> bool {
        skills.iter().any(|s| s == name)
    }

    #[test]
    fn should_return_empty_for_empty_input() {
        let skills = skills_from_keywords("");
        assert!(skills.is_empty());
    }

    #[test]
    fn should_detect_architecture_keywords() {
        // arch skill has triggers: ["architecture", "algorithm", "data structure", ...]
        let skills = skills_from_keywords("system design architecture scalability");
        assert!(has_skill(&skills, "arch"), "Expected arch in {:?}", skills);
    }

    #[test]
    fn should_detect_data_keywords() {
        // data skill triggers on: sqlx, migration, postgresql
        let skills = skills_from_keywords("add a migration for the users table with sqlx");
        assert!(has_skill(&skills, "data"), "Expected data in {:?}", skills);
    }

    #[test]
    fn should_detect_error_keywords() {
        // error skill has triggers: ["Result", "Option", "unwrap", "expect", "panic", ...]
        let skills = skills_from_keywords("fix the unwrap and expect calls with thiserror");
        assert!(has_skill(&skills, "error"), "Expected error in {:?}", skills);
    }

    #[test]
    fn should_be_case_insensitive() {
        let skills = skills_from_keywords("ARCHITECTURE SYSTEM DESIGN");
        assert!(has_skill(&skills, "arch"), "Expected arch in {:?}", skills);
    }

    #[test]
    fn should_load_skills_from_filesystem() {
        // Verify that routes are loaded from ~/.claude/skills/
        let loaded = routes();
        assert!(!loaded.is_empty(), "No skills loaded from filesystem");
    }
}
