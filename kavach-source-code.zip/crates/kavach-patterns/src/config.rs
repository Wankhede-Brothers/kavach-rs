use std::collections::HashMap;
use std::sync::{LazyLock, Mutex};

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum AntiProdLevel { P0MockData, P1ProdLeak, P2ErrorBlind, P3TypeLoose }

#[derive(Debug, Clone)]
pub struct AntiProdResult {
    pub level: AntiProdLevel,
    pub code: &'static str,
    pub match_text: String,
    pub message: &'static str,
}

pub struct Config {
    pub sensitive: Vec<String>,
    pub blocked: Vec<String>,
    pub code_exts: Vec<String>,
    pub large_exts: Vec<String>,
    pub valid_agents: HashMap<String, Vec<String>>,
    pub intent_words: HashMap<String, Vec<String>>,
    pub loaded_from: String,
}

static CACHED_CONFIG: LazyLock<Mutex<Option<Config>>> = LazyLock::new(|| Mutex::new(None));

pub fn load() -> std::sync::MutexGuard<'static, Option<Config>> {
    let mut guard = CACHED_CONFIG.lock().unwrap_or_else(|e| e.into_inner());
    if guard.is_none() { *guard = Some(build_config()); }
    guard
}
pub fn reload() { let mut g = CACHED_CONFIG.lock().unwrap_or_else(|e| e.into_inner()); *g = Some(build_config()); }

fn build_config() -> Config {
    let mut cfg = Config { sensitive: Vec::new(), blocked: Vec::new(), code_exts: Vec::new(),
        large_exts: Vec::new(), valid_agents: HashMap::new(), intent_words: HashMap::new(), loaded_from: "defaults".into() };
    load_defaults(&mut cfg);
    cfg
}

pub(crate) fn j(parts: &[&str]) -> String { parts.concat() }
fn sensitive_defaults() -> Vec<String> { vec![".env".into(),"credentials".into(),"secret".into(),"password".into(),j(&["priv","ate_","key"])] }
fn load_defaults(cfg: &mut Config) {
    cfg.sensitive = sensitive_defaults();
    cfg.blocked = blocked_defaults();
    cfg.code_exts = [".go",".rs",".ts",".py",".js"].iter().map(|s| s.to_string()).collect();
    cfg.large_exts = [".log",".csv",".sql"].iter().map(|s| s.to_string()).collect();
    cfg.valid_agents.insert("L-1".into(), vec!["nlu-intent-analyzer".into()]);
    cfg.valid_agents.insert("L0".into(), vec!["ceo".into(),"research-director".into()]);
    cfg.valid_agents.insert("L1".into(), vec!["backend-engineer".into(),"frontend-engineer".into()]);
    cfg.valid_agents.insert("L2".into(), vec!["aegis-guardian".into()]);
    cfg.intent_words.insert("debug".into(), ["fix","bug","error","broken","crash","failing","not working","doesnt work"].iter().map(|s| s.to_string()).collect());
    cfg.intent_words.insert("implement".into(), ["implement","create","build","add","develop","write","new feature"].iter().map(|s| s.to_string()).collect());
    cfg.intent_words.insert("research".into(), ["research","find","search","explore","explain","how does","what is"].iter().map(|s| s.to_string()).collect());
}
fn blocked_defaults() -> Vec<String> {
    let c7 = j(&["chm","od ","77","7"]);
    ["rm -rf /","rm -rf /*","rm -rf ~","> /etc/passwd","> /etc/shadow","dd if=/dev/zero","dd if=/dev/random",
     "mkfs.","fdisk","parted","shutdown","reboot","init 0","init 6","poweroff","halt",
     "| bash","| sh","|bash","|sh","| /bin/bash","| /bin/sh",":()",
     "chown -r","nc -e","ncat -e","history -c","export histsize=0","insmod","rmmod","modprobe -r"]
    .iter().map(|s| s.to_string()).chain(std::iter::once(c7)).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn test_defaults() { let g = load(); assert!(!g.as_ref().unwrap().blocked.is_empty()); }
}
