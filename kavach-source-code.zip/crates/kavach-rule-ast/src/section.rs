//! Section structures for skill TOON documents

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResearchGate {
    pub mandatory: bool,
    pub rule: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ErrorHandling {
    pub production_style: String,
    pub test_only: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PendingTasks {
    pub mandatory: bool,
    pub macros: Vec<String>,
}
