//! Skill enforcement priority levels.

use serde::{Deserialize, Serialize};

/// Priority level for a skill definition.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum SkillPriority {
    Critical,
    #[default]
    Advisory,
}

impl SkillPriority {
    /// Parse from a string, case-insensitive. Unknown values default to Advisory.
    pub fn parse_str(s: &str) -> Self {
        match s.to_ascii_lowercase().as_str() {
            "critical" => SkillPriority::Critical,
            _ => SkillPriority::Advisory,
        }
    }

    /// Returns true if this priority is Critical.
    pub fn is_critical(&self) -> bool {
        matches!(self, SkillPriority::Critical)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_priority_is_advisory() {
        assert_eq!(SkillPriority::default(), SkillPriority::Advisory);
        assert!(!SkillPriority::default().is_critical());
    }

    #[test]
    fn test_priority_from_str() {
        assert_eq!(SkillPriority::parse_str("critical"), SkillPriority::Critical);
        assert_eq!(SkillPriority::parse_str("CRITICAL"), SkillPriority::Critical);
        assert_eq!(SkillPriority::parse_str("Critical"), SkillPriority::Critical);
        assert_eq!(SkillPriority::parse_str("advisory"), SkillPriority::Advisory);
        assert_eq!(SkillPriority::parse_str("unknown"), SkillPriority::Advisory);
        assert_eq!(SkillPriority::parse_str(""), SkillPriority::Advisory);
        assert!(SkillPriority::parse_str("critical").is_critical());
        assert!(!SkillPriority::parse_str("advisory").is_critical());
    }
}
