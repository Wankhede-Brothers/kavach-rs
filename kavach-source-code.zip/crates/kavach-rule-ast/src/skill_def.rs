//! Skill metadata and definition

use serde::{Deserialize, Serialize};
use super::section::ResearchGate;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SkillDefinition {
    pub metadata: SkillMetadata,
    pub research_gate: ResearchGate,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SkillMetadata {
    pub name: String,
    pub description: String,
    pub protocol: String,
    pub triggers: Vec<String>,
    #[serde(default)]
    pub file_patterns: Vec<String>,
    #[serde(default)]
    pub priority: super::SkillPriority,
}
