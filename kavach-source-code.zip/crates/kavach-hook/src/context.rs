use crate::{modify, output, HookAction};
use kavach_types::{HookResponse, HookSpecificOutput};

/// Return today's date as YYYY-MM-DD using local time.
pub fn today() -> String {
    chrono::Local::now().format("%Y-%m-%d").to_string()
}

/// Return the current year (e.g., 2026).
/// Uses `unsigned_abs()` — year is always a non-negative i32, no fallible cast needed.
pub fn current_year() -> u32 {
    use chrono::Datelike;
    chrono::Local::now().year().unsigned_abs()
}

/// Return the current month (1-12).
pub fn current_month() -> u32 {
    use chrono::Datelike;
    chrono::Local::now().month()
}

/// Return the current ISO week number (1-53).
pub fn current_week() -> u32 {
    use chrono::Datelike;
    chrono::Local::now().iso_week().week()
}

/// Build a context block string. Name is kept as-is (NO case change).
/// ```text
/// [name]
/// key1: value1
/// key2: value2
/// ```
pub fn context_block(name: &str, kvs: &[(&str, &str)]) -> String {
    let mut out = format!("[{name}]\n");
    for (k, v) in kvs {
        out.push_str(&format!("{k}: {v}\n"));
    }
    out
}

/// PreToolUse allow with context GATE block, date auto-injected.
pub fn exit_approve_ctx(gate: &str) -> HookAction {
    let d = today();
    let context = context_block(gate, &[("status", "allow"), ("date", &d)]);
    let resp = HookResponse::new_pre_tool_use_with_context(gate, &context);
    output(&resp);
    HookAction::Done
}

/// PreToolUse deny with context BLOCK block, date auto-injected.
/// Sends plain reason as permissionDecisionReason, context block as additionalContext.
pub fn exit_block_ctx(gate: &str, reason: &str) -> HookAction {
    let d = today();
    let context = context_block(gate, &[("status", "block"), ("reason", reason), ("date", &d)]);
    let resp = HookResponse {
        hook_specific_output: Some(HookSpecificOutput {
            hook_event_name: "PreToolUse".into(),
            permission_decision: "deny".into(),
            permission_decision_reason: reason.into(),
            additional_context: context,
            ..Default::default()
        }),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}

/// Legacy modify with context injection, date auto-injected via kvs.
pub fn exit_modify_ctx(gate: &str, kvs: &[(&str, &str)]) -> HookAction {
    let context = context_block(gate, kvs);
    modify(gate, &context);
    HookAction::Done
}

/// Modify with context injection + lazy-loaded module content.
pub fn exit_modify_ctx_with_module(
    gate: &str,
    kvs: &[(&str, &str)],
    module_content: &str,
) -> HookAction {
    let mut context = context_block(gate, kvs);
    context.push_str("\n[MODULE:LAZY_LOADED]\n");
    context.push_str(module_content);
    modify(gate, &context);
    HookAction::Done
}

/// UserPromptSubmit with context block, date auto-injected.
pub fn exit_user_prompt_submit_ctx(
    gate: &str,
    kvs: &[(&str, &str)],
) -> HookAction {
    let d = today();
    let mut all_kvs: Vec<(&str, &str)> = kvs.to_vec();
    all_kvs.push(("date", &d));
    let context = context_block(gate, &all_kvs);
    crate::exit_user_prompt_submit(&context)
}

/// SessionEnd with context block, date auto-injected.
pub fn exit_session_end_ctx(kvs: &[(&str, &str)]) -> HookAction {
    let d = today();
    let mut all_kvs: Vec<(&str, &str)> = kvs.to_vec();
    all_kvs.push(("date", &d));
    let context = context_block("SESSION_END", &all_kvs);
    crate::exit_session_end(&context)
}
