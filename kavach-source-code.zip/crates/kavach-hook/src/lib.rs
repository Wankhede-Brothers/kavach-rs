use std::io::{self, BufRead, Write};

use kavach_types::{HookInput, HookResponse};
use serde::Serialize;

pub mod cc21;
pub mod lifecycle;
pub mod context;

#[cfg(test)]
#[path = "tests.rs"]
mod tests;

// Re-export context functions at crate root for backwards compatibility
pub use context::{
    context_block, current_month, current_week, current_year,
    exit_approve_ctx, exit_block_ctx, exit_modify_ctx,
    exit_modify_ctx_with_module, exit_session_end_ctx,
    exit_user_prompt_submit_ctx, today,
};

// Re-export CC 2.1 functions at crate root
pub use cc21::{
    exit_notification_context, exit_post_tool_block,
    exit_post_tool_context, exit_post_tool_failure_context,
    exit_post_tool_trimmed,
    exit_pre_tool_allow, exit_pre_tool_deny, exit_prompt_context,
    exit_session_start_context, exit_stop_block, exit_stop_context,
};

// Re-export lifecycle functions at crate root
pub use lifecycle::{
    exit_elicitation_decline,
    exit_permission_allow, exit_permission_deny,
    exit_permission_request_allow, exit_permission_request_deny,
    exit_session_end, exit_subagent_start, exit_subagent_stop,
    exit_user_prompt_submit, exit_user_prompt_submit_silent,
};

/// What the hook wants to do after outputting JSON.
pub enum HookAction {
    Done,
    Error,
}

// --- Input ---

pub fn read_hook_input() -> Result<HookInput, String> {
    let stdin = io::stdin();
    read_hook_input_from(stdin.lock())
}

pub fn read_hook_input_from<R: BufRead>(reader: R) -> Result<HookInput, String> {
    let mut buf = Vec::new();
    for line in reader.lines() {
        let line = line.map_err(|e| format!("read error: {e}"))?;
        buf.push(line);
    }
    let raw = buf.join("\n");
    serde_json::from_str(&raw).map_err(|e| format!("JSON parse error: {e}"))
}

pub fn must_read_hook_input() -> Result<HookInput, HookAction> {
    match read_hook_input() {
        Ok(input) => Ok(input),
        Err(e) => { output_error(&e); Err(HookAction::Error) }
    }
}

// --- Output helpers ---

pub(crate) fn write_json<T: Serialize>(val: &T) {
    let json = match serde_json::to_string(val) {
        Ok(j) => j,
        Err(e) => {
            let _ = writeln!(io::stderr().lock(), "kavach: serialization error: {e}");
            r#"{"decision":"block","reason":"hook internal error: serialization failed"}"#.into()
        }
    };
    if writeln!(io::stdout().lock(), "{json}").is_err() {
        let _ = writeln!(io::stderr().lock(), "kavach: stdout write failed");
    }
}

pub fn output(resp: &HookResponse) { write_json(resp); }
pub fn output_error(msg: &str) {
    output(&HookResponse::new_block(&format!("error: {msg}")));
}
pub fn approve(reason: &str) { output(&HookResponse::new_approve(reason)); }
pub fn block(reason: &str) { output(&HookResponse::new_block(reason)); }
pub fn modify(reason: &str, ctx: &str) {
    output(&HookResponse::new_modify(reason, ctx));
}

// --- Exit helpers ---

pub fn exit_silent() -> HookAction { approve("ok"); HookAction::Done }
pub fn exit_approve(reason: &str) -> HookAction { approve(reason); HookAction::Done }
pub fn exit_block(reason: &str) -> HookAction { block(reason); HookAction::Done }
pub fn exit_modify(reason: &str, ctx: &str) -> HookAction {
    modify(reason, ctx);
    HookAction::Done
}
