use kavach_types::HookResponse;
use serde::Serialize;

use crate::{output, write_json, HookAction};

// --- UserPromptSubmit legacy wire format ---

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct UserPromptSubmitOutput {
    pub hook_event_name: String,
    pub additional_context: String,
}

/// Write UserPromptSubmit JSON to stdout.
pub fn exit_user_prompt_submit(context: &str) -> HookAction {
    let out = UserPromptSubmitOutput {
        hook_event_name: "UserPromptSubmit".into(),
        additional_context: context.into(),
    };
    write_json(&out);
    HookAction::Done
}

/// UserPromptSubmit with empty context.
pub fn exit_user_prompt_submit_silent() -> HookAction {
    exit_user_prompt_submit("")
}

// --- SessionEnd ---

/// SessionEnd with context.
pub fn exit_session_end(context: &str) -> HookAction {
    output(&HookResponse::new_session_end_context(context));
    HookAction::Done
}

// --- Subagent ---

/// SubagentStart with context.
pub fn exit_subagent_start(context: &str) -> HookAction {
    output(&HookResponse::new_subagent_start_context(context));
    HookAction::Done
}

/// SubagentStop with context.
pub fn exit_subagent_stop(context: &str) -> HookAction {
    output(&HookResponse::new_subagent_stop_context(context));
    HookAction::Done
}

// --- Permission ---

/// PermissionRequest allow.
pub fn exit_permission_allow(reason: &str) -> HookAction {
    output(&HookResponse::new_permission_allow(reason));
    HookAction::Done
}

/// PermissionRequest deny.
pub fn exit_permission_deny(reason: &str) -> HookAction {
    output(&HookResponse::new_permission_deny(reason));
    HookAction::Done
}

/// PermissionRequest allow (PreToolUse permissionRequest event).
pub fn exit_permission_request_allow(reason: &str) -> HookAction {
    output(&HookResponse::new_permission_allow(reason));
    HookAction::Done
}

/// PermissionRequest deny (PreToolUse permissionRequest event).
pub fn exit_permission_request_deny(reason: &str) -> HookAction {
    output(&HookResponse::new_permission_deny(reason));
    HookAction::Done
}

/// Elicitation decline — user declined an elicitation prompt.
pub fn exit_elicitation_decline() -> HookAction {
    use serde::Serialize;
    #[derive(Serialize)]
    #[serde(rename_all = "camelCase")]
    struct ElicitationOutput {
        action: String,
    }
    crate::write_json(&ElicitationOutput { action: "decline".into() });
    HookAction::Done
}
