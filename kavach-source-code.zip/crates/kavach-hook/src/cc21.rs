use kavach_types::{HookResponse, HookSpecificOutput};

use crate::{output, HookAction};

/// PreToolUse: deny with reason via hookSpecificOutput.
pub fn exit_pre_tool_deny(reason: &str) -> HookAction {
    let resp = HookResponse::new_pre_tool_use_deny(reason);
    output(&resp);
    HookAction::Done
}

/// PreToolUse: allow with optional context via hookSpecificOutput.
pub fn exit_pre_tool_allow(context: Option<&str>) -> HookAction {
    let resp = match context {
        Some(ctx) => HookResponse::new_pre_tool_use_with_context("allow", ctx),
        None => HookResponse::new_pre_tool_use_allow("allow"),
    };
    output(&resp);
    HookAction::Done
}

/// PreToolUse: ask user for explicit approval via hookSpecificOutput.
/// Emits `permissionDecision: "ask"` — Claude Code prompts the user with
/// `reason` before proceeding. Precedence: deny > defer > ask > allow.
pub fn exit_pre_tool_ask(reason: &str) -> HookAction {
    let resp = HookResponse::new_pre_tool_use_ask(reason);
    output(&resp);
    HookAction::Done
}

/// PostToolUse: block with reason + context.
pub fn exit_post_tool_block(reason: &str, context: &str) -> HookAction {
    let resp = HookResponse::new_post_tool_use_block(reason, context);
    output(&resp);
    HookAction::Done
}

/// PostToolUse: context injection.
pub fn exit_post_tool_context(context: &str) -> HookAction {
    let resp = HookResponse {
        hook_specific_output: Some(HookSpecificOutput {
            hook_event_name: "PostToolUse".into(),
            additional_context: context.into(),
            ..Default::default()
        }),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}

/// UserPromptSubmit: context injection via hookSpecificOutput.
pub fn exit_prompt_context(context: &str) -> HookAction {
    let resp = HookResponse::new_user_prompt_submit_context(context);
    output(&resp);
    HookAction::Done
}

/// SessionStart: context injection.
/// SessionStart: context via systemMessage (no hookSpecificOutput).
pub fn exit_session_start_context(context: &str) -> HookAction {
    let resp = HookResponse {
        system_message: context.into(),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}

/// Stop: context injection (warn/info without blocking).
/// Stop hooks don't support hookSpecificOutput — use system_message instead.
pub fn exit_stop_context(context: &str) -> HookAction {
    let resp = HookResponse {
        system_message: context.into(),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}

/// Stop: block stopping.
pub fn exit_stop_block(reason: &str) -> HookAction {
    let resp = HookResponse::new_stop_block(reason);
    output(&resp);
    HookAction::Done
}

/// Notification: context injection via systemMessage (no hookSpecificOutput).
pub fn exit_notification_context(context: &str) -> HookAction {
    let resp = HookResponse {
        system_message: context.into(),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}

/// PostToolUse: trim verbose tool output and inject context.
/// Injects trimmed output as additional_context — CC 2.1 has no PostToolUse output replacement.
pub fn exit_post_tool_trimmed(trimmed_output: &str, context: &str) -> HookAction {
    let combined = if context.is_empty() {
        trimmed_output.to_owned()
    } else {
        format!("{trimmed_output}\n\n{context}")
    };
    let resp = HookResponse {
        hook_specific_output: Some(HookSpecificOutput {
            hook_event_name: "PostToolUse".into(),
            additional_context: combined,
            ..Default::default()
        }),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}

/// PostToolUseFailure: context injection via systemMessage (no hookSpecificOutput).
pub fn exit_post_tool_failure_context(context: &str) -> HookAction {
    let resp = HookResponse {
        system_message: context.into(),
        ..Default::default()
    };
    output(&resp);
    HookAction::Done
}
