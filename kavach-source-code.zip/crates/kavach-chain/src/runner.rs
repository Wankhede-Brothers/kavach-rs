use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;

use chrono::Local;

use crate::helpers::debug_stderr;
use crate::chain_state::ChainState;

pub struct Runner {
    pub state: ChainState,
    cache_dir: PathBuf,
    debug_mode: bool,
}

impl Runner {
    pub fn new(session_id: &str) -> Self {
        let home = std::env::var("HOME").unwrap_or_else(|_| ".".into());
        Self {
            state: ChainState::new(session_id),
            cache_dir: PathBuf::from(&home).join(".claude").join("chain"),
            debug_mode: std::env::var("KAVACH_DEBUG").unwrap_or_default() == "1",
        }
    }

    pub fn run_full(
        &mut self,
        prompt: &str,
        tool_name: &str,
        tool_input: &HashMap<String, serde_json::Value>,
        research_done: bool,
    ) -> &ChainState {
        self.debug("Starting verification chain");

        crate::gates::intent::run_gate(&mut self.state, prompt);
        if self.state.is_blocked() {
            return self.finalize();
        }

        let agent_type = tool_input
            .get("subagent_type")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        crate::gates::ceo::run_gate(&mut self.state, tool_name, &agent_type);
        if self.state.is_blocked() {
            return self.finalize();
        }

        crate::gates::aegis::run_gate(&mut self.state, tool_name, tool_input);
        if self.state.is_blocked() {
            return self.finalize();
        }

        crate::gates::research::run_gate(&mut self.state, research_done, prompt);
        if self.state.is_blocked() {
            return self.finalize();
        }

        self.state.final_status = "approved".into();
        self.finalize()
    }

    pub(crate) fn finalize(&mut self) -> &ChainState {
        self.save_state();
        &self.state
    }

    fn save_state(&self) {
        if self.cache_dir.as_os_str().is_empty() {
            return;
        }
        let _ = fs::create_dir_all(&self.cache_dir);
        let filename = format!(
            "chain_{}_{}.json",
            self.state.session_id,
            Local::now().timestamp()
        );
        let path = self.cache_dir.join(filename);
        if let Ok(data) = serde_json::to_string_pretty(&self.state) {
            let _ = fs::write(path, data);
        }
    }

    pub(crate) fn debug(&self, msg: &str) {
        if self.debug_mode {
            debug_stderr(msg);
        }
    }
}
