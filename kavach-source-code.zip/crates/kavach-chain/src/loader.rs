use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use std::sync::RwLock;

use crate::loader_types::{extract_description, extract_triggers, AgentDef, SkillDef};

pub struct DynamicLoader {
    agent_dir: PathBuf,
    skill_dir: PathBuf,
    agents: RwLock<HashMap<String, AgentDef>>,
    skills: RwLock<HashMap<String, SkillDef>>,
    skill_index: RwLock<HashMap<String, String>>,
}

impl DynamicLoader {
    pub fn new(agent_dir: PathBuf, skill_dir: PathBuf) -> Self {
        Self {
            agent_dir,
            skill_dir,
            agents: RwLock::new(HashMap::new()),
            skills: RwLock::new(HashMap::new()),
            skill_index: RwLock::new(HashMap::new()),
        }
    }

    pub fn get_agent(&self, name: &str) -> Option<AgentDef> {
        {
            let cache = self.agents.read().unwrap_or_else(|e| e.into_inner());
            if let Some(a) = cache.get(name) {
                return Some(a.clone());
            }
        }
        self.load_agent(name)
    }

    fn load_agent(&self, name: &str) -> Option<AgentDef> {
        let path = self.agent_dir.join(format!("{name}.md"));
        let data = fs::read_to_string(&path).ok()?;
        let agent = AgentDef {
            name: name.into(),
            description: extract_description(&data),
            model: String::new(),
            skills: Vec::new(),
            priority: 0,
        };
        let mut cache = self.agents.write().unwrap_or_else(|e| e.into_inner());
        cache.insert(name.into(), agent.clone());
        Some(agent)
    }

    pub fn get_skill(&self, name: &str) -> Option<SkillDef> {
        {
            let cache = self.skills.read().unwrap_or_else(|e| e.into_inner());
            if let Some(s) = cache.get(name) {
                return Some(s.clone());
            }
        }
        self.load_skill(name)
    }

    fn load_skill(&self, name: &str) -> Option<SkillDef> {
        let path = self.skill_dir.join(name).join("SKILL.md");
        let data = fs::read_to_string(&path).ok()?;
        let triggers = extract_triggers(&data);
        let skill = SkillDef {
            name: name.into(),
            description: extract_description(&data),
            triggers: triggers.clone(),
            auto_invoke: false,
            content: data,
        };
        let mut cache = self.skills.write().unwrap_or_else(|e| e.into_inner());
        cache.insert(name.into(), skill.clone());
        let mut idx = self.skill_index.write().unwrap_or_else(|e| e.into_inner());
        for t in &triggers {
            idx.insert(t.clone(), name.into());
        }
        Some(skill)
    }

    pub fn find_skill_by_trigger(&self, trigger: &str) -> Option<String> {
        let idx = self.skill_index.read().unwrap_or_else(|e| e.into_inner());
        idx.get(trigger).cloned()
    }

    pub fn loaded_agents(&self) -> Vec<String> {
        let cache = self.agents.read().unwrap_or_else(|e| e.into_inner());
        cache.keys().cloned().collect()
    }

    pub fn loaded_skills(&self) -> Vec<String> {
        let cache = self.skills.read().unwrap_or_else(|e| e.into_inner());
        cache.keys().cloned().collect()
    }
}
