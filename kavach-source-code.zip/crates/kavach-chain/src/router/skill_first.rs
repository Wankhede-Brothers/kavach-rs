use std::collections::HashMap;
use std::sync::RwLock;

use super::types::RoutingDecision;

pub struct SkillFirstRouter {
    skill_triggers: RwLock<HashMap<String, String>>,
    agent_skills: RwLock<HashMap<String, Vec<String>>>,
}

impl SkillFirstRouter {
    pub fn new() -> Self {
        Self {
            skill_triggers: RwLock::new(HashMap::new()),
            agent_skills: RwLock::new(HashMap::new()),
        }
    }

    pub fn register_skill_trigger(&self, keyword: &str, skill_name: &str) {
        let mut m = self.skill_triggers.write().unwrap_or_else(|e| e.into_inner());
        m.insert(keyword.to_lowercase(), skill_name.into());
    }

    pub fn register_agent_skills(&self, agent_name: &str, skills: Vec<String>) {
        let mut m = self.agent_skills.write().unwrap_or_else(|e| e.into_inner());
        m.insert(agent_name.into(), skills);
    }

    pub fn route(&self, intent: &str, keywords: &[&str]) -> RoutingDecision {
        let triggers = self.skill_triggers.read().unwrap_or_else(|e| e.into_inner());
        for kw in keywords {
            if let Some(skill) = triggers.get(&kw.to_lowercase()) {
                return RoutingDecision {
                    use_skill: true,
                    skill_name: skill.clone(),
                    agent_name: String::new(),
                    requires_ceo: false,
                    reason: "Keyword trigger matched skill".into(),
                };
            }
        }
        let lower = intent.to_lowercase();
        let mappings = kavach_config::get_intent_skill_mappings();
        for (keyword, skill) in &mappings {
            if lower.contains(keyword) {
                return RoutingDecision {
                    use_skill: true,
                    skill_name: skill.clone(),
                    agent_name: String::new(),
                    requires_ceo: false,
                    reason: "Intent matched skill domain".into(),
                };
            }
        }
        let complex = kavach_config::get_complex_indicators();
        for indicator in &complex {
            if lower.contains(indicator) {
                return RoutingDecision {
                    use_skill: false,
                    skill_name: String::new(),
                    agent_name: "ceo".into(),
                    requires_ceo: true,
                    reason: "Complex task requires orchestration".into(),
                };
            }
        }
        RoutingDecision {
            use_skill: false,
            skill_name: String::new(),
            agent_name: "backend-engineer".into(),
            requires_ceo: false,
            reason: "No specific skill match, using default agent".into(),
        }
    }

    pub fn get_skill_for_agent(&self, agent_name: &str) -> String {
        let skills = self.agent_skills.read().unwrap_or_else(|e| e.into_inner());
        if let Some(s) = skills.get(agent_name)
            && let Some(first) = s.first()
        {
            return first.clone();
        }
        let defaults = kavach_config::get_skill_agent_defaults();
        defaults.get(agent_name).cloned().unwrap_or_default()
    }

    pub fn should_prefer_skill(&self, task_type: &str) -> bool {
        let prefs = kavach_config::get_skill_preferred_keywords();
        let lower = task_type.to_lowercase();
        prefs.iter().any(|p| lower.contains(p))
    }
}

impl Default for SkillFirstRouter {
    fn default() -> Self { Self::new() }
}

#[cfg(test)]
#[path = "skill_first_tests.rs"]
mod tests;
