use std::collections::HashMap;

pub fn extract_framework_from_task(task: &str) -> Vec<String> {
    let patterns = load_framework_patterns();
    if patterns.is_empty() {
        return Vec::new();
    }
    let escaped: Vec<String> = patterns.iter().map(|p| regex::escape(p)).collect();
    let re_str = format!("(?i)({})", escaped.join("|"));
    let re = match regex::Regex::new(&re_str) {
        Ok(r) => r,
        Err(_) => return Vec::new(),
    };
    let mut seen = HashMap::new();
    for m in re.find_iter(task) {
        let lower = m.as_str().to_lowercase();
        seen.entry(lower).or_insert(());
    }
    seen.into_keys().collect()
}

pub(crate) fn load_framework_patterns() -> Vec<String> {
    let sections = kavach_config::get_framework_patterns();
    let all: Vec<String> = sections.values().flatten().cloned().collect();
    if all.is_empty() {
        return default_framework_patterns();
    }
    all
}

fn default_framework_patterns() -> Vec<String> {
    [
        "axum", "tonic", "tokio", "react", "vue", "angular", "dioxus",
        "leptos", "yew", "astro", "tauri", "postgres", "sqlx", "diesel",
        "prisma", "terraform", "kubernetes", "docker",
    ]
    .iter()
    .map(|s| s.to_string())
    .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_framework() {
        let fws = extract_framework_from_task("build an axum REST API with tokio");
        assert!(fws.contains(&"axum".to_string()));
        assert!(fws.contains(&"tokio".to_string()));
    }
}
