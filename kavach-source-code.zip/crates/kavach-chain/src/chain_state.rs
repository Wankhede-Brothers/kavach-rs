use chrono::Local;

use crate::types::{
    AegisVerification, CEODecision, IntentAnalysis, ResearchStatus, VerificationResult,
};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ChainState {
    pub session_id: String,
    pub intent: Option<IntentAnalysis>,
    pub ceo: Option<CEODecision>,
    pub aegis: Option<AegisVerification>,
    pub research: Option<ResearchStatus>,
    pub results: Vec<VerificationResult>,
    pub final_status: String,
}

impl ChainState {
    pub fn new(session_id: &str) -> Self {
        Self {
            session_id: session_id.into(),
            intent: None,
            ceo: None,
            aegis: None,
            research: None,
            results: Vec::new(),
            final_status: "pending".into(),
        }
    }

    pub fn add_result(&mut self, mut result: VerificationResult) {
        result.timestamp = Local::now().to_rfc3339();
        if result.status == "block" {
            self.final_status = "blocked".into();
        }
        self.results.push(result);
    }

    pub fn is_blocked(&self) -> bool {
        self.final_status == "blocked"
    }

    pub fn get_block_reason(&self) -> String {
        for r in &self.results {
            if r.status == "block" {
                return format!("{}: {}", r.gate, r.reason);
            }
        }
        String::new()
    }
}

#[cfg(test)]
#[path = "types_tests.rs"]
mod tests;
