use std::fmt::Write as FmtWrite;

use chrono::Local;

use crate::runner::Runner;

impl Runner {
    pub fn to_compact(&self) -> String {
        let mut s = String::new();
        let _ = writeln!(s, "[VERIFICATION_CHAIN]");
        let _ = writeln!(s, "session: {}", self.state.session_id);
        let _ = writeln!(s, "status: {}", self.state.final_status);
        let _ = writeln!(s, "timestamp: {}", Local::now().to_rfc3339());
        s.push('\n');

        for r in &self.state.results {
            let _ = writeln!(s, "[{}]", r.gate);
            let _ = writeln!(s, "status: {}", r.status);
            let _ = writeln!(s, "reason: {}", r.reason);
            if !r.next_action.is_empty() {
                let _ = writeln!(s, "next_action: {}", r.next_action);
            }
            s.push('\n');
        }
        s
    }
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use crate::runner::Runner;
    use crate::types::VerificationResult;

    #[test]
    fn test_runner_to_compact() {
        let mut runner = Runner::new("test-session");
        runner.state.final_status = "approved".into();
        runner.state.add_result(VerificationResult {
            gate: "INTENT".into(),
            status: "pass".into(),
            reason: "ok".into(),
            context: HashMap::new(),
            timestamp: String::new(),
            next_action: String::new(),
        });
        let toon = runner.to_compact();
        assert!(toon.contains("[VERIFICATION_CHAIN]"));
        assert!(toon.contains("status: approved"));
        assert!(toon.contains("[INTENT]"));
    }
}
