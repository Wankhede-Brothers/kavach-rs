use super::*;
use crate::types::IntentAnalysis;

#[test]
fn test_research_bypass() {
    let s = research_check(None, false, "fix typo in readme");
    assert!(s.bypass);
    assert!(s.bypass_reason.contains("Trivial"));
}

#[test]
fn test_research_required() {
    let intent = IntentAnalysis {
        intent_type: "implement".into(),
        confidence: 0.8,
        required_skills: Vec::new(),
        required_agents: Vec::new(),
        requires_research: true,
        complexity: "moderate".into(),
        risk_level: "low".into(),
    };
    let s = research_check(Some(&intent), false, "implement auth");
    assert!(!s.done);
    assert!(!s.suggested_query.is_empty());
}

#[test]
fn test_research_done() {
    let intent = IntentAnalysis {
        intent_type: "implement".into(),
        confidence: 0.8,
        required_skills: Vec::new(),
        required_agents: Vec::new(),
        requires_research: true,
        complexity: "moderate".into(),
        risk_level: "low".into(),
    };
    let s = research_check(Some(&intent), true, "implement auth");
    assert!(s.done);
}
