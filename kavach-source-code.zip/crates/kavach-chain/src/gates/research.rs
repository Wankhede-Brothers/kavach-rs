use crate::chain_state::ChainState;
use crate::types::{IntentAnalysis, ResearchStatus, VerificationResult};
use std::collections::HashMap;

use chrono::Local;

pub(crate) fn run_gate(state: &mut ChainState, research_done: bool, prompt: &str) {
    let research = research_check(state.intent.as_ref(), research_done, prompt);

    let mut result = VerificationResult {
        gate: "RESEARCH".into(),
        status: "pass".into(),
        reason: "TABULA_RASA compliance verified".into(),
        context: HashMap::new(),
        timestamp: String::new(),
        next_action: String::new(),
    };

    if research.bypass {
        result.reason = format!("Bypassed: {}", research.bypass_reason);
        state.research = Some(research);
        state.add_result(result);
        return;
    }

    let requires = state.intent.as_ref().map(|i| i.requires_research).unwrap_or(false);
    if !research.done && requires {
        result.status = "block".into();
        let itype = state.intent.as_ref().map(|i| i.intent_type.as_str()).unwrap_or("unknown");
        result.reason = format!("TABULA_RASA: Research required before {itype}");
        if !research.suggested_query.is_empty() {
            result.next_action = format!("WebSearch: {}", research.suggested_query);
            result
                .context
                .insert("suggested_query".into(), research.suggested_query.clone());
        }
    }

    state.research = Some(research);
    state.add_result(result);
}

pub fn research_check(
    intent: Option<&IntentAnalysis>,
    research_done: bool,
    prompt: &str,
) -> ResearchStatus {
    let mut status = ResearchStatus {
        done: research_done,
        sources: Vec::new(),
        suggested_query: String::new(),
        bypass: false,
        bypass_reason: String::new(),
    };

    let lower = prompt.to_lowercase();
    let bypass_patterns = [
        "typo", "comment", "rename", "format", "whitespace", "spacing", "fix typo",
    ];
    for p in &bypass_patterns {
        if lower.contains(p) {
            status.bypass = true;
            status.bypass_reason = format!("Trivial change: {p}");
            return status;
        }
    }

    if let Some(intent) = intent
        && intent.requires_research && !research_done
    {
        status.done = false;
        status.suggested_query = build_search_query(&intent.intent_type, prompt);
    }

    status
}

fn build_search_query(intent_type: &str, prompt: &str) -> String {
    let year = Local::now().format("%Y").to_string();
    let stop = ["this", "that", "with", "from", "have", "been"];
    let kw: String = prompt.split_whitespace()
        .filter(|w| w.len() > 3 && !stop.contains(w)).take(3)
        .collect::<Vec<_>>().join(" ");
    match intent_type {
        "implement" => format!("{kw} implementation patterns {year} best practices"),
        "debug" => format!("{kw} debugging troubleshooting {year} root cause"),
        "security" => format!("{kw} security best practices {year} OWASP"),
        "deploy" => format!("{kw} deployment patterns {year} production"),
        "refactor" => format!("{kw} refactoring patterns {year} clean code"),
        "memory" => format!("{kw} persistent memory architecture {year}"),
        _ => format!("{kw} latest patterns {year}"),
    }
}

#[cfg(test)]
#[path = "research_tests.rs"]
mod tests;
