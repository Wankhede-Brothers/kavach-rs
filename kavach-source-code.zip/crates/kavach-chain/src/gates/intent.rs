use std::collections::HashMap;

use crate::helpers::{contains_any, extract_agents};
use crate::chain_state::ChainState;
use crate::types::{IntentAnalysis, VerificationResult};

pub(crate) fn run_gate(state: &mut ChainState, prompt: &str) {
    let intent = analyze_intent(prompt);

    let mut result = VerificationResult {
        gate: "INTENT".into(),
        status: "pass".into(),
        reason: format!(
            "type={} confidence={:.2} risk={}",
            intent.intent_type, intent.confidence, intent.risk_level
        ),
        context: HashMap::from([
            ("type".into(), intent.intent_type.clone()),
            ("complexity".into(), intent.complexity.clone()),
            ("risk_level".into(), intent.risk_level.clone()),
        ]),
        timestamp: String::new(),
        next_action: String::new(),
    };

    if intent.risk_level == "critical" && intent.confidence < 0.7 {
        result.status = "warn".into();
        result.reason = format!(
            "INTENT: Critical risk with low confidence ({:.2}) — verify intent before proceeding",
            intent.confidence
        );
    }

    state.intent = Some(intent);
    state.add_result(result);
}

pub fn analyze_intent(prompt: &str) -> IntentAnalysis {
    let lower = prompt.to_lowercase();
    let mut a = IntentAnalysis {
        intent_type: "general".into(),
        confidence: 0.5,
        required_skills: Vec::new(),
        required_agents: Vec::new(),
        requires_research: true,
        complexity: "simple".into(),
        risk_level: "low".into(),
    };

    if contains_any(&lower, &["implement", "create", "build", "add", "develop", "write"]) {
        a.intent_type = "implement".into();
        a.requires_research = true;
        a.complexity = "moderate".into();
        a.confidence = 0.8;
    }
    if contains_any(&lower, &["fix", "bug", "error", "debug", "broken", "not working", "crash",
        "find", "discover", "locate", "trace", "investigate", "diagnose", "troubleshoot", "worst"]) {
        a.intent_type = "debug".into();
        if kavach_config::paths::skills_dir().join("debug-like-expert").join("SKILL.md").exists() {
            a.required_skills.push("debug-like-expert".into());
        }
        a.complexity = "moderate".into();
        a.confidence = 0.85;
    }
    if contains_any(&lower, &["refactor", "restructure", "clean up", "improve", "optimize"]) {
        a.intent_type = "refactor".into();
        a.requires_research = true;
        a.complexity = "complex".into();
        a.risk_level = "medium".into();
        a.confidence = 0.8;
    }
    if contains_any(&lower, &["deploy", "release", "publish", "production", "go live"]) {
        a.intent_type = "deploy".into();
        a.required_skills.push("cloud-infrastructure-mastery".into());
        a.risk_level = "high".into();
        a.complexity = "complex".into();
        a.confidence = 0.9;
        a.requires_research = true;
    }
    if contains_any(&lower, &["security", "auth", "encrypt", "vulnerability"]) {
        a.intent_type = "security".into();
        a.required_skills.push("security".into());
        a.risk_level = "high".into();
        a.requires_research = true;
        a.confidence = 0.85;
    }
    if contains_any(&lower, &["memory bank", "update memory", "remember this", "save to memory"]) {
        a.intent_type = "memory".into();
        a.confidence = 0.9;
        a.complexity = "simple".into();
        a.requires_research = false;
    }
    if contains_any(&lower, &["delete", "remove", "drop", "destroy", "purge"]) {
        a.risk_level = "critical".into();
        a.complexity = "complex".into();
        a.confidence = 0.75;
    }

    // Dynamic NLP skill routing — replaces static contains_any keyword matching.
    // Uses Aho-Corasick multi-pattern matching covering all 28 skills.
    // Only adds skills that exist on disk (checked via skills_dir).
    let sd = kavach_config::paths::skills_dir();
    for skill in kavach_patterns::skill_keyword_router::skills_from_keywords(prompt) {
        if sd.join(&skill).join("SKILL.md").exists()
            && !a.required_skills.iter().any(|s| s == &skill)
        {
            a.required_skills.push(skill);
        }
    }

    a.required_agents = extract_agents(&lower);
    a
}

#[cfg(test)]
#[path = "intent_tests.rs"]
mod tests;
