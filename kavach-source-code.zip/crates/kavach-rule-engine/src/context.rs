//! Evaluation context: input data for rule evaluation.

use serde::{Deserialize, Serialize};

/// Session phase for token budget awareness.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SessionPhase {
    Early,
    Mid,
    Late,
    Critical,
}

/// Input context for rule evaluation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvalContext {
    pub tool_name: String,
    pub file_path: Option<String>,
    pub prompt: String,
    pub content: Option<String>,
    pub research_done: bool,
    pub session_phase: SessionPhase,
    pub intent_type: String,
}

impl EvalContext {
    pub fn new(tool_name: &str, prompt: &str) -> Self {
        Self {
            tool_name: tool_name.to_string(),
            file_path: None,
            prompt: prompt.to_string(),
            content: None,
            research_done: false,
            session_phase: SessionPhase::Early,
            intent_type: kavach_patterns::classify_intent(prompt),
        }
    }

    pub fn with_file(mut self, path: &str) -> Self {
        self.file_path = Some(path.to_string());
        self
    }

    pub fn with_content(mut self, content: &str) -> Self {
        self.content = Some(content.to_string());
        self
    }

    pub fn with_research(mut self, done: bool) -> Self {
        self.research_done = done;
        self
    }

    pub fn with_phase(mut self, phase: SessionPhase) -> Self {
        self.session_phase = phase;
        self
    }

    pub fn is_write_tool(&self) -> bool {
        matches!(self.tool_name.as_str(), "Write" | "Edit" | "NotebookEdit")
    }

    pub fn is_code_target(&self) -> bool {
        self.file_path
            .as_deref()
            .map(kavach_patterns::is_code_file)
            .unwrap_or(false)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_new_context() {
        let ctx = EvalContext::new("Write", "fix the bug");
        assert_eq!(ctx.tool_name, "Write");
        assert!(!ctx.research_done);
    }

    #[test]
    fn test_builder_chain() {
        let ctx = EvalContext::new("Edit", "add feature")
            .with_file("src/main.rs")
            .with_research(true)
            .with_phase(SessionPhase::Mid);
        assert_eq!(ctx.file_path.as_deref(), Some("src/main.rs"));
        assert!(ctx.research_done);
        assert_eq!(ctx.session_phase, SessionPhase::Mid);
    }
}
