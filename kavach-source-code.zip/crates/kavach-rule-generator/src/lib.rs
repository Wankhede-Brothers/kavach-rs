//! Skill template generator from detected code patterns.
//! Auto-creates TOON skill files based on project analysis.

pub mod patterns;
pub mod detector;
pub mod template;
pub mod emitter;

pub use detector::{DetectedPattern, PatternType, detect_patterns};
pub use template::generate_skill;
pub use emitter::emit_skill;
pub use patterns::FrameworkPattern;
