use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// HookInput represents JSON input passed to any hook.
/// Wire-compatible with the Go `types.HookInput` struct.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct HookInput {
    // Common fields - ALL hooks receive these
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub session_id: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub transcript_path: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub cwd: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub permission_mode: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub hook_event_name: String,

    // PreToolUse / PostToolUse / PermissionRequest
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub tool_name: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_input: Option<HashMap<String, serde_json::Value>>,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub tool_use_id: String,

    // PostToolUse
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_response: Option<HashMap<String, serde_json::Value>>,

    // UserPromptSubmit
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub prompt: String,

    // Stop / SubagentStop
    #[serde(default)]
    pub stop_hook_active: bool,

    // SubagentStart / SubagentStop
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub agent_id: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub agent_type: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub agent_transcript_path: String,

    // SessionStart
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub source: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub model: String,

    // SessionEnd
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub reason: String,

    // PreCompact
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub trigger: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub custom_instructions: String,

    // Notification
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub message: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub notification_type: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub title: String,

    // Stop / SubagentStop
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub last_assistant_message: String,

    // InstructionsLoaded / ConfigChange
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub file_path: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub memory_type: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub load_reason: String,

    // WorktreeCreate
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub name: String,

    // WorktreeRemove
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub worktree_path: String,

    // TeammateIdle / TaskCompleted
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub teammate_name: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub team_name: String,

    // TaskCompleted
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub task_id: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub task_subject: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub task_description: String,

    // PostToolUseFailure
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub error: String,

    // PostCompact
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub compact_summary: String,
}

impl HookInput {
    /// Extract a string value from tool_input by key.
    /// Falls back to prompt field for "prompt" key.
    pub fn get_string(&self, key: &str) -> &str {
        if key == "prompt" && !self.prompt.is_empty() {
            return &self.prompt;
        }
        self.tool_input
            .as_ref()
            .and_then(|m| m.get(key))
            .and_then(|v| v.as_str())
            .unwrap_or("")
    }

    /// Extract a bool value from tool_input by key.
    pub fn get_bool(&self, key: &str) -> bool {
        self.tool_input
            .as_ref()
            .and_then(|m| m.get(key))
            .and_then(|v| v.as_bool())
            .unwrap_or(false)
    }

    /// Extract an integer value from tool_input by key.
    pub fn get_int(&self, key: &str) -> i64 {
        self.tool_input
            .as_ref()
            .and_then(|m| m.get(key))
            .and_then(|v| v.as_i64())
            .unwrap_or(0)
    }

    pub fn is_event(&self, event: &str) -> bool {
        self.hook_event_name == event
    }

    pub fn is_subagent_event(&self) -> bool {
        self.hook_event_name == "SubagentStart" || self.hook_event_name == "SubagentStop"
    }
}

/// HookSpecificOutput provides structured output per hook event type.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HookSpecificOutput {
    pub hook_event_name: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub permission_decision: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub permission_decision_reason: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub updated_input: Option<HashMap<String, serde_json::Value>>,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub additional_context: String,
}

/// HookResponse represents the hook's decision output.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HookResponse {
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub decision: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub reason: String,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub additional_context: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tool_input: Option<HashMap<String, serde_json::Value>>,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub hook_specific_output: Option<HookSpecificOutput>,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub r#continue: Option<bool>,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub stop_reason: String,
    #[serde(default)]
    pub suppress_output: bool,
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub system_message: String,
}

// --- Constructors ---

impl HookResponse {
    pub fn new_approve(reason: &str) -> Self {
        Self {
            decision: "approve".into(),
            reason: reason.into(),
            ..Default::default()
        }
    }

    pub fn new_block(reason: &str) -> Self {
        Self {
            decision: "block".into(),
            reason: reason.into(),
            ..Default::default()
        }
    }

    pub fn new_modify(reason: &str, context: &str) -> Self {
        Self {
            decision: "approve".into(),
            reason: reason.into(),
            additional_context: context.into(),
            ..Default::default()
        }
    }

    pub fn new_modify_input(reason: &str, modified_input: HashMap<String, serde_json::Value>) -> Self {
        Self {
            decision: "approve".into(),
            reason: reason.into(),
            tool_input: Some(modified_input),
            ..Default::default()
        }
    }

    // --- Claude Code 2026 format ---

    pub fn new_pre_tool_use_allow(reason: &str) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "PreToolUse".into(),
                permission_decision: "allow".into(),
                permission_decision_reason: reason.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_pre_tool_use_deny(reason: &str) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "PreToolUse".into(),
                permission_decision: "deny".into(),
                permission_decision_reason: reason.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_pre_tool_use_ask(reason: &str) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "PreToolUse".into(),
                permission_decision: "ask".into(),
                permission_decision_reason: reason.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_pre_tool_use_with_context(reason: &str, context: &str) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "PreToolUse".into(),
                permission_decision: "allow".into(),
                permission_decision_reason: reason.into(),
                additional_context: context.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_pre_tool_use_modify_input(
        reason: &str,
        updated_input: HashMap<String, serde_json::Value>,
    ) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "PreToolUse".into(),
                permission_decision: "allow".into(),
                permission_decision_reason: reason.into(),
                updated_input: Some(updated_input),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_post_tool_use_block(reason: &str, context: &str) -> Self {
        Self {
            decision: "block".into(),
            reason: reason.into(),
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "PostToolUse".into(),
                additional_context: context.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_user_prompt_submit_context(context: &str) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "UserPromptSubmit".into(),
                additional_context: context.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_user_prompt_submit_block(reason: &str) -> Self {
        Self {
            decision: "block".into(),
            reason: reason.into(),
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "UserPromptSubmit".into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    pub fn new_stop_block(reason: &str) -> Self {
        Self {
            decision: "block".into(),
            reason: reason.into(),
            ..Default::default()
        }
    }

    /// Permission: use decision/reason (no hookSpecificOutput for non-standard events).
    pub fn new_permission_allow(reason: &str) -> Self {
        Self {
            decision: "approve".into(),
            reason: reason.into(),
            ..Default::default()
        }
    }

    pub fn new_permission_deny(reason: &str) -> Self {
        Self {
            decision: "block".into(),
            reason: reason.into(),
            ..Default::default()
        }
    }

    pub fn new_permission_allow_with_input(
        reason: &str,
        updated_input: HashMap<String, serde_json::Value>,
    ) -> Self {
        Self {
            decision: "approve".into(),
            reason: reason.into(),
            tool_input: Some(updated_input),
            ..Default::default()
        }
    }

    /// SessionEnd: use systemMessage (no hookSpecificOutput).
    pub fn new_session_end_context(context: &str) -> Self {
        Self {
            system_message: context.into(),
            ..Default::default()
        }
    }

    /// SubagentStart: use systemMessage (no hookSpecificOutput).
    pub fn new_subagent_start_context(context: &str) -> Self {
        Self {
            system_message: context.into(),
            ..Default::default()
        }
    }

    /// SubagentStop: use systemMessage (no hookSpecificOutput).
    pub fn new_subagent_stop_context(context: &str) -> Self {
        Self {
            system_message: context.into(),
            ..Default::default()
        }
    }

    pub fn new_setup_context(context: &str) -> Self {
        Self {
            hook_specific_output: Some(HookSpecificOutput {
                hook_event_name: "Setup".into(),
                additional_context: context.into(),
                ..Default::default()
            }),
            ..Default::default()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hook_input_serde_roundtrip() {
        let json = r#"{
            "session_id": "sess_abc",
            "tool_name": "Bash",
            "tool_input": {"command": "ls -la"},
            "hook_event_name": "PreToolUse",
            "cwd": "/tmp"
        }"#;
        let input: HookInput = serde_json::from_str(json).unwrap();
        assert_eq!(input.session_id, "sess_abc");
        assert_eq!(input.tool_name, "Bash");
        assert_eq!(input.get_string("command"), "ls -la");
        assert!(input.is_event("PreToolUse"));
        assert!(!input.is_subagent_event());

        // Round-trip
        let serialized = serde_json::to_string(&input).unwrap();
        let deserialized: HookInput = serde_json::from_str(&serialized).unwrap();
        assert_eq!(deserialized.session_id, "sess_abc");
    }

    #[test]
    fn test_hook_input_empty() {
        let input: HookInput = serde_json::from_str("{}").unwrap();
        assert_eq!(input.get_string("anything"), "");
        assert!(!input.get_bool("anything"));
        assert_eq!(input.get_int("anything"), 0);
    }

    #[test]
    fn test_hook_input_prompt_fallback() {
        let input = HookInput {
            prompt: "hello world".into(),
            ..Default::default()
        };
        assert_eq!(input.get_string("prompt"), "hello world");
    }

    #[test]
    fn test_hook_response_approve() {
        let resp = HookResponse::new_approve("ok");
        let json = serde_json::to_string(&resp).unwrap();
        assert!(json.contains(r#""decision":"approve"#));
        assert!(json.contains(r#""reason":"ok"#));
    }

    #[test]
    fn test_hook_response_block() {
        let resp = HookResponse::new_block("denied");
        let json = serde_json::to_string(&resp).unwrap();
        assert!(json.contains(r#""decision":"block"#));
    }

    #[test]
    fn test_hook_specific_output_pretooluse() {
        let resp = HookResponse::new_pre_tool_use_deny("blocked cmd");
        let json = serde_json::to_string(&resp).unwrap();
        assert!(json.contains("PreToolUse"));
        assert!(json.contains("deny"));
    }

    #[test]
    fn test_hook_response_roundtrip_legacy() {
        let resp = HookResponse::new_modify("gate", "context here");
        let json = serde_json::to_string(&resp).unwrap();
        let parsed: HookResponse = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.decision, "approve");
        assert_eq!(parsed.additional_context, "context here");
    }

    #[test]
    fn test_subagent_event() {
        let input = HookInput {
            hook_event_name: "SubagentStart".into(),
            ..Default::default()
        };
        assert!(input.is_subagent_event());
    }
}
