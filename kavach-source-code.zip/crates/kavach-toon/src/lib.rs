use std::collections::HashMap;
use std::fmt;

/// A TOON block with key-value fields and arrays.
#[derive(Debug, Clone, Default)]
pub struct Block {
    pub name: String,
    pub fields: HashMap<String, String>,
    pub arrays: HashMap<String, Vec<String>>,
}

impl fmt::Display for Block {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.name)
    }
}

/// A parsed TOON document containing named blocks.
#[derive(Debug, Clone, Default)]
pub struct Document {
    pub blocks: HashMap<String, Block>,
}

impl Document {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn get(&self, name: &str) -> Option<&Block> {
        self.blocks.get(name)
    }

    pub fn add_block(&mut self, block: Block) {
        self.blocks.insert(block.name.clone(), block);
    }
}

/// Parse a TOON string into a Document.
/// Recognizes `[BLOCK_NAME]` headers and `key: value` fields.
pub fn parse_string(content: &str) -> Result<Document, String> {
    if content.trim().is_empty() {
        return Err("Empty TOON content".to_string());
    }

    let mut doc = Document::new();
    let mut current_block: Option<Block> = None;

    for line in content.lines() {
        let trimmed = line.trim();

        if trimmed.starts_with('[') && trimmed.ends_with(']') {
            if let Some(block) = current_block.take() {
                doc.add_block(block);
            }
            let name = trimmed[1..trimmed.len() - 1].to_string();
            current_block = Some(Block {
                name,
                fields: HashMap::new(),
                arrays: HashMap::new(),
            });
        } else if let Some(ref mut block) = current_block
            && let Some((key, value)) = trimmed.split_once(':')
        {
            let key = key.trim().to_string();
            let value = value.trim().to_string();
            if !key.is_empty() && !key.starts_with('#') {
                block.fields.insert(key, value);
            }
        }
    }

    if let Some(block) = current_block.take() {
        doc.add_block(block);
    }

    Ok(doc)
}
