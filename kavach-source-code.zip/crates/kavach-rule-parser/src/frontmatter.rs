//! YAML frontmatter parsing from TOON skill files

use serde::Deserialize;

fn default_priority() -> String {
    "advisory".into()
}

#[derive(Debug, Clone, Deserialize, Default)]
pub struct FrontmatterMetadata {
    #[serde(default)]
    pub triggers: Vec<String>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Frontmatter {
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub license: String,
    #[serde(default)]
    pub compatibility: String,
    #[serde(default)]
    pub file_patterns: Vec<String>,
    /// Alias for file_patterns used in some SKILL.md files.
    #[serde(default)]
    pub paths: Vec<String>,
    #[serde(default = "default_priority")]
    pub priority: String,
    #[serde(default)]
    pub metadata: FrontmatterMetadata,
}

impl Frontmatter {
    /// Returns file_patterns, falling back to paths if file_patterns is empty.
    pub fn effective_patterns(&self) -> &[String] {
        if !self.file_patterns.is_empty() {
            &self.file_patterns
        } else {
            &self.paths
        }
    }
}

#[derive(Debug, thiserror::Error)]
pub enum ParseError {
    #[error("Invalid frontmatter format")]
    InvalidFormat,
    #[error("YAML parsing error: {0}")]
    YamlError(String),
}

pub fn parse_frontmatter(content: &str) -> Result<Frontmatter, ParseError> {
    let lines: Vec<&str> = content.lines().collect();

    if !lines.first().is_some_and(|l| l.starts_with("---")) {
        return Err(ParseError::InvalidFormat);
    }

    let yaml_content: String = lines
        .iter()
        .skip(1)
        .take_while(|l| !l.starts_with("---"))
        .copied()
        .collect::<Vec<&str>>()
        .join("\n");

    if yaml_content.trim().is_empty() {
        return Err(ParseError::InvalidFormat);
    }

    serde_yaml::from_str(&yaml_content)
        .map_err(|e| ParseError::YamlError(e.to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_frontmatter_with_patterns() {
        let content = "---\nname: rust\ndescription: Rust skill\nfile_patterns:\n  - \"*.rs\"\n  - \"Cargo.toml\"\npriority: critical\n---\nbody";
        let fm = parse_frontmatter(content).unwrap();
        assert_eq!(fm.name, "rust");
        assert_eq!(fm.file_patterns, vec!["*.rs", "Cargo.toml"]);
        assert_eq!(fm.priority, "critical");
    }

    #[test]
    fn test_parse_frontmatter_without_patterns() {
        let content = "---\nname: general\ndescription: General skill\n---\nbody";
        let fm = parse_frontmatter(content).unwrap();
        assert_eq!(fm.name, "general");
        assert!(fm.file_patterns.is_empty());
        assert_eq!(fm.priority, "advisory");
    }
}
