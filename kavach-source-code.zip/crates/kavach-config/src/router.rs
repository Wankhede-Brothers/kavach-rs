use std::collections::HashMap;
use crate::loaders::get_router_mappings;

pub fn get_intent_skill_mappings() -> HashMap<String, String> {
    let data = get_router_mappings();
    let mut result = HashMap::new();
    if let Some(lines) = data.get("SKILL:INTENT_MAPPINGS") {
        for line in lines {
            if let Some((k, v)) = line.split_once(':') {
                result.insert(k.trim().to_string(), v.trim().to_string());
            }
        }
    }
    result
}

pub fn get_complex_indicators() -> Vec<String> {
    get_router_mappings()
        .get("COMPLEX:INDICATORS")
        .cloned()
        .unwrap_or_default()
}

pub fn get_skill_agent_defaults() -> HashMap<String, String> {
    let data = get_router_mappings();
    let mut result = HashMap::new();
    if let Some(lines) = data.get("SKILL:AGENT_DEFAULTS") {
        for line in lines {
            if let Some((k, v)) = line.split_once(':') {
                result.insert(k.trim().to_string(), v.trim().to_string());
            }
        }
    }
    result
}

pub fn get_skill_preferred_keywords() -> Vec<String> {
    get_router_mappings()
        .get("SKILL:PREFERRED_KEYWORDS")
        .cloned()
        .unwrap_or_default()
}
