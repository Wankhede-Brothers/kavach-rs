//! Platform-aware path helpers for skills and registry cache.

use std::io::Write;
use std::path::PathBuf;

/// Path to the skills directory (~/.claude/skills/).
pub fn skills_dir() -> PathBuf {
    match dirs::home_dir() {
        Some(home) => home.join(".claude").join("skills"),
        None => {
            let _ = writeln!(std::io::stderr(), "[kavach] WARNING: home_dir() returned None — skill lookups will fail");
            PathBuf::from("/nonexistent/.claude/skills")
        }
    }
}

/// Path to the registry cache file (~/.cache/kavach/skill-registry.json).
pub fn registry_cache_path() -> PathBuf {
    let cache = dirs::cache_dir().or_else(|| {
        dirs::home_dir().map(|h| h.join(".cache"))
    });
    match cache {
        Some(dir) => dir.join("kavach").join("skill-registry.json"),
        None => {
            let _ = writeln!(std::io::stderr(), "[kavach] WARNING: no cache or home dir — registry cache disabled");
            PathBuf::from("/nonexistent/.cache/kavach/skill-registry.json")
        }
    }
}

/// Path to the Tailwind Plus component directory (~/.claude/tailwind-plus/).
pub fn tailwind_plus_dir() -> PathBuf {
    match dirs::home_dir() {
        Some(home) => home.join(".claude").join("tailwind-plus"),
        None => {
            let _ = writeln!(std::io::stderr(), "[kavach] WARNING: home_dir() returned None — tailwind-plus lookups will fail");
            PathBuf::from("/nonexistent/.claude/tailwind-plus")
        }
    }
}

/// Path to the Tailwind Plus component index (~/.claude/tailwind-plus/index.json).
pub fn tailwind_plus_index() -> PathBuf {
    tailwind_plus_dir().join("index.json")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_skills_dir_ends_with_skills() {
        let path = skills_dir();
        assert!(path.ends_with("skills"));
    }

    #[test]
    fn test_registry_cache_path_ends_with_json() {
        let path = registry_cache_path();
        let name = path.file_name().and_then(|n| n.to_str());
        assert_eq!(name, Some("skill-registry.json"));
    }

    #[test]
    fn test_tailwind_plus_dir_ends_with_tailwind_plus() {
        assert!(tailwind_plus_dir().ends_with("tailwind-plus"));
    }

    #[test]
    fn test_tailwind_plus_index_ends_with_json() {
        let path = tailwind_plus_index();
        let name = path.file_name().and_then(|n| n.to_str());
        assert_eq!(name, Some("index.json"));
    }

    #[test]
    fn test_tailwind_plus_index_inside_tailwind_plus_dir() {
        let dir = tailwind_plus_dir();
        let idx = tailwind_plus_index();
        assert_eq!(idx.parent(), Some(dir.as_path()));
    }
}
