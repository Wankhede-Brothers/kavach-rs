//! Save, load, and check staleness of the registry cache.

use std::path::Path;

use crate::error::{Result, StorageError};
use crate::registry::SkillRegistry;

pub fn save_registry(path: &Path, registry: &SkillRegistry) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let json = serde_json::to_string_pretty(registry)
        .map_err(|e| StorageError::ParseError(e.to_string()))?;
    std::fs::write(path, json)?;
    Ok(())
}

pub fn load_registry(path: &Path) -> Result<SkillRegistry> {
    let content = std::fs::read_to_string(path)?;
    serde_json::from_str(&content)
        .map_err(|e| StorageError::ParseError(e.to_string()))
}

pub fn is_stale(cache_path: &Path, current_hash: &str) -> bool {
    match load_registry(cache_path) {
        Ok(cached) => cached.hash != current_hash,
        Err(_) => true,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::registry::{RegistryEntry, SkillRegistry};
    use kavach_rule_ast::SkillPriority;

    fn sample_registry(hash: &str) -> SkillRegistry {
        SkillRegistry {
            version: 1,
            hash: hash.into(),
            built_at: "2026-03-14T00:00:00".into(),
            skills: vec![RegistryEntry {
                name: "sp-rust".into(),
                file_patterns: vec!["*.rs".into()],
                priority: SkillPriority::Critical,
            }],
        }
    }

    #[test]
    fn test_save_and_load_registry() {
        let dir = tempfile::tempdir().expect("failed to create temp dir for registry test");
        let path = dir.path().join("registry.json");
        let reg = sample_registry("deadbeef");
        save_registry(&path, &reg).expect("save_registry should write JSON to temp path");
        let loaded = load_registry(&path).expect("load_registry should parse written JSON");
        assert_eq!(loaded.hash, "deadbeef");
        assert_eq!(loaded.skills.len(), 1);
        assert_eq!(loaded.version, 1);
    }

    #[test]
    fn test_load_missing_returns_err() {
        let result = load_registry(Path::new("/nonexistent/path/registry.json"));
        assert!(result.is_err());
    }

    #[test]
    fn test_is_stale_when_hash_differs() {
        let dir = tempfile::tempdir().expect("failed to create temp dir for staleness test");
        let path = dir.path().join("registry.json");
        let reg = sample_registry("hash-a");
        save_registry(&path, &reg).expect("save_registry should write registry for staleness test");
        assert!(is_stale(&path, "hash-b"));
        assert!(!is_stale(&path, "hash-a"));
    }
}
