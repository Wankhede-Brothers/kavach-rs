//! Central rule store: in-memory cache backed by disk persistence.

use std::collections::HashMap;
use std::path::PathBuf;

use kavach_rule_ast::SkillDefinition;
use serde::{Deserialize, Serialize};

use crate::error::{Result, StorageError};
use crate::index::RuleIndex;
use crate::version::RuleVersion;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoredRule {
    pub definition: SkillDefinition,
    pub source_path: PathBuf,
    pub content_hash: String,
    pub last_modified: String,
    pub version: u32,
}

pub struct RuleStore {
    pub(crate) rules_dir: PathBuf,
    pub(crate) cache: HashMap<String, StoredRule>,
    pub(crate) index: RuleIndex,
}

impl RuleStore {
    pub fn new(rules_dir: PathBuf) -> Self {
        Self {
            rules_dir,
            cache: HashMap::new(),
            index: RuleIndex::new(),
        }
    }

    pub fn load_all(&mut self) -> Result<()> {
        self.cache.clear();
        let loaded = crate::loader::load_rules_from_dir(&self.rules_dir)?;
        for rule in loaded {
            let name = rule.definition.metadata.name.clone();
            self.cache.insert(name, rule);
        }
        self.index.rebuild(&self.cache);
        Ok(())
    }

    pub fn get(&self, name: &str) -> Option<&StoredRule> {
        self.cache.get(name)
    }

    pub fn save(&mut self, rule: &StoredRule) -> Result<PathBuf> {
        let path = crate::writer::write_rule(&self.rules_dir, rule)?;
        let name = rule.definition.metadata.name.clone();
        let mut saved = rule.clone();
        saved.source_path = path.clone();
        self.cache.insert(name, saved);
        self.index.rebuild(&self.cache);
        Ok(path)
    }

    pub fn list(&self) -> Vec<&str> {
        self.cache.keys().map(|k| k.as_str()).collect()
    }

    pub fn remove(&mut self, name: &str) -> Result<()> {
        let rule = self.cache.remove(name)
            .ok_or_else(|| StorageError::NotFound(name.into()))?;
        if rule.source_path.exists() {
            std::fs::remove_file(&rule.source_path)?;
        }
        self.index.rebuild(&self.cache);
        Ok(())
    }

    pub fn by_trigger(&self, trigger: &str) -> Vec<&str> {
        self.index.by_trigger(trigger)
    }

    pub fn by_category(&self, category: &str) -> Vec<&str> {
        self.index.by_category(category)
    }

    pub fn has_changed(&self, name: &str) -> Result<bool> {
        let rule = self.cache.get(name)
            .ok_or_else(|| StorageError::NotFound(name.into()))?;
        RuleVersion::has_file_changed(rule)
    }
}
