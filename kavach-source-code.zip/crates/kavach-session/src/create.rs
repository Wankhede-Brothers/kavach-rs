use std::fmt::Write as FmtWrite;

use chrono::Local;

use crate::paths::{detect_project, today};
use crate::state::SessionState;

fn generate_session_id(work_dir: &str) -> String {
    // BLAKE3: 4x faster than SHA-256, same 128-bit collision resistance, simpler API.
    let mut hasher = blake3::Hasher::new();
    hasher.update(work_dir.as_bytes());
    hasher.update(Local::now().format("%Y%m%d").to_string().as_bytes());
    let hash = hasher.finalize();
    let hex: String = hash.as_bytes().iter().take(16).fold(String::new(), |mut s, b| {
        let _ = write!(s, "{b:02x}");
        s
    });
    format!("sess_{hex}")
}

impl SessionState {
    pub fn new(work_dir: &str) -> Self {
        let id = generate_session_id(work_dir);
        Self {
            id: id.clone(),
            session_id: id,
            today: today(),
            work_dir: work_dir.into(),
            project: detect_project(),
            ..Default::default()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::paths::today;

    #[test]
    fn test_generate_session_id() {
        let id = generate_session_id("/tmp/test");
        assert!(id.starts_with("sess_"));
        assert_eq!(id.len(), 5 + 32);
    }

    #[test]
    fn test_new_session() {
        let s = SessionState::new("/tmp/test");
        assert!(s.id.starts_with("sess_"));
        assert_eq!(s.today, today());
        assert_eq!(s.token_budget_total, 180000);
        assert_eq!(s.context_phase, "early");
        assert_eq!(s.subagent_max_output, 8000);
    }
}
