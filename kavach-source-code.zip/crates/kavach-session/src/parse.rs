use crate::load::split_csv;
use crate::state::{
    SessionState, DEFAULT_SUBAGENT_MAX_OUTPUT, DEFAULT_SUBAGENT_TOTAL_CAP, DEFAULT_TOKEN_BUDGET,
};

fn set_csv(target: &mut Vec<String>, value: &str) {
    if !value.is_empty() {
        *target = split_csv(value);
    }
}

/// Safe i32 parse — kavach eats its own dogfood (no unwrap_or in production).
fn pi32(value: &str, default: i32) -> i32 {
    match value.parse() { Ok(v) => v, Err(_) => default }
}

pub(crate) fn parse_field(
    state: &mut SessionState,
    key: &str,
    value: &str,
    in_files: &mut bool,
) {
    match key {
        "id" => state.id = value.into(),
        "today" => state.today = value.into(),
        "project" => state.project = value.into(),
        "workdir" => state.work_dir = value.into(),
        "research" | "research_done" => state.research_done = value == "true",
        "research_topics" => set_csv(&mut state.research_topics, value),
        "memory" => state.memory_queried = value == "true",
        "cutoff" => state.training_cutoff = value.into(),
        "post_compact" => state.post_compact = value == "true",
        "compacted_at" => state.compacted_at = value.into(),
        "compact_count" => state.compact_count = pi32(value, 0),
        "turn_count" => state.turn_count = pi32(value, 0),
        "last_reinforce_turn" => state.last_reinforce_turn = pi32(value, 0),
        "reinforce_every_n" => state.reinforce_every_n = pi32(value, 15),
        "tasks_created" => state.tasks_created = pi32(value, 0),
        "tasks_completed" => state.tasks_completed = pi32(value, 0),
        "session_id" => state.session_id = value.into(),
        "task" => state.current_task = value.into(),
        "task_status" => state.task_status = value.into(),
        "task_list_id" => state.task_list_id = value.into(),
        "files[]" => {
            *in_files = true;
            if !value.is_empty() {
                state.files_modified.push(value.into());
            }
        }
        "type" => {
            if state.intent_type.is_empty() {
                state.intent_type = value.into();
            }
        }
        "domain" => {
            if state.intent_domain.is_empty() {
                state.intent_domain = value.into();
            }
        }
        "skills" => {
            if !value.is_empty() && state.intent_skills.is_empty() {
                state.intent_skills = split_csv(value);
            }
        }
        "token_budget_total" => state.token_budget_total = pi32(value, DEFAULT_TOKEN_BUDGET),
        "token_budget_used" => state.token_budget_used = pi32(value, 0),
        "context_phase" => state.context_phase = value.into(),
        "active_subagents" => state.active_subagents = pi32(value, 0),
        "subagent_max_output" => state.subagent_max_output = pi32(value, DEFAULT_SUBAGENT_MAX_OUTPUT),
        "subagent_total_cap" => state.subagent_total_cap = pi32(value, DEFAULT_SUBAGENT_TOTAL_CAP),
        "team_name" => state.team_name = value.into(),
        "team_members" => set_csv(&mut state.team_members, value),
        "active_teammates" => state.active_teammates = pi32(value, 0),
        "model_id" => state.model_id = value.into(),
        "last_failure_tool" => state.last_failure_tool = value.into(),
        "last_failure_turn" => state.last_failure_turn = pi32(value, 0),
        "failure_block_count" => state.failure_block_count = pi32(value, 0),
        "failure_type" => state.failure_type = value.into(),
        "specs_injected" => set_csv(&mut state.specs_injected, value),
        "modules_injected" => set_csv(&mut state.modules_injected, value),
        "required_skills" => set_csv(&mut state.required_skills, value),
        "invoked_skills" => set_csv(&mut state.invoked_skills, value),
        "research_topic" => state.research_topic = value.into(),
        "last_subagent_turn" => state.last_subagent_turn = pi32(value, 0),
        "subagent_action_pending" => state.subagent_action_pending = value == "true",
        "subagent_action_turn" => state.subagent_action_turn = pi32(value, 0),
        "recent_commands" => set_csv(&mut state.recent_commands, value),
        "test_files_pending" => set_csv(&mut state.test_files_pending, value),
        "test_nudge_count" => state.test_nudge_count = pi32(value, 0),
        "last_api_error" => state.last_api_error = value.into(),
        "api_error_count" => state.api_error_count = pi32(value, 0),
        "last_api_error_time" => state.last_api_error_time = value.into(),
        "intent_risk" => state.intent_risk = value.into(),
        "last_write_turn" => state.last_write_turn = pi32(value, 0),
        "last_db_write_turn" => state.last_db_write_turn = pi32(value, 0),
        "subagent_files_read" => state.subagent_files_read = pi32(value, 0),
        "new_crate_confirmed" => state.new_crate_confirmed = value == "true",
        "algo_hunter_invoked" => state.algo_hunter_invoked = value == "true",
        "websearch_count_since_intent" => state.websearch_count_since_intent = pi32(value, 0),
        "intent_set_turn" => state.intent_set_turn = pi32(value, 0),
        "think_first_injected" => state.think_first_injected = value == "true",
        "research_advisory_sent" => state.research_advisory_sent = value == "true",
        "arch_skill_invoked" => state.arch_skill_invoked = value == "true",
        // ARCH: CircuitBreakerParsing — field parsing for circuit breaker state
        // PATTERN: circuit_breaker | SCOPE: session | CAP: AP | SEARCHED: 2026-04
        "gate_circuit_breaker_threshold" => state.gate_circuit_breaker_threshold = pi32(value, 3),
        "tripped_gate_categories" => set_csv(&mut state.tripped_gate_categories, value),
        "files_modified_this_turn" => {
            state.files_modified_this_turn = value
                .split(',')
                .filter(|s| !s.is_empty())
                .map(str::to_string)
                .collect();
        }
        "active_test_crates" => {
            state.active_test_crates = value
                .split(',')
                .filter(|s| !s.is_empty())
                .map(str::to_string)
                .collect();
        }
        _ => parse_output_field(state, key, value),
    }
}

fn parse_output_field(state: &mut SessionState, key: &str, value: &str) {
    if let Some(agent_id) = key.strip_prefix("output:")
        && !agent_id.is_empty()
    {
        let chars: i32 = pi32(value, 0);
        state.subagent_outputs.insert(agent_id.into(), chars);
    }
}
