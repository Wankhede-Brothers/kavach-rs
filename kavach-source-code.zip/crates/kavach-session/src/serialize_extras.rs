use std::fmt::Write as FmtWrite;

use crate::save::join_csv;
use crate::serialize::write_kv;
use crate::state::SessionState;

impl SessionState {
    pub(crate) fn serialize_extras(&self, s: &mut String) {
        if !self.intent_type.is_empty() {
            s.push_str("[INTENT_BRIDGE]\n");
            write_kv(s, "type", &self.intent_type);
            write_kv(s, "domain", &self.intent_domain);
            if !self.intent_skills.is_empty() {
                write_kv(s, "skills", &join_csv(&self.intent_skills));
            }
            s.push('\n');
        }

        s.push_str("[TOKEN_BUDGET]\n");
        write_kv(s, "token_budget_total", &self.token_budget_total.to_string());
        write_kv(s, "token_budget_used", &self.token_budget_used.to_string());
        write_kv(s, "context_phase", &self.context_phase);
        s.push('\n');

        s.push_str("[SUBAGENT_TRACKING]\n");
        write_kv(s, "active_subagents", &self.active_subagents.to_string());
        write_kv(s, "subagent_max_output", &self.subagent_max_output.to_string());
        write_kv(s, "subagent_total_cap", &self.subagent_total_cap.to_string());
        write_kv(s, "last_subagent_turn", &self.last_subagent_turn.to_string());
        write_kv(s, "subagent_action_pending", if self.subagent_action_pending { "true" } else { "false" });
        write_kv(s, "subagent_action_turn", &self.subagent_action_turn.to_string());
        let mut agent_ids: Vec<&String> = self.subagent_outputs.keys().collect();
        agent_ids.sort();
        for id in agent_ids {
            let chars = self.subagent_outputs[id];
            let _ = writeln!(s, "output:{id}: {chars}");
        }
        s.push('\n');

        if !self.modules_injected.is_empty() {
            s.push_str("[MODULES]\n");
            write_kv(s, "modules_injected", &join_csv(&self.modules_injected));
            s.push('\n');
        }

        if !self.specs_injected.is_empty() {
            s.push_str("[SPECS]\n");
            write_kv(s, "specs_injected", &join_csv(&self.specs_injected));
            s.push('\n');
        }

        if !self.last_failure_tool.is_empty() {
            s.push_str("[FAILURE_TRACKING]\n");
            write_kv(s, "last_failure_tool", &self.last_failure_tool);
            write_kv(s, "last_failure_turn", &self.last_failure_turn.to_string());
            write_kv(s, "failure_block_count", &self.failure_block_count.to_string());
            if !self.failure_type.is_empty() {
                write_kv(s, "failure_type", &self.failure_type);
            }
            s.push('\n');
        }

        if !self.last_api_error.is_empty() {
            s.push_str("[API_ERROR_TRACKING]\n");
            write_kv(s, "last_api_error", &self.last_api_error);
            write_kv(s, "api_error_count", &self.api_error_count.to_string());
            write_kv(s, "last_api_error_time", &self.last_api_error_time);
            s.push('\n');
        }

        if self.new_crate_confirmed {
            s.push_str("[NEW_CRATE]\n");
            write_kv(s, "new_crate_confirmed", "true");
            s.push('\n');
        }

        if self.algo_hunter_invoked {
            s.push_str("[ALGO_HUNTER]\n");
            write_kv(s, "algo_hunter_invoked", "true");
            s.push('\n');
        }

        if self.arch_skill_invoked {
            s.push_str("[ARCH_GATE]\n");
            write_kv(s, "arch_skill_invoked", "true");
            s.push('\n');
        }

        if self.websearch_count_since_intent > 0 || self.intent_set_turn > 0 {
            s.push_str("[EVIDENCE_CHAIN]\n");
            write_kv(s, "websearch_count_since_intent", &self.websearch_count_since_intent.to_string());
            write_kv(s, "intent_set_turn", &self.intent_set_turn.to_string());
            s.push('\n');
        }

        if self.think_first_injected {
            s.push_str("[ELICITATION]\n");
            write_kv(s, "think_first_injected", "true");
            s.push('\n');
        }

        if self.research_advisory_sent {
            s.push_str("[RESEARCH_ADVISORY]\n");
            write_kv(s, "research_advisory_sent", "true");
            s.push('\n');
        }

        if !self.files_modified_this_turn.is_empty() {
            s.push_str("[SURGICAL_TRACKING]\n");
            write_kv(s, "files_modified_this_turn", &self.files_modified_this_turn.join(","));
            s.push('\n');
        }

        if !self.active_test_crates.is_empty() {
            s.push_str("[TEST_RUN_TRACKING]\n");
            write_kv(s, "active_test_crates", &self.active_test_crates.join(","));
            s.push('\n');
        }

        // ARCH: CircuitBreakerSerialization — persist circuit breaker state
        // PATTERN: circuit_breaker | SCOPE: session | CAP: AP | SEARCHED: 2026-04
        if !self.tripped_gate_categories.is_empty() || self.gate_circuit_breaker_threshold != 3 {
            s.push_str("[CIRCUIT_BREAKER]\n");
            write_kv(s, "gate_circuit_breaker_threshold", &self.gate_circuit_breaker_threshold.to_string());
            if !self.tripped_gate_categories.is_empty() {
                write_kv(s, "tripped_gate_categories", &join_csv(&self.tripped_gate_categories));
            }
            s.push('\n');
        }

        self.serialize_enforcement_sections(s);
    }
}

// Tests moved to serialize_tests.rs (test_to_ini, test_to_ini_full_roundtrip)
#[cfg(test)]
#[path = "serialize_tests.rs"]
mod tests;
