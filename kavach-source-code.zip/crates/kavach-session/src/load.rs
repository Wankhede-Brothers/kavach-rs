use std::fs;
use std::io;

use crate::parse::parse_field;
use crate::paths::{ensure_parent_dir, state_path, today};
use crate::state::SessionState;

pub fn load_session_state() -> Result<Option<SessionState>, io::Error> {
    let path = state_path();
    if !path.exists() {
        return Ok(None);
    }

    // Shared lock prevents reading while a save() holds exclusive lock.
    // Multiple readers can proceed concurrently (shared is non-exclusive).
    let lock_path = path.with_extension("lock");
    ensure_parent_dir(&lock_path)?;
    let lock_file = fs::OpenOptions::new()
        .create(true)
        .truncate(true)
        .write(true)
        .open(&lock_path)?;
    lock_file.lock_shared()?;

    let content = fs::read_to_string(&path)?;

    lock_file.unlock()?;
    let mut state = SessionState::default();
    let mut in_files = false;
    let mut in_case_facts = false;

    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') {
            continue;
        }
        if trimmed.starts_with('[') {
            in_files = false;
            in_case_facts = trimmed == "[CASE_FACTS]";
            continue;
        }
        if in_files && trimmed.starts_with("- ") {
            state
                .files_modified
                .push(trimmed.strip_prefix("- ").unwrap_or(trimmed).to_string());
            continue;
        }
        if in_case_facts && trimmed.starts_with("- ") {
            state
                .case_facts
                .push(trimmed.strip_prefix("- ").unwrap_or(trimmed).to_string());
            continue;
        }
        if let Some(idx) = trimmed.find(':') {
            let key = trimmed[..idx].trim();
            let value = trimmed[idx + 1..].trim();
            parse_field(&mut state, key, value, &mut in_files);
        }
    }

    if state.today != today() {
        return Ok(None);
    }

    Ok(Some(state))
}

pub(crate) fn split_csv(s: &str) -> Vec<String> {
    s.split(',')
        .map(|p| p.trim().to_string())
        .filter(|p| !p.is_empty())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_split_csv() {
        assert_eq!(split_csv("a, b, c"), vec!["a", "b", "c"]);
        assert_eq!(split_csv(""), Vec::<String>::new());
        assert_eq!(split_csv("solo"), vec!["solo"]);
    }
}
