use crate::state::SessionState;

impl SessionState {
    /// Record which skills are required for this prompt turn.
    pub fn set_required_skills(&mut self, skills: Vec<String>) {
        self.required_skills = skills;
        self.invoked_skills.clear();
        self.save_or_log();
    }

    /// Record a skill invocation.
    pub fn record_skill_invoked(&mut self, skill_name: &str) {
        if !self.invoked_skills.iter().any(|s| s == skill_name) {
            self.invoked_skills.push(skill_name.into());
            self.save_or_log();
        }
    }

    /// Check if all required skills have been invoked.
    pub fn all_skills_satisfied(&self) -> bool {
        self.required_skills.iter().all(|req| {
            self.invoked_skills.iter().any(|inv| inv == req)
        })
    }

    /// Get list of missing (not yet invoked) skills.
    pub fn missing_skills(&self) -> Vec<&str> {
        self.required_skills
            .iter()
            .filter(|req| {
                !self.invoked_skills.iter().any(|inv| inv == req.as_str())
            })
            .map(|s| s.as_str())
            .collect()
    }

    /// Set what topic needs research.
    pub fn set_research_topic(&mut self, topic: &str) {
        self.research_topic = topic.into();
        self.save_or_log();
    }

    /// Kept for display in gate messages only — hard-blocking is disabled.
    /// `cargo check` and `clippy` are the real quality gates. Test enforcement
    /// is advisory-only to prevent the circular deadlock where the gate blocks
    /// the edit that fixes the compile error preventing `cargo test` from running.
    pub const TEST_BLOCK_THRESHOLD: i32 = i32::MAX;

    /// Mark a source file as needing test coverage.
    pub fn add_test_pending(&mut self, file_path: &str) {
        if !self.test_files_pending.iter().any(|f| f == file_path) {
            self.test_files_pending.push(file_path.into());
            self.test_nudge_count += 1;
            self.save_or_log();
        }
    }

    /// Check if any files are pending test coverage.
    pub fn has_pending_tests(&self) -> bool {
        !self.test_files_pending.is_empty()
    }

    /// Always false — test enforcement is advisory-only, never a hard block.
    /// Hard-blocking caused circular deadlocks when compile errors prevented
    /// cargo test from clearing the gate. Nudges remain active via post_write.
    pub fn should_block_for_tests(&self) -> bool {
        false
    }

    /// Clear all pending test files (called after tests are run).
    pub fn clear_test_pending(&mut self) {
        self.test_files_pending.clear();
        self.test_nudge_count = 0;
        self.save_or_log();
    }

    /// Reset enforcement state for a new user prompt.
    pub fn reset_enforcement(&mut self) {
        self.required_skills.clear();
        self.invoked_skills.clear();
        self.research_topic.clear();
        self.research_done = false;
        self.save_or_log();
    }

    /// Open a new evidence window for the current intent turn.
    /// Called by the intent gate whenever a new user prompt is classified.
    pub fn reset_evidence_window(&mut self) {
        self.websearch_count_since_intent = 0;
        self.intent_set_turn = self.turn_count;
        // Reset per-turn surgical tracking and elicitation flag on each new intent window.
        self.think_first_injected = false;
        self.research_advisory_sent = false;
        self.files_modified_this_turn = Vec::new();
        self.save_or_log();
    }

    /// Record one WebSearch or WebFetch tool completion in the current window.
    pub fn record_websearch(&mut self) {
        self.websearch_count_since_intent = self.websearch_count_since_intent.saturating_add(1);
        self.save_or_log();
    }

    /// Return true when sufficient research evidence exists before a Write.
    ///
    /// Blocks only when ALL conditions hold simultaneously:
    /// - intent_type is "implement" (research required by design)
    /// - no WebSearch has fired since the intent was set
    /// - the window is fresh (intent_set_turn == turn_count, same turn or one
    ///   turn behind — prevents blocking writes in later turns of a multi-turn
    ///   implement flow that already researched on turn N)
    pub fn evidence_window_satisfied(&self) -> bool {
        if self.intent_type != "implement" {
            return true;
        }
        if self.websearch_count_since_intent > 0 {
            return true;
        }
        // Allow writes in turns after the intent turn — research may have
        // occurred in the same turn as the intent classification, which is
        // persisted via record_websearch before pre_write fires.
        false
    }

    // ARCH: CircuitBreakerMethods — O(1) operations for gate circuit breaker
    // PATTERN: circuit_breaker | SCOPE: session | CAP: AP | SEARCHED: 2026-04
    // Per Meta-Harness research: complex verification gates degrade performance.
    // Circuit breaker trips after N blocks per category, then force-allows.

    /// Record a gate block for a category. Returns true if circuit should trip.
    /// O(1) lookup + increment via HashMap.
    pub fn record_gate_block(&mut self, category: &str) -> bool {
        let count = self.gate_block_counts.entry(category.into()).or_insert(0);
        *count = count.saturating_add(1);
        let should_trip = *count >= self.gate_circuit_breaker_threshold;
        if should_trip && !self.tripped_gate_categories.contains(&category.to_string()) {
            self.tripped_gate_categories.push(category.into());
        }
        self.save_or_log();
        should_trip
    }

    /// Check if a gate category has tripped (force-allow with advisory).
    /// O(n) where n = number of tripped categories (bounded by ~30).
    pub fn is_gate_tripped(&self, category: &str) -> bool {
        self.tripped_gate_categories.iter().any(|c| c == category)
    }

    /// Get block count for a category. O(1) lookup.
    pub fn gate_block_count(&self, category: &str) -> i32 {
        match self.gate_block_counts.get(category) {
            Some(count) => *count,
            None => 0,
        }
    }

    /// Reset circuit breaker for a category (e.g., after successful operation).
    pub fn reset_gate_circuit(&mut self, category: &str) {
        self.gate_block_counts.remove(category);
        self.tripped_gate_categories.retain(|c| c != category);
        self.save_or_log();
    }

    /// Reset all circuit breakers (session end or explicit reset).
    pub fn reset_all_circuits(&mut self) {
        self.gate_block_counts.clear();
        self.tripped_gate_categories.clear();
        self.save_or_log();
    }

    // ARCH: ScopeNarrowingHints — acceptance-gated retry with scope narrowing
    // PATTERN: retry_narrowing | SCOPE: session | CAP: AP | SEARCHED: 2026-04
    // Per harness research: on failure, narrow scope instead of retrying same params.
    // Block 1: full error. Block 2: suggest narrowing. Block 3: circuit trips.

    /// Get scope-narrowing hint based on block count for a category.
    /// Returns None if no narrowing needed, Some(hint) if narrowing suggested.
    pub fn scope_narrowing_hint(&self, category: &str) -> Option<String> {
        let count = self.gate_block_count(category);
        if count == 0 || count == 1 {
            // First block: just show error, no narrowing hint yet
            None
        } else if count == 2 {
            // Second block: suggest narrowing scope
            Some(format!(
                "[SCOPE_NARROW] Block {count}/3 for {category}. \
                 NARROW YOUR SCOPE: Focus on ONE file at a time. \
                 Complete that file fully before moving to the next. \
                 Broad multi-file changes compound errors."
            ))
        } else {
            // Third+ block: circuit tripped or will trip
            Some(format!(
                "[CIRCUIT_TRIPPED] {category} blocked {count} times. \
                 Force-allowing with advisory. Review tripped categories \
                 at session end."
            ))
        }
    }

    /// Check if we should suggest scope narrowing (block count == 2).
    pub fn should_suggest_narrowing(&self, category: &str) -> bool {
        self.gate_block_count(category) == 2
    }
}

#[cfg(test)]
mod tests {
    use crate::state::SessionState;

    #[test]
    fn test_skill_enforcement() {
        let mut s = SessionState::default();
        s.required_skills = vec!["rust".into(), "security".into()];
        assert!(!s.all_skills_satisfied());
        assert_eq!(s.missing_skills(), vec!["rust", "security"]);

        s.invoked_skills.push("rust".into());
        assert!(!s.all_skills_satisfied());
        assert_eq!(s.missing_skills(), vec!["security"]);

        s.invoked_skills.push("security".into());
        assert!(s.all_skills_satisfied());
        assert!(s.missing_skills().is_empty());
    }

    #[test]
    fn test_reset_enforcement() {
        let mut s = SessionState::default();
        s.required_skills = vec!["rust".into()];
        s.invoked_skills = vec!["rust".into()];
        s.research_topic = "axum".into();
        s.reset_enforcement();
        assert!(s.required_skills.is_empty());
        assert!(s.invoked_skills.is_empty());
        assert!(s.research_topic.is_empty());
    }

    #[test]
    fn test_record_skill_no_duplicate() {
        let mut s = SessionState::default();
        s.invoked_skills.push("rust".into());
        s.record_skill_invoked("rust");
        assert_eq!(s.invoked_skills.len(), 1);
    }

    #[test]
    fn evidence_window_non_implement_always_passes() {
        let mut s = SessionState::default();
        s.intent_type = "general".into();
        s.websearch_count_since_intent = 0;
        assert!(s.evidence_window_satisfied());

        s.intent_type = "explain".into();
        assert!(s.evidence_window_satisfied());
    }

    #[test]
    fn evidence_window_implement_blocked_without_websearch() {
        let mut s = SessionState::default();
        s.intent_type = "implement".into();
        s.websearch_count_since_intent = 0;
        assert!(!s.evidence_window_satisfied());
    }

    #[test]
    fn evidence_window_implement_passes_after_websearch() {
        let mut s = SessionState::default();
        s.intent_type = "implement".into();
        s.websearch_count_since_intent = 0;
        s.record_websearch();
        assert!(s.evidence_window_satisfied());
    }

    #[test]
    fn record_websearch_increments_counter() {
        let mut s = SessionState::default();
        assert_eq!(s.websearch_count_since_intent, 0);
        s.record_websearch();
        assert_eq!(s.websearch_count_since_intent, 1);
        s.record_websearch();
        assert_eq!(s.websearch_count_since_intent, 2);
    }

    #[test]
    fn record_websearch_saturates_at_i32_max() {
        let mut s = SessionState::default();
        s.websearch_count_since_intent = i32::MAX;
        s.record_websearch();
        assert_eq!(s.websearch_count_since_intent, i32::MAX);
    }

    #[test]
    fn reset_evidence_window_clears_counter_and_anchors_turn() {
        let mut s = SessionState::default();
        s.intent_type = "implement".into();
        s.websearch_count_since_intent = 3;
        s.turn_count = 5;
        s.reset_evidence_window();
        assert_eq!(s.websearch_count_since_intent, 0);
        assert_eq!(s.intent_set_turn, 5);
        assert!(!s.evidence_window_satisfied());
    }

    #[test]
    fn reset_then_research_satisfies_window() {
        let mut s = SessionState::default();
        s.intent_type = "implement".into();
        s.turn_count = 7;
        s.reset_evidence_window();
        assert!(!s.evidence_window_satisfied());
        s.record_websearch();
        assert!(s.evidence_window_satisfied());
    }
}
