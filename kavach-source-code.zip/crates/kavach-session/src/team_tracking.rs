use crate::state::SessionState;

impl SessionState {
    pub fn track_teammate_start(&mut self, name: &str, agent_type: &str) {
        let entry = format!("{name}:{agent_type}");
        if !self.team_members.contains(&entry) {
            self.team_members.push(entry);
            self.active_teammates += 1;
        }
        let _ = self.save();
    }

    pub fn track_teammate_stop(&mut self, name: &str) {
        self.team_members
            .retain(|m| !m.starts_with(&format!("{name}:")));
        if self.active_teammates > 0 {
            self.active_teammates -= 1;
        }
        let _ = self.save();
    }

    pub fn is_in_team(&self) -> bool {
        !self.team_name.is_empty()
    }

    pub fn set_team(&mut self, team_name: &str) {
        self.team_name = team_name.into();
        let _ = self.save();
    }

    pub fn team_summary(&self) -> String {
        format!(
            "team={} members={} active={}",
            self.team_name,
            self.team_members.len(),
            self.active_teammates
        )
    }
}

#[cfg(test)]
mod tests {
    use crate::state::SessionState;

    #[test]
    fn test_teammate_tracking() {
        let mut s = SessionState::default();
        s.track_teammate_start("researcher", "Explore");
        assert_eq!(s.active_teammates, 1);
        assert!(s.team_members.contains(&"researcher:Explore".to_string()));
        s.track_teammate_stop("researcher");
        assert_eq!(s.active_teammates, 0);
        assert!(s.team_members.is_empty());
    }

    #[test]
    fn test_set_team() {
        let mut s = SessionState::default();
        assert!(!s.is_in_team());
        s.set_team("my-team");
        assert!(s.is_in_team());
        assert_eq!(s.team_name, "my-team");
    }

    #[test]
    fn test_team_summary() {
        let mut s = SessionState::default();
        s.set_team("alpha");
        s.track_teammate_start("eng", "Code");
        let summary = s.team_summary();
        assert!(summary.contains("team=alpha"));
        assert!(summary.contains("members=1"));
        assert!(summary.contains("active=1"));
    }
}
