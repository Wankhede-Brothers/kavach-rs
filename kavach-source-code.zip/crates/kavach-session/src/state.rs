use std::collections::HashMap;

/// Default token budget for sonnet/haiku model class.
pub const DEFAULT_TOKEN_BUDGET: i32 = 180_000;
/// Default max output chars per subagent.
pub const DEFAULT_SUBAGENT_MAX_OUTPUT: i32 = 8_000;
/// Default total cap for all subagent output chars.
pub const DEFAULT_SUBAGENT_TOTAL_CAP: i32 = 30_000;

#[derive(Debug, Clone)]
pub struct SessionState {
    pub id: String,
    pub session_id: String,
    pub today: String,
    pub project: String,
    pub work_dir: String,
    pub training_cutoff: String,
    pub research_done: bool,
    pub research_topics: Vec<String>,
    pub memory_queried: bool,
    pub post_compact: bool,
    pub compacted_at: String,
    pub compact_count: i32,
    pub turn_count: i32,
    pub last_reinforce_turn: i32,
    pub reinforce_every_n: i32,
    pub current_task: String,
    pub task_status: String,
    pub files_modified: Vec<String>,
    pub tasks_created: i32,
    pub tasks_completed: i32,
    pub task_list_id: String,
    pub intent_type: String,
    pub intent_domain: String,
    pub intent_skills: Vec<String>,
    pub specs_injected: Vec<String>,
    pub token_budget_total: i32,
    pub token_budget_used: i32,
    pub context_phase: String,
    pub active_subagents: i32,
    pub subagent_outputs: HashMap<String, i32>,
    pub subagent_max_output: i32,
    pub subagent_total_cap: i32,
    pub team_name: String,
    pub team_members: Vec<String>,
    pub active_teammates: i32,
    pub model_id: String,
    pub modules_injected: Vec<String>,
    pub last_failure_tool: String,
    pub last_failure_turn: i32,
    /// How many times the stop gate has blocked due to this failure.
    /// Reset on clear_failure(). Prevents stop_hook_active from bypassing prematurely.
    pub failure_block_count: i32,
    /// Classified failure type: transient, not_found, permission, validation.
    /// Enables stop gate to make smarter retry/block/skip decisions.
    pub failure_type: String,
    pub required_skills: Vec<String>,
    pub invoked_skills: Vec<String>,
    pub research_topic: String,
    pub last_subagent_turn: i32,
    /// True when a subagent returned actionable results (fix strategies, file paths)
    /// that the parent has not yet acted on. Cleared by post-write gate.
    pub subagent_action_pending: bool,
    /// Turn when subagent_action_pending was set.
    pub subagent_action_turn: i32,
    pub recent_commands: Vec<String>,
    /// Files modified without corresponding test coverage (persistent across turns).
    pub test_files_pending: Vec<String>,
    /// Number of times test reminder has been injected (for escalation).
    pub test_nudge_count: i32,
    /// Last API error type from StopFailure event.
    pub last_api_error: String,
    /// Cumulative API error count in this session.
    pub api_error_count: i32,
    /// ISO timestamp of last API error for cooldown tracking.
    pub last_api_error_time: String,
    /// Critical decisions/blockers/discoveries that MUST survive compaction.
    /// Never summarized — injected verbatim into post-compact context.
    pub case_facts: Vec<String>,
    /// Intent risk level from intent gate (low/medium/high).
    pub intent_risk: String,
    /// Count of files read by current subagent pass (attention dilution tracking).
    pub subagent_files_read: i32,
    /// Turn when a file was last written/edited. Used by completion_guard
    /// to skip review isolation when recent turns were read-only.
    pub last_write_turn: i32,
    /// User explicitly confirmed creating a new package manifest in this workspace.
    /// Set by intent gate when user says "create new crate", "yes proceed", etc.
    /// Cleared after the Write succeeds (post-write gate).
    pub new_crate_confirmed: bool,
    /// True when /algorithm-hunter skill was invoked this turn.
    /// Pre-write algo guard reads this — resets to false at turn boundary.
    pub algo_hunter_invoked: bool,
    /// Crate/package names currently under a running `cargo test` / `cargo nextest` command.
    /// Pre-tool-bash guard blocks duplicate test runs on the same crate.
    /// Cleared by post-tool-bash when the command completes.
    pub active_test_crates: Vec<String>,
    /// Turn when `kavach db write` was last called with substantive content.
    /// Stop gate uses this to enforce db write every 5 turns.
    pub last_db_write_turn: i32,
    /// Number of WebSearch/WebFetch calls logged since the last intent reset.
    /// Evidence-chain gate reads this to verify research preceded a Write.
    pub websearch_count_since_intent: i32,
    /// Turn on which the current intent window was opened (intent gate fires).
    /// Used by the evidence-chain gate to scope the correlated block.
    pub intent_set_turn: i32,
    /// True when the [THINK_FIRST] advisory has been injected for the current intent window.
    /// Elicitation gate sets this — resets on intent window reset.
    pub think_first_injected: bool,
    /// Files modified in the current user prompt turn (reset on UserPromptSubmit).
    /// Surgical guard reads this to detect wide-scope edits.
    pub files_modified_this_turn: Vec<String>,
    /// True once the RESEARCH_PENDING advisory has been injected for the current intent window.
    /// Pre-tool gate sets this on first advisory — suppresses repeats until intent resets.
    pub research_advisory_sent: bool,
    /// True when /arch skill was invoked this turn.
    /// Pre-write arch guard reads this — resets to false at turn boundary.
    pub arch_skill_invoked: bool,
    // ARCH: CircuitBreakerState
    // PATTERN: circuit_breaker
    // SCOPE: session (per-session state tracking)
    // DECISION: HashMap<category, count> for O(1) lookup/increment
    // REJECTED: [{"name":"Vec<(String,i32)>","reason":"O(n) lookup per gate check"}]
    // TRADEOFF: Memory grows with unique categories (bounded by gate count ~30)
    // FAILURE_MODE: If session corrupt, all circuits reset (fail-open for availability)
    // CAP: AP — availability over consistency (allow work to proceed)
    // SEARCHED: 2026-04
    /// Map of gate category → block count this session. Circuit breaker reads this.
    /// O(1) lookup per gate check. Memory bounded by ~30 gate categories.
    pub gate_block_counts: HashMap<String, i32>,
    /// Maximum blocks per gate category before circuit breaker trips (force-allow).
    /// Default: 3. Per Meta-Harness research: complex verification degrades performance.
    pub gate_circuit_breaker_threshold: i32,
    /// Categories currently in "tripped" state (force-allow with advisory).
    /// Cleared on session end or explicit reset.
    pub tripped_gate_categories: Vec<String>,
}
