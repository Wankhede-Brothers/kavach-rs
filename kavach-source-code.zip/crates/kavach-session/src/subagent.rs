use std::collections::HashMap;

use crate::state::SessionState;

impl SessionState {
    pub fn track_subagent_start(&mut self, agent_id: &str) {
        if !self.subagent_outputs.contains_key(agent_id) {
            self.active_subagents += 1;
            self.subagent_outputs.insert(agent_id.into(), 0);
        }
        self.last_subagent_turn = self.turn_count;
        let _ = self.save();
    }

    /// Subagents are stale if active > 0 but no activity for 2+ turns.
    /// SubagentStop may never fire (crash, timeout, hook failure),
    /// leaving a stale counter that blocks the stop gate forever.
    pub fn has_stale_subagents(&self) -> bool {
        self.active_subagents > 0
            && self.turn_count.saturating_sub(self.last_subagent_turn) >= 2
    }

    /// Reset stale subagent counter so stop gate can proceed.
    /// Also clears related tracking fields to prevent ghost state.
    pub fn reset_stale_subagents(&mut self) {
        self.active_subagents = 0;
        self.last_subagent_turn = 0;
        self.subagent_action_pending = false;
        self.subagent_action_turn = 0;
        self.subagent_files_read = 0;
        let _ = self.save();
    }

    pub fn track_subagent_stop(
        &mut self,
        agent_id: &str,
        output_size: i32,
    ) {
        if self.active_subagents > 0 {
            self.active_subagents -= 1;
        }
        self.subagent_outputs.insert(agent_id.into(), output_size);
        // Large outputs (>2000 chars) from Explore/research agents likely contain
        // actionable findings. Set pending flag so stop gate enforces action.
        if output_size >= 2000 {
            self.subagent_action_pending = true;
            self.subagent_action_turn = self.turn_count;
        }
        let _ = self.save();
    }

    /// Mark subagent action as resolved (parent acted on findings).
    /// Called by post-write gate when code is written after subagent returned.
    pub fn clear_subagent_action(&mut self) {
        self.subagent_action_pending = false;
        self.subagent_action_turn = 0;
        let _ = self.save();
    }

    /// Check if a subagent returned actionable results that haven't been acted on.
    /// Returns true if action is pending AND it's been at least 1 turn since.
    pub fn has_unacted_subagent_result(&self) -> bool {
        self.subagent_action_pending
            && self.turn_count > self.subagent_action_turn
    }

    pub fn get_effective_output_limit(
        &self,
        agent_type: &str,
        limits: &HashMap<String, i32>,
    ) -> i32 {
        let base = limits
            .get(agent_type)
            .copied()
            .unwrap_or(self.subagent_max_output);
        let multiplier = match self.context_phase.as_str() {
            "mid" => 0.75,
            "late" => 0.5,
            "critical" => 0.25,
            _ => 1.0,
        };
        (base as f64 * multiplier) as i32
    }
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use crate::state::SessionState;

    #[test]
    fn test_subagent_tracking() {
        let mut s = SessionState::default();
        s.track_subagent_start("agent-1");
        assert_eq!(s.active_subagents, 1);
        s.track_subagent_stop("agent-1", 5000);
        assert_eq!(s.active_subagents, 0);
        assert_eq!(s.subagent_outputs.get("agent-1"), Some(&5000));
    }

    #[test]
    fn test_stale_subagent_detection() {
        let mut s = SessionState::default();
        s.turn_count = 5;
        s.track_subagent_start("agent-1");
        assert_eq!(s.last_subagent_turn, 5);
        assert!(!s.has_stale_subagents()); // same turn — not stale

        s.turn_count = 6;
        assert!(!s.has_stale_subagents()); // 1 turn gap — not stale yet

        s.turn_count = 7;
        assert!(s.has_stale_subagents()); // 2 turn gap — stale

        s.reset_stale_subagents();
        assert_eq!(s.active_subagents, 0);
        assert_eq!(s.last_subagent_turn, 0);
        assert!(!s.has_stale_subagents());
    }

    #[test]
    fn test_subagent_action_pending_on_large_output() {
        let mut s = SessionState::default();
        s.turn_count = 3;
        s.track_subagent_start("explore-1");
        s.track_subagent_stop("explore-1", 5000); // >2000 = actionable
        assert!(s.subagent_action_pending);
        assert_eq!(s.subagent_action_turn, 3);
    }

    #[test]
    fn test_subagent_action_not_pending_on_small_output() {
        let mut s = SessionState::default();
        s.turn_count = 3;
        s.track_subagent_start("haiku-1");
        s.track_subagent_stop("haiku-1", 500); // <2000 = not actionable
        assert!(!s.subagent_action_pending);
    }

    #[test]
    fn test_has_unacted_subagent_result() {
        let mut s = SessionState::default();
        s.turn_count = 3;
        s.track_subagent_start("explore-1");
        s.track_subagent_stop("explore-1", 5000);
        assert!(!s.has_unacted_subagent_result()); // same turn — not yet
        s.turn_count = 4;
        assert!(s.has_unacted_subagent_result()); // next turn — pending
        s.clear_subagent_action();
        assert!(!s.has_unacted_subagent_result()); // cleared
    }

    #[test]
    fn test_effective_output_limit() {
        let s = SessionState {
            context_phase: "mid".into(),
            subagent_max_output: 8000,
            ..Default::default()
        };
        let limits = HashMap::new();
        assert_eq!(s.get_effective_output_limit("test", &limits), 6000);
    }
}
