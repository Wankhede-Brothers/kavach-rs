use crate::paths::now_datetime;
use crate::state::SessionState;

impl SessionState {
    pub fn mark_research_done(&mut self) {
        self.research_done = true;
        self.save_or_log();
    }

    pub fn mark_research_done_with_topic(&mut self, topic: &str) {
        self.research_done = true;
        if !topic.is_empty() && !self.research_topics.contains(&topic.to_string()) {
            self.research_topics.push(topic.into());
        }
        self.save_or_log();
    }

    pub fn mark_memory_queried(&mut self) {
        self.memory_queried = true;
        self.save_or_log();
    }

    pub fn mark_post_compact(&mut self) {
        self.post_compact = true;
        self.compacted_at = now_datetime();
        self.compact_count += 1;
        self.save_or_log();
    }

    pub fn clear_post_compact(&mut self) {
        self.post_compact = false;
        self.save_or_log();
    }

    pub fn is_post_compact(&self) -> bool {
        self.post_compact
    }

    pub fn increment_turn(&mut self) {
        self.turn_count += 1;
        self.save_or_log();
    }

    pub fn record_failure(&mut self, tool: &str) {
        self.last_failure_tool = tool.into();
        self.last_failure_turn = self.turn_count;
        self.save_or_log();
    }

    pub fn record_failure_typed(&mut self, tool: &str, failure_type: &str) {
        self.last_failure_tool = tool.into();
        self.last_failure_turn = self.turn_count;
        self.failure_type = failure_type.into();
        self.save_or_log();
    }

    pub fn clear_failure(&mut self) {
        self.last_failure_tool.clear();
        self.last_failure_turn = 0;
        self.failure_block_count = 0;
        self.failure_type.clear();
        self.save_or_log();
    }

    /// True if failure is transient (timeout, rate limit) and worth retrying.
    pub fn is_transient_failure(&self) -> bool {
        self.failure_type == "transient"
    }

    /// True if failure is a valid "not found" result, not a real error.
    pub fn is_not_found_failure(&self) -> bool {
        self.failure_type == "not_found"
    }

    /// Record a critical fact that must survive compaction.
    /// Capped at 20 entries. First 3 entries (founding facts) are preserved;
    /// eviction starts from position 3 to keep early session context intact.
    /// Newlines replaced with spaces to prevent serialization corruption.
    pub fn add_case_fact(&mut self, fact: &str) {
        const MAX_CASE_FACTS: usize = 20;
        const MAX_FACT_LEN: usize = 500;
        const PRESERVE_HEAD: usize = 3;
        if self.case_facts.len() >= MAX_CASE_FACTS {
            let evict_pos = PRESERVE_HEAD.min(self.case_facts.len() - 1);
            self.case_facts.remove(evict_pos);
        }
        let sanitized: String = fact.chars()
            .map(|c| if c == '\n' || c == '\r' { ' ' } else { c })
            .take(MAX_FACT_LEN)
            .collect();
        self.case_facts.push(sanitized);
        self.save_or_log();
    }

    pub fn set_intent_risk(&mut self, risk: &str) {
        self.intent_risk = risk.into();
        self.save_or_log();
    }

    pub fn increment_files_read(&mut self) {
        self.subagent_files_read += 1;
        self.save_or_log();
    }

    pub fn reset_files_read(&mut self) {
        self.subagent_files_read = 0;
        self.save_or_log();
    }

    pub fn has_recent_failure(&self) -> bool {
        !self.last_failure_tool.is_empty()
            && (self.last_failure_turn == self.turn_count || self.failure_block_count > 0)
    }

    /// Increment the stop-block counter for the current failure.
    /// Called by the stop gate each time it blocks due to an unresolved failure.
    pub fn increment_failure_blocks(&mut self) {
        self.failure_block_count = self.failure_block_count.saturating_add(1)
            .min(Self::max_failure_blocks() + 1);
        self.save_or_log();
    }

    /// Max number of times the stop gate will block before allowing forced stop.
    /// Gives Claude 3 chances to fix the failure before giving up.
    pub fn max_failure_blocks() -> i32 {
        3
    }
}

#[cfg(test)]
#[path = "markers_tests.rs"]
mod tests;
