use crate::load::load_session_state;
use crate::paths::detect_project;
use crate::state::SessionState;

/// Load existing session or create a new one.
pub fn get_or_create_session() -> SessionState {
    match load_session_state() {
        Ok(Some(mut state)) => {
            let wd = std::env::current_dir()
                .map(|p| p.to_string_lossy().to_string())
                .unwrap_or_default();
            let old_wd = state.work_dir.clone();
            state.work_dir = wd.clone();
            state.project = detect_project();
            if old_wd != wd {
                filter_test_pending_for_project(&mut state, &wd);
            }
            let _ = state.save();
            state
        }
        _ => {
            let wd = std::env::current_dir()
                .map(|p| p.to_string_lossy().to_string())
                .unwrap_or_default();
            let state = SessionState::new(&wd);
            let _ = state.save();
            state
        }
    }
}

/// Remove test_files_pending entries that don't belong to the current work_dir.
/// Prevents cross-project test enforcement leakage when switching directories.
pub(crate) fn filter_test_pending_for_project(state: &mut SessionState, work_dir: &str) {
    if work_dir.is_empty() || state.test_files_pending.is_empty() {
        return;
    }
    let before = state.test_files_pending.len();
    // Ensure trailing separator to prevent "/kavach" matching "/kavach-backup"
    let prefix = if work_dir.ends_with('/') {
        work_dir.to_string()
    } else {
        format!("{work_dir}/")
    };
    state.test_files_pending.retain(|f| f.starts_with(&prefix));
    if state.test_files_pending.is_empty() && before > 0 {
        state.test_nudge_count = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn filter_removes_other_project_files() {
        let mut s = SessionState::default();
        s.test_files_pending = vec![
            "/Users/g/Astro/astro-advisor/src/forecast.rs".into(),
            "/Users/g/Nicole/Backend/src/routes.rs".into(),
        ];
        s.test_nudge_count = 5;
        filter_test_pending_for_project(&mut s, "/Users/g/Nicole");
        assert_eq!(s.test_files_pending.len(), 1);
        assert_eq!(s.test_files_pending[0], "/Users/g/Nicole/Backend/src/routes.rs");
        assert_eq!(s.test_nudge_count, 5);
    }

    #[test]
    fn filter_resets_nudge_when_all_cleared() {
        let mut s = SessionState::default();
        s.test_files_pending = vec![
            "/Users/g/Astro/src/forecast.rs".into(),
        ];
        s.test_nudge_count = 49;
        filter_test_pending_for_project(&mut s, "/Users/g/Nicole");
        assert!(s.test_files_pending.is_empty());
        assert_eq!(s.test_nudge_count, 0);
    }

    #[test]
    fn filter_keeps_all_when_same_project() {
        let mut s = SessionState::default();
        s.test_files_pending = vec![
            "/Users/g/Nicole/src/auth.rs".into(),
            "/Users/g/Nicole/src/pay.rs".into(),
        ];
        s.test_nudge_count = 3;
        filter_test_pending_for_project(&mut s, "/Users/g/Nicole");
        assert_eq!(s.test_files_pending.len(), 2);
        assert_eq!(s.test_nudge_count, 3);
    }

    #[test]
    fn filter_noop_on_empty_pending() {
        let mut s = SessionState::default();
        s.test_nudge_count = 2;
        filter_test_pending_for_project(&mut s, "/Users/g/Nicole");
        assert!(s.test_files_pending.is_empty());
        assert_eq!(s.test_nudge_count, 2);
    }

    #[test]
    fn filter_noop_on_empty_work_dir() {
        let mut s = SessionState::default();
        s.test_files_pending = vec!["/Users/g/Astro/src/lib.rs".into()];
        s.test_nudge_count = 1;
        filter_test_pending_for_project(&mut s, "");
        assert_eq!(s.test_files_pending.len(), 1);
        assert_eq!(s.test_nudge_count, 1);
    }
}
