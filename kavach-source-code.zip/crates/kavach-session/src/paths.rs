use std::fs;
use std::io;
use std::path::{Path, PathBuf};

use chrono::Local;
// BLAKE3: 4x faster than SHA-256 for path slug hashing.

pub(crate) fn home_dir() -> PathBuf {
    match std::env::var("HOME") {
        Ok(v) => PathBuf::from(v),
        Err(_) => match std::env::var("USERPROFILE") {
            Ok(v) => PathBuf::from(v),
            Err(_) => PathBuf::from("."),
        },
    }
}

/// Shared state directory (XDG on Linux, Library on macOS, LOCALAPPDATA on Windows).
pub fn state_dir() -> PathBuf {
    if cfg!(target_os = "macos") {
        home_dir()
            .join("Library")
            .join("Application Support")
            .join("SharedAI")
            .join("state")
    } else if cfg!(target_os = "windows") {
        let base = match std::env::var("LOCALAPPDATA") {
            Ok(v) => PathBuf::from(v),
            Err(_) => home_dir(),
        };
        base.join("SharedAI").join("state")
    } else {
        let xdg = match std::env::var("XDG_DATA_HOME") {
            Ok(v) => PathBuf::from(v),
            Err(_) => home_dir().join(".local").join("share"),
        };
        xdg.join("shared-ai").join("state")
    }
}

/// STM (short-term memory) path -- same as state dir for session files.
pub fn stm_path() -> PathBuf {
    state_dir()
}

/// Compute a stable 16-character hex digest of the canonical working directory.
/// Used to scope session state files per terminal/project so state never
/// leaks across concurrent Claude Code sessions running in different cwds.
fn workdir_slug() -> String {
    let cwd = match std::env::current_dir() {
        Ok(p) => p,
        Err(_) => PathBuf::from("."),
    };
    let canonical = match fs::canonicalize(&cwd) {
        Ok(p) => p,
        Err(_) => cwd,
    };
    slug_from_path(&canonical)
}

fn slug_from_path(path: &Path) -> String {
    let hash = blake3::hash(path.to_string_lossy().as_bytes());
    let mut hex = String::with_capacity(16);
    for byte in hash.as_bytes().iter().take(8) {
        let _ = std::fmt::Write::write_fmt(&mut hex, format_args!("{byte:02x}"));
    }
    hex
}

/// Path to the session state file, scoped per working directory.
/// Each terminal/project gets an isolated file so state never leaks across
/// concurrent Claude Code sessions. Migrates legacy shared files on first access
/// into the scoped file for the current cwd.
pub fn state_path() -> PathBuf {
    let slug = workdir_slug();
    let target = stm_path().join(format!("session-state-{slug}.kavach"));
    if target.exists() {
        return target;
    }
    for name in ["session-state.kavach", "session-state.ini", "session-state.toon"] {
        let legacy = stm_path().join(name);
        if legacy.exists() && fs::rename(&legacy, &target).is_ok() {
            return target;
        }
    }
    target
}

/// Memory bank directory.
pub fn memory_dir() -> PathBuf {
    if cfg!(target_os = "macos") {
        home_dir()
            .join("Library")
            .join("Application Support")
            .join("SharedAI")
            .join("memory")
    } else if cfg!(target_os = "windows") {
        let base = match std::env::var("LOCALAPPDATA") {
            Ok(v) => PathBuf::from(v),
            Err(_) => home_dir(),
        };
        base.join("SharedAI").join("memory")
    } else {
        let xdg = match std::env::var("XDG_DATA_HOME") {
            Ok(v) => PathBuf::from(v),
            Err(_) => home_dir().join(".local").join("share"),
        };
        xdg.join("shared-ai").join("memory")
    }
}

pub(crate) fn ensure_parent_dir(path: &std::path::Path) -> io::Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    Ok(())
}

pub(crate) fn detect_project() -> String {
    let cwd = match std::env::current_dir() {
        Ok(p) => p,
        Err(_) => return "unknown".into(),
    };
    let git_dir = cwd.join(".git");
    if git_dir.exists()
        && let Some(name) = cwd.file_name()
    {
        return name.to_string_lossy().to_string();
    }
    match cwd.file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => "unknown".into(),
    }
}

pub(crate) fn today() -> String {
    Local::now().format("%Y-%m-%d").to_string()
}

pub(crate) fn now_datetime() -> String {
    Local::now().format("%Y-%m-%dT%H:%M:%S").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slug_is_stable_for_same_path() {
        let p = Path::new("/tmp/kavach-test-a");
        assert_eq!(slug_from_path(p), slug_from_path(p));
    }

    #[test]
    fn slug_differs_across_paths() {
        let a = slug_from_path(Path::new("/tmp/project-a"));
        let b = slug_from_path(Path::new("/tmp/project-b"));
        assert_ne!(a, b);
    }

    #[test]
    fn slug_is_16_hex_chars() {
        let s = slug_from_path(Path::new("/any/path"));
        assert_eq!(s.len(), 16);
        assert!(s.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn state_path_contains_slug() {
        let p = state_path();
        let name = match p.file_name() {
            Some(n) => n.to_string_lossy().to_string(),
            None => String::new(),
        };
        assert!(name.starts_with("session-state-"));
        assert!(name.ends_with(".kavach"));
    }
}
