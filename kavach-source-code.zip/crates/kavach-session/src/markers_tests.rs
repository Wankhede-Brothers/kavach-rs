use crate::state::SessionState;

#[test]
fn mark_research_done() {
    let mut s = SessionState::default();
    assert!(!s.research_done);
    s.mark_research_done();
    assert!(s.research_done);
}

#[test]
fn mark_memory_queried() {
    let mut s = SessionState::default();
    assert!(!s.memory_queried);
    s.mark_memory_queried();
    assert!(s.memory_queried);
}

#[test]
fn mark_post_compact_cycle() {
    let mut s = SessionState::default();
    assert!(!s.post_compact);
    s.mark_post_compact();
    assert!(s.post_compact);
    assert_eq!(s.compact_count, 1);
    s.clear_post_compact();
    assert!(!s.post_compact);
}

#[test]
fn increment_turn() {
    let mut s = SessionState::default();
    assert_eq!(s.turn_count, 0);
    s.increment_turn();
    s.increment_turn();
    assert_eq!(s.turn_count, 2);
}

#[test]
fn record_and_clear_failure() {
    let mut s = SessionState::default();
    s.turn_count = 5;
    s.record_failure("Bash");
    assert_eq!(s.last_failure_tool, "Bash");
    assert_eq!(s.last_failure_turn, 5);
    assert!(s.has_recent_failure());
    s.clear_failure();
    assert!(!s.has_recent_failure());
    assert!(s.last_failure_tool.is_empty());
}

#[test]
fn record_failure_typed() {
    let mut s = SessionState::default();
    s.record_failure_typed("Write", "transient");
    assert_eq!(s.failure_type, "transient");
    assert!(s.is_transient_failure());
    assert!(!s.is_not_found_failure());
}

#[test]
fn add_case_fact_caps_at_20() {
    let mut s = SessionState::default();
    for i in 0..25 {
        s.add_case_fact(&format!("fact-{i}"));
    }
    assert_eq!(s.case_facts.len(), 20);
}

#[test]
fn add_case_fact_sanitizes_newlines() {
    let mut s = SessionState::default();
    s.add_case_fact("line1\nline2\rline3");
    assert_eq!(s.case_facts[0], "line1 line2 line3");
}

#[test]
fn has_recent_failure_false_initially() {
    let s = SessionState::default();
    assert!(!s.has_recent_failure());
}

#[test]
fn increment_failure_blocks_caps() {
    let mut s = SessionState::default();
    for _ in 0..10 {
        s.increment_failure_blocks();
    }
    assert!(s.failure_block_count <= SessionState::max_failure_blocks() + 1);
}
