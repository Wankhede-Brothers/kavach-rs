use std::fs;
use std::io;

use fs2::FileExt;

use crate::paths::{ensure_parent_dir, state_path};
use crate::state::SessionState;

impl SessionState {
    /// Save session state to INI file with file locking + atomic rename.
    pub fn save(&self) -> io::Result<()> {
        let path = state_path();
        ensure_parent_dir(&path)?;

        let lock_path = path.with_extension("lock");
        ensure_parent_dir(&lock_path)?;
        let lock_file = fs::OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)
            .open(&lock_path)?;
        lock_file.lock_exclusive()?;

        let tmp_path = path.with_extension("tmp");
        let content = self.to_ini_full();
        fs::write(&tmp_path, &content)?;
        fs::rename(&tmp_path, &path)?;

        lock_file.unlock()?;
        Ok(())
    }

    /// Save session state, logging any I/O error via tracing instead of propagating.
    pub fn save_or_log(&mut self) {
        if let Err(e) = self.save() {
            tracing::warn!(error = %e, "kavach-session: save failed");
        }
    }
}

pub(crate) fn join_csv(items: &[String]) -> String {
    items.join(",")
}
