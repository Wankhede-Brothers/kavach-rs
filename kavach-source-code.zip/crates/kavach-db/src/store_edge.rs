/// EdgeStore — O(1) adjacency list by entity id.
///
/// SmallVec<[EdgeRef; 8]>: 8 edges stored inline without heap allocation.
/// Concept hub nodes (> 8 edges) spill to heap transparently.
/// parking_lot::RwLock: concurrent reads hold shared lock; writes exclusive.
use smallvec::SmallVec;

#[derive(Debug, Clone)]
pub struct EdgeRef {
    pub to_id: i64,
    pub rel_type: String,
    pub weight: f64,
}

#[derive(Debug)]
pub struct EdgeStore {
    slots: parking_lot::RwLock<Vec<SmallVec<[EdgeRef; 8]>>>,
}

impl EdgeStore {
    #[must_use]
    pub fn new() -> Self {
        // Slot 0 is a placeholder — entity ids start at 1
        Self {
            slots: parking_lot::RwLock::new(vec![SmallVec::new()]),
        }
    }

    /// Add an edge from_id → to_id. Idempotent by (to_id, rel_type).
    pub fn add(&self, from_id: i64, to_id: i64, rel_type: &str, weight: f64) {
        let from = match usize::try_from(from_id) {
            Ok(v) => v,
            Err(_) => return,
        };
        let mut guard = self.slots.write();
        if guard.len() <= from {
            guard.resize_with(from.saturating_add(1), SmallVec::new);
        }
        if let Some(slot) = guard.get_mut(from) {
            if slot.iter().any(|e| e.to_id == to_id && e.rel_type == rel_type) {
                return;
            }
            slot.push(EdgeRef { to_id, rel_type: rel_type.to_string(), weight });
        }
    }

    /// Get up to `limit` outgoing edges — O(1) index, owned snapshot.
    #[must_use]
    pub fn get(&self, from_id: i64, limit: usize) -> Vec<EdgeRef> {
        let from = match usize::try_from(from_id) {
            Ok(v) => v,
            Err(_) => return Vec::new(),
        };
        let guard = self.slots.read();
        match guard.get(from) {
            Some(edges) => edges.iter().take(limit).cloned().collect(),
            None => Vec::new(),
        }
    }

    /// Load all relationships from SQLite at startup — O(E) single scan.
    pub fn load_from_db(conn: &rusqlite::Connection) -> rusqlite::Result<Self> {
        let store = Self::new();
        let mut stmt = conn.prepare(
            "SELECT from_id, to_id, rel_type, weight FROM relationships ORDER BY from_id",
        )?;
        let mut rows = stmt.query([])?;
        while let Some(row) = rows.next()? {
            let from_id: i64 = row.get(0)?;
            let to_id: i64 = row.get(1)?;
            let rel_type: String = row.get(2)?;
            let weight: f64 = row.get(3)?;
            store.add(from_id, to_id, &rel_type, weight);
        }
        Ok(store)
    }

    #[must_use]
    pub fn node_count(&self) -> usize {
        self.slots.read().iter().filter(|v| !v.is_empty()).count()
    }
}

impl Default for EdgeStore {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_store_and_retrieve_edges() {
        let store = EdgeStore::new();
        store.add(1, 2, "uses_skill", 1.0);
        store.add(1, 3, "belongs_to", 0.5);
        assert_eq!(store.get(1, 100).len(), 2);
    }

    #[test]
    fn should_deduplicate_identical_edges() {
        let store = EdgeStore::new();
        store.add(1, 2, "uses_skill", 1.0);
        store.add(1, 2, "uses_skill", 1.0);
        assert_eq!(store.get(1, 100).len(), 1);
    }

    #[test]
    fn should_respect_limit() {
        let store = EdgeStore::new();
        for i in 2..12_i64 {
            store.add(1, i, "references", 1.0);
        }
        assert_eq!(store.get(1, 5).len(), 5);
    }

    #[test]
    fn should_return_empty_for_unknown_id() {
        let store = EdgeStore::new();
        assert!(store.get(999, 100).is_empty());
    }
}
