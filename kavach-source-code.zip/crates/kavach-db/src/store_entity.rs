/// EntityIndex — O(1) in-memory (type, name) → id lookup.
///
/// Replaces the double SQLite round-trip in `upsert_entity`.
/// Write path: insert confirmed SQL id here after RETURNING.
/// Read path: `get()` before issuing any SQL — cache hit avoids the DB entirely.
use std::sync::atomic::{AtomicI64, Ordering};
use dashmap::DashMap;

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct EntityKey {
    entity_type: String,
    name: String,
}

impl EntityKey {
    #[must_use]
    pub fn new(entity_type: &str, name: &str) -> Self {
        Self {
            entity_type: entity_type.to_string(),
            name: name.to_string(),
        }
    }
}

#[derive(Debug, Default)]
pub struct EntityIndex {
    map: DashMap<EntityKey, i64>,
    next_id: AtomicI64,
}

impl EntityIndex {
    #[must_use]
    pub fn new() -> Self {
        Self {
            map: DashMap::new(),
            next_id: AtomicI64::new(1),
        }
    }

    /// Load all entities from SQLite at startup — O(N) single scan.
    pub fn load_from_db(conn: &rusqlite::Connection) -> rusqlite::Result<Self> {
        let idx = Self::new();
        let mut stmt = conn.prepare(
            "SELECT id, entity_type, name FROM entities ORDER BY id",
        )?;
        let mut max_id: i64 = 0;
        let mut rows = stmt.query([])?;
        while let Some(row) = rows.next()? {
            let id: i64 = row.get(0)?;
            let entity_type: String = row.get(1)?;
            let name: String = row.get(2)?;
            idx.map.insert(EntityKey { entity_type, name }, id);
            if id > max_id { max_id = id; }
        }
        idx.next_id.store(max_id.saturating_add(1), Ordering::Relaxed);
        Ok(idx)
    }

    /// O(1) DashMap shard lookup — no SQL, no allocation.
    #[must_use]
    pub fn get(&self, entity_type: &str, name: &str) -> Option<i64> {
        self.map.get(&EntityKey::new(entity_type, name)).map(|v| *v)
    }

    /// Insert a confirmed SQL id. Idempotent.
    pub fn insert(&self, entity_type: &str, name: &str, id: i64) {
        self.map.insert(EntityKey::new(entity_type, name), id);
        let cur = self.next_id.load(Ordering::Relaxed);
        if id >= cur {
            self.next_id.store(id.saturating_add(1), Ordering::Relaxed);
        }
    }

    #[must_use]
    pub fn len(&self) -> usize { self.map.len() }

    #[must_use]
    pub fn is_empty(&self) -> bool { self.map.is_empty() }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_return_id_after_insert() {
        let idx = EntityIndex::new();
        idx.insert("skill", "rust", 42);
        assert_eq!(idx.get("skill", "rust"), Some(42));
    }

    #[test]
    fn should_return_none_for_missing_key() {
        let idx = EntityIndex::new();
        assert_eq!(idx.get("skill", "python"), None);
    }

    #[test]
    fn should_not_grow_on_duplicate_insert() {
        let idx = EntityIndex::new();
        idx.insert("gate", "pre_write", 1);
        idx.insert("gate", "pre_write", 1);
        assert_eq!(idx.len(), 1);
    }
}
