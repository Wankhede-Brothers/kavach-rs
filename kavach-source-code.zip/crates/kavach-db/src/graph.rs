/// Relationship CRUD with JOIN queries.
///
/// Entity operations are in `graph_entity`. This module owns
/// the relationships table: add, query, and bounded traversal.
use crate::error::Result;
use crate::graph_entity::Entity;
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct Relationship {
    pub id: i64,
    pub from_id: i64,
    pub to_id: i64,
    pub rel_type: String,
    pub properties: Option<String>,
    pub weight: f64,
    pub created_at: String,
}

/// Add a relationship between two entities. Idempotent by (from, to, type).
pub fn add_relationship(
    conn: &Connection,
    from_id: i64,
    to_id: i64,
    rel_type: &str,
    weight: f64,
) -> Result<i64> {
    conn.execute(
        "INSERT INTO relationships (from_id, to_id, rel_type, weight)
         VALUES (?1, ?2, ?3, ?4)
         ON CONFLICT(from_id, to_id, rel_type) DO UPDATE SET
            weight = excluded.weight",
        params![from_id, to_id, rel_type, weight],
    )?;
    Ok(conn.last_insert_rowid())
}

/// Get relationships FROM an entity, bounded to `limit` rows.
pub fn get_related(conn: &Connection, entity_id: i64, limit: i64) -> Result<Vec<(Relationship, Entity)>> {
    let mut stmt = conn.prepare(
        "SELECT r.id, r.from_id, r.to_id, r.rel_type, r.properties,
                r.weight, r.created_at,
                e.id, e.entity_type, e.name, e.properties,
                e.created_at, e.updated_at
         FROM relationships r
         JOIN entities e ON e.id = r.to_id
         WHERE r.from_id = ?1
         ORDER BY r.rel_type
         LIMIT ?2",
    )?;
    let rows = stmt.query_map(params![entity_id, limit], |row| {
        Ok((
            Relationship {
                id: row.get(0)?,
                from_id: row.get(1)?,
                to_id: row.get(2)?,
                rel_type: row.get(3)?,
                properties: row.get(4)?,
                weight: row.get(5)?,
                created_at: row.get(6)?,
            },
            Entity {
                id: row.get(7)?,
                entity_type: row.get(8)?,
                name: row.get(9)?,
                properties: row.get(10)?,
                created_at: row.get(11)?,
                updated_at: row.get(12)?,
            },
        ))
    })?;
    let mut results = Vec::new();
    for row in rows {
        results.push(row?);
    }
    Ok(results)
}
