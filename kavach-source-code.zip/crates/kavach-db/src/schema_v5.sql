-- v5: content_hash on entities for cross-project pattern deduplication
ALTER TABLE entities ADD COLUMN content_hash TEXT;
CREATE INDEX IF NOT EXISTS idx_entities_content_hash ON entities(content_hash)
    WHERE content_hash IS NOT NULL;
