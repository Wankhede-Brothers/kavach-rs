/// EventBuf — fixed-capacity ring buffer for append-only event log.
///
/// Uses `VecDeque` — no direct slot indexing.
/// Capacity: 4096 events. Overflow silently drops the oldest.
use std::collections::VecDeque;
use std::iter;

const EVENT_BUF_CAP: usize = 4096;

#[derive(Debug, Clone)]
pub struct EventEntry {
    pub session_id: Option<String>,
    pub event_type: String,
    pub source: String,
    pub project_id: Option<i64>,
    pub payload: Option<String>,
}

#[derive(Debug)]
pub struct EventBuf {
    buf: parking_lot::Mutex<VecDeque<EventEntry>>,
}

impl EventBuf {
    #[must_use]
    pub fn new() -> Self {
        Self {
            buf: parking_lot::Mutex::new(VecDeque::with_capacity(EVENT_BUF_CAP)),
        }
    }

    /// Append an event. O(1). Drops oldest on overflow.
    pub fn push(&self, entry: EventEntry) {
        let mut guard = self.buf.lock();
        if guard.len() >= EVENT_BUF_CAP {
            guard.pop_front();
        }
        guard.push_back(entry);
    }

    /// Drain up to `max` events in FIFO order for flushing to SQLite.
    #[must_use]
    pub fn drain(&self, max: usize) -> Vec<EventEntry> {
        let mut guard = self.buf.lock();
        let take = max.min(guard.len());
        iter::from_fn(|| guard.pop_front()).take(take).collect()
    }

    #[must_use]
    pub fn len(&self) -> usize {
        self.buf.lock().len()
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.buf.lock().is_empty()
    }
}

impl Default for EventBuf {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_entry(event_type: &str) -> EventEntry {
        EventEntry {
            session_id: None,
            event_type: event_type.to_string(),
            source: "test".to_string(),
            project_id: None,
            payload: None,
        }
    }

    #[test]
    fn should_drain_fifo_order() {
        let buf = EventBuf::new();
        buf.push(make_entry("a"));
        buf.push(make_entry("b"));
        let out = buf.drain(10);
        assert_eq!(out.len(), 2);
        let mut it = out.into_iter();
        assert_eq!(it.next().map(|e| e.event_type).as_deref(), Some("a"));
        assert_eq!(it.next().map(|e| e.event_type).as_deref(), Some("b"));
        assert!(buf.is_empty());
    }

    #[test]
    fn should_stay_at_cap_on_overflow() {
        let buf = EventBuf::new();
        for i in 0..EVENT_BUF_CAP + 10 {
            buf.push(make_entry(&format!("e{i}")));
        }
        assert_eq!(buf.len(), EVENT_BUF_CAP);
    }

    #[test]
    fn should_drain_partial() {
        let buf = EventBuf::new();
        for _ in 0..5_u8 {
            buf.push(make_entry("x"));
        }
        let out = buf.drain(3);
        assert_eq!(out.len(), 3);
        assert_eq!(buf.len(), 2);
    }
}
