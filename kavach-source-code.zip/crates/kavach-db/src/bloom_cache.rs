//! mmap'd bloom filter cache for fast gate-pattern pre-screening.
//!
//! Layout: `[count: u64 LE] [record × count]`
//! Record: `[pattern_id: i64 LE] [bloom: 64 bytes]`  (72 bytes each)
//!
//! Built once per session from the gate_patterns table, then memory-mapped
//! read-only so every gate worker shares the same physical pages.

use std::path::PathBuf;

use memmap2::Mmap;
use rusqlite::Connection;

use crate::error::Result;

const BLOOM_BYTES: usize = 64;
const ID_BYTES: usize = 8;
/// Bytes per record: 8-byte id + 64-byte bloom.
const RECORD_BYTES: usize = ID_BYTES + BLOOM_BYTES;

/// Path to the bloom-cache binary.
///
/// macOS: `~/Library/Application Support/SharedAI/bloom_cache.bin`
/// Linux: `$XDG_DATA_HOME/shared-ai/bloom_cache.bin`
/// Fallback: `/tmp/bloom_cache.bin`
pub fn cache_path() -> PathBuf {
    let base = match dirs::data_dir() {
        Some(d) => d,
        None => match dirs::home_dir() {
            Some(h) => h.join(".local").join("share"),
            None => PathBuf::from("/tmp"),
        },
    };
    base.join("SharedAI").join("bloom_cache.bin")
}

/// Build (or rebuild) the cache from the gate_patterns table.
///
/// Writes count (u64 LE) followed by one 72-byte record per pattern.
/// Returns the number of patterns written.
pub fn build(conn: &Connection, project_id: i64) -> Result<usize> {
    let rows = load_rows(conn, project_id)?;
    let path = cache_path();
    write_cache(&path, &rows)?;
    Ok(rows.len())
}

/// Open the cache file and return a read-only memory map.
///
/// # Errors
/// Returns `DbError::Io` if the file does not exist or cannot be mapped.
pub fn open(path: &std::path::Path) -> Result<Mmap> {
    let file = std::fs::File::open(path)?;
    // SAFETY: The bloom_cache.bin is written atomically by `build()` and is
    // never truncated while mapped. The file is opened read-only, so no
    // mutation can occur through this mapping. The backing file outlives the
    // Mmap because `build()` only overwrites it between sessions.
    let mmap = unsafe { Mmap::map(&file)? };
    Ok(mmap)
}

/// Look up a pattern's bloom bytes by its database id.
///
/// Performs a linear scan — O(n) where n is the number of cached patterns,
/// bounded by HISTORY_SIZE (typically < 200). Returns `None` if not found
/// or if the mmap is malformed.
pub fn lookup(mmap: &Mmap, pattern_id: i64) -> Option<[u8; BLOOM_BYTES]> {
    let bytes = mmap.as_ref();
    if bytes.len() < ID_BYTES {
        return None;
    }
    let count_slice = bytes.get(..ID_BYTES)?;
    let count_arr: [u8; ID_BYTES] = match count_slice.try_into() {
        Ok(a) => a,
        Err(_) => return None,
    };
    let count = u64::from_le_bytes(count_arr) as usize;
    for i in 0..count {
        let offset = ID_BYTES + i * RECORD_BYTES;
        let id_end = offset + ID_BYTES;
        let bloom_end = id_end + BLOOM_BYTES;
        let id_slice = bytes.get(offset..id_end)?;
        let id_arr: [u8; ID_BYTES] = match id_slice.try_into() {
            Ok(a) => a,
            Err(_) => return None,
        };
        let stored_id = i64::from_le_bytes(id_arr);
        if stored_id == pattern_id {
            let bloom_slice = bytes.get(id_end..bloom_end)?;
            let bloom: [u8; BLOOM_BYTES] = match bloom_slice.try_into() {
                Ok(a) => a,
                Err(_) => return None,
            };
            return Some(bloom);
        }
    }
    None
}

// ── private helpers ──────────────────────────────────────────────────────────

struct PatternRow {
    id: i64,
    bloom: Vec<u8>,
}

fn load_rows(conn: &Connection, project_id: i64) -> Result<Vec<PatternRow>> {
    let mut stmt = conn.prepare(
        "SELECT id, bloom_bytes FROM gate_patterns \
         WHERE project_id = ?1 AND bloom_bytes IS NOT NULL \
         ORDER BY id",
    )?;
    let rows = stmt.query_map([project_id], |row| {
        let id: i64 = row.get(0)?;
        let bloom: Vec<u8> = row.get(1)?;
        Ok(PatternRow { id, bloom })
    })?;
    let mut out = Vec::with_capacity(64);
    for row in rows {
        out.push(row?);
    }
    Ok(out)
}

fn write_cache(path: &std::path::Path, rows: &[PatternRow]) -> Result<()> {
    use std::io::Write;
    let tmp = path.with_extension("tmp");
    let mut f = std::fs::File::create(&tmp)?;
    let count = rows.len() as u64;
    f.write_all(&count.to_le_bytes())?;
    for row in rows {
        f.write_all(&row.id.to_le_bytes())?;
        let mut bloom_fixed = [0u8; BLOOM_BYTES];
        let copy_len = row.bloom.len().min(BLOOM_BYTES);
        if let Some(src) = row.bloom.get(..copy_len) {
            bloom_fixed[..copy_len].copy_from_slice(src);
        }
        f.write_all(&bloom_fixed)?;
    }
    f.sync_all()?;
    drop(f);
    std::fs::rename(&tmp, path)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::DbError;

    fn make_cache_buf(rows: &[(i64, [u8; BLOOM_BYTES])]) -> Vec<u8> {
        let mut buf = Vec::with_capacity(ID_BYTES + rows.len() * RECORD_BYTES);
        buf.extend_from_slice(&(rows.len() as u64).to_le_bytes());
        for (id, bloom) in rows {
            buf.extend_from_slice(&id.to_le_bytes());
            buf.extend_from_slice(bloom);
        }
        buf
    }

    fn mmap_from_buf(buf: &[u8]) -> Result<(tempfile::TempDir, Mmap)> {
        let dir = tempfile::tempdir().map_err(DbError::Io)?;
        let path = dir.path().join("test.bin");
        std::fs::write(&path, buf).map_err(DbError::Io)?;
        let mmap = open(&path)?;
        Ok((dir, mmap))
    }

    #[test]
    fn lookup_finds_matching_id() -> Result<()> {
        let bloom = [0xABu8; BLOOM_BYTES];
        let buf = make_cache_buf(&[(42, bloom)]);
        let (_dir, mmap) = mmap_from_buf(&buf)?;
        assert_eq!(lookup(&mmap, 42), Some(bloom));
        Ok(())
    }

    #[test]
    fn lookup_returns_none_for_missing_id() -> Result<()> {
        let bloom = [0x01u8; BLOOM_BYTES];
        let buf = make_cache_buf(&[(10, bloom)]);
        let (_dir, mmap) = mmap_from_buf(&buf)?;
        assert_eq!(lookup(&mmap, 99), None);
        Ok(())
    }

    #[test]
    fn lookup_returns_none_on_empty_cache() -> Result<()> {
        let buf = make_cache_buf(&[]);
        let (_dir, mmap) = mmap_from_buf(&buf)?;
        assert_eq!(lookup(&mmap, 1), None);
        Ok(())
    }

    #[test]
    fn lookup_finds_second_record() -> Result<()> {
        let b1 = [0x11u8; BLOOM_BYTES];
        let b2 = [0x22u8; BLOOM_BYTES];
        let buf = make_cache_buf(&[(1, b1), (2, b2)]);
        let (_dir, mmap) = mmap_from_buf(&buf)?;
        assert_eq!(lookup(&mmap, 2), Some(b2));
        Ok(())
    }
}
