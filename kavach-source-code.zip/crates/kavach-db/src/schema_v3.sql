-- Vectorless RAG tree storage.
-- Each row is one built tree (from `kavach rag build`). source is the
-- human-readable label passed at build time ("skills", "rules", etc.).
-- source_hash is the sha256 of the concatenated source files so gates can
-- detect stale trees and trigger a rebuild.
CREATE TABLE IF NOT EXISTS rag_trees (
    source TEXT PRIMARY KEY,
    built_at TEXT NOT NULL,
    tree_json BLOB NOT NULL,
    source_hash TEXT NOT NULL
);
