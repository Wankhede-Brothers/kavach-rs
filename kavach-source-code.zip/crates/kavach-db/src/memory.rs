/// CRUD for memory_entries (decisions, research, patterns, proposals, roadmaps).
use crate::error::{DbError, Result};
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct MemoryEntry {
    pub id: i64,
    pub project_id: i64,
    pub category: String,
    pub entry_key: String,
    pub title: String,
    pub content: String,
    pub status: String,
    pub tags: Option<String>,
    pub ttl_days: Option<i64>,
    pub source: Option<String>,
    pub verified_at: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub expires_at: Option<String>,
    pub accessed_at: Option<String>,
    pub access_count: i64,
    pub decay_score: Option<f64>,
}

/// Parameters for upserting a memory entry.
pub struct UpsertParams<'a> {
    pub project_id: i64,
    pub category: &'a str,
    pub entry_key: &'a str,
    pub title: &'a str,
    pub content: &'a str,
    pub tags: Option<&'a str>,
    pub ttl_days: Option<i64>,
    pub source: Option<&'a str>,
}

/// Insert or update (upsert) a memory entry.
/// expires_at computed via SQL CASE — datetime() must be in the query, not a bound parameter.
pub fn upsert(conn: &Connection, p: &UpsertParams<'_>) -> Result<i64> {
    validate_category(p.category)?;
    let id: i64 = conn.query_row(
        "INSERT INTO memory_entries
            (project_id, category, entry_key, title, content, tags,
             ttl_days, source, expires_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8,
            CASE WHEN ?7 IS NOT NULL
                 THEN datetime('now', '+' || ?7 || ' days') ELSE NULL END)
         ON CONFLICT(project_id, category, entry_key) DO UPDATE SET
            title = excluded.title,
            content = excluded.content,
            tags = excluded.tags,
            ttl_days = excluded.ttl_days,
            source = excluded.source,
            expires_at = excluded.expires_at,
            updated_at = datetime('now')
         RETURNING id",
        params![
            p.project_id, p.category, p.entry_key, p.title, p.content,
            p.tags, p.ttl_days, p.source,
        ],
        |row| row.get(0),
    )?;
    Ok(id)
}

pub fn get(
    conn: &Connection,
    project_id: i64,
    category: &str,
    entry_key: &str,
) -> Result<MemoryEntry> {
    // Bump access tracking
    conn.execute(
        "UPDATE memory_entries SET accessed_at = datetime('now'),
                access_count = access_count + 1
         WHERE project_id = ?1 AND category = ?2 AND entry_key = ?3",
        params![project_id, category, entry_key],
    )?;
    conn.query_row(
        "SELECT id, project_id, category, entry_key, title, content,
                status, tags, ttl_days, source, verified_at,
                created_at, updated_at, expires_at, accessed_at,
                access_count, decay_score
         FROM memory_entries
         WHERE project_id = ?1 AND category = ?2 AND entry_key = ?3",
        params![project_id, category, entry_key],
        row_to_entry,
    )
    .map_err(|e| match e {
        rusqlite::Error::QueryReturnedNoRows => DbError::EntryNotFound {
            category: category.to_string(),
            key: entry_key.to_string(),
        },
        other => DbError::Sqlite(other),
    })
}

/// Fetch a single entry by project + category + key without bumping access tracking.
/// Returns `DbError::EntryNotFound` if no match.
pub fn get_by_key(
    conn: &Connection,
    project_id: i64,
    category: &str,
    key: &str,
) -> Result<MemoryEntry> {
    conn.query_row(
        "SELECT id, project_id, category, entry_key, title, content,
                status, tags, ttl_days, source, verified_at,
                created_at, updated_at, expires_at, accessed_at,
                access_count, decay_score
         FROM memory_entries
         WHERE project_id = ?1 AND category = ?2 AND entry_key = ?3
         LIMIT 1",
        params![project_id, category, key],
        row_to_entry,
    )
    .map_err(|e| match e {
        rusqlite::Error::QueryReturnedNoRows => DbError::EntryNotFound {
            category: category.to_string(),
            key: key.to_string(),
        },
        other => DbError::Sqlite(other),
    })
}

pub fn list_by_project(
    conn: &Connection,
    project_id: i64,
    category: Option<&str>,
) -> Result<Vec<MemoryEntry>> {
    let (sql, cat_param);
    if let Some(c) = category {
        validate_category(c)?;
        cat_param = c.to_string();
        sql = "SELECT id, project_id, category, entry_key, title, content,
                      status, tags, ttl_days, source, verified_at,
                      created_at, updated_at, expires_at, accessed_at,
                      access_count, decay_score
               FROM memory_entries
               WHERE project_id = ?1 AND category = ?2 AND status = 'active'
               ORDER BY updated_at DESC";
    } else {
        cat_param = String::new();
        sql = "SELECT id, project_id, category, entry_key, title, content,
                      status, tags, ttl_days, source, verified_at,
                      created_at, updated_at, expires_at, accessed_at,
                      access_count, decay_score
               FROM memory_entries
               WHERE project_id = ?1 AND status = 'active'
               ORDER BY category, updated_at DESC";
    }

    let mut stmt = conn.prepare(sql)?;
    let rows = if category.is_some() {
        stmt.query_map(params![project_id, cat_param], row_to_entry)?
    } else {
        stmt.query_map(params![project_id], row_to_entry)?
    };

    let mut entries = Vec::new();
    for row in rows {
        entries.push(row?);
    }
    Ok(entries)
}

/// List titles only (no content) for a project, ordered by recency.
/// Used by CLI `kavach db query` and session_start injection to avoid
/// fetching full content bodies when only the index is needed.
pub fn list_titles_by_project(
    conn: &Connection,
    project_id: i64,
    category: Option<&str>,
    limit: usize,
) -> Result<Vec<MemoryEntry>> {
    let lim = if limit == 0 { 20_i64 } else {
        i64::try_from(limit).map_err(|_| DbError::InvalidCategory("limit overflow".into()))?
    };
    let (sql, cat_param);
    if let Some(c) = category {
        validate_category(c)?;
        cat_param = c.to_string();
        sql = "SELECT id, project_id, category, entry_key, title, '' as content,
                      status, tags, ttl_days, source, verified_at,
                      created_at, updated_at, expires_at, accessed_at,
                      access_count, decay_score
               FROM memory_entries
               WHERE project_id = ?1 AND category = ?2 AND status = 'active'
               ORDER BY updated_at DESC
               LIMIT ?3";
    } else {
        cat_param = String::new();
        sql = "SELECT id, project_id, category, entry_key, title, '' as content,
                      status, tags, ttl_days, source, verified_at,
                      created_at, updated_at, expires_at, accessed_at,
                      access_count, decay_score
               FROM memory_entries
               WHERE project_id = ?1 AND status = 'active'
               ORDER BY category, updated_at DESC
               LIMIT ?2";
    }

    let mut stmt = conn.prepare(sql)?;
    let rows = if category.is_some() {
        stmt.query_map(params![project_id, cat_param, lim], row_to_entry)?
    } else {
        stmt.query_map(params![project_id, lim], row_to_entry)?
    };

    let mut entries = Vec::with_capacity(lim as usize);
    for row in rows {
        entries.push(row?);
    }
    Ok(entries)
}

/// Mark expired entries as archived.
pub fn expire_stale(conn: &Connection) -> Result<usize> {
    let count = conn.execute(
        "UPDATE memory_entries SET status = 'archived'
         WHERE expires_at IS NOT NULL
           AND expires_at < datetime('now')
           AND status = 'active'",
        [],
    )?;
    Ok(count)
}

/// Batch upsert multiple entries in a single transaction.
/// Chunks entries into batches of `chunk_size` for WAL-friendly writes.
/// Returns total number of entries written.
pub fn batch_upsert(
    conn: &Connection,
    entries: &[UpsertParams<'_>],
    chunk_size: usize,
) -> Result<usize> {
    if entries.is_empty() {
        return Ok(0);
    }
    let batch = if chunk_size == 0 { 50 } else { chunk_size };
    let mut total = 0;
    for chunk in entries.chunks(batch) {
        let tx = conn.unchecked_transaction()?;
        for p in chunk {
            validate_category(p.category)?;
            tx.execute(
                "INSERT INTO memory_entries
                    (project_id, category, entry_key, title, content, tags,
                     ttl_days, source, expires_at)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8,
                    CASE WHEN ?7 IS NOT NULL
                         THEN datetime('now', '+' || ?7 || ' days') ELSE NULL END)
                 ON CONFLICT(project_id, category, entry_key) DO UPDATE SET
                    title = excluded.title,
                    content = excluded.content,
                    tags = excluded.tags,
                    ttl_days = excluded.ttl_days,
                    source = excluded.source,
                    expires_at = excluded.expires_at,
                    updated_at = datetime('now')",
                params![
                    p.project_id, p.category, p.entry_key, p.title, p.content,
                    p.tags, p.ttl_days, p.source,
                ],
            )?;
            total += 1;
        }
        tx.commit()?;
    }
    Ok(total)
}

fn validate_category(category: &str) -> Result<()> {
    match category {
        "decision" | "research" | "pattern" | "proposal" | "roadmap" => Ok(()),
        other => Err(DbError::InvalidCategory(other.to_string())),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations, projects};

    type R = std::result::Result<(), Box<dyn std::error::Error>>;

    fn setup() -> std::result::Result<Connection, Box<dyn std::error::Error>> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        Ok(conn)
    }

    fn make_entry<'a>(project_id: i64, category: &'a str, key: &'a str, title: &'a str) -> UpsertParams<'a> {
        UpsertParams {
            project_id,
            category,
            entry_key: key,
            title,
            content: "test content",
            tags: None,
            ttl_days: None,
            source: None,
        }
    }

    #[test]
    fn list_titles_no_category_does_not_panic() -> R {
        // Regression: no-category branch previously passed wrong param count to rusqlite
        // (cat_param as ?2 when SQL only had ?1 and ?3), causing a runtime param mismatch.
        let conn = setup()?;
        let pid = projects::insert(&conn, "test", "Test")?;
        upsert(&conn, &make_entry(pid, "decision", "k1", "Title 1"))?;
        upsert(&conn, &make_entry(pid, "research", "k2", "Title 2"))?;
        let entries = list_titles_by_project(&conn, pid, None, 10)?;
        assert_eq!(entries.len(), 2);
        Ok(())
    }

    #[test]
    fn list_titles_with_category_filters_correctly() -> R {
        let conn = setup()?;
        let pid = projects::insert(&conn, "proj2", "P2")?;
        upsert(&conn, &make_entry(pid, "decision", "d1", "Decision"))?;
        upsert(&conn, &make_entry(pid, "research", "r1", "Research"))?;
        let entries = list_titles_by_project(&conn, pid, Some("decision"), 10)?;
        assert_eq!(entries.len(), 1);
        match entries.first() {
            Some(e) => assert_eq!(e.entry_key, "d1"),
            None => return Err("expected one entry".into()),
        }
        Ok(())
    }

    #[test]
    fn get_by_key_returns_entry() -> R {
        let conn = setup()?;
        let pid = projects::insert(&conn, "gbk1", "GBK1")?;
        upsert(&conn, &make_entry(pid, "roadmap", "k1", "My Task"))?;
        let e = get_by_key(&conn, pid, "roadmap", "k1")?;
        assert_eq!(e.entry_key, "k1");
        assert_eq!(e.title, "My Task");
        Ok(())
    }

    #[test]
    fn get_by_key_returns_entry_not_found_for_missing_key() -> R {
        let conn = setup()?;
        let pid = projects::insert(&conn, "gbk2", "GBK2")?;
        let result = get_by_key(&conn, pid, "roadmap", "missing");
        assert!(result.is_err());
        Ok(())
    }

    #[test]
    fn expire_stale_does_not_archive_entries_without_expires_at() -> R {
        // Roadmap entries written via CLI never have ttl_days — must never be archived.
        let conn = setup()?;
        let pid = projects::insert(&conn, "proj3", "P3")?;
        upsert(&conn, &make_entry(pid, "roadmap", "task-1", "Open task"))?;
        let archived = expire_stale(&conn)?;
        assert_eq!(archived, 0);
        let entries = list_by_project(&conn, pid, Some("roadmap"))?;
        assert_eq!(entries.len(), 1);
        Ok(())
    }
}

fn row_to_entry(row: &rusqlite::Row) -> rusqlite::Result<MemoryEntry> {
    Ok(MemoryEntry {
        id: row.get(0)?,
        project_id: row.get(1)?,
        category: row.get(2)?,
        entry_key: row.get(3)?,
        title: row.get(4)?,
        content: row.get(5)?,
        status: row.get(6)?,
        tags: row.get(7)?,
        ttl_days: row.get(8)?,
        source: row.get(9)?,
        verified_at: row.get(10)?,
        created_at: row.get(11)?,
        updated_at: row.get(12)?,
        expires_at: row.get(13)?,
        accessed_at: row.get(14)?,
        access_count: row.get(15)?,
        decay_score: row.get(16)?,
    })
}
