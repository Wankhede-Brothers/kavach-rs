-- kavach-db schema v1: Memory bank + session state + knowledge graph

CREATE TABLE projects (
    id          INTEGER PRIMARY KEY,
    slug        TEXT NOT NULL UNIQUE,
    display     TEXT NOT NULL,
    workdir     TEXT,
    stack       TEXT,
    aliases     TEXT,
    parent_id   INTEGER REFERENCES projects(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE sessions (
    id          TEXT PRIMARY KEY,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    model_id    TEXT,
    started_at  TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at    TEXT,
    turn_count  INTEGER NOT NULL DEFAULT 0,
    compact_count INTEGER NOT NULL DEFAULT 0,
    context_phase TEXT NOT NULL DEFAULT 'early',
    token_budget_total  INTEGER NOT NULL DEFAULT 1000000,
    token_budget_used   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE memory_entries (
    id          INTEGER PRIMARY KEY,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    category    TEXT NOT NULL CHECK(category IN (
                    'decision', 'research', 'pattern', 'proposal', 'roadmap'
                )),
    entry_key   TEXT NOT NULL,
    title       TEXT NOT NULL,
    content     TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'active',
    tags        TEXT,
    ttl_days    INTEGER,
    source      TEXT,
    verified_at TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at  TEXT,
    accessed_at TEXT,
    access_count INTEGER NOT NULL DEFAULT 0,
    decay_score REAL,
    UNIQUE(project_id, category, entry_key)
);

CREATE TABLE entities (
    id          INTEGER PRIMARY KEY,
    entity_type TEXT NOT NULL,
    name        TEXT NOT NULL,
    properties  TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(entity_type, name)
);

CREATE TABLE relationships (
    id          INTEGER PRIMARY KEY,
    from_id     INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    to_id       INTEGER NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    rel_type    TEXT NOT NULL,
    properties  TEXT,
    weight      REAL NOT NULL DEFAULT 1.0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(from_id, to_id, rel_type)
);

CREATE TABLE events (
    id          INTEGER PRIMARY KEY,
    session_id  TEXT REFERENCES sessions(id),
    event_type  TEXT NOT NULL,
    source      TEXT NOT NULL DEFAULT 'kavach',
    project_id  INTEGER REFERENCES projects(id),
    payload     TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE kanban_cards (
    id          INTEGER PRIMARY KEY,
    project_id  INTEGER NOT NULL REFERENCES projects(id),
    title       TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'backlog',
    priority    TEXT NOT NULL DEFAULT 'P2',
    description TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT
);

CREATE TABLE session_state (
    session_id      TEXT PRIMARY KEY REFERENCES sessions(id),
    research_done   INTEGER NOT NULL DEFAULT 0,
    research_topics TEXT,
    memory_loaded   INTEGER NOT NULL DEFAULT 0,
    required_skills TEXT,
    invoked_skills  TEXT,
    active_task     TEXT,
    task_status     TEXT,
    completed_work  TEXT,
    intent_type     TEXT,
    intent_domain   TEXT,
    files_read      TEXT,
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE file_context (
    id          INTEGER PRIMARY KEY,
    session_id  TEXT NOT NULL REFERENCES sessions(id),
    file_path   TEXT NOT NULL,
    file_size   INTEGER,
    extension   TEXT,
    is_code     INTEGER NOT NULL DEFAULT 0,
    read_at     TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(session_id, file_path)
);

-- Indexes for common query patterns
CREATE INDEX idx_memory_project_category ON memory_entries(project_id, category);
CREATE INDEX idx_memory_expires ON memory_entries(expires_at)
    WHERE expires_at IS NOT NULL;
CREATE INDEX idx_memory_accessed ON memory_entries(accessed_at);
CREATE INDEX idx_events_session ON events(session_id);
CREATE INDEX idx_events_type ON events(event_type);
CREATE INDEX idx_events_created ON events(created_at);
CREATE INDEX idx_kanban_project_status ON kanban_cards(project_id, status);
CREATE INDEX idx_relationships_from ON relationships(from_id);
CREATE INDEX idx_relationships_to ON relationships(to_id);
CREATE INDEX idx_file_context_session ON file_context(session_id);
