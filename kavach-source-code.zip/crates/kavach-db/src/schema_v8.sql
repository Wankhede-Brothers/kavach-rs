-- v8: Algorithm decision store for self-evolving algorithm selection.
--
-- Recency is always dynamic: (CAST(strftime('%Y','now') AS INTEGER) - search_year) <= 1
-- Never use static year flags. search_year + search_month form the TTL base.
-- Query order: search_year DESC, search_month DESC — freshest decisions first.

CREATE TABLE IF NOT EXISTS algorithm_decisions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id       INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    problem_class    TEXT NOT NULL,
    chosen           TEXT NOT NULL,
    rejected         TEXT NOT NULL DEFAULT '[]',  -- JSON: [{"name":"X","reason":"Y"}]
    rationale        TEXT NOT NULL DEFAULT '',
    time_complexity  TEXT NOT NULL DEFAULT 'unknown',
    space_complexity TEXT NOT NULL DEFAULT 'unknown',
    year_published   INTEGER NOT NULL DEFAULT 0,
    search_year      INTEGER NOT NULL,   -- year research was run (dynamic TTL base)
    search_month     INTEGER NOT NULL,   -- month research was run (1-12)
    benchmark_source TEXT,               -- URL or citation
    simd_capable     INTEGER NOT NULL DEFAULT 0,
    parallel_safe    INTEGER NOT NULL DEFAULT 0,
    file_path        TEXT NOT NULL,
    turn             INTEGER NOT NULL DEFAULT 0,
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

-- Unique constraint enables ON CONFLICT upsert by (project, class, file).
CREATE UNIQUE INDEX IF NOT EXISTS idx_algo_unique
    ON algorithm_decisions(project_id, problem_class, file_path);

-- Project + recency DESC — primary query path for session_start injector.
CREATE INDEX IF NOT EXISTS idx_algo_project
    ON algorithm_decisions(project_id, created_at DESC);

-- Problem class lookup — used by pre-write guard for context injection.
CREATE INDEX IF NOT EXISTS idx_algo_class
    ON algorithm_decisions(problem_class);

-- Freshest-first ordering for session context (dynamic TTL, never stale).
CREATE INDEX IF NOT EXISTS idx_algo_recency
    ON algorithm_decisions(project_id, search_year DESC, search_month DESC);
