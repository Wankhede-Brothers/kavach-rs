/// Database connection management with WAL mode and platform-native paths.
use crate::error::Result;
use rusqlite::Connection;
use std::path::{Path, PathBuf};

/// Returns the platform-native database path.
pub fn default_db_path() -> PathBuf {
    if cfg!(target_os = "macos") {
        let home = std::env::var("HOME").unwrap_or_else(|_| String::from("/tmp"));
        PathBuf::from(home)
            .join("Library/Application Support/SharedAI/kavach.db")
    } else if cfg!(target_os = "windows") {
        let local = std::env::var("LOCALAPPDATA")
            .unwrap_or_else(|_| String::from("C:\\Users\\Public"));
        PathBuf::from(local).join("SharedAI\\kavach.db")
    } else {
        // Linux: respect XDG_DATA_HOME
        let base = std::env::var("XDG_DATA_HOME").unwrap_or_else(|_| {
            let home = std::env::var("HOME").unwrap_or_else(|_| String::from("/tmp"));
            format!("{home}/.local/share")
        });
        PathBuf::from(base).join("shared-ai/kavach.db")
    }
}

/// Opens (or creates) the database at the given path with production PRAGMAs.
pub fn open_db(path: &Path) -> Result<Connection> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let conn = Connection::open(path)?;
    apply_pragmas(&conn)?;
    Ok(conn)
}

/// Opens the database at the default platform path.
pub fn open_default() -> Result<Connection> {
    open_db(&default_db_path())
}

/// Opens an in-memory database (for tests).
pub fn open_memory() -> Result<Connection> {
    let conn = Connection::open_in_memory()?;
    apply_pragmas(&conn)?;
    Ok(conn)
}

fn apply_pragmas(conn: &Connection) -> Result<()> {
    conn.execute_batch(
        "PRAGMA journal_mode = WAL;
         PRAGMA synchronous = NORMAL;
         PRAGMA foreign_keys = ON;
         PRAGMA busy_timeout = 5000;
         PRAGMA cache_size = -2000;
         PRAGMA temp_store = MEMORY;",
    )?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_open_memory() {
        let conn = open_memory().expect("should open in-memory db");
        let mode: String = conn
            .query_row("PRAGMA journal_mode", [], |r| r.get(0))
            .expect("should query pragma");
        // In-memory DBs use "memory" journal mode, not WAL
        assert_eq!(mode, "memory");
    }

    #[test]
    fn test_foreign_keys_enabled() {
        let conn = open_memory().expect("should open");
        let fk: i64 = conn
            .query_row("PRAGMA foreign_keys", [], |r| r.get(0))
            .expect("should query");
        assert_eq!(fk, 1);
    }
}
