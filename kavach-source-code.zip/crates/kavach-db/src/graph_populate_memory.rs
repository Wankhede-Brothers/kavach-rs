/// Memory DAG population — O(V+E) hub-and-spoke topology.
///
/// Cross-references use concept hub nodes (inverted index as graph):
///   decision → references → concept:keyword
/// Avoids O(n²) pair emission — co-referenced decisions found in O(degree).
///
/// Gate wiring: memory_node → triggered_by → gate  (O(|GATES|) per row)
/// P3 resolved_by: pattern → resolved_by → decision via gate_to_decisions HashMap (O(1) lookup)
/// P1 content_hash dedup: identical bodies across projects share one entity node.
use std::collections::HashMap;
use rusqlite::Connection;

use crate::error::Result;
use crate::graph::add_relationship;
use crate::graph_entity::{upsert_entity, upsert_entity_with_hash};
use crate::graph_populate_util::{collect_gates_in, collect_gates_in_key, content_hash, keywords_from};

const GATE_KEYWORDS: &[&str] = &[
    "pre_write", "post_write", "intent", "stop",
    "pre_tool", "post_tool", "session",
];

const CATEGORY_DECISION: &str = "decision";
const CATEGORY_ROADMAP: &str = "roadmap";
const CATEGORY_PATTERN: &str = "pattern";
const NODE_TYPE_CONCEPT: &str = "concept";
const NODE_TYPE_GATE: &str = "gate";
const NODE_TYPE_PROJECT: &str = "project";

struct MemoryRow {
    category: String,
    entry_key: String,
    title: String,
    content: String,
    proj_slug: String,
}

/// Populate the memory DAG. Returns count of entity nodes upserted.
/// Idempotent — all writes use upsert semantics.
pub fn populate_memory_dag(conn: &Connection) -> Result<usize> {
    let rows = load_memory_rows(conn)?;
    let mut count = 0;
    // gate keyword → Vec<decision_node_id> — O(1) lookup in P3
    let mut gate_to_decisions: HashMap<&str, Vec<i64>> = HashMap::new();
    // name → node_id cache — eliminates upsert_entity round-trips in wire_resolved_by (P3)
    let mut node_id_cache: HashMap<String, i64> = HashMap::with_capacity(rows.len());

    for row in &rows {
        let hash = content_hash(&row.title, &row.content);
        let name = format!("{}/{}/{}", row.proj_slug, row.category, row.entry_key);
        let props = format!(r#"{{"project":"{}","key":"{}"}}"#, row.proj_slug, row.entry_key);

        // P0+P1: upsert with content_hash — merges identical patterns across projects
        let node_id = match upsert_entity_with_hash(
            conn, &row.category, &name, Some(&props), Some(&hash),
        ) {
            Ok(id) => id,
            Err(_) => continue,
        };
        // Cache node_id for O(1) P3 lookup — avoids re-issuing upsert_entity per pattern
        node_id_cache.insert(name, node_id);

        // Project isolation: every memory node links to its own project only
        if let Ok(proj_id) = upsert_entity(conn, NODE_TYPE_PROJECT, &row.proj_slug, None) {
            let _ = add_relationship(conn, node_id, proj_id, "memory_of", 1.0);
        }

        // P0: gate hub edges — O(|GATE_KEYWORDS|) constant per row
        let gates = collect_gates_in(GATE_KEYWORDS, &row.entry_key, &row.content);
        for gate in &gates {
            if let Ok(gate_id) = upsert_entity(conn, NODE_TYPE_GATE, gate, None) {
                let _ = add_relationship(conn, node_id, gate_id, "triggered_by", 1.0);
                if row.category == CATEGORY_DECISION {
                    gate_to_decisions.entry(gate).or_default().push(node_id);
                }
            }
        }

        // P2: concept hub edges — O(keywords) per row, zero pair emission
        if row.category == CATEGORY_DECISION || row.category == CATEGORY_ROADMAP {
            for keyword in keywords_from(&row.title) {
                let concept_name = format!("keyword:{keyword}");
                if let Ok(concept_id) = upsert_entity(conn, NODE_TYPE_CONCEPT, &concept_name, None) {
                    let _ = add_relationship(conn, node_id, concept_id, "references", 1.0);
                }
            }
        }

        count += 1;
    }

    // P3: pattern → resolved_by → decision, O(patterns × |GATE_KEYWORDS|)
    wire_resolved_by(conn, &rows, &gate_to_decisions, &node_id_cache)?;
    Ok(count)
}

/// P3: connect pattern nodes to decision nodes sharing the same gate keyword.
/// Uses `node_id_cache` for O(1) lookup — no upsert round-trips.
fn wire_resolved_by(
    conn: &Connection,
    rows: &[MemoryRow],
    gate_to_decisions: &HashMap<&str, Vec<i64>>,
    node_id_cache: &HashMap<String, i64>,
) -> Result<()> {
    for row in rows {
        if row.category != CATEGORY_PATTERN {
            continue;
        }
        let name = format!("{}/{}/{}", row.proj_slug, row.category, row.entry_key);
        let node_id = match node_id_cache.get(&name) {
            Some(&id) => id,
            None => continue,
        };
        let gates = collect_gates_in_key(GATE_KEYWORDS, &row.entry_key);
        for gate in &gates {
            if let Some(decision_ids) = gate_to_decisions.get(gate) {
                for &dec_id in decision_ids {
                    let _ = add_relationship(conn, node_id, dec_id, "resolved_by", 1.0);
                }
            }
        }
    }
    Ok(())
}

fn load_memory_rows(conn: &Connection) -> Result<Vec<MemoryRow>> {
    let mut stmt = conn.prepare(
        "SELECT me.category, me.entry_key, me.title, me.content, p.slug
         FROM memory_entries me
         JOIN projects p ON p.id = me.project_id
         WHERE me.status = 'active'",
    )?;
    let rows: rusqlite::Result<Vec<MemoryRow>> = stmt
        .query_map([], |r| {
            Ok(MemoryRow {
                category: r.get(0)?,
                entry_key: r.get(1)?,
                title: r.get(2)?,
                content: r.get(3)?,
                proj_slug: r.get(4)?,
            })
        })?
        .collect();
    Ok(rows?)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{open_memory, run_migrations, projects};
    use crate::graph_populate_util::content_hash;

    #[test]
    fn should_populate_memory_dag_on_empty_db() -> Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "test", "Test")?;
        let count = populate_memory_dag(&conn)?;
        assert_eq!(count, 0);
        Ok(())
    }

    #[test]
    fn should_dedup_identical_content_by_hash() {
        let h1 = content_hash("same title", "same body");
        let h2 = content_hash("same title", "same body");
        assert_eq!(h1, h2);
    }

    #[test]
    fn should_differ_for_different_content() {
        let h1 = content_hash("title a", "body x");
        let h2 = content_hash("title b", "body y");
        assert_ne!(h1, h2);
    }

    #[test]
    fn should_extract_keywords_min_4_chars() {
        let kws: Vec<String> = crate::graph_populate_util::keywords_from("stop gate v2 fix").collect();
        assert!(kws.iter().any(|k| k == "stop"));
        assert!(!kws.iter().any(|k| k == "v2"));
    }
}
