/// CRUD operations for the projects table.
use crate::error::{DbError, Result};
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct Project {
    pub id: i64,
    pub slug: String,
    pub display: String,
    pub workdir: Option<String>,
    pub stack: Option<String>,
    pub aliases: Option<String>,
    pub parent_id: Option<i64>,
    pub created_at: String,
    pub updated_at: String,
}

pub fn insert(conn: &Connection, slug: &str, display: &str) -> Result<i64> {
    conn.execute(
        "INSERT INTO projects (slug, display) VALUES (?1, ?2)",
        params![slug, display],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn insert_full(
    conn: &Connection,
    slug: &str,
    display: &str,
    workdir: Option<&str>,
    stack: Option<&str>,
    aliases: Option<&str>,
    parent_id: Option<i64>,
) -> Result<i64> {
    conn.execute(
        "INSERT INTO projects (slug, display, workdir, stack, aliases, parent_id)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
        params![slug, display, workdir, stack, aliases, parent_id],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn get_by_slug(conn: &Connection, slug: &str) -> Result<Project> {
    conn.query_row(
        "SELECT id, slug, display, workdir, stack, aliases, parent_id,
                created_at, updated_at
         FROM projects WHERE slug = ?1",
        params![slug],
        row_to_project,
    )
    .map_err(|e| match e {
        rusqlite::Error::QueryReturnedNoRows => DbError::ProjectNotFound {
            slug: slug.to_string(),
        },
        other => DbError::Sqlite(other),
    })
}

pub fn get_by_id(conn: &Connection, id: i64) -> Result<Project> {
    conn.query_row(
        "SELECT id, slug, display, workdir, stack, aliases, parent_id,
                created_at, updated_at
         FROM projects WHERE id = ?1",
        params![id],
        row_to_project,
    )
    .map_err(|e| match e {
        rusqlite::Error::QueryReturnedNoRows => DbError::ProjectNotFound {
            slug: format!("id={id}"),
        },
        other => DbError::Sqlite(other),
    })
}

pub fn list_all(conn: &Connection) -> Result<Vec<Project>> {
    let mut stmt = conn.prepare(
        "SELECT id, slug, display, workdir, stack, aliases, parent_id,
                created_at, updated_at
         FROM projects ORDER BY slug",
    )?;
    let rows = stmt.query_map([], row_to_project)?;
    let mut projects = Vec::new();
    for row in rows {
        projects.push(row?);
    }
    Ok(projects)
}

pub fn get_or_create(conn: &Connection, slug: &str, display: &str) -> Result<i64> {
    match get_by_slug(conn, slug) {
        Ok(p) => Ok(p.id),
        Err(DbError::ProjectNotFound { .. }) => insert(conn, slug, display),
        Err(e) => Err(e),
    }
}

/// Register a project with its absolute path. Upserts on slug.
pub fn register(
    conn: &Connection,
    slug: &str,
    display: &str,
    abs_path: &str,
    stack: Option<&str>,
    aliases: Option<&str>,
) -> Result<i64> {
    let id = get_or_create(conn, slug, display)?;
    conn.execute(
        "UPDATE projects SET workdir = ?2, stack = COALESCE(?3, stack),
                aliases = COALESCE(?4, aliases), updated_at = datetime('now')
         WHERE id = ?1",
        params![id, abs_path, stack, aliases],
    )?;
    Ok(id)
}

/// Find project whose workdir is the longest prefix of the given path.
pub fn find_by_path(conn: &Connection, file_path: &str) -> Result<Option<Project>> {
    let mut stmt = conn.prepare(
        "SELECT id, slug, display, workdir, stack, aliases, parent_id,
                created_at, updated_at
         FROM projects WHERE workdir IS NOT NULL
         ORDER BY LENGTH(workdir) DESC",
    )?;
    let rows = stmt.query_map([], row_to_project)?;
    for row in rows {
        let project = row?;
        if let Some(ref wd) = project.workdir
            && file_path.starts_with(wd)
        {
            return Ok(Some(project));
        }
    }
    Ok(None)
}

/// Walk the parent_id chain starting from `project_id` using a recursive CTE.
/// Returns [child, parent, grandparent, ...] — child first, root last.
/// Depth is bounded by SQLite's default recursion limit (1000).
pub fn get_ancestry(conn: &Connection, project_id: i64) -> Result<Vec<Project>> {
    let mut stmt = conn.prepare(
        "WITH RECURSIVE ancestry(id, slug, display, workdir, stack, aliases, parent_id,
                                  created_at, updated_at, depth) AS (
             SELECT id, slug, display, workdir, stack, aliases, parent_id,
                    created_at, updated_at, 0
             FROM projects WHERE id = ?1
             UNION ALL
             SELECT p.id, p.slug, p.display, p.workdir, p.stack, p.aliases, p.parent_id,
                    p.created_at, p.updated_at, a.depth + 1
             FROM projects p
             INNER JOIN ancestry a ON p.id = a.parent_id
             WHERE a.depth < 7
         )
         SELECT id, slug, display, workdir, stack, aliases, parent_id,
                created_at, updated_at
         FROM ancestry ORDER BY depth ASC",
    )?;
    let rows = stmt.query_map(params![project_id], row_to_project)?;
    let mut chain = Vec::new();
    for row in rows {
        chain.push(row?);
    }
    Ok(chain)
}

/// Update project workdir to an absolute path.
pub fn set_workdir(conn: &Connection, id: i64, abs_path: &str) -> Result<()> {
    conn.execute(
        "UPDATE projects SET workdir = ?2, updated_at = datetime('now') WHERE id = ?1",
        params![id, abs_path],
    )?;
    Ok(())
}

fn row_to_project(row: &rusqlite::Row) -> rusqlite::Result<Project> {
    Ok(Project {
        id: row.get(0)?,
        slug: row.get(1)?,
        display: row.get(2)?,
        workdir: row.get(3)?,
        stack: row.get(4)?,
        aliases: row.get(5)?,
        parent_id: row.get(6)?,
        created_at: row.get(7)?,
        updated_at: row.get(8)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations};

    fn setup() -> Result<Connection> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        Ok(conn)
    }

    #[test]
    fn test_insert_and_get() -> Result<()> {
        let conn = setup()?;
        let id = insert(&conn, "kavach-rs", "Kavach RS")?;
        let p = get_by_id(&conn, id)?;
        assert_eq!(p.slug, "kavach-rs");
        assert_eq!(p.display, "Kavach RS");
        Ok(())
    }

    #[test]
    fn test_get_or_create_idempotent() -> Result<()> {
        let conn = setup()?;
        let id1 = get_or_create(&conn, "test", "Test")?;
        let id2 = get_or_create(&conn, "test", "Test")?;
        assert_eq!(id1, id2);
        Ok(())
    }

    #[test]
    fn test_not_found() -> Result<()> {
        let conn = setup()?;
        match get_by_slug(&conn, "nope") {
            Err(DbError::ProjectNotFound { .. }) => Ok(()),
            Ok(_) => Err(DbError::ProjectNotFound { slug: "expected Err but got Ok".into() }),
            Err(e) => Err(e),
        }
    }

    #[test]
    fn test_get_ancestry_root_only() -> Result<()> {
        let conn = setup()?;
        let id = insert_full(&conn, "root", "Root", Some("/root"), None, None, None)?;
        let chain = get_ancestry(&conn, id)?;
        assert_eq!(chain.len(), 1);
        assert_eq!(chain.first().map(|p| p.slug.as_str()), Some("root"));
        Ok(())
    }

    #[test]
    fn test_get_ancestry_two_levels() -> Result<()> {
        let conn = setup()?;
        let parent_id = insert_full(&conn, "parent", "Parent", Some("/p"), None, None, None)?;
        let child_id = insert_full(&conn, "child", "Child", Some("/p/c"), None, None, Some(parent_id))?;
        let chain = get_ancestry(&conn, child_id)?;
        assert_eq!(chain.len(), 2);
        assert_eq!(chain.first().map(|p| p.slug.as_str()), Some("child"));
        assert_eq!(chain.get(1).map(|p| p.slug.as_str()), Some("parent"));
        Ok(())
    }
}
