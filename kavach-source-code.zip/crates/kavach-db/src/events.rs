/// Event log: append-only with rotation.
use crate::error::Result;
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct Event {
    pub id: i64,
    pub session_id: Option<String>,
    pub event_type: String,
    pub source: String,
    pub project_id: Option<i64>,
    pub payload: Option<String>,
    pub created_at: String,
}

pub fn append(
    conn: &Connection,
    session_id: Option<&str>,
    event_type: &str,
    source: &str,
    project_id: Option<i64>,
    payload: Option<&str>,
) -> Result<i64> {
    conn.execute(
        "INSERT INTO events (session_id, event_type, source, project_id, payload)
         VALUES (?1, ?2, ?3, ?4, ?5)",
        params![session_id, event_type, source, project_id, payload],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn list_recent(conn: &Connection, limit: i64) -> Result<Vec<Event>> {
    let mut stmt = conn.prepare(
        "SELECT id, session_id, event_type, source, project_id, payload, created_at
         FROM events ORDER BY created_at DESC LIMIT ?1",
    )?;
    let rows = stmt.query_map(params![limit], row_to_event)?;
    let mut events = Vec::new();
    for row in rows {
        events.push(row?);
    }
    Ok(events)
}

pub fn list_by_session(conn: &Connection, session_id: &str) -> Result<Vec<Event>> {
    let mut stmt = conn.prepare(
        "SELECT id, session_id, event_type, source, project_id, payload, created_at
         FROM events WHERE session_id = ?1 ORDER BY created_at",
    )?;
    let rows = stmt.query_map(params![session_id], row_to_event)?;
    let mut events = Vec::new();
    for row in rows {
        events.push(row?);
    }
    Ok(events)
}

pub fn count_by_type(conn: &Connection, event_type: &str) -> Result<i64> {
    let count: i64 = conn.query_row(
        "SELECT COUNT(*) FROM events WHERE event_type = ?1",
        params![event_type],
        |r| r.get(0),
    )?;
    Ok(count)
}

/// Delete events older than `days` days. Returns count deleted.
pub fn rotate(conn: &Connection, days: i64) -> Result<usize> {
    let count = conn.execute(
        "DELETE FROM events
         WHERE created_at < datetime('now', ?1)",
        params![format!("-{days} days")],
    )?;
    Ok(count)
}

fn row_to_event(row: &rusqlite::Row) -> rusqlite::Result<Event> {
    Ok(Event {
        id: row.get(0)?,
        session_id: row.get(1)?,
        event_type: row.get(2)?,
        source: row.get(3)?,
        project_id: row.get(4)?,
        payload: row.get(5)?,
        created_at: row.get(6)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations};

    fn setup() -> Connection {
        let conn = open_memory().expect("open");
        run_migrations(&conn).expect("migrate");
        conn
    }

    #[test]
    fn test_append_and_list() {
        let conn = setup();
        append(&conn, None, "session_start", "kavach", None, None)
            .expect("append");
        append(&conn, None, "memory_write", "kavach", None, None)
            .expect("append2");
        let events = list_recent(&conn, 10).expect("list");
        assert_eq!(events.len(), 2);
        assert_eq!(events.first().map(|e| e.event_type.as_str()), Some("memory_write"));
    }

    #[test]
    fn test_count_by_type() {
        let conn = setup();
        for _ in 0..5 {
            append(&conn, None, "gate_decision", "kavach", None, None)
                .expect("append");
        }
        let count = count_by_type(&conn, "gate_decision").expect("count");
        assert_eq!(count, 5);
    }
}
