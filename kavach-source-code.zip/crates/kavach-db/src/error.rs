/// Database error types for kavach-db.
#[derive(Debug, thiserror::Error)]
pub enum DbError {
    #[error("sqlite error: {0}")]
    Sqlite(#[from] rusqlite::Error),

    #[error("project not found: {slug}")]
    ProjectNotFound { slug: String },

    #[error("session not found: {id}")]
    SessionNotFound { id: String },

    #[error("entry not found: {key} in {category}")]
    EntryNotFound { category: String, key: String },

    #[error("entity not found: {name}")]
    EntityNotFound { name: String },

    #[error("duplicate project: {slug}")]
    DuplicateProject { slug: String },

    #[error("invalid category: {0}")]
    InvalidCategory(String),

    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
}

pub type Result<T> = std::result::Result<T, DbError>;
