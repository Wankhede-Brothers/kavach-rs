-- v9: Architecture decision store for enforcing /arch skill research.
--
-- Stores structured architecture decisions (scaling, caching, messaging, data, service).
-- 9 required fields mirror // ARCH: comment format in code.
-- Recency: (CAST(strftime('%Y','now') AS INTEGER) - search_year) <= 1
-- Query order: search_year DESC, search_month DESC — freshest decisions first.

CREATE TABLE IF NOT EXISTS architecture_decisions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id       INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    pattern          TEXT NOT NULL,
    scope            TEXT NOT NULL CHECK(scope IN ('scale','cache','messaging','data','service')),
    cap_choice       TEXT CHECK(cap_choice IN ('CP','AP','N/A')),
    qps_estimate     TEXT,
    peak_multiplier  REAL,
    storage_estimate TEXT,
    failure_mode     TEXT NOT NULL,
    tradeoff         TEXT NOT NULL,
    search_year      INTEGER NOT NULL,   -- year research was run (dynamic TTL base)
    search_month     INTEGER NOT NULL,   -- month research was run (1-12)
    reference_url    TEXT,
    file_path        TEXT NOT NULL,
    turn             INTEGER NOT NULL DEFAULT 0,
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

-- Unique constraint enables ON CONFLICT upsert by (project, pattern, file).
CREATE UNIQUE INDEX IF NOT EXISTS idx_arch_unique
    ON architecture_decisions(project_id, pattern, file_path);

-- Project + recency DESC — primary query path for session_start injector.
CREATE INDEX IF NOT EXISTS idx_arch_project
    ON architecture_decisions(project_id, created_at DESC);

-- Scope lookup — used by pre-write guard for pattern category.
CREATE INDEX IF NOT EXISTS idx_arch_scope
    ON architecture_decisions(scope);

-- Freshest-first ordering for session context (dynamic TTL, never stale).
CREATE INDEX IF NOT EXISTS idx_arch_recency
    ON architecture_decisions(project_id, search_year DESC, search_month DESC);
