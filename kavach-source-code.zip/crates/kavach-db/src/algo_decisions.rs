/// Algorithm decision store — upsert, query, and stale-detection.
///
/// Dynamic recency: `(CAST(strftime('%Y','now') AS INTEGER) - search_year) <= 1`.
/// Never use static year thresholds. Query order: search_year DESC, search_month DESC.
use crate::error::Result;
use rusqlite::{Connection, Row};

/// A persisted algorithm selection decision.
#[derive(Debug, Clone)]
pub struct AlgoDecision {
    pub id: i64,
    pub project_id: i64,
    pub problem_class: String,
    pub chosen: String,
    /// JSON: `[{"name":"X","reason":"Y"}, ...]`
    pub rejected: String,
    pub rationale: String,
    pub time_complexity: String,
    pub space_complexity: String,
    pub year_published: i64,
    pub search_year: i64,
    pub search_month: i64,
    pub benchmark_source: Option<String>,
    pub simd_capable: bool,
    pub parallel_safe: bool,
    pub file_path: String,
    pub turn: i64,
    pub created_at: String,
}

/// Input for inserting or updating an algorithm decision.
#[derive(Debug, Clone)]
pub struct AlgoDecisionInput<'a> {
    pub project_id: i64,
    pub problem_class: &'a str,
    pub chosen: &'a str,
    pub rejected: &'a str,
    pub rationale: &'a str,
    pub time_complexity: &'a str,
    pub space_complexity: &'a str,
    pub year_published: i64,
    pub search_year: i64,
    pub search_month: i64,
    pub benchmark_source: Option<&'a str>,
    pub simd_capable: bool,
    pub parallel_safe: bool,
    pub file_path: &'a str,
    pub turn: i64,
}

/// Upsert an algorithm decision. Updates all fields on conflict
/// `(project_id, problem_class, file_path)`.
pub fn upsert(conn: &Connection, input: &AlgoDecisionInput<'_>) -> Result<i64> {
    conn.execute(
        "INSERT INTO algorithm_decisions (
            project_id, problem_class, chosen, rejected, rationale,
            time_complexity, space_complexity, year_published,
            search_year, search_month, benchmark_source,
            simd_capable, parallel_safe, file_path, turn
        ) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15)
        ON CONFLICT(project_id, problem_class, file_path) DO UPDATE SET
            chosen           = excluded.chosen,
            rejected         = excluded.rejected,
            rationale        = excluded.rationale,
            time_complexity  = excluded.time_complexity,
            space_complexity = excluded.space_complexity,
            year_published   = excluded.year_published,
            search_year      = excluded.search_year,
            search_month     = excluded.search_month,
            benchmark_source = excluded.benchmark_source,
            simd_capable     = excluded.simd_capable,
            parallel_safe    = excluded.parallel_safe,
            turn             = excluded.turn,
            created_at       = strftime('%Y-%m-%dT%H:%M:%SZ','now')",
        rusqlite::params![
            input.project_id,
            input.problem_class,
            input.chosen,
            input.rejected,
            input.rationale,
            input.time_complexity,
            input.space_complexity,
            input.year_published,
            input.search_year,
            input.search_month,
            input.benchmark_source,
            input.simd_capable as i64,
            input.parallel_safe as i64,
            input.file_path,
            input.turn,
        ],
    )?;
    Ok(conn.last_insert_rowid())
}

/// List recent decisions for a project, ordered freshest first.
/// Dynamic TTL: only decisions where `(current_year - search_year) <= 1`.
pub fn list_recent(conn: &Connection, project_id: i64, limit: i64) -> Result<Vec<AlgoDecision>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, problem_class, chosen, rejected, rationale,
                time_complexity, space_complexity, year_published,
                search_year, search_month, benchmark_source,
                simd_capable, parallel_safe, file_path, turn, created_at
         FROM algorithm_decisions
         WHERE project_id = ?1
           AND (CAST(strftime('%Y','now') AS INTEGER) - search_year) <= 1
         ORDER BY search_year DESC, search_month DESC
         LIMIT ?2",
    )?;
    collect_rows(&mut stmt, rusqlite::params![project_id, limit])
}

/// List stale decisions — `(current_year - search_year) > 1` — for re-research prompts.
pub fn list_stale(conn: &Connection, project_id: i64) -> Result<Vec<AlgoDecision>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, problem_class, chosen, rejected, rationale,
                time_complexity, space_complexity, year_published,
                search_year, search_month, benchmark_source,
                simd_capable, parallel_safe, file_path, turn, created_at
         FROM algorithm_decisions
         WHERE project_id = ?1
           AND (CAST(strftime('%Y','now') AS INTEGER) - search_year) > 1
         ORDER BY search_year ASC, search_month ASC",
    )?;
    collect_rows(&mut stmt, rusqlite::params![project_id])
}

fn row_to_decision(row: &Row<'_>) -> rusqlite::Result<AlgoDecision> {
    let simd_raw: i64 = row.get("simd_capable")?;
    let parallel_raw: i64 = row.get("parallel_safe")?;
    Ok(AlgoDecision {
        id:               row.get("id")?,
        project_id:       row.get("project_id")?,
        problem_class:    row.get("problem_class")?,
        chosen:           row.get("chosen")?,
        rejected:         row.get("rejected")?,
        rationale:        row.get("rationale")?,
        time_complexity:  row.get("time_complexity")?,
        space_complexity: row.get("space_complexity")?,
        year_published:   row.get("year_published")?,
        search_year:      row.get("search_year")?,
        search_month:     row.get("search_month")?,
        benchmark_source: row.get("benchmark_source")?,
        simd_capable:     simd_raw != 0,
        parallel_safe:    parallel_raw != 0,
        file_path:        row.get("file_path")?,
        turn:             row.get("turn")?,
        created_at:       row.get("created_at")?,
    })
}

fn collect_rows(
    stmt: &mut rusqlite::Statement<'_>,
    params: impl rusqlite::Params,
) -> Result<Vec<AlgoDecision>> {
    let iter = stmt.query_map(params, row_to_decision)?;
    let mut out = Vec::new();
    for item in iter {
        out.push(item?);
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::connection::open_memory;
    use crate::error::DbError;
    use crate::migrate::run_migrations;

    fn current_year() -> crate::error::Result<i64> {
        match std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH) {
            Ok(d) => match i64::try_from(d.as_secs() / 31_557_600) {
                Ok(y) => Ok(1970 + y),
                Err(e) => Err(DbError::Io(std::io::Error::other(e.to_string()))),
            },
            Err(e) => Err(DbError::Io(std::io::Error::other(e.to_string()))),
        }
    }

    fn first_or_err(rows: &[AlgoDecision]) -> crate::error::Result<&AlgoDecision> {
        rows.first().ok_or_else(|| DbError::Io(std::io::Error::other("expected one decision")))
    }

    fn sample_input(project_id: i64, year: i64, month: i64) -> AlgoDecisionInput<'static> {
        AlgoDecisionInput {
            project_id,
            problem_class: "sort",
            chosen: "pdqsort",
            rejected: r#"[{"name":"quicksort","reason":"unstable worst case"}]"#,
            rationale: "pdqsort blends insertion sort + heapsort fallback",
            time_complexity: "O(n log n)",
            space_complexity: "O(log n)",
            year_published: 2021,
            search_year: year,
            search_month: month,
            benchmark_source: Some("https://crates.io/crates/pdqselect"),
            simd_capable: false,
            parallel_safe: true,
            file_path: "src/sort.rs",
            turn: 1,
        }
    }

    fn insert_project(conn: &rusqlite::Connection) -> crate::error::Result<i64> {
        conn.execute(
            "INSERT INTO projects (slug, display) VALUES ('test', 'Test Project')",
            [],
        )?;
        Ok(conn.last_insert_rowid())
    }

    #[test]
    fn test_upsert_and_list_recent() -> crate::error::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let pid = insert_project(&conn)?;
        let year = current_year()?;
        upsert(&conn, &sample_input(pid, year, 3))?;
        let rows = list_recent(&conn, pid, 10)?;
        assert_eq!(rows.len(), 1);
        let d = first_or_err(&rows)?;
        assert_eq!(d.chosen, "pdqsort");
        Ok(())
    }

    #[test]
    fn test_upsert_idempotent() -> crate::error::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let pid = insert_project(&conn)?;
        let year = current_year()?;
        upsert(&conn, &sample_input(pid, year, 3))?;
        upsert(&conn, &sample_input(pid, year, 4))?;
        let rows = list_recent(&conn, pid, 10)?;
        assert_eq!(rows.len(), 1);
        let d = first_or_err(&rows)?;
        assert_eq!(d.search_month, 4);
        Ok(())
    }

    #[test]
    fn test_stale_detection() -> crate::error::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let pid = insert_project(&conn)?;
        upsert(&conn, &sample_input(pid, 2020, 1))?;
        let stale = list_stale(&conn, pid)?;
        assert_eq!(stale.len(), 1);
        let recent = list_recent(&conn, pid, 10)?;
        assert_eq!(recent.len(), 0);
        Ok(())
    }

    #[test]
    fn test_list_recent_empty() -> crate::error::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let rows = list_recent(&conn, 99, 10)?;
        assert!(rows.is_empty());
        Ok(())
    }
}
