/// Shared utilities for graph population passes.
///
/// FNV-1a hash: deterministic across processes, unlike DefaultHasher (random seed).
/// Used for content_hash dedup — cross-session identical bodies share one entity node.

/// Returns true if `haystack` contains `needle`.
#[inline]
pub(crate) fn has_substr(haystack: &str, needle: &str) -> bool {
    haystack.find(needle).is_some()
}

/// Deterministic FNV-1a hash of a single string — stable across processes.
pub(crate) fn short_hash(s: &str) -> String {
    const FNV_OFFSET: u64 = 14_695_981_039_346_656_037;
    const FNV_PRIME: u64 = 1_099_511_628_211;
    let mut hash = FNV_OFFSET;
    for byte in s.bytes() {
        hash ^= u64::from(byte);
        hash = hash.wrapping_mul(FNV_PRIME);
    }
    format!("{hash:016x}")
}

/// Stable deterministic content hash using FNV-1a.
pub(crate) fn content_hash(title: &str, content: &str) -> String {
    const FNV_OFFSET: u64 = 14_695_981_039_346_656_037;
    const FNV_PRIME: u64 = 1_099_511_628_211;
    let mut hash = FNV_OFFSET;
    for byte in title.bytes().chain(std::iter::once(b'\n')).chain(content.bytes()) {
        hash ^= u64::from(byte);
        hash = hash.wrapping_mul(FNV_PRIME);
    }
    format!("{hash:016x}")
}

/// Extract significant keywords (>= 4 chars, alphanumeric) from a title.
pub(crate) fn keywords_from(title: &str) -> impl Iterator<Item = String> + '_ {
    title
        .split(|c: char| !c.is_alphanumeric())
        .filter(|w| w.len() >= 4)
        .map(|w| w.to_lowercase())
}

/// Collect gate keywords mentioned in key or content.
pub(crate) fn collect_gates_in<'a>(
    gate_keywords: &[&'a str],
    key: &str,
    content: &str,
) -> Vec<&'a str> {
    gate_keywords
        .iter()
        .copied()
        .filter(|g| has_substr(key, g) || has_substr(content, g))
        .collect()
}

/// Collect gate keywords mentioned in key only.
pub(crate) fn collect_gates_in_key<'a>(gate_keywords: &[&'a str], key: &str) -> Vec<&'a str> {
    gate_keywords
        .iter()
        .copied()
        .filter(|g| has_substr(key, g))
        .collect()
}

/// Extract a JSON string field value: `"<key>":"<value>"` → `Some(value)`.
pub(crate) fn extract_json_field(json: &str, key: &str) -> Option<String> {
    let needle = format!(r#""{key}":""#);
    let start = json.find(needle.as_str())?.saturating_add(needle.len());
    let rest = json.get(start..)?;
    let end = rest.find('"')?;
    rest.get(..end).map(str::to_string)
}

/// Collect all rows from a SQL query into a Vec<T>.
pub(crate) fn collect_rows<T, F>(
    conn: &rusqlite::Connection,
    sql: &str,
    f: F,
) -> crate::error::Result<Vec<T>>
where
    F: Fn(&rusqlite::Row<'_>) -> rusqlite::Result<T>,
{
    let mut stmt = conn.prepare(sql)?;
    let rows: rusqlite::Result<Vec<T>> = stmt.query_map([], f)?.collect();
    Ok(rows?)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_hash_deterministically() {
        assert_eq!(content_hash("t", "b"), content_hash("t", "b"));
    }

    #[test]
    fn should_differ_for_different_content() {
        assert_ne!(content_hash("a", "x"), content_hash("b", "y"));
    }

    #[test]
    fn should_extract_keywords_min_4_chars() {
        let kws: Vec<String> = keywords_from("stop gate v2 fix").collect();
        assert!(kws.iter().any(|k| k == "stop"));
        assert!(!kws.iter().any(|k| k == "v2"));
    }

    #[test]
    fn should_extract_json_string_field() {
        assert_eq!(
            extract_json_field(r#"{"id":"foo","x":1}"#, "id"),
            Some("foo".to_string())
        );
    }
}
