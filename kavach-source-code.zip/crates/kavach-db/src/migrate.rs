/// Schema creation and version tracking.
use crate::error::Result;
use rusqlite::Connection;

const CURRENT_VERSION: i64 = 9;

/// Runs all pending migrations. Safe to call on every startup.
///
/// Each migration runs inside a SAVEPOINT so schema changes and version
/// bumps commit atomically. A half-applied migration (schema partially
/// created, version still old) can never leave the database in a state
/// where the version says "N" but the tables for N don't exist.
pub fn run_migrations(conn: &Connection) -> Result<()> {
    create_version_table(conn)?;
    let version = get_version(conn)?;
    if version < 1 {
        run_step(conn, "v1", 1, migrate_v1)?;
    }
    if version < 2 {
        run_step(conn, "v2", 2, migrate_v2)?;
    }
    if version < 3 {
        run_step(conn, "v3", 3, migrate_v3)?;
    }
    if version < 4 {
        run_step(conn, "v4", 4, migrate_v4)?;
    }
    if version < 5 {
        run_step(conn, "v5", 5, migrate_v5)?;
    }
    if version < 6 {
        run_step(conn, "v6", 6, migrate_v6)?;
    }
    if version < 7 {
        run_step(conn, "v7", 7, migrate_v7)?;
    }
    if version < 8 {
        run_step(conn, "v8", 8, migrate_v8)?;
    }
    if version < 9 {
        run_step(conn, "v9", 9, migrate_v9)?;
    }
    Ok(())
}

fn run_step(
    conn: &Connection,
    name: &str,
    version: i64,
    step: fn(&Connection) -> Result<()>,
) -> Result<()> {
    conn.execute_batch(&format!("SAVEPOINT mig_{name};"))?;
    let outcome = step(conn).and_then(|()| set_version(conn, version));
    match outcome {
        Ok(()) => {
            conn.execute_batch(&format!("RELEASE mig_{name};"))?;
            Ok(())
        }
        Err(e) => {
            let _ = conn.execute_batch(&format!("ROLLBACK TO mig_{name}; RELEASE mig_{name};"));
            Err(e)
        }
    }
}

fn create_version_table(conn: &Connection) -> Result<()> {
    conn.execute_batch(
        "CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER NOT NULL
        );",
    )?;
    Ok(())
}

fn get_version(conn: &Connection) -> Result<i64> {
    let count: i64 = conn.query_row(
        "SELECT COUNT(*) FROM schema_version",
        [],
        |r| r.get(0),
    )?;
    if count == 0 {
        return Ok(0);
    }
    let ver: i64 = conn.query_row(
        "SELECT version FROM schema_version ORDER BY version DESC LIMIT 1",
        [],
        |r| r.get(0),
    )?;
    Ok(ver)
}

fn set_version(conn: &Connection, version: i64) -> Result<()> {
    conn.execute("DELETE FROM schema_version", [])?;
    conn.execute(
        "INSERT INTO schema_version (version) VALUES (?1)",
        [version],
    )?;
    Ok(())
}

/// Returns the current schema version.
pub fn current_version(conn: &Connection) -> Result<i64> {
    create_version_table(conn)?;
    get_version(conn)
}

/// Returns the target schema version.
pub fn target_version() -> i64 {
    CURRENT_VERSION
}

/// Report a single foreign key violation produced by `PRAGMA foreign_key_check`.
/// Columns (per SQLite docs): table, rowid, parent, fkid.
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub struct FkViolation {
    pub child_table: String,
    pub child_rowid: i64,
    pub parent_table: String,
    pub fk_index: i64,
}

/// Run `PRAGMA foreign_key_check` and return every orphan row.
/// Empty Vec = clean database. Uses `.get()` + `?` throughout — no unwrap.
pub fn foreign_key_check(conn: &Connection) -> Result<Vec<FkViolation>> {
    let mut stmt = conn.prepare("PRAGMA foreign_key_check")?;
    let rows = stmt.query_map([], |row| {
        Ok(FkViolation {
            child_table: row.get(0)?,
            child_rowid: row.get(1)?,
            parent_table: row.get(2)?,
            fk_index: row.get(3)?,
        })
    })?;
    let mut out = Vec::new();
    for r in rows {
        out.push(r?);
    }
    Ok(out)
}

fn migrate_v1(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v1.sql"))?;
    Ok(())
}

fn migrate_v2(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v2.sql"))?;
    Ok(())
}

fn migrate_v3(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v3.sql"))?;
    Ok(())
}

fn migrate_v4(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v4.sql"))?;
    Ok(())
}

fn migrate_v5(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v5.sql"))?;
    Ok(())
}

fn migrate_v6(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v6.sql"))?;
    Ok(())
}

fn migrate_v7(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v7.sql"))?;
    Ok(())
}

fn migrate_v8(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v8.sql"))?;
    Ok(())
}

fn migrate_v9(conn: &Connection) -> Result<()> {
    conn.execute_batch(include_str!("schema_v9.sql"))?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::connection::open_memory;

    #[test]
    fn test_migration_idempotent() -> Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        run_migrations(&conn)?;
        assert_eq!(current_version(&conn)?, 9);
        Ok(())
    }

    #[test]
    fn test_target_version() {
        assert_eq!(target_version(), 9);
    }

    #[test]
    fn test_fresh_migration_has_no_fk_violations() -> Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let violations = foreign_key_check(&conn)?;
        assert!(
            violations.is_empty(),
            "fresh migrated DB has FK violations: {violations:?}"
        );
        Ok(())
    }

    #[test]
    fn test_fk_check_empty_for_empty_db() -> Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let violations = foreign_key_check(&conn)?;
        assert_eq!(violations.len(), 0);
        Ok(())
    }
}
