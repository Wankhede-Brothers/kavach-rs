/// CRUD operations for the sessions table.
use crate::error::{DbError, Result};
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct Session {
    pub id: String,
    pub project_id: i64,
    pub model_id: Option<String>,
    pub started_at: String,
    pub ended_at: Option<String>,
    pub turn_count: i64,
    pub compact_count: i64,
    pub context_phase: String,
    pub token_budget_total: i64,
    pub token_budget_used: i64,
}

pub fn create(conn: &Connection, id: &str, project_id: i64) -> Result<()> {
    conn.execute(
        "INSERT INTO sessions (id, project_id) VALUES (?1, ?2)",
        params![id, project_id],
    )?;
    Ok(())
}

pub fn get(conn: &Connection, id: &str) -> Result<Session> {
    conn.query_row(
        "SELECT id, project_id, model_id, started_at, ended_at,
                turn_count, compact_count, context_phase,
                token_budget_total, token_budget_used
         FROM sessions WHERE id = ?1",
        params![id],
        row_to_session,
    )
    .map_err(|e| match e {
        rusqlite::Error::QueryReturnedNoRows => DbError::SessionNotFound {
            id: id.to_string(),
        },
        other => DbError::Sqlite(other),
    })
}

pub fn end_session(conn: &Connection, id: &str) -> Result<()> {
    conn.execute(
        "UPDATE sessions SET ended_at = datetime('now') WHERE id = ?1",
        params![id],
    )?;
    Ok(())
}

pub fn increment_turn(conn: &Connection, id: &str) -> Result<()> {
    conn.execute(
        "UPDATE sessions SET turn_count = turn_count + 1 WHERE id = ?1",
        params![id],
    )?;
    Ok(())
}

pub fn set_model(conn: &Connection, id: &str, model_id: &str) -> Result<()> {
    conn.execute(
        "UPDATE sessions SET model_id = ?2 WHERE id = ?1",
        params![id, model_id],
    )?;
    Ok(())
}

pub fn update_phase(
    conn: &Connection,
    id: &str,
    phase: &str,
    used: i64,
) -> Result<()> {
    conn.execute(
        "UPDATE sessions SET context_phase = ?2, token_budget_used = ?3
         WHERE id = ?1",
        params![id, phase, used],
    )?;
    Ok(())
}

pub fn list_by_project(conn: &Connection, project_id: i64) -> Result<Vec<Session>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, model_id, started_at, ended_at,
                turn_count, compact_count, context_phase,
                token_budget_total, token_budget_used
         FROM sessions WHERE project_id = ?1
         ORDER BY started_at DESC",
    )?;
    let rows = stmt.query_map(params![project_id], row_to_session)?;
    let mut sessions = Vec::new();
    for row in rows {
        sessions.push(row?);
    }
    Ok(sessions)
}

fn row_to_session(row: &rusqlite::Row) -> rusqlite::Result<Session> {
    Ok(Session {
        id: row.get(0)?,
        project_id: row.get(1)?,
        model_id: row.get(2)?,
        started_at: row.get(3)?,
        ended_at: row.get(4)?,
        turn_count: row.get(5)?,
        compact_count: row.get(6)?,
        context_phase: row.get(7)?,
        token_budget_total: row.get(8)?,
        token_budget_used: row.get(9)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations, projects};

    fn setup() -> Connection {
        let conn = open_memory().expect("open");
        run_migrations(&conn).expect("migrate");
        projects::insert(&conn, "test", "Test").expect("project");
        conn
    }

    #[test]
    fn test_create_and_get() {
        let conn = setup();
        let p = projects::get_by_slug(&conn, "test").expect("project");
        create(&conn, "sess_abc", p.id).expect("create");
        let s = get(&conn, "sess_abc").expect("get");
        assert_eq!(s.project_id, p.id);
        assert_eq!(s.turn_count, 0);
        assert_eq!(s.context_phase, "early");
    }

    #[test]
    fn test_increment_turn() {
        let conn = setup();
        let p = projects::get_by_slug(&conn, "test").expect("project");
        create(&conn, "sess_t", p.id).expect("create");
        increment_turn(&conn, "sess_t").expect("inc");
        increment_turn(&conn, "sess_t").expect("inc2");
        let s = get(&conn, "sess_t").expect("get");
        assert_eq!(s.turn_count, 2);
    }
}
