//! Vectorless, reasoning-based RAG index for kavach gates.
//!
//! Replaces static skill-priority tables with a hierarchical tree whose nodes
//! carry summaries and keyword hints. Hook hot paths traverse the tree via
//! pure-Rust scoring — no embeddings, no LLM, no network calls at runtime.

pub mod error;
pub mod matcher;
pub mod node;
pub mod protocol;
pub mod query;
pub mod scanner;
pub mod score;
pub mod tree;
pub mod walker;
pub mod graph_boost;

pub use error::RagError;
pub use matcher::{MatchResult, Matcher};
pub use node::{NodeId, TreeNode};
pub use protocol::{apply_summaries, pending_requests, SummaryRequest, SummaryResponse};
pub use query::Query;
pub use scanner::{scan_dir, ScannedDoc};
pub use score::Score;
pub use tree::RagTree;
pub use walker::{build_trees_from_dir, from_markdown};
pub use graph_boost::{compute_graph_boost, compute_graph_boosts};

#[cfg(test)]
#[path = "tests.rs"]
mod tests;
