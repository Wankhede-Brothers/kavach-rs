use std::collections::HashMap;

use super::node::{NodeId, TreeNode};
use super::query::Query;
use super::score::{score_node, score_node_with_boost, Score};
use super::tree::RagTree;

/// Pure-Rust tree traversal matcher. Walks the tree depth-first, scores each
/// node, and returns the top-k matches sorted by score descending. No LLM,
/// no network, no embeddings — suitable for hook hot paths.
pub struct Matcher<'a> {
    tree: &'a RagTree,
    top_k: usize,
    graph_boosts: Option<HashMap<String, u32>>,
}

/// A single match result: node id, title (for user-facing messages), and
/// computed score so gates can threshold / rank.
#[derive(Debug, Clone)]
pub struct MatchResult {
    pub node_id: NodeId,
    pub title: String,
    pub score: Score,
}

impl<'a> Matcher<'a> {
    pub fn new(tree: &'a RagTree) -> Self {
        Self { tree, top_k: 5, graph_boosts: None }
    }

    pub fn with_top_k(mut self, top_k: usize) -> Self {
        self.top_k = top_k.max(1);
        self
    }

    /// Attach pre-computed graph boosts (skill_name → boost_weight).
    /// Built via `rag::graph_boost::compute_graph_boosts`.
    pub fn with_graph_boosts(mut self, boosts: HashMap<String, u32>) -> Self {
        self.graph_boosts = Some(boosts);
        self
    }

    pub fn run(&self, query: &Query) -> Vec<MatchResult> {
        let mut hits: Vec<MatchResult> = Vec::new();
        walk(&self.tree.root, query, &self.graph_boosts, &mut hits);
        hits.sort_by(|a, b| b.score.cmp(&a.score));
        hits.truncate(self.top_k);
        hits
    }
}

fn walk(
    node: &TreeNode,
    query: &Query,
    boosts: &Option<HashMap<String, u32>>,
    out: &mut Vec<MatchResult>,
) {
    let score = match boosts {
        Some(map) => {
            let skill_name = extract_skill_name(&node.id);
            let boost = match map.get(skill_name) {
                Some(&b) => b,
                None => 0,
            };
            score_node_with_boost(node, query, boost)
        }
        None => score_node(node, query),
    };
    if score.is_nonzero() {
        out.push(MatchResult {
            node_id: node.id.clone(),
            title: node.title.clone(),
            score,
        });
    }
    for child in &node.children {
        walk(child, query, boosts, out);
    }
}

/// Extract skill name from node id like "skills/rust/SKILL.md" → "rust"
fn extract_skill_name(node_id: &str) -> &str {
    let stripped = node_id.trim_end_matches("/SKILL.md");
    match stripped.rsplit('/').next() {
        Some(name) if !name.is_empty() => name,
        Some(_) | None => node_id,
    }
}
