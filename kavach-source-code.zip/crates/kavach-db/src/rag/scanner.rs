use std::fs;
use std::io;
use std::path::{Path, PathBuf};

/// A single discovered source document: stable id (used as the tree root id)
/// and full textual body. Ids are derived from the path relative to the scan
/// root so emitted trees remain portable across machines.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ScannedDoc {
    id: String,
    path: PathBuf,
    body: String,
}

impl ScannedDoc {
    pub fn id(&self) -> &str {
        &self.id
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn body(&self) -> &str {
        &self.body
    }
}

/// Recursively scan `root` and return every file whose extension is in
/// `allowed_exts` (lowercased, without leading dot). Symlinks and hidden
/// directories (leading `.`) are skipped so the scan never follows build
/// caches, `.git`, or backup trees.
pub fn scan_dir(root: &Path, allowed_exts: &[&str]) -> io::Result<Vec<ScannedDoc>> {
    let mut out: Vec<ScannedDoc> = Vec::new();
    if !root.exists() {
        return Ok(out);
    }
    let canonical = fs::canonicalize(root)?;
    walk(&canonical, &canonical, allowed_exts, &mut out)?;
    out.sort_by(|a, b| a.id.cmp(&b.id));
    Ok(out)
}

fn walk(
    root: &Path,
    dir: &Path,
    allowed_exts: &[&str],
    out: &mut Vec<ScannedDoc>,
) -> io::Result<()> {
    let entries = fs::read_dir(dir)?;
    for entry in entries {
        let entry = entry?;
        let file_type = entry.file_type()?;
        if file_type.is_symlink() {
            continue;
        }
        let name = entry.file_name();
        let name_str = name.to_string_lossy();
        if name_str.starts_with('.') {
            continue;
        }
        let path = entry.path();
        if file_type.is_dir() {
            walk(root, &path, allowed_exts, out)?;
            continue;
        }
        if !file_type.is_file() {
            continue;
        }
        if !has_allowed_ext(&path, allowed_exts) {
            continue;
        }
        let body = match fs::read_to_string(&path) {
            Ok(b) => b,
            Err(_) => continue,
        };
        let id = relative_id(root, &path);
        out.push(ScannedDoc { id, path, body });
    }
    Ok(())
}

fn has_allowed_ext(path: &Path, allowed: &[&str]) -> bool {
    let ext = match path.extension().and_then(|e| e.to_str()) {
        Some(e) => e.to_lowercase(),
        None => return false,
    };
    allowed.iter().any(|a| *a == ext)
}

fn relative_id(root: &Path, path: &Path) -> String {
    match path.strip_prefix(root) {
        Ok(rel) => rel.to_string_lossy().replace('\\', "/"),
        Err(_) => path.to_string_lossy().to_string(),
    }
}
