/// Graph-boosted RAG scoring — the bridge connecting graph edges to RAG retrieval.
///
/// Queries the graph for edge count of a skill entity, returning a boost weight.
/// Skills with more project/gate/session edges rank higher in RAG results.
/// This closes the trilogy: DB → Graph → RAG → DB (feedback loop).
// ALGO: SingleSqlEdgeCount
// PROBLEM_CLASS: graph_traversal
// REJECTED: [{"name":"N+1_SQL_COUNT","reason":"O(n) round-trips per matcher walk"},{"name":"InMemoryDegreeMap","reason":"cache invalidation complexity for <500 edges"}]
// TIME: O(1) per skill (indexed COUNT) | SPACE: O(1)
// YEAR: 1970 (SQL COUNT aggregate) | SEARCHED: 2026-04
// TRADEOFF: one SQL round-trip per skill — use batch compute_graph_boosts for hot paths
// BENCHMARK: https://docs.rs/rusqlite/latest/rusqlite/
use rusqlite::Connection;

const WEIGHT_GRAPH_BOOST: u32 = 30;
const MAX_EDGE_MULTIPLIER: u32 = 3;

/// Compute graph boost for a skill name by counting its outgoing edges.
/// Returns 0 if the skill has no graph presence or on any DB error.
/// Capped at WEIGHT_GRAPH_BOOST * MAX_EDGE_MULTIPLIER to prevent runaway scores.
pub fn compute_graph_boost(conn: &Connection, skill_name: &str) -> u32 {
    match compute_graph_boost_inner(conn, skill_name) {
        Some(boost) => boost,
        None => 0,
    }
}

fn compute_graph_boost_inner(conn: &Connection, skill_name: &str) -> Option<u32> {
    let entity_id: i64 = match conn.query_row(
        "SELECT id FROM entities WHERE entity_type = 'skill' AND name = ?1",
        [skill_name],
        |r| r.get(0),
    ) {
        Ok(id) => id,
        Err(_) => return None,
    };

    let raw_count: i64 = match conn.query_row(
        "SELECT COUNT(*) FROM relationships WHERE from_id = ?1 OR to_id = ?1",
        [entity_id],
        |r| r.get(0),
    ) {
        Ok(c) => c,
        Err(_) => return None,
    };

    let edge_count = match u32::try_from(raw_count) {
        Ok(c) => c,
        Err(_) => return None,
    };

    let clamped = edge_count.min(MAX_EDGE_MULTIPLIER);
    Some(clamped.saturating_mul(WEIGHT_GRAPH_BOOST))
}

/// Batch-compute graph boosts for multiple skill names.
/// Returns a Vec of (skill_name, boost) pairs — callers build a HashMap.
pub fn compute_graph_boosts(conn: &Connection, skill_names: &[&str]) -> Vec<(String, u32)> {
    skill_names
        .iter()
        .map(|name| ((*name).to_string(), compute_graph_boost(conn, name)))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{open_memory, run_migrations};
    use crate::graph_entity::upsert_entity;
    use crate::graph::add_relationship;

    #[test]
    fn should_return_zero_for_unknown_skill() -> crate::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        assert_eq!(compute_graph_boost(&conn, "nonexistent"), 0);
        Ok(())
    }

    #[test]
    fn should_boost_skill_with_edges() -> crate::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let skill_id = upsert_entity(&conn, "skill", "evidence-chain", None)?;
        let gate_id = upsert_entity(&conn, "gate", "pre_write", None)?;
        add_relationship(&conn, skill_id, gate_id, "applies_to_gate", 1.0)?;
        let boost = compute_graph_boost(&conn, "evidence-chain");
        assert_eq!(boost, 30);
        Ok(())
    }

    #[test]
    fn should_cap_at_max_multiplier() -> crate::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let skill_id = upsert_entity(&conn, "skill", "cap_test_skill", None)?;
        for i in 0..5 {
            let target = upsert_entity(&conn, "gate", &format!("cap_gate_{i}"), None)?;
            add_relationship(&conn, skill_id, target, "applies_to_gate", 1.0)?;
        }
        let boost = compute_graph_boost(&conn, "cap_test_skill");
        assert_eq!(boost, 90); // capped at 3 * 30
        Ok(())
    }

    #[test]
    fn should_batch_compute() -> crate::Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        upsert_entity(&conn, "skill", "arch", None)?;
        let boosts = compute_graph_boosts(&conn, &["arch", "missing"]);
        assert_eq!(boosts.len(), 2);
        assert_eq!(boosts.get(1).map(|(_, b)| *b), Some(0));
        Ok(())
    }
}
