use serde::{Deserialize, Serialize};

use super::error::RagError;
use super::node::TreeNode;

/// Root container for a persisted RAG tree.
///
/// Built offline by `kavach rag build` (Phase B), consumed at runtime by
/// `Matcher`. The `version` field lets us evolve the schema without breaking
/// previously-built trees.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RagTree {
    pub version: u32,
    pub source: String,
    pub root: TreeNode,
}

impl RagTree {
    pub const CURRENT_VERSION: u32 = 1;

    pub fn new(source: impl Into<String>, root: TreeNode) -> Self {
        Self {
            version: Self::CURRENT_VERSION,
            source: source.into(),
            root,
        }
    }

    pub fn from_json(json: &str) -> Result<Self, RagError> {
        let tree: Self = serde_json::from_str(json)?;
        tree.validate()?;
        Ok(tree)
    }

    pub fn to_json(&self) -> Result<String, RagError> {
        serde_json::to_string(self).map_err(RagError::from)
    }

    pub fn to_json_pretty(&self) -> Result<String, RagError> {
        serde_json::to_string_pretty(self).map_err(RagError::from)
    }

    /// Reject trees with schema drift or unsupported versions early so runtime
    /// gates never see malformed state.
    pub fn validate(&self) -> Result<(), RagError> {
        if self.version != Self::CURRENT_VERSION {
            return Err(RagError::Invalid(format!(
                "unsupported version {}, expected {}",
                self.version,
                Self::CURRENT_VERSION
            )));
        }
        if self.root.id.is_empty() {
            return Err(RagError::Invalid("root node has empty id".into()));
        }
        Ok(())
    }

    pub fn find(&self, id: &str) -> Result<&TreeNode, RagError> {
        match walk(&self.root, id) {
            Some(node) => Ok(node),
            None => Err(RagError::NodeNotFound(id.into())),
        }
    }
}

fn walk<'a>(node: &'a TreeNode, id: &str) -> Option<&'a TreeNode> {
    if node.id == id {
        return Some(node);
    }
    for child in &node.children {
        if let Some(hit) = walk(child, id) {
            return Some(hit);
        }
    }
    None
}
