//! Architecture decision CRUD operations.

use crate::error::Result;
use rusqlite::{Connection, Row};

use super::types::{ArchDecision, ArchDecisionInput};

/// Upsert an architecture decision.
pub fn upsert(conn: &Connection, input: &ArchDecisionInput<'_>) -> Result<i64> {
    conn.execute(
        "INSERT INTO architecture_decisions (
            project_id, pattern, scope, cap_choice, qps_estimate,
            peak_multiplier, storage_estimate, failure_mode, tradeoff,
            search_year, search_month, reference_url, file_path, turn
        ) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14)
        ON CONFLICT(project_id, pattern, file_path) DO UPDATE SET
            scope            = excluded.scope,
            cap_choice       = excluded.cap_choice,
            qps_estimate     = excluded.qps_estimate,
            peak_multiplier  = excluded.peak_multiplier,
            storage_estimate = excluded.storage_estimate,
            failure_mode     = excluded.failure_mode,
            tradeoff         = excluded.tradeoff,
            search_year      = excluded.search_year,
            search_month     = excluded.search_month,
            reference_url    = excluded.reference_url,
            turn             = excluded.turn,
            created_at       = strftime('%Y-%m-%dT%H:%M:%SZ','now')",
        rusqlite::params![
            input.project_id,
            input.pattern,
            input.scope,
            input.cap_choice,
            input.qps_estimate,
            input.peak_multiplier,
            input.storage_estimate,
            input.failure_mode,
            input.tradeoff,
            input.search_year,
            input.search_month,
            input.reference_url,
            input.file_path,
            input.turn,
        ],
    )?;
    Ok(conn.last_insert_rowid())
}

/// List recent decisions for a project, ordered freshest first.
pub fn list_recent(conn: &Connection, project_id: i64, limit: i64) -> Result<Vec<ArchDecision>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, pattern, scope, cap_choice, qps_estimate,
                peak_multiplier, storage_estimate, failure_mode, tradeoff,
                search_year, search_month, reference_url, file_path, turn, created_at
         FROM architecture_decisions
         WHERE project_id = ?1
           AND (CAST(strftime('%Y','now') AS INTEGER) - search_year) <= 1
         ORDER BY search_year DESC, search_month DESC
         LIMIT ?2",
    )?;
    collect_rows(&mut stmt, rusqlite::params![project_id, limit])
}

fn row_to_decision(row: &Row<'_>) -> rusqlite::Result<ArchDecision> {
    Ok(ArchDecision {
        id:               row.get("id")?,
        project_id:       row.get("project_id")?,
        pattern:          row.get("pattern")?,
        scope:            row.get("scope")?,
        cap_choice:       row.get("cap_choice")?,
        qps_estimate:     row.get("qps_estimate")?,
        peak_multiplier:  row.get("peak_multiplier")?,
        storage_estimate: row.get("storage_estimate")?,
        failure_mode:     row.get("failure_mode")?,
        tradeoff:         row.get("tradeoff")?,
        search_year:      row.get("search_year")?,
        search_month:     row.get("search_month")?,
        reference_url:    row.get("reference_url")?,
        file_path:        row.get("file_path")?,
        turn:             row.get("turn")?,
        created_at:       row.get("created_at")?,
    })
}

fn collect_rows(
    stmt: &mut rusqlite::Statement<'_>,
    params: impl rusqlite::Params,
) -> Result<Vec<ArchDecision>> {
    let iter = stmt.query_map(params, row_to_decision)?;
    let mut out = Vec::new();
    for item in iter {
        out.push(item?);
    }
    Ok(out)
}
