//! Architecture decision types.

/// A persisted architecture decision.
#[derive(Debug, Clone)]
pub struct ArchDecision {
    pub id: i64,
    pub project_id: i64,
    pub pattern: String,
    pub scope: String,
    pub cap_choice: Option<String>,
    pub qps_estimate: Option<String>,
    pub peak_multiplier: Option<f64>,
    pub storage_estimate: Option<String>,
    pub failure_mode: String,
    pub tradeoff: String,
    pub search_year: i64,
    pub search_month: i64,
    pub reference_url: Option<String>,
    pub file_path: String,
    pub turn: i64,
    pub created_at: String,
}

/// Input for inserting or updating an architecture decision.
#[derive(Debug, Clone)]
pub struct ArchDecisionInput<'a> {
    pub project_id: i64,
    pub pattern: &'a str,
    pub scope: &'a str,
    pub cap_choice: Option<&'a str>,
    pub qps_estimate: Option<&'a str>,
    pub peak_multiplier: Option<f64>,
    pub storage_estimate: Option<&'a str>,
    pub failure_mode: &'a str,
    pub tradeoff: &'a str,
    pub search_year: i64,
    pub search_month: i64,
    pub reference_url: Option<&'a str>,
    pub file_path: &'a str,
    pub turn: i64,
}
