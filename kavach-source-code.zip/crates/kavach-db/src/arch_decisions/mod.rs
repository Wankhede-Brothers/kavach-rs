//! Architecture decision store — upsert, query, and stale-detection.

mod crud;
mod types;

pub use crud::{list_recent, upsert};
pub use types::{ArchDecision, ArchDecisionInput};

#[cfg(test)]
mod tests;
