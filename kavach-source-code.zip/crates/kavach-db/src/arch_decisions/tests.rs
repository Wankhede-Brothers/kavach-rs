//! Tests for architecture decisions.

use super::*;
use crate::connection::open_memory;
use crate::error::Result;
use crate::migrate::run_migrations;

/// Seconds per year (approximate).
const SECS_PER_YEAR: u64 = 31_557_600;
/// Unix epoch year.
const EPOCH_YEAR: i64 = 1970;

fn insert_project(conn: &rusqlite::Connection) -> Result<i64> {
    conn.execute(
        "INSERT INTO projects (slug, display) VALUES ('test', 'Test')",
        [],
    )?;
    Ok(conn.last_insert_rowid())
}

fn current_year() -> Result<i64> {
    use std::time::{SystemTime, UNIX_EPOCH};
    let duration = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| crate::error::DbError::Io(std::io::Error::other(e.to_string())))?;
    let years = i64::try_from(duration.as_secs() / SECS_PER_YEAR)
        .map_err(|e| crate::error::DbError::Io(std::io::Error::other(e.to_string())))?;
    Ok(EPOCH_YEAR + years)
}

fn sample_input(pid: i64, year: i64) -> ArchDecisionInput<'static> {
    ArchDecisionInput {
        project_id: pid,
        pattern: "distributed_cache",
        scope: "cache",
        cap_choice: Some("AP"),
        qps_estimate: Some("10000"),
        peak_multiplier: Some(3.0),
        storage_estimate: Some("10GB"),
        failure_mode: "stale reads",
        tradeoff: "consistency",
        search_year: year,
        search_month: 4,
        reference_url: Some("https://example.com"),
        file_path: "src/cache.rs",
        turn: 1,
    }
}

#[test]
fn test_upsert_and_list() -> Result<()> {
    let conn = open_memory()?;
    run_migrations(&conn)?;
    let pid = insert_project(&conn)?;
    let year = current_year()?;
    upsert(&conn, &sample_input(pid, year))?;
    let rows = list_recent(&conn, pid, 10)?;
    assert_eq!(rows.len(), 1);
    let first = rows.first().ok_or(crate::error::DbError::EntityNotFound {
        name: "arch_decision".into()
    })?;
    assert_eq!(first.pattern, "distributed_cache");
    Ok(())
}

#[test]
fn test_upsert_idempotent() -> Result<()> {
    let conn = open_memory()?;
    run_migrations(&conn)?;
    let pid = insert_project(&conn)?;
    let year = current_year()?;
    upsert(&conn, &sample_input(pid, year))?;
    upsert(&conn, &sample_input(pid, year))?;
    let rows = list_recent(&conn, pid, 10)?;
    assert_eq!(rows.len(), 1);
    Ok(())
}
