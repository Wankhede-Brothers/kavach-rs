/// CRUD for project_parts: sub-components within a project (backend, frontend, etc.).
use crate::error::Result;
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct ProjectPart {
    pub id: i64,
    pub project_id: i64,
    pub part_name: String,
    pub part_path: String,
    pub part_type: String,
    pub stack: Option<String>,
    pub description: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

/// Register a sub-part for a project. Upserts on (project_id, part_name).
pub fn upsert(
    conn: &Connection,
    project_id: i64,
    part_name: &str,
    part_path: &str,
    part_type: &str,
    stack: Option<&str>,
    description: Option<&str>,
) -> Result<i64> {
    conn.execute(
        "INSERT INTO project_parts (project_id, part_name, part_path, part_type, stack, description)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)
         ON CONFLICT(project_id, part_name) DO UPDATE SET
            part_path = excluded.part_path,
            part_type = excluded.part_type,
            stack = COALESCE(excluded.stack, project_parts.stack),
            description = COALESCE(excluded.description, project_parts.description),
            updated_at = datetime('now')",
        params![project_id, part_name, part_path, part_type, stack, description],
    )?;
    Ok(conn.last_insert_rowid())
}

/// List all parts for a project.
pub fn list_by_project(conn: &Connection, project_id: i64) -> Result<Vec<ProjectPart>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, part_name, part_path, part_type, stack, description,
                created_at, updated_at
         FROM project_parts WHERE project_id = ?1 ORDER BY part_name",
    )?;
    let rows = stmt.query_map(params![project_id], row_to_part)?;
    let mut parts = Vec::new();
    for row in rows {
        parts.push(row?);
    }
    Ok(parts)
}

/// Find the most specific part matching a file path (longest path prefix match).
pub fn find_by_path(conn: &Connection, file_path: &str) -> Result<Option<ProjectPart>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, part_name, part_path, part_type, stack, description,
                created_at, updated_at
         FROM project_parts ORDER BY LENGTH(part_path) DESC",
    )?;
    let rows = stmt.query_map([], row_to_part)?;
    for row in rows {
        let part = row?;
        if file_path.starts_with(&part.part_path) {
            return Ok(Some(part));
        }
    }
    Ok(None)
}

/// Delete a part by project_id and part_name.
pub fn delete(conn: &Connection, project_id: i64, part_name: &str) -> Result<bool> {
    let count = conn.execute(
        "DELETE FROM project_parts WHERE project_id = ?1 AND part_name = ?2",
        params![project_id, part_name],
    )?;
    Ok(count > 0)
}

fn row_to_part(row: &rusqlite::Row) -> rusqlite::Result<ProjectPart> {
    Ok(ProjectPart {
        id: row.get(0)?,
        project_id: row.get(1)?,
        part_name: row.get(2)?,
        part_path: row.get(3)?,
        part_type: row.get(4)?,
        stack: row.get(5)?,
        description: row.get(6)?,
        created_at: row.get(7)?,
        updated_at: row.get(8)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations, projects};

    fn setup() -> Connection {
        let conn = open_memory().expect("open");
        run_migrations(&conn).expect("migrate");
        projects::insert_full(&conn, "nc", "NC", Some("/abs/nc"), None, None, None)
            .expect("project");
        conn
    }

    #[test]
    fn test_upsert_and_list() {
        let conn = setup();
        let p = projects::get_by_slug(&conn, "nc").expect("proj");
        upsert(&conn, p.id, "backend", "/abs/nc/backend", "backend", Some("rust|axum"), None)
            .expect("part1");
        upsert(&conn, p.id, "frontend", "/abs/nc/frontend", "frontend", Some("react"), None)
            .expect("part2");
        let parts = list_by_project(&conn, p.id).expect("list");
        assert_eq!(parts.len(), 2);
        assert_eq!(parts[0].part_name, "backend");
        assert_eq!(parts[0].part_path, "/abs/nc/backend");
    }

    #[test]
    fn test_find_by_path() {
        let conn = setup();
        let p = projects::get_by_slug(&conn, "nc").expect("proj");
        upsert(&conn, p.id, "backend", "/abs/nc/backend", "backend", None, None)
            .expect("part");
        upsert(&conn, p.id, "frontend", "/abs/nc/frontend", "frontend", None, None)
            .expect("part2");
        let found = find_by_path(&conn, "/abs/nc/backend/src/main.rs").expect("find");
        assert!(found.is_some());
        assert_eq!(found.as_ref().map(|p| p.part_name.as_str()), Some("backend"));
    }
}
