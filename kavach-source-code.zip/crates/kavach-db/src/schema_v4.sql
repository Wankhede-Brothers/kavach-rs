-- Add source_dir to rag_trees so session_start can refresh all labels.
ALTER TABLE rag_trees ADD COLUMN source_dir TEXT NOT NULL DEFAULT '';
