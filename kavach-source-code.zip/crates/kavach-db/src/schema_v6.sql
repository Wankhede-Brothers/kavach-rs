-- v6: Covering indexes to eliminate temp B-tree sorts on hot query paths.
--
-- memory_entries: (project_id, category, updated_at DESC) eliminates TEMP B-TREE
-- for ORDER BY updated_at DESC in kavach db query — fires on every prompt.
CREATE INDEX IF NOT EXISTS idx_memory_project_category_updated
    ON memory_entries(project_id, category, updated_at DESC);

-- events: (project_id, event_type, created_at DESC) enables O(log n) project+type
-- filtering instead of full index scan on idx_events_created alone.
CREATE INDEX IF NOT EXISTS idx_events_project_type_created
    ON events(project_id, event_type, created_at DESC)
    WHERE project_id IS NOT NULL;
