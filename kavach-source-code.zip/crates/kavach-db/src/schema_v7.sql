-- v7: Self-evolving gate patterns table.
--
-- Stores error patterns resolved through Claude-assisted research.
-- Each row encodes: the error fingerprint (keyword tokens), the fix
-- strategy (injected as advisory), the imperative instruction rewrite
-- (what the gate block message should say next time), and the DSA/
-- algorithm rationale (why this lookup strategy was chosen).
--
-- Tier promotion: occurrence_count drives algorithm selection.
-- < 50 hits  → linear keyword scan (O(n), negligible at small n)
-- ≥ 50 hits  → bloom-filter pre-check (O(1) false-negative-free fast path)
-- Bloom bytes are pre-computed and stored; gate reads them cold.

CREATE TABLE IF NOT EXISTS gate_patterns (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id       INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    -- Canonical space-separated keyword tokens extracted from the error text.
    -- Used for linear scan (Tier 1 cold path) and bloom filter seed (hot path).
    error_tokens     TEXT NOT NULL,
    -- Human-readable fix strategy injected as [SELF_EVOLVE] advisory.
    fix_strategy     TEXT NOT NULL,
    -- Rewritten gate block message — replaces the original block reason
    -- once this pattern reaches autonomous Tier 1 status.
    imperative_rewrite TEXT NOT NULL,
    -- DSA/algorithm rationale: why this data structure was chosen for lookup.
    dsa_rationale    TEXT NOT NULL,
    -- Tool name where this error originated (Bash, Edit, Write, …).
    tool_name        TEXT NOT NULL DEFAULT '',
    -- Gate that fired the block (pre_write, bash, stop, …).
    gate_name        TEXT NOT NULL DEFAULT '',
    -- Number of times this pattern has fired. Drives tier promotion.
    occurrence_count INTEGER NOT NULL DEFAULT 1,
    -- Serialized bloom filter bytes (NULL until promoted to Tier 1).
    -- Format: little-endian u64 array, length = ceil(m/64).
    bloom_bytes      BLOB,
    -- Tier: 'research' (novel, needs Claude) or 'autonomous' (hot, cached).
    tier             TEXT NOT NULL DEFAULT 'research'
                         CHECK (tier IN ('research', 'autonomous')),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    updated_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Fast lookup by project + tier for session-start injection.
CREATE INDEX IF NOT EXISTS idx_gate_patterns_project_tier
    ON gate_patterns(project_id, tier, occurrence_count DESC);

-- Lookup by tool+gate for PostToolUseFailure hot path.
CREATE INDEX IF NOT EXISTS idx_gate_patterns_tool_gate
    ON gate_patterns(tool_name, gate_name, occurrence_count DESC)
    WHERE tier = 'autonomous';
