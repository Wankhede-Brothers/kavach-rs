/// Graph population orchestrator — delegates to single-concern node passes.
///
/// Maps: project, project_part, session, memory_entry, file_context, event_type,
/// and enforcement topology (rules→gates, skills→gates) from rag_trees.
use std::collections::HashSet;
use rusqlite::Connection;

use crate::error::Result;
use crate::graph::add_relationship;
use crate::graph_entity::upsert_entity;
use crate::graph_populate_memory::populate_memory_dag;
use crate::graph_populate_nodes::{
    populate_algo_decisions, populate_arch_decisions, populate_event_types,
    populate_file_context, populate_gate_patterns, populate_memory,
    populate_parts, populate_projects, populate_sessions,
};
use crate::graph_populate_util::{collect_rows, extract_json_field};

/// Gates recognized by kavach's enforcement pipeline.
const KNOWN_GATES: &[&str] = &[
    "pre_write", "post_write", "intent", "stop",
    "pre_tool", "post_tool", "session",
];

#[derive(Debug, Default)]
pub struct PopulateStats {
    pub projects: usize,
    pub parts: usize,
    pub sessions: usize,
    pub memory: usize,
    pub files: usize,
    pub event_types: usize,
    pub enforcement_nodes: usize,
    pub memory_dag: usize,
    pub algo_decisions: usize,
    pub arch_decisions: usize,
    pub gate_patterns: usize,
}

/// Run a full graph population pass over all existing relational data.
/// Idempotent — upserts are safe to run repeatedly.
pub fn populate_all(conn: &Connection) -> Result<PopulateStats> {
    Ok(PopulateStats {
        projects: populate_projects(conn)?,
        parts: populate_parts(conn)?,
        sessions: populate_sessions(conn)?,
        memory: populate_memory(conn)?,
        files: populate_file_context(conn)?,
        event_types: populate_event_types(conn)?,
        enforcement_nodes: populate_enforcement(conn)?,
        memory_dag: populate_memory_dag(conn)?,
        algo_decisions: populate_algo_decisions(conn)?,
        arch_decisions: populate_arch_decisions(conn)?,
        gate_patterns: populate_gate_patterns(conn)?,
    })
}

/// Map rag_trees rows (rules + skills labels) into typed enforcement graph nodes.
///
/// For each rule tree: `rule` entity → `enforces_gate` edges.
/// For each skill tree: `skill` entity → `applies_to_gate` edges.
fn populate_enforcement(conn: &Connection) -> Result<usize> {
    let known: HashSet<&str> = KNOWN_GATES.iter().copied().collect();
    let rows: Vec<(String, Vec<u8>)> = collect_rows(
        conn,
        "SELECT source, tree_json FROM rag_trees WHERE source IN ('rules', 'skills')",
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let mut count = 0;
    for (label, blob) in &rows {
        let body = match std::str::from_utf8(blob) {
            Ok(s) => s,
            Err(_) => continue,
        };
        let entity_type = if label == "rules" { "rule" } else { "skill" };
        let rel_type = if label == "rules" { "enforces_gate" } else { "applies_to_gate" };
        for line in body.lines() {
            if line.trim().is_empty() {
                continue;
            }
            let node_name = extract_json_field(line, "id")
                .or_else(|| extract_json_field(line, "title"));
            let name = match node_name {
                Some(n) if !n.is_empty() => n,
                Some(_) | None => continue,
            };
            let clean = match name.trim_end_matches("/SKILL.md").split('/').next_back() {
                Some(s) if !s.is_empty() => s.to_string(),
                Some(_) | None => continue,
            };
            let node_id = match upsert_entity(conn, entity_type, &clean, None) {
                Ok(id) => id,
                Err(_) => continue,
            };
            let gates_in_line: Vec<&str> = known.iter()
                .copied()
                .filter(|g| line.contains(g))
                .collect();
            for gate in gates_in_line {
                if let Ok(gate_id) = upsert_entity(conn, "gate", gate, None) {
                    let _ = add_relationship(conn, node_id, gate_id, rel_type, 1.0);
                }
            }
            count += 1;
        }
    }
    Ok(count)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{open_memory, run_migrations};

    #[test]
    fn should_populate_empty_db_without_error() -> Result<()> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        let stats = populate_all(&conn)?;
        assert_eq!(stats.projects, 0);
        assert_eq!(stats.parts, 0);
        assert_eq!(stats.sessions, 0);
        assert_eq!(stats.memory, 0);
        assert_eq!(stats.files, 0);
        assert_eq!(stats.event_types, 0);
        assert_eq!(stats.enforcement_nodes, 0);
        Ok(())
    }
}
