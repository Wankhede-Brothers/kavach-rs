/// Kanban card tracking per project.
use crate::error::Result;
use rusqlite::{Connection, params};

#[derive(Debug, Clone, serde::Serialize)]
pub struct KanbanCard {
    pub id: i64,
    pub project_id: i64,
    pub title: String,
    pub status: String,
    pub priority: String,
    pub description: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub completed_at: Option<String>,
}

pub fn create(
    conn: &Connection,
    project_id: i64,
    title: &str,
    priority: &str,
) -> Result<i64> {
    conn.execute(
        "INSERT INTO kanban_cards (project_id, title, priority)
         VALUES (?1, ?2, ?3)",
        params![project_id, title, priority],
    )?;
    Ok(conn.last_insert_rowid())
}

pub fn update_status(conn: &Connection, id: i64, status: &str) -> Result<()> {
    let completed = if status == "done" {
        Some("datetime('now')".to_string())
    } else {
        None
    };
    conn.execute(
        "UPDATE kanban_cards
         SET status = ?2, updated_at = datetime('now'),
             completed_at = CASE WHEN ?2 = 'done' THEN datetime('now')
                            ELSE completed_at END
         WHERE id = ?1",
        params![id, status],
    )?;
    drop(completed);
    Ok(())
}

pub fn list_by_project(
    conn: &Connection,
    project_id: i64,
    status: Option<&str>,
) -> Result<Vec<KanbanCard>> {
    let mut cards = Vec::new();
    if let Some(s) = status {
        let mut stmt = conn.prepare(
            "SELECT id, project_id, title, status, priority,
                    description, created_at, updated_at, completed_at
             FROM kanban_cards
             WHERE project_id = ?1 AND status = ?2
             ORDER BY priority, created_at",
        )?;
        let rows = stmt.query_map(params![project_id, s], row_to_card)?;
        for row in rows {
            cards.push(row?);
        }
    } else {
        let mut stmt = conn.prepare(
            "SELECT id, project_id, title, status, priority,
                    description, created_at, updated_at, completed_at
             FROM kanban_cards
             WHERE project_id = ?1
             ORDER BY status, priority, created_at",
        )?;
        let rows = stmt.query_map(params![project_id], row_to_card)?;
        for row in rows {
            cards.push(row?);
        }
    }
    Ok(cards)
}

fn row_to_card(row: &rusqlite::Row) -> rusqlite::Result<KanbanCard> {
    Ok(KanbanCard {
        id: row.get(0)?,
        project_id: row.get(1)?,
        title: row.get(2)?,
        status: row.get(3)?,
        priority: row.get(4)?,
        description: row.get(5)?,
        created_at: row.get(6)?,
        updated_at: row.get(7)?,
        completed_at: row.get(8)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations, projects};

    fn setup() -> Connection {
        let conn = open_memory().expect("open");
        run_migrations(&conn).expect("migrate");
        projects::insert(&conn, "test", "Test").expect("project");
        conn
    }

    #[test]
    fn test_create_and_list() {
        let conn = setup();
        let p = projects::get_by_slug(&conn, "test").expect("proj");
        create(&conn, p.id, "Fix bug", "P0").expect("create");
        create(&conn, p.id, "Add feature", "P2").expect("create2");
        let cards = list_by_project(&conn, p.id, None).expect("list");
        assert_eq!(cards.len(), 2);
    }

    #[test]
    fn test_update_status() {
        let conn = setup();
        let p = projects::get_by_slug(&conn, "test").expect("proj");
        let id = create(&conn, p.id, "Task", "P1").expect("create");
        update_status(&conn, id, "done").expect("done");
        let cards = list_by_project(&conn, p.id, Some("done")).expect("list");
        assert_eq!(cards.len(), 1);
    }
}
