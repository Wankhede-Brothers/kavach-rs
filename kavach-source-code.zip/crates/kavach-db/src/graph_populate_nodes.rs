/// Node population passes — maps relational rows to graph entities + edges.
///
/// Each function is a single-concern pass over one relational table.
/// All writes are idempotent upserts — safe to run repeatedly.
use rusqlite::Connection;

use crate::error::Result;
use crate::graph::add_relationship;
use crate::graph_entity::upsert_entity;
use crate::graph_populate_util::collect_rows;

pub(crate) fn populate_projects(conn: &Connection) -> Result<usize> {
    let rows: Vec<(i64, String, Option<String>, Option<i64>)> = collect_rows(
        conn,
        "SELECT id, slug, stack, parent_id FROM projects",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
    )?;
    let id_to_slug: std::collections::HashMap<i64, &str> = rows
        .iter()
        .map(|(id, slug, _, _)| (*id, slug.as_str()))
        .collect();
    let mut count = 0;
    for (_, slug, stack, parent_id) in &rows {
        let props = stack.as_deref().map(|s| format!(r#"{{"stack":"{s}"}}"#));
        let id = upsert_entity(conn, "project", slug, props.as_deref())?;
        if let Some(pid) = parent_id {
            if let Some(&parent_slug) = id_to_slug.get(pid) {
                let parent_eid = upsert_entity(conn, "project", parent_slug, None)?;
                add_relationship(conn, id, parent_eid, "child_of", 1.0)?;
            }
        }
        count += 1;
    }
    Ok(count)
}

pub(crate) fn populate_parts(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, String, Option<String>, String)> = collect_rows(
        conn,
        "SELECT pp.part_name, pp.part_type, pp.stack, p.slug
         FROM project_parts pp
         JOIN projects p ON p.id = pp.project_id",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
    )?;
    let mut count = 0;
    for (part_name, part_type, stack, proj_slug) in &rows {
        let props = stack.as_deref()
            .map(|s| format!(r#"{{"type":"{part_type}","stack":"{s}"}}"#));
        let part_entity = format!("{proj_slug}/{part_name}");
        let part_id = upsert_entity(conn, "project_part", &part_entity, props.as_deref())?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, part_id, proj_id, "part_of", 1.0)?;
        count += 1;
    }
    Ok(count)
}

pub(crate) fn populate_sessions(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, String)> = collect_rows(
        conn,
        "SELECT s.id, p.slug FROM sessions s
         JOIN projects p ON p.id = s.project_id",
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let mut count = 0;
    for (session_id, proj_slug) in &rows {
        let sess_id = upsert_entity(conn, "session", session_id, None)?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, sess_id, proj_id, "belongs_to", 1.0)?;
        count += 1;
    }
    Ok(count)
}

pub(crate) fn populate_memory(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, String, Option<String>, String)> = collect_rows(
        conn,
        "SELECT me.category, me.entry_key, me.tags, p.slug
         FROM memory_entries me
         JOIN projects p ON p.id = me.project_id",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
    )?;
    let mut count = 0;
    for (category, entry_key, tags, proj_slug) in &rows {
        let name = format!("{proj_slug}/{category}/{entry_key}");
        let props = tags.as_deref().map(|t| format!(r#"{{"tags":"{t}"}}"#));
        let mem_id = upsert_entity(conn, "memory", &name, props.as_deref())?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, mem_id, proj_id, "memory_of", 1.0)?;
        count += 1;
    }
    Ok(count)
}

pub(crate) fn populate_file_context(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, Option<String>, String)> = collect_rows(
        conn,
        "SELECT fc.file_path, fc.extension, fc.session_id FROM file_context fc",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
    )?;
    let mut count = 0;
    for (file_path, ext, session_id) in &rows {
        let props = ext.as_deref().map(|e| format!(r#"{{"ext":"{e}"}}"#));
        let file_id = upsert_entity(conn, "file", file_path, props.as_deref())?;
        let sess_id = upsert_entity(conn, "session", session_id, None)?;
        add_relationship(conn, file_id, sess_id, "used_in", 1.0)?;
        count += 1;
    }
    Ok(count)
}

/// Populate algo_decision nodes with edges to project and file entities.
pub(crate) fn populate_algo_decisions(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, String, String, String)> = collect_rows(
        conn,
        "SELECT ad.problem_class, ad.chosen, ad.file_path, p.slug
         FROM algorithm_decisions ad
         JOIN projects p ON p.id = ad.project_id",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
    )?;
    let mut count = 0;
    for (problem_class, chosen, file_path, proj_slug) in &rows {
        let name = format!("{proj_slug}/algo/{problem_class}/{chosen}");
        let props = format!(
            r#"{{"problem_class":"{problem_class}","chosen":"{chosen}"}}"#
        );
        let algo_id = upsert_entity(conn, "algo_decision", &name, Some(&props))?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, algo_id, proj_id, "decided_for", 1.0)?;
        if !file_path.is_empty() {
            let file_id = upsert_entity(conn, "file", file_path, None)?;
            add_relationship(conn, algo_id, file_id, "applies_to", 1.0)?;
        }
        count += 1;
    }
    Ok(count)
}

/// Populate arch_decision nodes with edges to project, file, and scope entities.
pub(crate) fn populate_arch_decisions(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, String, String, String)> = collect_rows(
        conn,
        "SELECT ad.pattern, ad.scope, ad.file_path, p.slug
         FROM architecture_decisions ad
         JOIN projects p ON p.id = ad.project_id",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
    )?;
    let mut count = 0;
    for (pattern, scope, file_path, proj_slug) in &rows {
        let name = format!("{proj_slug}/arch/{pattern}");
        let props = format!(r#"{{"pattern":"{pattern}","scope":"{scope}"}}"#);
        let arch_id = upsert_entity(conn, "arch_decision", &name, Some(&props))?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, arch_id, proj_id, "decided_for", 1.0)?;
        let scope_id = upsert_entity(conn, "arch_scope", scope, None)?;
        add_relationship(conn, arch_id, scope_id, "in_scope", 1.0)?;
        if !file_path.is_empty() {
            let file_id = upsert_entity(conn, "file", file_path, None)?;
            add_relationship(conn, arch_id, file_id, "applies_to", 1.0)?;
        }
        count += 1;
    }
    Ok(count)
}

/// Populate gate_pattern nodes with edges to their associated gate.
pub(crate) fn populate_gate_patterns(conn: &Connection) -> Result<usize> {
    let rows: Vec<(i64, String, String)> = collect_rows(
        conn,
        "SELECT gp.id, gp.gate_name, p.slug
         FROM gate_patterns gp
         JOIN projects p ON p.id = gp.project_id",
        |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)),
    )?;
    let mut count = 0;
    for (pattern_row_id, gate_name, proj_slug) in &rows {
        let name = format!("{proj_slug}/pattern/{pattern_row_id}");
        let pattern_id = upsert_entity(conn, "gate_pattern", &name, None)?;
        let gate_id = upsert_entity(conn, "gate", gate_name, None)?;
        add_relationship(conn, pattern_id, gate_id, "resolves_in", 1.0)?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, pattern_id, proj_id, "pattern_of", 1.0)?;
        count += 1;
    }
    Ok(count)
}

pub(crate) fn populate_event_types(conn: &Connection) -> Result<usize> {
    let rows: Vec<(String, String)> = collect_rows(
        conn,
        "SELECT DISTINCT e.event_type, p.slug
         FROM events e
         JOIN projects p ON p.id = e.project_id
         WHERE e.project_id IS NOT NULL",
        |r| Ok((r.get(0)?, r.get(1)?)),
    )?;
    let mut count = 0;
    for (event_type, proj_slug) in &rows {
        let evt_id = upsert_entity(conn, "event_type", event_type, None)?;
        let proj_id = upsert_entity(conn, "project", proj_slug, None)?;
        add_relationship(conn, evt_id, proj_id, "fired_in", 1.0)?;
        count += 1;
    }
    Ok(count)
}
