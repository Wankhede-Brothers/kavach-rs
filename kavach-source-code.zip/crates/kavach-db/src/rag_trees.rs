use rusqlite::{params, Connection};

use crate::error::Result;

/// One persisted RAG tree row. `tree_json` is the full serialized
/// `kavach_rag::RagTree`; `source_hash` lets gates detect stale trees.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StoredTree {
    pub source: String,
    pub built_at: String,
    pub tree_json: Vec<u8>,
    pub source_hash: String,
}

/// Insert or replace a tree by source label. Idempotent — each build of the
/// same source overwrites the previous row. Uses ON CONFLICT UPSERT rather
/// than INSERT OR REPLACE to avoid the row-delete-and-reinsert cycle.
pub fn upsert(
    conn: &Connection,
    source: &str,
    built_at: &str,
    tree_json: &[u8],
    source_hash: &str,
) -> Result<()> {
    upsert_with_dir(conn, source, built_at, tree_json, source_hash, "")
}

/// Insert or replace a tree with an explicit source directory for refresh.
pub fn upsert_with_dir(
    conn: &Connection,
    source: &str,
    built_at: &str,
    tree_json: &[u8],
    source_hash: &str,
    source_dir: &str,
) -> Result<()> {
    conn.execute(
        "INSERT INTO rag_trees (source, built_at, tree_json, source_hash, source_dir) \
         VALUES (?1, ?2, ?3, ?4, ?5) \
         ON CONFLICT(source) DO UPDATE SET \
             built_at = excluded.built_at, \
             tree_json = excluded.tree_json, \
             source_hash = excluded.source_hash, \
             source_dir = excluded.source_dir",
        params![source, built_at, tree_json, source_hash, source_dir],
    )?;
    Ok(())
}

/// Fetch a single tree by source label.
pub fn get(conn: &Connection, source: &str) -> Result<Option<StoredTree>> {
    let mut stmt = conn.prepare(
        "SELECT source, built_at, tree_json, source_hash FROM rag_trees WHERE source = ?1",
    )?;
    let row = stmt.query_row([source], |r| {
        Ok(StoredTree {
            source: r.get(0)?,
            built_at: r.get(1)?,
            tree_json: r.get(2)?,
            source_hash: r.get(3)?,
        })
    });
    match row {
        Ok(t) => Ok(Some(t)),
        Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
        Err(e) => Err(e.into()),
    }
}

/// List every stored tree (source + built_at + source_hash only, no blob).
pub fn list(conn: &Connection) -> Result<Vec<(String, String, String)>> {
    let mut stmt = conn.prepare(
        "SELECT source, built_at, source_hash FROM rag_trees ORDER BY source",
    )?;
    let rows = stmt.query_map([], |r| {
        Ok((
            r.get::<_, String>(0)?,
            r.get::<_, String>(1)?,
            r.get::<_, String>(2)?,
        ))
    })?;
    let mut out: Vec<(String, String, String)> = Vec::new();
    for row in rows {
        out.push(row?);
    }
    Ok(out)
}

/// List all stored trees with their source directories for refresh.
pub fn list_refreshable(conn: &Connection) -> Result<Vec<(String, String)>> {
    let mut stmt = conn.prepare(
        "SELECT source, source_dir FROM rag_trees WHERE source_dir != '' ORDER BY source",
    )?;
    let rows = stmt.query_map([], |r| {
        Ok((
            r.get::<_, String>(0)?,
            r.get::<_, String>(1)?,
        ))
    })?;
    let mut out: Vec<(String, String)> = Vec::new();
    for row in rows {
        out.push(row?);
    }
    Ok(out)
}

/// Delete a tree by source label. Returns true if a row was removed.
pub fn delete(conn: &Connection, source: &str) -> Result<bool> {
    let affected = conn.execute("DELETE FROM rag_trees WHERE source = ?1", [source])?;
    Ok(affected > 0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::connection::open_memory;
    use crate::migrate::run_migrations;

    fn fresh() -> Result<Connection> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        Ok(conn)
    }

    #[test]
    fn should_upsert_and_fetch_tree_by_source() -> Result<()> {
        let conn = fresh()?;
        upsert(&conn, "skills", "2026-04-05", b"{\"v\":1}", "hash-a")?;
        let row = get(&conn, "skills")?;
        let row = match row {
            Some(r) => r,
            None => return Err(crate::error::DbError::EntryNotFound {
                category: "rag_trees".into(),
                key: "expected-row".into(),
            }),
        };
        assert_eq!(row.source, "skills");
        assert_eq!(row.tree_json, b"{\"v\":1}");
        Ok(())
    }

    #[test]
    fn should_replace_existing_row_on_upsert() -> Result<()> {
        let conn = fresh()?;
        upsert(&conn, "rules", "t1", b"v1", "h1")?;
        upsert(&conn, "rules", "t2", b"v2", "h2")?;
        let row = get(&conn, "rules")?;
        let row = match row {
            Some(r) => r,
            None => return Err(crate::error::DbError::EntryNotFound {
                category: "rag_trees".into(),
                key: "expected-row".into(),
            }),
        };
        assert_eq!(row.built_at, "t2");
        assert_eq!(row.source_hash, "h2");
        Ok(())
    }

    #[test]
    fn should_return_none_for_missing_source() -> Result<()> {
        let conn = fresh()?;
        let row = get(&conn, "nope")?;
        assert!(row.is_none());
        Ok(())
    }

    #[test]
    fn should_list_all_sources() -> Result<()> {
        let conn = fresh()?;
        upsert(&conn, "a", "t", b"x", "h")?;
        upsert(&conn, "b", "t", b"x", "h")?;
        let rows = list(&conn)?;
        assert_eq!(rows.len(), 2);
        Ok(())
    }

    #[test]
    fn should_delete_row_and_report_removal() -> Result<()> {
        let conn = fresh()?;
        upsert(&conn, "temp", "t", b"x", "h")?;
        let first = delete(&conn, "temp")?;
        let second = delete(&conn, "temp")?;
        assert!(first);
        assert!(!second);
        Ok(())
    }
}
