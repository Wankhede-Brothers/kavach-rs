/// Event projections — turns append-only events into graph edges, kanban cards, memory.
/// Projections are idempotent. On failure they must never block the gate pipeline,
/// but they DO audit the failure via an internal `projection_failure` event so the
/// interconnection loss leaves a trail rather than silent drift.
use rusqlite::Connection;

use crate::graph_populate_util::short_hash;
use crate::projections_util::{extract_content_references, skill_for_file};

/// Log a projection failure to the events table so the audit chain captures
/// interconnection drift. Failure-of-the-failure-logger is swallowed — the only
/// alternative is to panic inside the gate hot path, which breaks CC wire format.
fn audit_projection_failure(
    conn: &Connection,
    project_id: Option<i64>,
    projection: &str,
    reason: &str,
) {
    let payload = format!(
        r#"{{"projection":"{projection}","reason":"{}"}}"#,
        reason.replace('"', "\\\"").chars().take(200).collect::<String>(),
    );
    let _ = crate::events::append(
        conn,
        Some(""),
        "projection_failure",
        "kavach-db::projections",
        project_id,
        Some(&payload),
    );
}

/// Project a file_write event into graph edges.
/// Creates: file→skill (extension), file→project, file→skill (content references).
pub fn project_file_write(conn: &Connection, file_path: &str, project_id: i64, content: &str) {
    let file_id = match crate::graph_entity::upsert_entity(conn, "file", file_path, None) {
        Ok(id) => id,
        Err(e) => {
            audit_projection_failure(conn, Some(project_id), "project_file_write.file_entity", &e.to_string());
            return;
        }
    };
    let skill = skill_for_file(file_path);
    if !skill.is_empty() {
        match crate::graph_entity::upsert_entity(conn, "skill", skill, None) {
            Ok(skill_id) => {
                if let Err(e) = crate::graph::add_relationship(conn, file_id, skill_id, "uses_skill", 1.0) {
                    audit_projection_failure(conn, Some(project_id), "project_file_write.uses_skill", &e.to_string());
                }
            }
            Err(e) => audit_projection_failure(conn, Some(project_id), "project_file_write.skill_entity", &e.to_string()),
        }
    }
    let proj_name = project_id.to_string();
    match crate::graph_entity::upsert_entity(conn, "project", &proj_name, None) {
        Ok(proj_ent) => {
            if let Err(e) = crate::graph::add_relationship(conn, file_id, proj_ent, "belongs_to", 1.0) {
                audit_projection_failure(conn, Some(project_id), "project_file_write.belongs_to", &e.to_string());
            }
        }
        Err(e) => audit_projection_failure(conn, Some(project_id), "project_file_write.project_entity", &e.to_string()),
    }
    if !content.is_empty() {
        for target in extract_content_references(content) {
            match crate::graph_entity::upsert_entity(conn, "skill", &target, None) {
                Ok(ref_id) => {
                    if let Err(e) = crate::graph::add_relationship(conn, file_id, ref_id, "references", 1.0) {
                        audit_projection_failure(conn, Some(project_id), "project_file_write.references", &e.to_string());
                    }
                }
                Err(e) => audit_projection_failure(conn, Some(project_id), "project_file_write.ref_entity", &e.to_string()),
            }
        }
    }
}

/// Project a high-risk intent into a kanban card.
pub fn project_intent_to_kanban(
    conn: &Connection,
    project_id: i64,
    intent_type: &str,
    risk: &str,
) {
    if risk != "critical" && risk != "high" {
        return;
    }
    let title = format!("[{risk}] {intent_type} task detected");
    let priority = if risk == "critical" { "P0" } else { "P1" };
    if let Err(e) = crate::kanban::create(conn, project_id, &title, priority) {
        audit_projection_failure(conn, Some(project_id), "project_intent_to_kanban", &e.to_string());
    }
}

/// Project a gate block into memory as a recurring pattern.
pub fn project_gate_block_to_memory(
    conn: &Connection,
    project_id: i64,
    gate: &str,
    reason: &str,
) {
    let key = format!("block-{gate}-{}", short_hash(reason));
    let params = crate::memory::UpsertParams {
        project_id,
        category: "pattern",
        entry_key: &key,
        title: &format!("Gate block: {gate}"),
        content: reason,
        tags: Some(gate),
        ttl_days: Some(30),
        source: Some("projection"),
    };
    if let Err(e) = crate::memory::upsert(conn, &params) {
        audit_projection_failure(conn, Some(project_id), "project_gate_block_to_memory", &e.to_string());
    }
}

/// Project a tool failure into a gate_pattern row (self-evolution loop).
/// Novel errors start at Tier 2 "research"; repeated ones accumulate count
/// and auto-promote to Tier 1 "autonomous" at PROMOTION_THRESHOLD.
pub fn project_error_to_pattern(
    conn: &Connection,
    project_id: i64,
    error: &str,
    fix_strategy: &str,
    imperative_rewrite: &str,
    dsa_rationale: &str,
    tool_name: &str,
    gate_name: &str,
) {
    let params = crate::gate_patterns::UpsertParams {
        project_id,
        error_tokens: error,
        fix_strategy,
        imperative_rewrite,
        dsa_rationale,
        tool_name,
        gate_name,
    };
    if let Err(e) = crate::gate_patterns::upsert(conn, &params) {
        audit_projection_failure(conn, Some(project_id), "project_error_to_pattern", &e.to_string());
    }
}

/// Project a session start into a graph edge: session → project.
pub fn project_session_to_graph(conn: &Connection, session_id: &str, project_id: i64) {
    let sess_ent = match crate::graph_entity::upsert_entity(conn, "session", session_id, None) {
        Ok(id) => id,
        Err(e) => {
            audit_projection_failure(conn, Some(project_id), "project_session_to_graph.session_entity", &e.to_string());
            return;
        }
    };
    let proj_name = project_id.to_string();
    let proj_ent = match crate::graph_entity::upsert_entity(conn, "project", &proj_name, None) {
        Ok(id) => id,
        Err(e) => {
            audit_projection_failure(conn, Some(project_id), "project_session_to_graph.project_entity", &e.to_string());
            return;
        }
    };
    if let Err(e) = crate::graph::add_relationship(conn, sess_ent, proj_ent, "works_on", 1.0) {
        audit_projection_failure(conn, Some(project_id), "project_session_to_graph.works_on", &e.to_string());
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations, projects};

    fn setup() -> crate::error::Result<Connection> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "test", "Test")?;
        Ok(conn)
    }

    #[test]
    fn should_create_graph_edge_on_file_write() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        project_file_write(&conn, "src/main.rs", p.id, "");
        let file_ent = crate::graph_entity::find_entity(&conn, "file", "src/main.rs");
        assert!(file_ent.is_ok());
        let skill_ent = crate::graph_entity::find_entity(&conn, "skill", "rust");
        assert!(skill_ent.is_ok());
        Ok(())
    }

    #[test]
    fn should_create_kanban_card_for_critical_intent() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        project_intent_to_kanban(&conn, p.id, "deploy", "critical");
        let cards = crate::kanban::list_by_project(&conn, p.id, None)?;
        assert_eq!(cards.len(), 1);
        Ok(())
    }

    #[test]
    fn should_skip_kanban_for_low_risk_intent() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        project_intent_to_kanban(&conn, p.id, "general", "low");
        let cards = crate::kanban::list_by_project(&conn, p.id, None)?;
        assert!(cards.is_empty());
        Ok(())
    }

    #[test]
    fn should_write_gate_block_to_memory() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        project_gate_block_to_memory(&conn, p.id, "pre_write", "SKILL VIOLATION");
        let entries = crate::memory::list_by_project(&conn, p.id, Some("pattern"))?;
        assert_eq!(entries.len(), 1);
        Ok(())
    }

    #[test]
    fn should_create_session_graph_edge() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        project_session_to_graph(&conn, "sess_123", p.id);
        let sess = crate::graph_entity::find_entity(&conn, "session", "sess_123");
        assert!(sess.is_ok());
        Ok(())
    }
}
