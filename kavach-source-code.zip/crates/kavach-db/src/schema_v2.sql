-- kavach-db schema v2: Project sub-parts for precise memory targeting

CREATE TABLE project_parts (
    id          INTEGER PRIMARY KEY,
    project_id  INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    part_name   TEXT NOT NULL,
    part_path   TEXT NOT NULL,
    part_type   TEXT NOT NULL CHECK(part_type IN (
                    'backend', 'frontend', 'database', 'mobile',
                    'infra', 'docs', 'shared', 'other'
                )),
    stack       TEXT,
    description TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(project_id, part_name)
);

CREATE INDEX idx_parts_project ON project_parts(project_id);
CREATE INDEX idx_parts_path ON project_parts(part_path);
