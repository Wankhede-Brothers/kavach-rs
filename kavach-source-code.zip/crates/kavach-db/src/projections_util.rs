/// Projection helpers — file skill mapping and content reference extraction.

const EXT_RS: &str = ".rs";
const EXT_TS: &str = ".ts";
const EXT_TSX: &str = ".tsx";
const EXT_SQL: &str = ".sql";
const EXT_JSX: &str = ".jsx";
const EXT_ASTRO: &str = ".astro";
const EXT_CSS: &str = ".css";
const EXT_TOML: &str = ".toml";
const EXT_YAML: &str = ".yaml";
const EXT_YML: &str = ".yml";
const EXT_MD: &str = ".md";

/// Map file extension to skill name for graph edges.
pub(crate) fn skill_for_file(path: &str) -> &str {
    if path.ends_with(EXT_RS) { return "rust"; }
    if path.ends_with(EXT_TS) || path.ends_with(EXT_TSX) { return "typescript"; }
    if path.ends_with(EXT_SQL) { return "sql"; }
    if path.ends_with(EXT_JSX) || path.ends_with(EXT_ASTRO) { return "frontend"; }
    if path.ends_with(EXT_CSS) { return "css"; }
    if path.ends_with(EXT_TOML) || path.ends_with(EXT_YAML) || path.ends_with(EXT_YML) {
        return "config";
    }
    if path.ends_with(EXT_MD) { return "docs"; }
    ""
}

/// Extract referenced names from file content.
/// Parses: `[[wikilinks]]` and `INVOKE skill-name` directives.
/// Deduplication: sort + dedup — O(n log n), no repeated scan.
pub(crate) fn extract_content_references(content: &str) -> Vec<String> {
    let mut refs: Vec<String> = Vec::new();
    for line in content.lines() {
        collect_wikilinks(line, &mut refs);
        collect_invoke(line, &mut refs);
    }
    refs.sort_unstable();
    refs.dedup();
    refs
}

fn collect_wikilinks(line: &str, refs: &mut Vec<String>) {
    let mut rest = line;
    while let Some(start) = rest.find("[[") {
        let after_open = match rest.get(start.saturating_add(2)..) {
            Some(s) => s,
            None => break,
        };
        match after_open.find("]]") {
            None => break,
            Some(end) => {
                if let Some(name) = after_open.get(..end) {
                    let trimmed = name.trim();
                    if !trimmed.is_empty() {
                        refs.push(trimmed.to_string());
                    }
                }
                rest = match after_open.get(end.saturating_add(2)..) {
                    Some(s) => s,
                    None => break,
                };
            }
        }
    }
}

const INVOKE_PREFIX: &str = "INVOKE ";

fn collect_invoke(line: &str, refs: &mut Vec<String>) {
    let Some(pos) = line.find(INVOKE_PREFIX) else { return };
    let offset = pos.saturating_add(INVOKE_PREFIX.len());
    let Some(after) = line.get(offset..) else { return };
    let Some(skill_raw) = after.split_whitespace().next() else { return };
    let skill = skill_raw.trim_end_matches('.');
    if !skill.is_empty() {
        refs.push(skill.to_string());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn should_map_rs_to_rust_skill() {
        assert_eq!(skill_for_file("src/main.rs"), "rust");
    }

    #[test]
    fn should_map_tsx_to_typescript_skill() {
        assert_eq!(skill_for_file("src/App.tsx"), "typescript");
    }

    #[test]
    fn should_return_empty_for_unknown_extension() {
        assert_eq!(skill_for_file("data.bin"), "");
    }

    #[test]
    fn should_parse_wikilinks() {
        let refs = extract_content_references("See [[rust]] and [[sql]]");
        assert!(refs.iter().any(|r| r == "rust"));
        assert!(refs.iter().any(|r| r == "sql"));
    }

    #[test]
    fn should_parse_invoke_directives() {
        let refs = extract_content_references("INVOKE m13-domain-error");
        assert!(refs.iter().any(|r| r == "m13-domain-error"));
    }

    #[test]
    fn should_deduplicate_refs() {
        let refs = extract_content_references("[[rust]]\n[[rust]]");
        assert_eq!(refs.iter().filter(|r| r.as_str() == "rust").count(), 1);
    }
}
