/// Entity CRUD with process-local write-through cache.
///
/// Hot path: `upsert_entity` checks `ENTITY_CACHE` first (O(1) DashMap).
/// Cache miss: single SQL RETURNING id round-trip, then cached.
/// SQLite is the durable store — cache is purely additive.
use std::sync::OnceLock;
use crate::error::{DbError, Result};
use crate::store_entity::EntityIndex;
use rusqlite::{Connection, params};

static ENTITY_CACHE: OnceLock<EntityIndex> = OnceLock::new();

pub(crate) fn entity_cache(conn: &Connection) -> &'static EntityIndex {
    ENTITY_CACHE.get_or_init(|| {
        match EntityIndex::load_from_db(conn) {
            Ok(idx) => idx,
            Err(_) => EntityIndex::new(),
        }
    })
}

#[derive(Debug, Clone, serde::Serialize)]
pub struct Entity {
    pub id: i64,
    pub entity_type: String,
    pub name: String,
    pub properties: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

/// Insert or get an entity by (type, name), returning its id.
///
/// Cache hit:  O(1) DashMap lookup — zero SQL.
/// Cache miss: SQL RETURNING id (single round-trip), then cached.
pub fn upsert_entity(
    conn: &Connection,
    entity_type: &str,
    name: &str,
    properties: Option<&str>,
) -> Result<i64> {
    let cache = entity_cache(conn);
    if let Some(id) = cache.get(entity_type, name) {
        return Ok(id);
    }
    let id: i64 = conn.query_row(
        "INSERT INTO entities (entity_type, name, properties)
         VALUES (?1, ?2, ?3)
         ON CONFLICT(entity_type, name) DO UPDATE SET
            properties = COALESCE(excluded.properties, entities.properties),
            updated_at = datetime('now')
         RETURNING id",
        params![entity_type, name, properties],
        |r| r.get(0),
    )?;
    cache.insert(entity_type, name, id);
    Ok(id)
}

/// Insert or get an entity by content_hash — merges identical patterns.
/// Falls back to `upsert_entity` when hash is None.
pub fn upsert_entity_with_hash(
    conn: &Connection,
    entity_type: &str,
    name: &str,
    properties: Option<&str>,
    content_hash: Option<&str>,
) -> Result<i64> {
    let Some(hash) = content_hash else {
        return upsert_entity(conn, entity_type, name, properties);
    };
    let existing: rusqlite::Result<i64> = conn.query_row(
        "SELECT id FROM entities WHERE entity_type = ?1 AND content_hash = ?2",
        params![entity_type, hash],
        |r| r.get(0),
    );
    match existing {
        Ok(id) => return Ok(id),
        Err(rusqlite::Error::QueryReturnedNoRows) => {}
        Err(e) => return Err(DbError::Sqlite(e)),
    }
    let id: i64 = conn.query_row(
        "INSERT INTO entities (entity_type, name, properties, content_hash)
         VALUES (?1, ?2, ?3, ?4)
         ON CONFLICT(entity_type, name) DO UPDATE SET
            properties = COALESCE(excluded.properties, entities.properties),
            content_hash = COALESCE(excluded.content_hash, entities.content_hash),
            updated_at = datetime('now')
         RETURNING id",
        params![entity_type, name, properties, hash],
        |r| r.get(0),
    )?;
    Ok(id)
}

pub fn find_entity(conn: &Connection, entity_type: &str, name: &str) -> Result<Entity> {
    conn.query_row(
        "SELECT id, entity_type, name, properties, created_at, updated_at
         FROM entities WHERE entity_type = ?1 AND name = ?2",
        params![entity_type, name],
        row_to_entity,
    )
    .map_err(|e| match e {
        rusqlite::Error::QueryReturnedNoRows => DbError::EntityNotFound {
            name: name.to_string(),
        },
        other => DbError::Sqlite(other),
    })
}

pub fn list_entities(conn: &Connection, entity_type: Option<&str>) -> Result<Vec<Entity>> {
    let mut entries = Vec::new();
    if let Some(t) = entity_type {
        let mut stmt = conn.prepare(
            "SELECT id, entity_type, name, properties, created_at, updated_at
             FROM entities WHERE entity_type = ?1 ORDER BY name",
        )?;
        let rows = stmt.query_map(params![t], row_to_entity)?;
        for row in rows {
            entries.push(row?);
        }
    } else {
        let mut stmt = conn.prepare(
            "SELECT id, entity_type, name, properties, created_at, updated_at
             FROM entities ORDER BY entity_type, name",
        )?;
        let rows = stmt.query_map([], row_to_entity)?;
        for row in rows {
            entries.push(row?);
        }
    }
    Ok(entries)
}

pub(crate) fn row_to_entity(row: &rusqlite::Row) -> rusqlite::Result<Entity> {
    Ok(Entity {
        id: row.get(0)?,
        entity_type: row.get(1)?,
        name: row.get(2)?,
        properties: row.get(3)?,
        created_at: row.get(4)?,
        updated_at: row.get(5)?,
    })
}
