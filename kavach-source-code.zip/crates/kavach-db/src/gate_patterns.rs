//! CRUD for the `gate_patterns` table — self-evolving error pattern store.
//!
//! Two-tier lookup:
//! - Tier 1 "autonomous": pattern has ≥ PROMOTION_THRESHOLD hits, bloom_bytes
//!   populated, gate injects cached fix directly without Claude involvement.
//! - Tier 2 "research": novel error, gate injects [SELF_EVOLVE] block so
//!   Claude researches and writes back via `upsert`.
//!
//! Bloom filter uses two FNV-1a hash functions over keyword tokens.
//! False positives send the query to the linear scan — no correctness issue.

use rusqlite::{Connection, Row, params};

use crate::error::{DbError, Result};

const TIER_RESEARCH: &str = "research";
const TIER_AUTONOMOUS: &str = "autonomous";
/// Occurrences before a pattern is promoted to autonomous (Tier 1).
const PROMOTION_THRESHOLD: i64 = 50;
/// Bloom filter size in bits — 512 bits ≈ 1% FPR at 25 tokens.
const BLOOM_BITS: usize = 512;
const BLOOM_BYTE_LEN: usize = BLOOM_BITS / 8;
/// FNV-1a seed 1 (standard offset basis).
const FNV_SEED_1: u32 = 0x811c_9dc5;
/// FNV-1a seed 2 (alternative basis for second hash).
const FNV_SEED_2: u32 = 0xdead_beef;
/// FNV-1a prime.
const FNV_PRIME: u32 = 0x0100_0193;
/// Maximum tokens retained after tokenization.
const MAX_TOKENS: usize = 20;
/// Minimum token length kept by tokenizer.
const MIN_TOKEN_LEN: usize = 3;
/// Candidate limit for autonomous pattern scan.
const SCAN_LIMIT: i64 = 200;

#[derive(Debug, Clone)]
pub struct GatePattern {
    pub id: i64,
    pub project_id: i64,
    pub error_tokens: String,
    pub fix_strategy: String,
    pub imperative_rewrite: String,
    pub dsa_rationale: String,
    pub tool_name: String,
    pub gate_name: String,
    pub occurrence_count: i64,
    pub bloom_bytes: Option<Vec<u8>>,
    pub tier: String,
}

pub struct UpsertParams<'a> {
    pub project_id: i64,
    pub error_tokens: &'a str,
    pub fix_strategy: &'a str,
    pub imperative_rewrite: &'a str,
    pub dsa_rationale: &'a str,
    pub tool_name: &'a str,
    pub gate_name: &'a str,
}

fn from_row(row: &Row<'_>) -> rusqlite::Result<GatePattern> {
    Ok(GatePattern {
        id: row.get(0)?,
        project_id: row.get(1)?,
        error_tokens: row.get(2)?,
        fix_strategy: row.get(3)?,
        imperative_rewrite: row.get(4)?,
        dsa_rationale: row.get(5)?,
        tool_name: row.get(6)?,
        gate_name: row.get(7)?,
        occurrence_count: row.get(8)?,
        bloom_bytes: row.get(9)?,
        tier: row.get(10)?,
    })
}

/// Tokenize an error string into sorted, deduplicated lowercase keywords.
/// Strips punctuation, drops words shorter than MIN_TOKEN_LEN, caps at MAX_TOKENS.
pub fn tokenize(error: &str) -> String {
    let mut tokens: Vec<String> = error
        .split(|c: char| !c.is_alphanumeric())
        .filter(|t| t.len() >= MIN_TOKEN_LEN)
        .map(|t| t.to_lowercase())
        .collect();
    tokens.sort_unstable();
    tokens.dedup();
    tokens.truncate(MAX_TOKENS);
    tokens.join(" ")
}

/// Build a BLOOM_BYTE_LEN-byte Bloom filter over keyword tokens.
pub fn bloom_from_tokens(tokens: &str) -> Vec<u8> {
    let mut bits = vec![0u8; BLOOM_BYTE_LEN];
    for token in tokens.split_whitespace() {
        let h1 = fnv1a(token, FNV_SEED_1);
        let h2 = fnv1a(token, FNV_SEED_2);
        set_bit(&mut bits, (h1 as usize) % BLOOM_BITS);
        set_bit(&mut bits, (h2 as usize) % BLOOM_BITS);
    }
    bits
}

/// Test whether all query tokens are likely present in the bloom filter.
/// A false positive sends the query to the linear scan — no correctness issue.
pub fn bloom_might_match(bloom: &[u8], query_tokens: &str) -> bool {
    if bloom.len() < BLOOM_BYTE_LEN {
        return true; // degenerate bloom — fall through to linear scan
    }
    for token in query_tokens.split_whitespace() {
        let h1 = fnv1a(token, FNV_SEED_1);
        let h2 = fnv1a(token, FNV_SEED_2);
        if !test_bit(bloom, (h1 as usize) % BLOOM_BITS)
            || !test_bit(bloom, (h2 as usize) % BLOOM_BITS)
        {
            return false;
        }
    }
    true
}

fn set_bit(bytes: &mut [u8], pos: usize) {
    if let Some(byte) = bytes.get_mut(pos / 8) {
        *byte |= 1u8 << (pos % 8);
    }
}

fn test_bit(bytes: &[u8], pos: usize) -> bool {
    bytes.get(pos / 8).map_or(false, |b| b & (1u8 << (pos % 8)) != 0)
}

fn fnv1a(s: &str, seed: u32) -> u32 {
    let mut h = seed;
    for b in s.bytes() {
        h ^= u32::from(b);
        h = h.wrapping_mul(FNV_PRIME);
    }
    h
}

/// Insert or increment an existing pattern matched by project + token set.
/// On increment, re-evaluates tier promotion and refreshes bloom bytes.
pub fn upsert(conn: &Connection, p: &UpsertParams<'_>) -> Result<i64> {
    let tokens = tokenize(p.error_tokens);
    let existing: Option<(i64, i64)> = conn
        .query_row(
            "SELECT id, occurrence_count FROM gate_patterns
             WHERE project_id = ?1 AND error_tokens = ?2",
            params![p.project_id, tokens],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )
        .optional()?;

    match existing {
        Some((id, count)) => {
            let new_count = count + 1;
            let (tier, bloom): (&str, Option<Vec<u8>>) = if new_count >= PROMOTION_THRESHOLD {
                (TIER_AUTONOMOUS, Some(bloom_from_tokens(&tokens)))
            } else {
                (TIER_RESEARCH, None)
            };
            conn.execute(
                "UPDATE gate_patterns
                 SET occurrence_count = ?1,
                     fix_strategy = ?2,
                     imperative_rewrite = ?3,
                     dsa_rationale = ?4,
                     tier = ?5,
                     bloom_bytes = ?6,
                     updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                 WHERE id = ?7",
                params![
                    new_count, p.fix_strategy, p.imperative_rewrite,
                    p.dsa_rationale, tier, bloom, id
                ],
            )?;
            Ok(id)
        }
        None => {
            conn.execute(
                "INSERT INTO gate_patterns
                 (project_id, error_tokens, fix_strategy, imperative_rewrite,
                  dsa_rationale, tool_name, gate_name, occurrence_count, tier)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, 1, 'research')",
                params![
                    p.project_id, tokens, p.fix_strategy, p.imperative_rewrite,
                    p.dsa_rationale, p.tool_name, p.gate_name
                ],
            )?;
            Ok(conn.last_insert_rowid())
        }
    }
}

/// Find the best autonomous pattern matching `error` for the given tool.
/// Pipeline: bloom pre-check (O(1)) then TF-IDF weighted cosine similarity.
///
/// IDF(token) = ln(N / df) where N = candidate count, df = candidates
/// containing that token. Rare tokens score higher than common ones.
/// Returns the best candidate with cosine similarity >= MIN_SIM, or None.
pub fn find_autonomous(
    conn: &Connection,
    project_id: i64,
    error: &str,
    tool_name: &str,
) -> Result<Option<GatePattern>> {
    let query_tokens = tokenize(error);
    let query_vec: Vec<&str> = query_tokens.split_whitespace().collect();
    if query_vec.is_empty() {
        return Ok(None);
    }

    let mut stmt = conn.prepare(
        "SELECT id, project_id, error_tokens, fix_strategy, imperative_rewrite,
                dsa_rationale, tool_name, gate_name, occurrence_count, bloom_bytes, tier
         FROM gate_patterns
         WHERE project_id = ?1 AND tier = 'autonomous'
           AND (tool_name = '' OR tool_name = ?2)
         ORDER BY occurrence_count DESC
         LIMIT ?3",
    )?;

    let mut candidates = Vec::new();
    let mut rows = stmt.query(params![project_id, tool_name, SCAN_LIMIT])?;
    while let Some(row) = rows.next()? {
        candidates.push(from_row(row).map_err(DbError::Sqlite)?);
    }
    if candidates.is_empty() {
        return Ok(None);
    }

    tfidf_best_match(candidates, &query_vec, &query_tokens)
}

/// Score candidates via TF-IDF cosine similarity and return the best match.
/// Extracted to keep find_autonomous under 100 lines.
fn tfidf_best_match(
    candidates: Vec<GatePattern>,
    query_vec: &[&str],
    query_tokens: &str,
) -> Result<Option<GatePattern>> {
    let n = candidates.len() as f64;
    let mut df = std::collections::HashMap::new();
    for token in query_vec {
        let count = candidates
            .iter()
            .filter(|p| p.error_tokens.split_whitespace().any(|t| t == *token))
            .count() as f64;
        if count > 0.0 {
            df.insert(*token, count);
        }
    }
    // idf(t) = ln(N/df). Tokens absent from all candidates return 0.0.
    let idf = |token: &str| -> f64 {
        df.get(token).map_or(0.0, |&d| (n / d).ln())
    };
    let query_norm: f64 = query_vec.iter()
        .map(|t| { let w = idf(t); w * w })
        .sum::<f64>()
        .sqrt();
    if query_norm == 0.0 {
        return Ok(None);
    }
    const MIN_SIM: f64 = 0.35;
    let best = candidates
        .into_iter()
        .filter(|c| c.bloom_bytes.as_ref().map_or(true, |b| bloom_might_match(b, query_tokens)))
        .filter_map(|candidate| {
            let pat_str = candidate.error_tokens.clone();
            let pat_tokens: Vec<&str> = pat_str.split_whitespace().collect();
            let dot: f64 = query_vec.iter()
                .filter(|t| pat_tokens.iter().any(|p| p == *t))
                .map(|t| { let w = idf(t); w * w })
                .sum();
            let pat_sq: f64 = pat_tokens.iter()
                .filter(|t| query_vec.iter().any(|q| q == *t))
                .map(|t| { let w = idf(t); w * w })
                .sum();
            let pat_norm = pat_sq.sqrt();
            if pat_norm == 0.0 { return None; }
            let sim = dot / (query_norm * pat_norm);
            if sim >= MIN_SIM { Some((sim, candidate)) } else { None }
        })
        .reduce(|(best_sim, best_pat), (sim, pat)| {
            if sim > best_sim { (sim, pat) } else { (best_sim, best_pat) }
        })
        .map(|(_, pat)| pat);
    Ok(best)
}

/// List top autonomous patterns for a project ordered by occurrence_count.
/// Used by session_start to inject hot patterns into context.
pub fn list_hot(conn: &Connection, project_id: i64, limit: usize) -> Result<Vec<GatePattern>> {
    let mut stmt = conn.prepare(
        "SELECT id, project_id, error_tokens, fix_strategy, imperative_rewrite,
                dsa_rationale, tool_name, gate_name, occurrence_count, bloom_bytes, tier
         FROM gate_patterns
         WHERE project_id = ?1 AND tier = 'autonomous'
         ORDER BY occurrence_count DESC
         LIMIT ?2",
    )?;
    let mut patterns = Vec::new();
    let mut rows = stmt.query(params![project_id, limit as i64])?;
    while let Some(row) = rows.next()? {
        patterns.push(from_row(row).map_err(DbError::Sqlite)?);
    }
    Ok(patterns)
}

trait OptionalExt<T> {
    fn optional(self) -> Result<Option<T>>;
}

impl<T> OptionalExt<T> for rusqlite::Result<T> {
    fn optional(self) -> Result<Option<T>> {
        match self {
            Ok(v) => Ok(Some(v)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e.into()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{connection::open_memory, migrate::run_migrations, projects};

    fn setup() -> crate::error::Result<Connection> {
        let conn = open_memory()?;
        run_migrations(&conn)?;
        projects::insert(&conn, "test", "Test")?;
        Ok(conn)
    }

    #[test]
    fn tokenize_deduplicates_and_sorts() {
        let t = tokenize("source .env loads secret values source");
        let tokens: Vec<&str> = t.split_whitespace().collect();
        // Verify sorted: each consecutive pair satisfies a <= b
        assert!(tokens.iter().zip(tokens.iter().skip(1)).all(|(a, b)| a <= b));
        assert_eq!(tokens.iter().filter(|&&t| t == "source").count(), 1);
    }

    #[test]
    fn tokenize_drops_short_words() {
        let t = tokenize("an is to source .env");
        assert!(!t.split_whitespace().any(|w| w.len() < MIN_TOKEN_LEN));
    }

    #[test]
    fn bloom_self_matches() {
        let tokens = tokenize("source env blocked secret values");
        let bloom = bloom_from_tokens(&tokens);
        assert!(bloom_might_match(&bloom, &tokens));
    }

    #[test]
    fn bloom_degenerate_passes_through() {
        assert!(bloom_might_match(&[], "any token here"));
    }

    #[test]
    fn upsert_creates_research_tier() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        let id = upsert(&conn, &UpsertParams {
            project_id: p.id,
            error_tokens: "source .env loads secret values into shell",
            fix_strategy: "Strip source .env && prefix, retry downstream command directly",
            imperative_rewrite: "BLOCKED: source .env — retry with: `<downstream_cmd>`",
            dsa_rationale: "Keyword tokenization; corpus < 50, linear scan O(n) sufficient",
            tool_name: "Bash",
            gate_name: "env_guard",
        })?;
        assert!(id > 0);
        let (tier, count): (String, i64) = conn.query_row(
            "SELECT tier, occurrence_count FROM gate_patterns WHERE id = ?1",
            params![id],
            |r| Ok((r.get(0)?, r.get(1)?)),
        )?;
        assert_eq!(tier, TIER_RESEARCH);
        assert_eq!(count, 1);
        Ok(())
    }

    #[test]
    fn upsert_increments_count() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        let p1 = UpsertParams {
            project_id: p.id,
            error_tokens: "permission denied access forbidden",
            fix_strategy: "Use alternative tool or escalate",
            imperative_rewrite: "BLOCKED: permission denied — try alternative",
            dsa_rationale: "Linear scan; low frequency",
            tool_name: "Bash",
            gate_name: "pre_tool",
        };
        upsert(&conn, &p1)?;
        upsert(&conn, &p1)?;
        let count: i64 = conn.query_row(
            "SELECT occurrence_count FROM gate_patterns WHERE project_id = ?1 LIMIT 1",
            params![p.id],
            |r| r.get(0),
        )?;
        assert_eq!(count, 2);
        Ok(())
    }

    #[test]
    fn find_autonomous_none_for_research_tier() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        upsert(&conn, &UpsertParams {
            project_id: p.id,
            error_tokens: "source env blocked values shell",
            fix_strategy: "strip prefix",
            imperative_rewrite: "BLOCKED: stripped",
            dsa_rationale: "linear",
            tool_name: "Bash",
            gate_name: "env_guard",
        })?;
        let result = find_autonomous(&conn, p.id, "source .env blocked values", "Bash")?;
        assert!(result.is_none());
        Ok(())
    }

    #[test]
    fn list_hot_empty_when_no_autonomous() -> crate::error::Result<()> {
        let conn = setup()?;
        let p = projects::get_by_slug(&conn, "test")?;
        assert!(list_hot(&conn, p.id, 10)?.is_empty());
        Ok(())
    }
}
